"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addLabResults = exports.getLabTestById = exports.createLabTest = exports.getLabTests = void 0;
const lab_test_service_1 = require("../services/lab-test.service");
const lab_test_validation_1 = require("../validation/lab-test.validation");
const errorHandler_1 = require("../middleware/errorHandler");
const AppError_1 = require("../errors/AppError");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
});
const labTestService = new lab_test_service_1.LabTestService(pool);
exports.getLabTests = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const query = lab_test_validation_1.LabTestSearchSchema.parse(req.query);
    const { tests, total } = yield labTestService.searchLabTests(query, tenantId);
    const { page, limit } = query;
    const pages = Math.ceil(total / limit);
    res.json({
        success: true,
        data: {
            tests,
            pagination: {
                page,
                limit,
                total,
                pages,
                has_next: page < pages,
                has_prev: page > 1
            }
        }
    });
}));
exports.createLabTest = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const validatedData = lab_test_validation_1.CreateLabTestSchema.parse(req.body);
    // Convert date strings to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { expected_completion_date: validatedData.expected_completion_date
            ? new Date(validatedData.expected_completion_date)
            : undefined });
    const labTest = yield labTestService.createLabTest(data, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { labTest },
        message: 'Lab test ordered successfully'
    });
}));
exports.getLabTestById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const testId = parseInt(req.params.id);
    if (isNaN(testId)) {
        throw new AppError_1.ValidationError('Invalid lab test ID');
    }
    const labTest = yield labTestService.getLabTestById(testId, tenantId);
    if (!labTest) {
        throw new AppError_1.NotFoundError('Lab test');
    }
    res.json({
        success: true,
        data: { labTest }
    });
}));
exports.addLabResults = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const testId = parseInt(req.params.id);
    const { results } = req.body;
    if (!Array.isArray(results)) {
        throw new AppError_1.ValidationError('Results must be an array');
    }
    for (const result of results) {
        yield labTestService.addLabResult(Object.assign(Object.assign({}, result), { lab_test_id: testId }), tenantId);
    }
    const labTest = yield labTestService.getLabTestById(testId, tenantId);
    res.json({
        success: true,
        data: { labTest },
        message: 'Lab results added successfully'
    });
}));
