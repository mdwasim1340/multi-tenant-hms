"use strict";
/**
 * Authorization Middleware
 * Enforces application-level access control
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireRole = exports.requirePermission = exports.requireApplicationAccess = void 0;
const authorization_1 = require("../services/authorization");
/**
 * Application access middleware
 * Checks if user can access the requesting application
 */
const requireApplicationAccess = (applicationId) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            // Skip for auth endpoints
            if (req.path.startsWith('/auth/')) {
                return next();
            }
            // Get user ID from request (set by auth middleware)
            const userId = req.userId;
            if (!userId) {
                return res.status(401).json({
                    error: 'Authentication required',
                    message: 'Please login to access this application'
                });
            }
            // Check application access
            const hasAccess = yield (0, authorization_1.canUserAccessApplication)(userId, applicationId);
            if (!hasAccess) {
                return res.status(403).json({
                    error: 'Access denied',
                    message: `You don't have permission to access ${applicationId}`,
                    application: applicationId,
                    user_id: userId
                });
            }
            // Add permission helpers to request
            req.permissions = {
                canAccess: (resource, action) => __awaiter(void 0, void 0, void 0, function* () {
                    return yield (0, authorization_1.checkUserPermission)(userId, resource, action);
                }),
                canAccessApp: (appId) => __awaiter(void 0, void 0, void 0, function* () {
                    return yield (0, authorization_1.canUserAccessApplication)(userId, appId);
                })
            };
            next();
        }
        catch (error) {
            console.error('Authorization middleware error:', error);
            res.status(500).json({
                error: 'Authorization check failed',
                message: 'Internal server error during authorization'
            });
        }
    });
};
exports.requireApplicationAccess = requireApplicationAccess;
/**
 * Permission-based middleware
 * Checks if user has specific permission
 */
const requirePermission = (resource, action) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            const userId = req.userId;
            if (!userId) {
                return res.status(401).json({
                    error: 'Authentication required',
                    message: 'Please login to access this resource'
                });
            }
            const hasPermission = yield (0, authorization_1.checkUserPermission)(userId, resource, action);
            if (!hasPermission) {
                return res.status(403).json({
                    error: 'Permission denied',
                    message: `You don't have permission to ${action} ${resource}`,
                    required_permission: `${resource}:${action}`
                });
            }
            next();
        }
        catch (error) {
            console.error('Permission check error:', error);
            res.status(500).json({
                error: 'Permission check failed',
                message: 'Internal server error during permission check'
            });
        }
    });
};
exports.requirePermission = requirePermission;
/**
 * Role-based middleware
 * Checks if user has specific role
 */
const requireRole = (roleName) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        try {
            const userId = req.userId;
            if (!userId) {
                return res.status(401).json({
                    error: 'Authentication required',
                    message: 'Please login to access this resource'
                });
            }
            // Check if user has the required role
            const query = `
        SELECT EXISTS(
          SELECT 1
          FROM user_roles ur
          JOIN roles r ON ur.role_id = r.id
          WHERE ur.user_id = $1 AND r.name = $2
        ) as has_role
      `;
            const pool = require('../database').default;
            const result = yield pool.query(query, [userId, roleName]);
            const hasRole = ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.has_role) || false;
            if (!hasRole) {
                return res.status(403).json({
                    error: 'Role required',
                    message: `You must have the '${roleName}' role to access this resource`,
                    required_role: roleName
                });
            }
            next();
        }
        catch (error) {
            console.error('Role check error:', error);
            res.status(500).json({
                error: 'Role check failed',
                message: 'Internal server error during role check'
            });
        }
    });
};
exports.requireRole = requireRole;
