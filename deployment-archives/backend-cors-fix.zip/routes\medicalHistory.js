"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMedicalHistoryRouter = void 0;
const express_1 = require("express");
const medicalHistory_controller_1 = require("../controllers/medicalHistory.controller");
const createMedicalHistoryRouter = () => {
    const router = (0, express_1.Router)();
    // Medical history CRUD
    router.post('/', medicalHistory_controller_1.createMedicalHistory);
    // Get critical allergies (MUST be before /patient/:patientId to avoid route conflict)
    router.get('/patient/:patientId/critical-allergies', medicalHistory_controller_1.getCriticalAllergies);
    // Get patient summary (MUST be before /patient/:patientId to avoid route conflict)
    router.get('/patient/:patientId/summary', medicalHistory_controller_1.getPatientSummary);
    // Get patient medical history (more general route, must come after specific routes)
    router.get('/patient/:patientId', medicalHistory_controller_1.getPatientMedicalHistory);
    // Single entry operations
    router.get('/:id', medicalHistory_controller_1.getMedicalHistory);
    router.put('/:id', medicalHistory_controller_1.updateMedicalHistory);
    router.delete('/:id', medicalHistory_controller_1.deleteMedicalHistory);
    return router;
};
exports.createMedicalHistoryRouter = createMedicalHistoryRouter;
