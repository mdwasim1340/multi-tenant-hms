"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const zod_1 = require("zod");
const bed_status_tracker_1 = require("../services/bed-status-tracker");
const bedStatusTracker = new bed_status_tracker_1.BedStatusTracker();
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const router = express_1.default.Router();
// Apply middleware to all routes
router.use(auth_1.authMiddleware);
router.use(tenant_1.tenantMiddleware);
/**
 * Zod Schemas for Request Validation
 */
const BedStatusUpdateSchema = zod_1.z.object({
    status: zod_1.z.enum(['available', 'occupied', 'cleaning', 'maintenance', 'reserved']),
    cleaning_status: zod_1.z.enum(['clean', 'dirty', 'in_progress']).optional(),
    notes: zod_1.z.string().optional()
});
const HousekeepingAlertSchema = zod_1.z.object({
    bed_id: zod_1.z.number().int().positive(),
    priority: zod_1.z.enum(['stat', 'high', 'normal', 'low']),
    reason: zod_1.z.string().min(1)
});
const TurnoverMetricsSchema = zod_1.z.object({
    start_date: zod_1.z.string().datetime().optional(),
    end_date: zod_1.z.string().datetime().optional()
});
/**
 * GET /api/bed-management/status/:unit
 * Get real-time bed status for a unit
 */
router.get('/status/:unit', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const unitId = req.params.unit === 'all' ? undefined : parseInt(req.params.unit);
        const status = yield bedStatusTracker.getBedStatus(tenantId, unitId);
        res.json(Object.assign({ success: true }, status));
    }
    catch (error) {
        console.error('Error fetching bed status:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch bed status'
        });
    }
}));
/**
 * PUT /api/bed-management/status/:bedId
 * Update bed status
 */
router.put('/status/:bedId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.bedId);
        const data = BedStatusUpdateSchema.parse(req.body);
        const updatedBed = yield bedStatusTracker.updateBedStatus(tenantId, bedId, data.status, data.cleaning_status, data.notes);
        res.json({
            success: true,
            bed: updatedBed,
            message: 'Bed status updated successfully'
        });
    }
    catch (error) {
        console.error('Error updating bed status:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to update bed status'
        });
    }
}));
/**
 * GET /api/bed-management/cleaning-priority
 * Get prioritized list of beds needing cleaning
 */
router.get('/cleaning-priority', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prioritizedBeds = yield bedStatusTracker.prioritizeCleaning(tenantId);
        res.json({
            success: true,
            beds: prioritizedBeds,
            count: prioritizedBeds.length,
            stat_count: prioritizedBeds.filter((b) => b.cleaning_priority === 'stat').length,
            overdue_count: prioritizedBeds.filter((b) => b.is_overdue).length
        });
    }
    catch (error) {
        console.error('Error fetching cleaning priorities:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch cleaning priorities'
        });
    }
}));
/**
 * GET /api/bed-management/turnover-metrics
 * Get bed turnover metrics
 */
router.get('/turnover-metrics', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const startDate = req.query.start_date
            ? new Date(req.query.start_date)
            : undefined;
        const endDate = req.query.end_date
            ? new Date(req.query.end_date)
            : undefined;
        const metrics = yield bedStatusTracker.getTurnoverMetrics(tenantId, startDate, endDate);
        res.json({
            success: true,
            metrics
        });
    }
    catch (error) {
        console.error('Error fetching turnover metrics:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch turnover metrics'
        });
    }
}));
/**
 * POST /api/bed-management/alert-housekeeping
 * Alert housekeeping for expedited cleaning
 */
router.post('/alert-housekeeping', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const data = HousekeepingAlertSchema.parse(req.body);
        yield bedStatusTracker.alertHousekeeping(tenantId, data.bed_id, data.priority, data.reason);
        res.json({
            success: true,
            message: 'Housekeeping alert sent successfully'
        });
    }
    catch (error) {
        console.error('Error sending housekeeping alert:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to send housekeeping alert'
        });
    }
}));
/**
 * GET /api/bed-management/status-summary
 * Get summary of bed status across all units
 */
router.get('/status-summary', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const status = yield bedStatusTracker.getBedStatus(tenantId);
        res.json({
            success: true,
            summary: status.summary,
            beds_by_unit: status.beds_by_unit.map((unit) => ({
                unit_id: unit.unit_id,
                unit_name: unit.unit_name,
                summary: unit.summary
            })),
            timestamp: status.timestamp
        });
    }
    catch (error) {
        console.error('Error fetching status summary:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch status summary'
        });
    }
}));
exports.default = router;
