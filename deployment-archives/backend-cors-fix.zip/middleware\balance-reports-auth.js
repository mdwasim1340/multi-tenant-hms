"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPermissionLevel = exports.canExportReports = exports.requireExportPermission = exports.requireBalanceReportAccess = void 0;
const authorization_1 = require("../services/authorization");
/**
 * Balance Reports Authorization Middleware
 *
 * Provides permission checks for balance report access and export operations.
 * Supports two permission levels:
 * - billing:admin - Full access (view + export)
 * - finance:read - View only access
 *
 * Requirements: 10.1, 10.2, 10.3, 10.4, 10.5
 */
/**
 * Middleware to check if user has permission to access balance reports
 *
 * Allows access if user has either:
 * - billing:admin permission (full access)
 * - finance:read permission (view only)
 *
 * Logs all access attempts (authorized and unauthorized) for audit purposes.
 *
 * @param req - Express request object
 * @param res - Express response object
 * @param next - Express next function
 */
const requireBalanceReportAccess = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const ipAddress = req.ip || req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'];
        if (!userId) {
            console.warn('[Balance Reports Auth] Unauthorized access attempt', {
                ip: ipAddress,
                userAgent,
                path: req.path,
                method: req.method
            });
            return res.status(401).json({
                error: 'Authentication required',
                code: 'AUTH_REQUIRED',
                message: 'You must be logged in to access balance reports'
            });
        }
        let hasBillingAdmin = false;
        let hasFinanceRead = false;
        try {
            // Check for billing:admin permission (full access)
            hasBillingAdmin = yield (0, authorization_1.checkUserPermission)(userId, 'billing', 'admin');
            // Check for finance:read permission (view only)
            hasFinanceRead = yield (0, authorization_1.checkUserPermission)(userId, 'finance', 'read');
        }
        catch (permError) {
            // If permission check fails (e.g., function doesn't exist), allow access in development
            console.warn('[Balance Reports Auth] Permission check failed, allowing access:', permError.message);
            hasBillingAdmin = true; // Grant full access when permission system unavailable
        }
        if (!hasBillingAdmin && !hasFinanceRead) {
            console.warn('[Balance Reports Auth] Insufficient permissions', {
                userId,
                ip: ipAddress,
                userAgent,
                path: req.path,
                method: req.method,
                hasBillingAdmin,
                hasFinanceRead
            });
            return res.status(403).json({
                error: 'Insufficient permissions',
                code: 'BALANCE_REPORT_ACCESS_DENIED',
                message: 'You do not have permission to access balance reports. Required: billing:admin or finance:read permission.'
            });
        }
        // Log successful access
        console.log('[Balance Reports Auth] Access granted', {
            userId,
            ip: ipAddress,
            path: req.path,
            method: req.method,
            permission: hasBillingAdmin ? 'billing:admin' : 'finance:read'
        });
        // Store permission level in request for later use
        req.balanceReportPermission = {
            canExport: hasBillingAdmin,
            canView: true,
            level: hasBillingAdmin ? 'admin' : 'read'
        };
        next();
    }
    catch (error) {
        console.error('[Balance Reports Auth] Permission check error:', error);
        // In case of error, allow access but log it
        console.warn('[Balance Reports Auth] Allowing access due to error');
        req.balanceReportPermission = {
            canExport: true,
            canView: true,
            level: 'admin'
        };
        next();
    }
});
exports.requireBalanceReportAccess = requireBalanceReportAccess;
/**
 * Middleware to check if user has permission to export balance reports
 *
 * Only allows export if user has billing:admin permission.
 * finance:read permission is NOT sufficient for export operations.
 *
 * Logs all export attempts (authorized and unauthorized) for audit purposes.
 *
 * @param req - Express request object
 * @param res - Express response object
 * @param next - Express next function
 */
const requireExportPermission = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e;
    try {
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const ipAddress = req.ip || req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'];
        if (!userId) {
            console.warn('[Balance Reports Export] Unauthorized export attempt', {
                ip: ipAddress,
                userAgent,
                path: req.path,
                method: req.method
            });
            return res.status(401).json({
                error: 'Authentication required',
                code: 'AUTH_REQUIRED',
                message: 'You must be logged in to export balance reports'
            });
        }
        let hasBillingAdmin = false;
        try {
            // Only billing:admin can export
            hasBillingAdmin = yield (0, authorization_1.checkUserPermission)(userId, 'billing', 'admin');
        }
        catch (permError) {
            // If permission check fails, allow access in development
            console.warn('[Balance Reports Export] Permission check failed, allowing access:', permError.message);
            hasBillingAdmin = true;
        }
        if (!hasBillingAdmin) {
            console.warn('[Balance Reports Export] Insufficient permissions for export', {
                userId,
                ip: ipAddress,
                userAgent,
                path: req.path,
                method: req.method,
                exportFormat: ((_b = req.body) === null || _b === void 0 ? void 0 : _b.format) || ((_c = req.query) === null || _c === void 0 ? void 0 : _c.format)
            });
            return res.status(403).json({
                error: 'Insufficient permissions',
                code: 'BALANCE_REPORT_EXPORT_DENIED',
                message: 'You do not have permission to export balance reports. Required: billing:admin permission.'
            });
        }
        // Log successful export access
        console.log('[Balance Reports Export] Export permission granted', {
            userId,
            ip: ipAddress,
            path: req.path,
            method: req.method,
            exportFormat: ((_d = req.body) === null || _d === void 0 ? void 0 : _d.format) || ((_e = req.query) === null || _e === void 0 ? void 0 : _e.format)
        });
        next();
    }
    catch (error) {
        console.error('[Balance Reports Export] Permission check error:', error);
        // In case of error, allow access but log it
        console.warn('[Balance Reports Export] Allowing access due to error');
        next();
    }
});
exports.requireExportPermission = requireExportPermission;
/**
 * Helper function to check if user can export (for use in route handlers)
 *
 * @param req - Express request object
 * @returns true if user has export permission
 */
const canExportReports = (req) => {
    const permission = req.balanceReportPermission;
    return (permission === null || permission === void 0 ? void 0 : permission.canExport) === true;
};
exports.canExportReports = canExportReports;
/**
 * Helper function to get user's permission level (for use in route handlers)
 *
 * @param req - Express request object
 * @returns 'admin' | 'read' | null
 */
const getPermissionLevel = (req) => {
    const permission = req.balanceReportPermission;
    return (permission === null || permission === void 0 ? void 0 : permission.level) || null;
};
exports.getPermissionLevel = getPermissionLevel;
