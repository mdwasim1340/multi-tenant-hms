"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateBody = exports.validateQuery = exports.validate = void 0;
const zod_1 = require("zod");
/**
 * Validation Middleware for Balance Reports
 *
 * Provides middleware functions to validate request query parameters and body
 * using Zod schemas. Returns consistent error responses for validation failures.
 *
 * Requirements: 4.3, 14.1
 */
/**
 * Generic validation middleware factory
 *
 * Creates a middleware function that validates request data against a Zod schema.
 * Supports validation of query parameters or request body.
 *
 * @param schema - Zod schema to validate against
 * @param source - Source of data to validate ('query' or 'body')
 * @returns Express middleware function
 */
const validate = (schema, source = 'query') => {
    return (req, res, next) => {
        try {
            // Get data from specified source
            const data = source === 'query' ? req.query : req.body;
            // Validate data against schema
            const validated = schema.parse(data);
            // Store validated data in request object (don't replace req.query as it's read-only in Express 5)
            if (source === 'query') {
                req.validatedQuery = validated;
            }
            else {
                req.validatedBody = validated;
            }
            next();
        }
        catch (error) {
            if (error instanceof zod_1.ZodError) {
                // Format Zod validation errors
                const errors = error.issues.map((err) => ({
                    field: err.path.join('.'),
                    message: err.message,
                    code: err.code
                }));
                return res.status(400).json({
                    error: 'Validation failed',
                    code: 'VALIDATION_ERROR',
                    message: 'Request validation failed. Please check your input.',
                    details: errors
                });
            }
            // Handle unexpected errors
            console.error('[Validation] Unexpected error:', error);
            return res.status(500).json({
                error: 'Validation error',
                code: 'VALIDATION_SYSTEM_ERROR',
                message: 'An error occurred during validation'
            });
        }
    };
};
exports.validate = validate;
/**
 * Validation middleware for query parameters
 *
 * Convenience wrapper for validating query parameters.
 *
 * @param schema - Zod schema to validate against
 * @returns Express middleware function
 */
const validateQuery = (schema) => {
    return (0, exports.validate)(schema, 'query');
};
exports.validateQuery = validateQuery;
/**
 * Validation middleware for request body
 *
 * Convenience wrapper for validating request body.
 *
 * @param schema - Zod schema to validate against
 * @returns Express middleware function
 */
const validateBody = (schema) => {
    return (0, exports.validate)(schema, 'body');
};
exports.validateBody = validateBody;
