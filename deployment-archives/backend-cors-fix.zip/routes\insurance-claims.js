"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = require("../middleware/auth");
const billing_auth_1 = require("../middleware/billing-auth");
const database_1 = __importDefault(require("../database"));
const router = express_1.default.Router();
// Create insurance claim
router.post('/', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenant_id, patient_id, invoice_id, insurance_provider, policy_number, claim_amount, submission_date, documents, notes } = req.body;
        if (!tenant_id || !patient_id || !insurance_provider || !policy_number || !claim_amount) {
            return res.status(400).json({
                error: 'Missing required fields',
                code: 'MISSING_REQUIRED_FIELDS'
            });
        }
        // Generate unique claim number
        const claim_number = `CLM-${Date.now()}-${tenant_id.slice(-6)}`;
        const result = yield database_1.default.query(`
      INSERT INTO insurance_claims (
        tenant_id, patient_id, invoice_id, claim_number,
        insurance_provider, policy_number, claim_amount,
        status, submission_date, documents, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `, [
            tenant_id,
            patient_id,
            invoice_id || null,
            claim_number,
            insurance_provider,
            policy_number,
            claim_amount,
            'submitted',
            submission_date || new Date(),
            JSON.stringify(documents || []),
            notes || null
        ]);
        res.json({
            success: true,
            message: 'Insurance claim created successfully',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error creating insurance claim:', error);
        res.status(500).json({
            error: error.message || 'Failed to create insurance claim',
            code: 'CREATE_CLAIM_ERROR'
        });
    }
}));
// Get all insurance claims for tenant
router.get('/', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingRead, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { status, patient_id, insurance_provider, limit = 50, offset = 0 } = req.query;
        let query = 'SELECT * FROM insurance_claims WHERE tenant_id = $1';
        const params = [tenantId];
        let paramIndex = 2;
        if (status) {
            query += ` AND status = $${paramIndex}`;
            params.push(status);
            paramIndex++;
        }
        if (patient_id) {
            query += ` AND patient_id = $${paramIndex}`;
            params.push(patient_id);
            paramIndex++;
        }
        if (insurance_provider) {
            query += ` AND insurance_provider ILIKE $${paramIndex}`;
            params.push(`%${insurance_provider}%`);
            paramIndex++;
        }
        query += ` ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
        params.push(parseInt(limit), parseInt(offset));
        const result = yield database_1.default.query(query, params);
        res.json({
            success: true,
            claims: result.rows,
            pagination: {
                limit: parseInt(limit),
                offset: parseInt(offset),
                total: result.rows.length
            }
        });
    }
    catch (error) {
        console.error('Error fetching insurance claims:', error);
        res.status(500).json({
            error: error.message || 'Failed to fetch insurance claims',
            code: 'FETCH_CLAIMS_ERROR'
        });
    }
}));
// Get insurance claim by ID
router.get('/:claimId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingRead, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const result = yield database_1.default.query('SELECT * FROM insurance_claims WHERE id = $1 AND tenant_id = $2', [claimId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found',
                code: 'CLAIM_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error fetching insurance claim:', error);
        res.status(500).json({
            error: error.message || 'Failed to fetch insurance claim',
            code: 'FETCH_CLAIM_ERROR'
        });
    }
}));
// Update insurance claim
router.put('/:claimId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { insurance_provider, policy_number, claim_amount, notes, documents } = req.body;
        const result = yield database_1.default.query(`
      UPDATE insurance_claims
      SET insurance_provider = COALESCE($1, insurance_provider),
          policy_number = COALESCE($2, policy_number),
          claim_amount = COALESCE($3, claim_amount),
          notes = COALESCE($4, notes),
          documents = COALESCE($5, documents),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $6 AND tenant_id = $7
      RETURNING *
    `, [
            insurance_provider,
            policy_number,
            claim_amount,
            notes,
            documents ? JSON.stringify(documents) : null,
            claimId,
            tenantId
        ]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found',
                code: 'CLAIM_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            message: 'Insurance claim updated successfully',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error updating insurance claim:', error);
        res.status(500).json({
            error: error.message || 'Failed to update insurance claim',
            code: 'UPDATE_CLAIM_ERROR'
        });
    }
}));
// Approve insurance claim
router.post('/:claimId/approve', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { approved_amount } = req.body;
        if (!approved_amount) {
            return res.status(400).json({
                error: 'Missing required field: approved_amount',
                code: 'MISSING_APPROVED_AMOUNT'
            });
        }
        const result = yield database_1.default.query(`
      UPDATE insurance_claims
      SET status = 'approved',
          approved_amount = $1,
          approval_date = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $2 AND tenant_id = $3
      RETURNING *
    `, [approved_amount, claimId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found',
                code: 'CLAIM_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            message: 'Insurance claim approved successfully',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error approving insurance claim:', error);
        res.status(500).json({
            error: error.message || 'Failed to approve insurance claim',
            code: 'APPROVE_CLAIM_ERROR'
        });
    }
}));
// Reject insurance claim
router.post('/:claimId/reject', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { rejection_reason } = req.body;
        if (!rejection_reason) {
            return res.status(400).json({
                error: 'Missing required field: rejection_reason',
                code: 'MISSING_REJECTION_REASON'
            });
        }
        const result = yield database_1.default.query(`
      UPDATE insurance_claims
      SET status = 'rejected',
          rejection_reason = $1,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $2 AND tenant_id = $3
      RETURNING *
    `, [rejection_reason, claimId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found',
                code: 'CLAIM_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            message: 'Insurance claim rejected',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error rejecting insurance claim:', error);
        res.status(500).json({
            error: error.message || 'Failed to reject insurance claim',
            code: 'REJECT_CLAIM_ERROR'
        });
    }
}));
// Mark claim as paid
router.post('/:claimId/mark-paid', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const result = yield database_1.default.query(`
      UPDATE insurance_claims
      SET status = 'paid',
          payment_date = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2 AND status = 'approved'
      RETURNING *
    `, [claimId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found or not approved',
                code: 'CLAIM_NOT_FOUND_OR_NOT_APPROVED'
            });
        }
        res.json({
            success: true,
            message: 'Insurance claim marked as paid',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error marking claim as paid:', error);
        res.status(500).json({
            error: error.message || 'Failed to mark claim as paid',
            code: 'MARK_PAID_ERROR'
        });
    }
}));
// Upload documents to claim
router.post('/:claimId/documents', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { claimId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { documents } = req.body;
        if (!documents || !Array.isArray(documents)) {
            return res.status(400).json({
                error: 'Invalid documents array',
                code: 'INVALID_DOCUMENTS'
            });
        }
        // Get existing documents
        const claimResult = yield database_1.default.query('SELECT documents FROM insurance_claims WHERE id = $1 AND tenant_id = $2', [claimId, tenantId]);
        if (claimResult.rows.length === 0) {
            return res.status(404).json({
                error: 'Insurance claim not found',
                code: 'CLAIM_NOT_FOUND'
            });
        }
        const existingDocs = claimResult.rows[0].documents || [];
        const updatedDocs = [...existingDocs, ...documents];
        const result = yield database_1.default.query(`
      UPDATE insurance_claims
      SET documents = $1,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $2 AND tenant_id = $3
      RETURNING *
    `, [JSON.stringify(updatedDocs), claimId, tenantId]);
        res.json({
            success: true,
            message: 'Documents uploaded successfully',
            claim: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error uploading documents:', error);
        res.status(500).json({
            error: error.message || 'Failed to upload documents',
            code: 'UPLOAD_DOCUMENTS_ERROR'
        });
    }
}));
exports.default = router;
