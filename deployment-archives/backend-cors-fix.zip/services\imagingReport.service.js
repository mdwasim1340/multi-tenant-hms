"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImagingReportService = void 0;
class ImagingReportService {
    constructor(pool) {
        this.pool = pool;
    }
    createReport(tenantId, data, createdBy) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Create table if not exists
                yield client.query(`
        CREATE TABLE IF NOT EXISTS imaging_reports (
          id SERIAL PRIMARY KEY,
          patient_id INTEGER NOT NULL,
          imaging_type VARCHAR(100) NOT NULL,
          body_part VARCHAR(100),
          radiologist_id INTEGER,
          findings TEXT NOT NULL,
          impression TEXT,
          recommendations TEXT,
          report_date DATE,
          study_date DATE,
          modality VARCHAR(50),
          contrast_used BOOLEAN DEFAULT false,
          status VARCHAR(20) DEFAULT 'pending',
          created_by INTEGER,
          updated_by INTEGER,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
                const result = yield client.query(`INSERT INTO imaging_reports (
          patient_id, imaging_type, body_part, radiologist_id,
          findings, impression, report_date, study_date, modality, contrast_used, status, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *`, [
                    data.patient_id,
                    data.imaging_type,
                    data.body_part || null,
                    data.radiologist_id,
                    data.findings,
                    data.impression || null,
                    data.report_date,
                    data.study_date || null,
                    data.modality || null,
                    data.contrast_used || false,
                    'pending',
                    createdBy,
                ]);
                return result.rows[0];
            }
            finally {
                client.release();
            }
        });
    }
    getReportById(tenantId, reportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT * FROM imaging_reports WHERE id = $1`, [reportId]);
                return result.rows[0] || null;
            }
            finally {
                client.release();
            }
        });
    }
    getReports(tenantId, filters) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check if imaging_reports table exists
                const tableCheck = yield client.query(`SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = $1 AND table_name = 'imaging_reports'
        )`, [tenantId]);
                if (!tableCheck.rows[0].exists) {
                    return { reports: [], total: 0 };
                }
                const whereConditions = ['1=1'];
                const queryParams = [];
                let paramIndex = 1;
                if (filters === null || filters === void 0 ? void 0 : filters.patient_id) {
                    whereConditions.push(`patient_id = $${paramIndex}`);
                    queryParams.push(filters.patient_id);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.imaging_type) {
                    whereConditions.push(`imaging_type = $${paramIndex}`);
                    queryParams.push(filters.imaging_type);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.body_part) {
                    whereConditions.push(`body_part ILIKE $${paramIndex}`);
                    queryParams.push(`%${filters.body_part}%`);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.status) {
                    whereConditions.push(`status = $${paramIndex}`);
                    queryParams.push(filters.status);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_from) {
                    whereConditions.push(`created_at >= $${paramIndex}`);
                    queryParams.push(filters.date_from);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_to) {
                    whereConditions.push(`created_at <= $${paramIndex}`);
                    queryParams.push(filters.date_to);
                    paramIndex++;
                }
                const whereClause = whereConditions.join(' AND ');
                // Get total count
                const countResult = yield client.query(`SELECT COUNT(*) FROM imaging_reports WHERE ${whereClause}`, queryParams);
                // Get paginated results
                const page = (filters === null || filters === void 0 ? void 0 : filters.page) || 1;
                const limit = (filters === null || filters === void 0 ? void 0 : filters.limit) || 10;
                const offset = (page - 1) * limit;
                const result = yield client.query(`SELECT * FROM imaging_reports 
         WHERE ${whereClause}
         ORDER BY created_at DESC
         LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...queryParams, limit, offset]);
                return {
                    reports: result.rows,
                    total: parseInt(countResult.rows[0].count),
                };
            }
            catch (error) {
                console.error('Error in getReports:', error);
                return { reports: [], total: 0 };
            }
            finally {
                client.release();
            }
        });
    }
    getReportsByPatient(tenantId, patientId, filters) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check if imaging_reports table exists
                const tableCheck = yield client.query(`SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = $1 AND table_name = 'imaging_reports'
        )`, [tenantId]);
                if (!tableCheck.rows[0].exists) {
                    return { reports: [], total: 0 };
                }
                const whereConditions = ['patient_id = $1'];
                const queryParams = [patientId];
                let paramIndex = 2;
                if (filters === null || filters === void 0 ? void 0 : filters.imaging_type) {
                    whereConditions.push(`imaging_type = $${paramIndex}`);
                    queryParams.push(filters.imaging_type);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.body_part) {
                    whereConditions.push(`body_part ILIKE $${paramIndex}`);
                    queryParams.push(`%${filters.body_part}%`);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.status) {
                    whereConditions.push(`status = $${paramIndex}`);
                    queryParams.push(filters.status);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_from) {
                    whereConditions.push(`created_at >= $${paramIndex}`);
                    queryParams.push(filters.date_from);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_to) {
                    whereConditions.push(`created_at <= $${paramIndex}`);
                    queryParams.push(filters.date_to);
                    paramIndex++;
                }
                const whereClause = whereConditions.join(' AND ');
                // Get total count
                const countResult = yield client.query(`SELECT COUNT(*) FROM imaging_reports WHERE ${whereClause}`, queryParams);
                // Get paginated results
                const page = (filters === null || filters === void 0 ? void 0 : filters.page) || 1;
                const limit = (filters === null || filters === void 0 ? void 0 : filters.limit) || 10;
                const offset = (page - 1) * limit;
                const result = yield client.query(`SELECT * FROM imaging_reports 
         WHERE ${whereClause}
         ORDER BY created_at DESC
         LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...queryParams, limit, offset]);
                return {
                    reports: result.rows,
                    total: parseInt(countResult.rows[0].count),
                };
            }
            catch (error) {
                console.error('Error in getReportsByPatient:', error);
                return { reports: [], total: 0 };
            }
            finally {
                client.release();
            }
        });
    }
    updateReport(tenantId, reportId, data, updatedBy) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const updateFields = [];
                const queryParams = [];
                let paramIndex = 1;
                if (data.imaging_type !== undefined) {
                    updateFields.push(`imaging_type = $${paramIndex}`);
                    queryParams.push(data.imaging_type);
                    paramIndex++;
                }
                if (data.body_part !== undefined) {
                    updateFields.push(`body_part = $${paramIndex}`);
                    queryParams.push(data.body_part);
                    paramIndex++;
                }
                if (data.radiologist_id !== undefined) {
                    updateFields.push(`radiologist_id = $${paramIndex}`);
                    queryParams.push(data.radiologist_id);
                    paramIndex++;
                }
                if (data.findings !== undefined) {
                    updateFields.push(`findings = $${paramIndex}`);
                    queryParams.push(data.findings);
                    paramIndex++;
                }
                if (data.impression !== undefined) {
                    updateFields.push(`impression = $${paramIndex}`);
                    queryParams.push(data.impression);
                    paramIndex++;
                }
                if (data.recommendations !== undefined) {
                    updateFields.push(`recommendations = $${paramIndex}`);
                    queryParams.push(data.recommendations);
                    paramIndex++;
                }
                if (data.status !== undefined) {
                    updateFields.push(`status = $${paramIndex}`);
                    queryParams.push(data.status);
                    paramIndex++;
                }
                updateFields.push(`updated_by = $${paramIndex}`);
                queryParams.push(updatedBy);
                paramIndex++;
                updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
                queryParams.push(reportId);
                const result = yield client.query(`UPDATE imaging_reports 
         SET ${updateFields.join(', ')}
         WHERE id = $${paramIndex}
         RETURNING *`, queryParams);
                return result.rows[0] || null;
            }
            finally {
                client.release();
            }
        });
    }
    deleteReport(tenantId, reportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Delete associated files first (ignore if table doesn't exist)
                try {
                    yield client.query(`DELETE FROM imaging_report_files WHERE report_id = $1`, [reportId]);
                }
                catch (_a) {
                    // Table may not exist
                }
                const result = yield client.query(`DELETE FROM imaging_reports WHERE id = $1`, [reportId]);
                return result.rowCount !== null && result.rowCount > 0;
            }
            finally {
                client.release();
            }
        });
    }
    // File operations
    addReportFile(tenantId, reportId, fileData, uploadedBy) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`INSERT INTO imaging_report_files (
          report_id, file_name, file_type, file_size,
          s3_key, s3_url, uploaded_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *`, [
                    reportId,
                    fileData.file_name,
                    fileData.file_type,
                    fileData.file_size,
                    fileData.s3_key,
                    fileData.s3_url,
                    uploadedBy,
                ]);
                return result.rows[0];
            }
            finally {
                client.release();
            }
        });
    }
    getReportFiles(tenantId, reportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT * FROM imaging_report_files 
         WHERE report_id = $1
         ORDER BY uploaded_at DESC`, [reportId]);
                return result.rows;
            }
            catch (_a) {
                return [];
            }
            finally {
                client.release();
            }
        });
    }
    deleteReportFile(tenantId, fileId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`DELETE FROM imaging_report_files WHERE id = $1`, [fileId]);
                return result.rowCount !== null && result.rowCount > 0;
            }
            finally {
                client.release();
            }
        });
    }
    searchReports(tenantId, searchTerm, filters) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check if imaging_reports table exists
                const tableCheck = yield client.query(`SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = $1 AND table_name = 'imaging_reports'
        )`, [tenantId]);
                if (!tableCheck.rows[0].exists) {
                    return { reports: [], total: 0 };
                }
                const whereConditions = [
                    `(findings ILIKE $1 OR impression ILIKE $1 OR body_part ILIKE $1)`,
                ];
                const queryParams = [`%${searchTerm}%`];
                let paramIndex = 2;
                if (filters === null || filters === void 0 ? void 0 : filters.imaging_type) {
                    whereConditions.push(`imaging_type = $${paramIndex}`);
                    queryParams.push(filters.imaging_type);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.status) {
                    whereConditions.push(`status = $${paramIndex}`);
                    queryParams.push(filters.status);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_from) {
                    whereConditions.push(`created_at >= $${paramIndex}`);
                    queryParams.push(filters.date_from);
                    paramIndex++;
                }
                if (filters === null || filters === void 0 ? void 0 : filters.date_to) {
                    whereConditions.push(`created_at <= $${paramIndex}`);
                    queryParams.push(filters.date_to);
                    paramIndex++;
                }
                const whereClause = whereConditions.join(' AND ');
                // Get total count
                const countResult = yield client.query(`SELECT COUNT(*) FROM imaging_reports WHERE ${whereClause}`, queryParams);
                // Get paginated results
                const page = (filters === null || filters === void 0 ? void 0 : filters.page) || 1;
                const limit = (filters === null || filters === void 0 ? void 0 : filters.limit) || 10;
                const offset = (page - 1) * limit;
                const result = yield client.query(`SELECT * FROM imaging_reports 
         WHERE ${whereClause}
         ORDER BY created_at DESC
         LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...queryParams, limit, offset]);
                return {
                    reports: result.rows,
                    total: parseInt(countResult.rows[0].count),
                };
            }
            catch (error) {
                console.error('Error in searchReports:', error);
                return { reports: [], total: 0 };
            }
            finally {
                client.release();
            }
        });
    }
}
exports.ImagingReportService = ImagingReportService;
