"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabTestSearchSchema = exports.CreateImagingStudySchema = exports.CreateLabResultSchema = exports.CreateLabTestSchema = void 0;
const zod_1 = require("zod");
exports.CreateLabTestSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    medical_record_id: zod_1.z.number().int().positive().optional(),
    appointment_id: zod_1.z.number().int().positive().optional(),
    ordered_by: zod_1.z.number().int().positive(),
    test_type: zod_1.z.string().min(1).max(100),
    test_code: zod_1.z.string().max(50).optional(),
    test_name: zod_1.z.string().min(1).max(255),
    panel_id: zod_1.z.number().int().positive().optional(),
    priority: zod_1.z.enum(['routine', 'urgent', 'stat']).optional(),
    clinical_indication: zod_1.z.string().optional(),
    specimen_type: zod_1.z.string().max(100).optional(),
    expected_completion_date: zod_1.z.string().datetime().optional(),
    notes: zod_1.z.string().optional()
});
exports.CreateLabResultSchema = zod_1.z.object({
    lab_test_id: zod_1.z.number().int().positive(),
    result_code: zod_1.z.string().max(50).optional(),
    result_name: zod_1.z.string().min(1).max(255),
    result_value: zod_1.z.string().max(500).optional(),
    result_unit: zod_1.z.string().max(50).optional(),
    reference_range_low: zod_1.z.string().max(50).optional(),
    reference_range_high: zod_1.z.string().max(50).optional(),
    reference_range_text: zod_1.z.string().max(255).optional(),
    interpretation: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional()
});
exports.CreateImagingStudySchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    medical_record_id: zod_1.z.number().int().positive().optional(),
    appointment_id: zod_1.z.number().int().positive().optional(),
    ordered_by: zod_1.z.number().int().positive(),
    study_type: zod_1.z.string().min(1).max(100),
    body_part: zod_1.z.string().min(1).max(100),
    modality: zod_1.z.string().max(50).optional(),
    clinical_indication: zod_1.z.string().optional(),
    priority: zod_1.z.enum(['routine', 'urgent', 'stat']).optional(),
    scheduled_date: zod_1.z.string().datetime().optional(),
    performing_facility: zod_1.z.string().max(255).optional()
});
exports.LabTestSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().positive().default(1),
    limit: zod_1.z.coerce.number().int().positive().max(100).default(10),
    patient_id: zod_1.z.coerce.number().int().positive().optional(),
    status: zod_1.z.enum(['ordered', 'collected', 'processing', 'completed', 'cancelled']).optional(),
    test_type: zod_1.z.string().optional(),
    date_from: zod_1.z.string().date().optional(),
    date_to: zod_1.z.string().date().optional(),
    sort_by: zod_1.z.enum(['ordered_date', 'completed_date', 'created_at']).default('ordered_date'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc')
});
