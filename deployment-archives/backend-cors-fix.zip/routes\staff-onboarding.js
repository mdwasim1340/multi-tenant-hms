"use strict";
/**
 * Staff Onboarding Routes
 * Handles new staff member registration with email verification
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const staffOnboarding = __importStar(require("../services/staff-onboarding"));
const router = (0, express_1.Router)();
/**
 * POST /api/staff-onboarding/initiate
 * Step 1: Create staff member and send verification email
 * Requires: Admin authentication
 */
router.post('/initiate', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({
                success: false,
                error: 'X-Tenant-ID header is required'
            });
        }
        const data = Object.assign(Object.assign({}, req.body), { tenant_id: tenantId });
        const result = yield staffOnboarding.initiateStaffOnboarding(data);
        res.status(201).json({
            success: true,
            message: 'Staff member created successfully. Verification email sent.',
            data: result
        });
    }
    catch (error) {
        console.error('Error initiating staff onboarding:', error);
        let errorMessage = 'Failed to create staff member';
        let statusCode = 500;
        if (error.message.includes('already registered') || error.message.includes('already exists')) {
            errorMessage = error.message;
            statusCode = 409;
        }
        else if (error.message.includes('not found')) {
            errorMessage = error.message;
            statusCode = 404;
        }
        else if (error.message) {
            errorMessage = error.message;
        }
        res.status(statusCode).json({
            success: false,
            error: errorMessage,
            message: error.message
        });
    }
}));
/**
 * POST /api/staff-onboarding/verify-otp
 * Step 2: Verify OTP code from email
 * Public endpoint (no auth required)
 */
router.post('/verify-otp', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email, otp } = req.body;
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                error: 'Email and OTP are required'
            });
        }
        const result = yield staffOnboarding.verifyStaffOTP(email, otp);
        res.json({
            success: true,
            message: result.message,
            data: {
                reset_token: result.reset_token,
                email: result.email
            }
        });
    }
    catch (error) {
        console.error('Error verifying OTP:', error);
        let statusCode = 400;
        if (error.message.includes('not found')) {
            statusCode = 404;
        }
        else if (error.message.includes('expired')) {
            statusCode = 410; // Gone
        }
        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to verify OTP'
        });
    }
}));
/**
 * POST /api/staff-onboarding/set-password
 * Step 3: Set password using reset token
 * Public endpoint (no auth required)
 */
router.post('/set-password', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { token, password } = req.body;
        if (!token || !password) {
            return res.status(400).json({
                success: false,
                error: 'Token and password are required'
            });
        }
        // Validate password strength
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'Password must be at least 8 characters long'
            });
        }
        const result = yield staffOnboarding.setStaffPassword(token, password);
        res.json({
            success: true,
            message: result.message,
            data: {
                email: result.email
            }
        });
    }
    catch (error) {
        console.error('Error setting password:', error);
        let statusCode = 400;
        if (error.message.includes('expired') || error.message.includes('Invalid')) {
            statusCode = 410; // Gone
        }
        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to set password'
        });
    }
}));
/**
 * POST /api/staff-onboarding/resend-otp
 * Resend verification OTP
 * Public endpoint (no auth required)
 */
router.post('/resend-otp', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({
                success: false,
                error: 'Email is required'
            });
        }
        const result = yield staffOnboarding.resendStaffVerificationOTP(email);
        res.json({
            success: true,
            message: result.message
        });
    }
    catch (error) {
        console.error('Error resending OTP:', error);
        let statusCode = 400;
        if (error.message.includes('not found')) {
            statusCode = 404;
        }
        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to resend OTP'
        });
    }
}));
exports.default = router;
