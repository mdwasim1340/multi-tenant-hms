"use strict";
/**
 * Bed Management Validation Schemas
 * Zod schemas for request validation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvailableBedsQuerySchema = exports.BedTransferSearchSchema = exports.CancelBedTransferSchema = exports.CompleteBedTransferSchema = exports.UpdateBedTransferSchema = exports.CreateBedTransferSchema = exports.BedAssignmentSearchSchema = exports.DischargeBedAssignmentSchema = exports.UpdateBedAssignmentSchema = exports.CreateBedAssignmentSchema = exports.BedSearchSchema = exports.UpdateBedSchema = exports.CreateBedSchema = exports.DepartmentSearchSchema = exports.UpdateDepartmentSchema = exports.CreateDepartmentSchema = exports.DepartmentStatusSchema = exports.TransferStatusSchema = exports.TransferTypeSchema = exports.AssignmentStatusSchema = exports.PatientConditionSchema = exports.AdmissionTypeSchema = exports.BedStatusSchema = exports.BedTypeSchema = void 0;
const zod_1 = require("zod");
// ==================
// Enum Schemas
// ==================
exports.BedTypeSchema = zod_1.z.enum(['standard', 'icu', 'isolation', 'pediatric', 'maternity']);
exports.BedStatusSchema = zod_1.z.enum(['available', 'occupied', 'maintenance', 'cleaning', 'reserved']);
exports.AdmissionTypeSchema = zod_1.z.enum(['emergency', 'scheduled', 'transfer']);
exports.PatientConditionSchema = zod_1.z.enum(['stable', 'critical', 'moderate', 'serious']);
exports.AssignmentStatusSchema = zod_1.z.enum(['active', 'discharged', 'transferred']);
exports.TransferTypeSchema = zod_1.z.enum(['routine', 'emergency', 'medical_necessity', 'patient_request']);
exports.TransferStatusSchema = zod_1.z.enum(['pending', 'in_progress', 'completed', 'cancelled']);
exports.DepartmentStatusSchema = zod_1.z.enum(['active', 'inactive']);
// ==================
// Department Schemas
// ==================
exports.CreateDepartmentSchema = zod_1.z.object({
    department_code: zod_1.z.string().min(2).max(50).toUpperCase(),
    name: zod_1.z.string().min(3).max(255),
    description: zod_1.z.string().max(1000).optional(),
    floor_number: zod_1.z.number().int().min(0).max(50).optional(),
    building: zod_1.z.string().max(100).optional(),
    total_bed_capacity: zod_1.z.number().int().min(0).max(1000),
});
exports.UpdateDepartmentSchema = zod_1.z.object({
    name: zod_1.z.string().min(3).max(255).optional(),
    description: zod_1.z.string().max(1000).optional(),
    floor_number: zod_1.z.number().int().min(0).max(50).optional(),
    building: zod_1.z.string().max(100).optional(),
    total_bed_capacity: zod_1.z.number().int().min(0).max(1000).optional(),
    status: exports.DepartmentStatusSchema.optional(),
});
exports.DepartmentSearchSchema = zod_1.z.object({
    status: exports.DepartmentStatusSchema.optional(),
    floor_number: zod_1.z.coerce.number().int().optional(),
    building: zod_1.z.string().optional(),
    search: zod_1.z.string().optional(),
});
// ==================
// Bed Schemas
// ==================
exports.CreateBedSchema = zod_1.z.object({
    bed_number: zod_1.z.string().min(1).max(50),
    department_id: zod_1.z.number().int().positive().optional(),
    category_id: zod_1.z.number().int().positive().optional(),
    bed_type: zod_1.z.string().min(1).max(50), // Allow any string, will be validated/mapped in service
    floor_number: zod_1.z.number().int().min(0).max(50).optional(),
    room_number: zod_1.z.string().max(50).optional(),
    wing: zod_1.z.string().max(50).optional(),
    status: exports.BedStatusSchema.optional(), // Allow status to be set on creation
    features: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    notes: zod_1.z.string().max(1000).optional(),
}).refine(data => data.department_id || data.category_id, {
    message: 'Either department_id or category_id must be provided',
    path: ['department_id'],
});
exports.UpdateBedSchema = zod_1.z.object({
    bed_number: zod_1.z.string().min(1).max(50).optional(),
    department_id: zod_1.z.number().int().positive().optional(),
    category_id: zod_1.z.number().int().positive().optional(),
    bed_type: zod_1.z.string().max(50).optional(), // Allow any string for flexibility
    floor_number: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).transform(val => typeof val === 'string' ? (val ? parseInt(val, 10) : undefined) : val).optional(),
    room_number: zod_1.z.string().max(50).optional(),
    wing: zod_1.z.string().max(50).optional(),
    status: zod_1.z.string().max(50).optional(), // Allow any string for flexibility
    features: zod_1.z.any().optional(), // Allow any format for features
    last_cleaned_at: zod_1.z.string().optional(),
    last_maintenance_at: zod_1.z.string().optional(),
    notes: zod_1.z.string().max(1000).optional(),
    is_active: zod_1.z.boolean().optional(),
});
exports.BedSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(1000).default(1000),
    department_id: zod_1.z.coerce.number().int().positive().optional(),
    status: exports.BedStatusSchema.optional(),
    bed_type: exports.BedTypeSchema.optional(),
    floor_number: zod_1.z.coerce.number().int().optional(),
    room_number: zod_1.z.string().optional(),
    search: zod_1.z.string().optional(),
    sort_by: zod_1.z.string().default('bed_number'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('asc'),
    is_active: zod_1.z.coerce.boolean().optional(),
});
// ==================
// Bed Assignment Schemas
// ==================
exports.CreateBedAssignmentSchema = zod_1.z.object({
    bed_id: zod_1.z.number().int().positive(),
    patient_id: zod_1.z.number().int().positive(),
    admission_type: exports.AdmissionTypeSchema,
    admission_reason: zod_1.z.string().max(1000).optional(),
    patient_condition: exports.PatientConditionSchema.optional(),
    assigned_nurse_id: zod_1.z.number().int().positive().optional(),
    assigned_doctor_id: zod_1.z.number().int().positive().optional(),
    expected_discharge_date: zod_1.z.string().date().optional(),
    notes: zod_1.z.string().max(1000).optional(),
});
exports.UpdateBedAssignmentSchema = zod_1.z.object({
    expected_discharge_date: zod_1.z.string().date().optional(),
    patient_condition: exports.PatientConditionSchema.optional(),
    assigned_nurse_id: zod_1.z.number().int().positive().optional(),
    assigned_doctor_id: zod_1.z.number().int().positive().optional(),
    notes: zod_1.z.string().max(1000).optional(),
});
exports.DischargeBedAssignmentSchema = zod_1.z.object({
    discharge_reason: zod_1.z.string().min(1).max(1000),
    notes: zod_1.z.string().max(1000).optional(),
});
exports.BedAssignmentSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(100).default(10),
    bed_id: zod_1.z.coerce.number().int().positive().optional(),
    patient_id: zod_1.z.coerce.number().int().positive().optional(),
    status: exports.AssignmentStatusSchema.optional(),
    admission_type: exports.AdmissionTypeSchema.optional(),
    patient_condition: exports.PatientConditionSchema.optional(),
    assigned_nurse_id: zod_1.z.coerce.number().int().positive().optional(),
    assigned_doctor_id: zod_1.z.coerce.number().int().positive().optional(),
    admission_date_from: zod_1.z.string().date().optional(),
    admission_date_to: zod_1.z.string().date().optional(),
    sort_by: zod_1.z.string().default('admission_date'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc'),
});
// ==================
// Bed Transfer Schemas
// ==================
exports.CreateBedTransferSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    from_bed_id: zod_1.z.number().int().positive(),
    to_bed_id: zod_1.z.number().int().positive(),
    transfer_reason: zod_1.z.string().min(1).max(1000),
    transfer_type: exports.TransferTypeSchema.optional(),
    notes: zod_1.z.string().max(1000).optional(),
}).refine(data => data.from_bed_id !== data.to_bed_id, {
    message: 'Source and destination beds must be different',
    path: ['to_bed_id'],
});
exports.UpdateBedTransferSchema = zod_1.z.object({
    transfer_reason: zod_1.z.string().min(1).max(1000).optional(),
    transfer_type: exports.TransferTypeSchema.optional(),
    notes: zod_1.z.string().max(1000).optional(),
});
exports.CompleteBedTransferSchema = zod_1.z.object({
    notes: zod_1.z.string().max(1000).optional(),
});
exports.CancelBedTransferSchema = zod_1.z.object({
    cancellation_reason: zod_1.z.string().min(1).max(1000),
    notes: zod_1.z.string().max(1000).optional(),
});
exports.BedTransferSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(100).default(10),
    patient_id: zod_1.z.coerce.number().int().positive().optional(),
    from_bed_id: zod_1.z.coerce.number().int().positive().optional(),
    to_bed_id: zod_1.z.coerce.number().int().positive().optional(),
    from_department_id: zod_1.z.coerce.number().int().positive().optional(),
    to_department_id: zod_1.z.coerce.number().int().positive().optional(),
    status: exports.TransferStatusSchema.optional(),
    transfer_type: exports.TransferTypeSchema.optional(),
    transfer_date_from: zod_1.z.string().date().optional(),
    transfer_date_to: zod_1.z.string().date().optional(),
    sort_by: zod_1.z.string().default('transfer_date'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc'),
});
// ==================
// Availability Schemas
// ==================
exports.AvailableBedsQuerySchema = zod_1.z.object({
    department_id: zod_1.z.coerce.number().int().positive().optional(),
    bed_type: exports.BedTypeSchema.optional(),
    floor_number: zod_1.z.coerce.number().int().optional(),
    required_features: zod_1.z.array(zod_1.z.string()).optional(),
    exclude_bed_ids: zod_1.z.array(zod_1.z.coerce.number().int()).optional(),
});
