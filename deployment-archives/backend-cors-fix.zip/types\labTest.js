"use strict";
/**
 * Lab Tests Type Definitions
 *
 * Types for laboratory test management system including:
 * - Test categories and definitions
 * - Lab orders and order items
 * - Lab results and verification
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.VerifyLabResultSchema = exports.UpdateLabResultSchema = exports.CreateLabResultSchema = exports.UpdateLabOrderItemSchema = exports.UpdateLabOrderSchema = exports.CreateLabOrderSchema = exports.LabTestSchema = exports.LabTestCategorySchema = void 0;
const zod_1 = require("zod");
exports.LabTestCategorySchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(255),
    description: zod_1.z.string().optional().nullable(),
    display_order: zod_1.z.number().int().default(0),
    is_active: zod_1.z.boolean().default(true)
});
exports.LabTestSchema = zod_1.z.object({
    category_id: zod_1.z.number().int().optional().nullable(),
    test_code: zod_1.z.string().min(1).max(50),
    test_name: zod_1.z.string().min(1).max(255),
    description: zod_1.z.string().optional().nullable(),
    normal_range_min: zod_1.z.string().max(100).optional().nullable(),
    normal_range_max: zod_1.z.string().max(100).optional().nullable(),
    normal_range_text: zod_1.z.string().max(255).optional().nullable(),
    unit: zod_1.z.string().max(50).optional().nullable(),
    specimen_type: zod_1.z.string().max(100).optional().nullable(),
    price: zod_1.z.number().positive().optional().nullable(),
    turnaround_time: zod_1.z.number().int().positive().optional().nullable(),
    preparation_instructions: zod_1.z.string().optional().nullable(),
    status: zod_1.z.enum(['active', 'inactive', 'discontinued']).default('active')
});
exports.CreateLabOrderSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    medical_record_id: zod_1.z.number().int().positive().optional().nullable(),
    appointment_id: zod_1.z.number().int().positive().optional().nullable(),
    order_date: zod_1.z.string().datetime().optional(),
    ordered_by: zod_1.z.number().int().positive(),
    priority: zod_1.z.enum(['routine', 'urgent', 'stat']).default('routine'),
    clinical_notes: zod_1.z.string().optional().nullable(),
    special_instructions: zod_1.z.string().optional().nullable(),
    test_ids: zod_1.z.array(zod_1.z.number().int().positive()).min(1)
});
exports.UpdateLabOrderSchema = zod_1.z.object({
    priority: zod_1.z.enum(['routine', 'urgent', 'stat']).optional(),
    clinical_notes: zod_1.z.string().optional().nullable(),
    special_instructions: zod_1.z.string().optional().nullable()
});
exports.UpdateLabOrderItemSchema = zod_1.z.object({
    status: zod_1.z.enum(['pending', 'collected', 'processing', 'completed', 'cancelled']).optional(),
    specimen_collected_at: zod_1.z.string().datetime().optional().nullable(),
    processing_started_at: zod_1.z.string().datetime().optional().nullable(),
    cancellation_reason: zod_1.z.string().optional().nullable(),
    notes: zod_1.z.string().optional().nullable()
});
exports.CreateLabResultSchema = zod_1.z.object({
    // Either order_item_id OR (patient_id + test_id) is required
    order_item_id: zod_1.z.number().int().positive().optional(),
    patient_id: zod_1.z.number().int().positive().optional(),
    test_id: zod_1.z.number().int().positive().optional(),
    result_value: zod_1.z.string().max(500).optional().nullable(),
    result_numeric: zod_1.z.number().optional().nullable(),
    result_text: zod_1.z.string().optional().nullable(),
    result_unit: zod_1.z.string().max(50).optional().nullable(),
    reference_range: zod_1.z.string().max(255).optional().nullable(),
    result_date: zod_1.z.string().optional(),
    performed_by: zod_1.z.number().int().positive().optional().nullable(),
    interpretation: zod_1.z.string().optional().nullable(),
    notes: zod_1.z.string().optional().nullable(),
    attachments: zod_1.z.any().optional().nullable(),
    is_abnormal: zod_1.z.boolean().optional(),
    abnormal_flag: zod_1.z.string().optional().nullable(),
    value: zod_1.z.string().optional(), // Alias for result_value
    unit: zod_1.z.string().optional().nullable(), // Alias for result_unit
    // New fields for enhanced lab result entry
    sample_type: zod_1.z.string().max(50).optional().nullable(), // blood, urine, stool, CSF, etc.
    ordering_doctor: zod_1.z.string().max(100).optional().nullable(), // doctor who ordered the test
    result_status: zod_1.z.enum(['final', 'preliminary', 'corrected', 'amended']).optional().default('final'),
});
exports.UpdateLabResultSchema = zod_1.z.object({
    result_value: zod_1.z.string().max(500).optional().nullable(),
    result_numeric: zod_1.z.number().optional().nullable(),
    result_text: zod_1.z.string().optional().nullable(),
    result_unit: zod_1.z.string().max(50).optional().nullable(),
    reference_range: zod_1.z.string().max(255).optional().nullable(),
    interpretation: zod_1.z.string().optional().nullable(),
    notes: zod_1.z.string().optional().nullable(),
    attachments: zod_1.z.any().optional().nullable()
});
exports.VerifyLabResultSchema = zod_1.z.object({
    verified_by: zod_1.z.number().int().positive()
});
