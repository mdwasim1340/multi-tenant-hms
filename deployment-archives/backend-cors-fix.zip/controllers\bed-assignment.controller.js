"use strict";
/**
 * Bed Assignment Controller
 * HTTP request handlers for bed assignment endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBedAssignmentHistory = exports.getPatientBedHistory = exports.dischargeBedAssignment = exports.updateBedAssignment = exports.createBedAssignment = exports.getBedAssignmentById = exports.getBedAssignments = void 0;
const bed_assignment_service_1 = __importDefault(require("../services/bed-assignment.service"));
const bed_validation_1 = require("../validation/bed.validation");
const bed_1 = require("../types/bed");
/**
 * GET /api/bed-assignments
 * List bed assignments with filtering
 */
const getBedAssignments = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Validate query parameters
        const params = bed_validation_1.BedAssignmentSearchSchema.parse(req.query);
        const result = yield bed_assignment_service_1.default.getBedAssignments(tenantId, params);
        res.json(result);
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Get assignments error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed assignments',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedAssignments = getBedAssignments;
/**
 * GET /api/bed-assignments/:id
 * Get bed assignment by ID
 */
const getBedAssignmentById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const assignmentId = parseInt(req.params.id);
        if (isNaN(assignmentId)) {
            return res.status(400).json({ error: 'Invalid assignment ID' });
        }
        const assignment = yield bed_assignment_service_1.default.getBedAssignmentById(tenantId, assignmentId);
        res.json({ assignment });
    }
    catch (error) {
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Get assignment error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed assignment',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedAssignmentById = getBedAssignmentById;
/**
 * POST /api/bed-assignments
 * Create bed assignment
 */
const createBedAssignment = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        // Validate request body
        const data = bed_validation_1.CreateBedAssignmentSchema.parse(req.body);
        const assignment = yield bed_assignment_service_1.default.createBedAssignment(tenantId, data, userId);
        res.status(201).json({
            message: 'Bed assigned successfully',
            assignment,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.BedUnavailableError) {
            return res.status(409).json({
                error: error.message,
                code: error.code,
            });
        }
        if (error instanceof bed_1.BedAssignmentConflictError) {
            return res.status(409).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Create assignment error:', error);
        res.status(500).json({
            error: 'Failed to create bed assignment',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.createBedAssignment = createBedAssignment;
/**
 * PUT /api/bed-assignments/:id
 * Update bed assignment
 */
const updateBedAssignment = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const assignmentId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(assignmentId)) {
            return res.status(400).json({ error: 'Invalid assignment ID' });
        }
        // Validate request body
        const data = bed_validation_1.UpdateBedAssignmentSchema.parse(req.body);
        const assignment = yield bed_assignment_service_1.default.updateBedAssignment(tenantId, assignmentId, data, userId);
        res.json({
            message: 'Bed assignment updated successfully',
            assignment,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Update assignment error:', error);
        res.status(500).json({
            error: 'Failed to update bed assignment',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.updateBedAssignment = updateBedAssignment;
/**
 * POST /api/bed-assignments/:id/discharge
 * Discharge patient from bed
 */
const dischargeBedAssignment = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const assignmentId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(assignmentId)) {
            return res.status(400).json({ error: 'Invalid assignment ID' });
        }
        // Validate request body
        const data = bed_validation_1.DischargeBedAssignmentSchema.parse(req.body);
        const assignment = yield bed_assignment_service_1.default.dischargeBedAssignment(tenantId, assignmentId, data, userId);
        res.json({
            message: 'Patient discharged successfully',
            assignment,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Discharge assignment error:', error);
        res.status(500).json({
            error: 'Failed to discharge patient',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.dischargeBedAssignment = dischargeBedAssignment;
/**
 * GET /api/bed-assignments/patient/:patientId/history
 * Get patient bed history
 */
const getPatientBedHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const history = yield bed_assignment_service_1.default.getPatientBedHistory(tenantId, patientId);
        res.json({
            patient_id: patientId,
            history,
            count: history.length,
        });
    }
    catch (error) {
        console.error('Get patient history error:', error);
        res.status(500).json({
            error: 'Failed to fetch patient bed history',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getPatientBedHistory = getPatientBedHistory;
/**
 * GET /api/bed-assignments/bed/:bedId/history
 * Get bed assignment history
 */
const getBedAssignmentHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.bedId);
        if (isNaN(bedId)) {
            return res.status(400).json({ error: 'Invalid bed ID' });
        }
        const history = yield bed_assignment_service_1.default.getBedAssignmentHistory(tenantId, bedId);
        res.json({
            bed_id: bedId,
            history,
            count: history.length,
        });
    }
    catch (error) {
        console.error('Get bed history error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed assignment history',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedAssignmentHistory = getBedAssignmentHistory;
