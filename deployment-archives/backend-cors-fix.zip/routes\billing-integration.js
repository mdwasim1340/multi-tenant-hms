"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = require("../middleware/auth");
const billing_auth_1 = require("../middleware/billing-auth");
const billing_integration_1 = require("../services/billing-integration");
const router = express_1.default.Router();
// Generate invoice from appointment
router.post('/from-appointment/:appointmentId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { appointmentId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { include_consultation_fee, additional_charges } = req.body;
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        const invoice = yield billing_integration_1.billingIntegrationService.generateInvoiceFromAppointment(tenantId, parseInt(appointmentId), { include_consultation_fee, additional_charges });
        res.json({
            success: true,
            message: 'Invoice generated from appointment successfully',
            invoice
        });
    }
    catch (error) {
        console.error('Error generating invoice from appointment:', error);
        res.status(500).json({
            error: error.message || 'Failed to generate invoice from appointment',
            code: 'APPOINTMENT_INVOICE_ERROR'
        });
    }
}));
// Generate invoice from lab order
router.post('/from-lab-order/:labOrderId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { labOrderId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        const invoice = yield billing_integration_1.billingIntegrationService.generateInvoiceFromLabOrder(tenantId, parseInt(labOrderId));
        res.json({
            success: true,
            message: 'Invoice generated from lab order successfully',
            invoice
        });
    }
    catch (error) {
        console.error('Error generating invoice from lab order:', error);
        res.status(500).json({
            error: error.message || 'Failed to generate invoice from lab order',
            code: 'LAB_ORDER_INVOICE_ERROR'
        });
    }
}));
// Generate invoice from prescription
router.post('/from-prescription/:prescriptionId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { prescriptionId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        const invoice = yield billing_integration_1.billingIntegrationService.generateInvoiceFromPrescription(tenantId, parseInt(prescriptionId));
        res.json({
            success: true,
            message: 'Invoice generated from prescription successfully',
            invoice
        });
    }
    catch (error) {
        console.error('Error generating invoice from prescription:', error);
        res.status(500).json({
            error: error.message || 'Failed to generate invoice from prescription',
            code: 'PRESCRIPTION_INVOICE_ERROR'
        });
    }
}));
// Generate invoice from bed assignment
router.post('/from-bed-assignment/:assignmentId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { assignmentId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { include_room_charges, discharge_date } = req.body;
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        const invoice = yield billing_integration_1.billingIntegrationService.generateInvoiceFromBedAssignment(tenantId, parseInt(assignmentId), {
            include_room_charges,
            discharge_date: discharge_date ? new Date(discharge_date) : undefined
        });
        res.json({
            success: true,
            message: 'Invoice generated from bed assignment successfully',
            invoice
        });
    }
    catch (error) {
        console.error('Error generating invoice from bed assignment:', error);
        res.status(500).json({
            error: error.message || 'Failed to generate invoice from bed assignment',
            code: 'BED_ASSIGNMENT_INVOICE_ERROR'
        });
    }
}));
// Calculate late fee for invoice
router.get('/late-fee/:invoiceId', auth_1.hospitalAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { invoiceId } = req.params;
        const { fee_percentage = 2 } = req.query;
        const lateFee = yield billing_integration_1.billingIntegrationService.calculateLateFee(parseInt(invoiceId), parseFloat(fee_percentage));
        res.json({
            success: true,
            invoice_id: parseInt(invoiceId),
            late_fee: lateFee,
            fee_percentage: parseFloat(fee_percentage)
        });
    }
    catch (error) {
        console.error('Error calculating late fee:', error);
        res.status(500).json({
            error: error.message || 'Failed to calculate late fee',
            code: 'LATE_FEE_CALCULATION_ERROR'
        });
    }
}));
// Apply late fee to invoice
router.post('/apply-late-fee/:invoiceId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingWrite, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { invoiceId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { fee_percentage = 2, created_by } = req.body;
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        if (!created_by) {
            return res.status(400).json({
                error: 'created_by is required',
                code: 'MISSING_CREATED_BY'
            });
        }
        const adjustment = yield billing_integration_1.billingIntegrationService.applyLateFee(tenantId, parseInt(invoiceId), created_by, fee_percentage);
        res.json({
            success: true,
            message: 'Late fee applied successfully',
            adjustment
        });
    }
    catch (error) {
        console.error('Error applying late fee:', error);
        res.status(500).json({
            error: error.message || 'Failed to apply late fee',
            code: 'APPLY_LATE_FEE_ERROR'
        });
    }
}));
exports.default = router;
