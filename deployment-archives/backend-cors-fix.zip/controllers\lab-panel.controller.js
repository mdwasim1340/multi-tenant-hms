"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabPanelById = exports.getLabPanels = void 0;
const errorHandler_1 = require("../middleware/errorHandler");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
});
exports.getLabPanels = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const client = yield pool.connect();
    try {
        yield client.query(`SET search_path TO "${tenantId}"`);
        const result = yield client.query('SELECT * FROM lab_panels WHERE is_active = true ORDER BY panel_name');
        res.json({
            success: true,
            data: { panels: result.rows }
        });
    }
    finally {
        client.release();
    }
}));
exports.getLabPanelById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const panelId = parseInt(req.params.id);
    const client = yield pool.connect();
    try {
        yield client.query(`SET search_path TO "${tenantId}"`);
        const result = yield client.query('SELECT * FROM lab_panels WHERE id = $1', [panelId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: 'Lab panel not found'
            });
        }
        res.json({
            success: true,
            data: { panel: result.rows[0] }
        });
    }
    finally {
        client.release();
    }
}));
