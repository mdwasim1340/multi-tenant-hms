"use strict";
/**
 * Team Alpha - Medical Record Template Routes
 * API endpoints for template management
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const template_controller_1 = __importDefault(require("../controllers/template.controller"));
const router = (0, express_1.Router)();
// Apply middleware to all routes
router.use(auth_1.authMiddleware);
router.use(tenant_1.tenantMiddleware);
/**
 * GET /api/templates
 * Get templates with filtering and pagination
 * Query params:
 * - template_type: Filter by template type
 * - specialty: Filter by medical specialty
 * - is_active: Filter by active status (true/false)
 * - is_default: Filter by default status (true/false)
 * - search: Search in name and description
 * - created_by: Filter by creator user ID
 * - limit: Number of results per page (default: 50)
 * - offset: Number of results to skip (default: 0)
 */
router.get('/', template_controller_1.default.getTemplates);
/**
 * GET /api/templates/statistics
 * Get template usage statistics for current tenant
 */
router.get('/statistics', template_controller_1.default.getTemplateStatistics);
/**
 * GET /api/templates/recommendations
 * Get recommended templates for current user
 * Query params:
 * - specialty: Filter recommendations by specialty
 * - template_type: Filter recommendations by template type
 */
router.get('/recommendations', template_controller_1.default.getRecommendedTemplates);
/**
 * POST /api/templates/copy-defaults
 * Copy default templates to current tenant
 * Requires admin permissions
 */
router.post('/copy-defaults', template_controller_1.default.copyDefaultTemplates);
/**
 * POST /api/templates/usage
 * Record template usage for analytics
 * Body:
 * - template_id: ID of template used
 * - medical_record_id: ID of medical record created
 * - customizations: Any customizations made (optional)
 * - completion_time_seconds: Time taken to complete (optional)
 */
router.post('/usage', template_controller_1.default.recordTemplateUsage);
/**
 * GET /api/templates/:id
 * Get a single template by ID
 */
router.get('/:id', template_controller_1.default.getTemplateById);
/**
 * POST /api/templates
 * Create a new template
 * Body:
 * - name: Template name (required)
 * - description: Template description (optional)
 * - template_type: Type of template (required)
 * - specialty: Medical specialty (optional)
 * - fields: Template field definitions (required)
 * - default_values: Default values for fields (optional)
 * - validation_rules: Field validation rules (optional)
 * - is_default: Whether this is the default template (optional)
 * - parent_template_id: Parent template for versioning (optional)
 */
router.post('/', template_controller_1.default.createTemplate);
/**
 * PUT /api/templates/:id
 * Update a template
 * Body: Same as POST, all fields optional
 */
router.put('/:id', template_controller_1.default.updateTemplate);
/**
 * DELETE /api/templates/:id
 * Delete (deactivate) a template
 */
router.delete('/:id', template_controller_1.default.deleteTemplate);
/**
 * POST /api/templates/:id/apply
 * Apply a template to get populated data
 * Body:
 * - custom_values: Custom values to override defaults (optional)
 */
router.post('/:id/apply', template_controller_1.default.applyTemplate);
exports.default = router;
