"use strict";
/**
 * Inventory Management System - TypeScript Interfaces
 * Team Beta - Sprint 1, Day 3
 */
Object.defineProperty(exports, "__esModule", { value: true });
