"use strict";
/**
 * Notification Types and Schemas
 * Team: Epsilon
 * Purpose: TypeScript interfaces and Zod validation for notification system
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateNotificationTemplateSchema = exports.CreateNotificationTemplateSchema = exports.UpdateMultipleSettingsSchema = exports.NotificationSettingsSchema = exports.BulkOperationSchema = exports.ListNotificationsQuerySchema = exports.UpdateNotificationSchema = exports.CreateNotificationSchema = exports.DigestFrequency = exports.DeliveryStatus = exports.NotificationChannel = exports.NotificationPriority = exports.NotificationType = void 0;
const zod_1 = require("zod");
// ============================================================================
// Enums and Constants
// ============================================================================
exports.NotificationType = {
    CRITICAL_ALERT: 'critical_alert',
    APPOINTMENT_REMINDER: 'appointment_reminder',
    LAB_RESULT: 'lab_result',
    BILLING_UPDATE: 'billing_update',
    STAFF_SCHEDULE: 'staff_schedule',
    INVENTORY_ALERT: 'inventory_alert',
    SYSTEM_MAINTENANCE: 'system_maintenance',
    GENERAL_INFO: 'general_info',
};
exports.NotificationPriority = {
    CRITICAL: 'critical',
    HIGH: 'high',
    MEDIUM: 'medium',
    LOW: 'low',
};
exports.NotificationChannel = {
    IN_APP: 'in_app',
    EMAIL: 'email',
    SMS: 'sms',
    PUSH: 'push',
};
exports.DeliveryStatus = {
    PENDING: 'pending',
    SENT: 'sent',
    DELIVERED: 'delivered',
    FAILED: 'failed',
};
exports.DigestFrequency = {
    HOURLY: 'hourly',
    DAILY: 'daily',
    WEEKLY: 'weekly',
};
// ============================================================================
// Zod Validation Schemas
// ============================================================================
// Create Notification Schema
exports.CreateNotificationSchema = zod_1.z.object({
    user_id: zod_1.z.number().int().positive(),
    type: zod_1.z.enum([
        exports.NotificationType.CRITICAL_ALERT,
        exports.NotificationType.APPOINTMENT_REMINDER,
        exports.NotificationType.LAB_RESULT,
        exports.NotificationType.BILLING_UPDATE,
        exports.NotificationType.STAFF_SCHEDULE,
        exports.NotificationType.INVENTORY_ALERT,
        exports.NotificationType.SYSTEM_MAINTENANCE,
        exports.NotificationType.GENERAL_INFO,
    ]),
    priority: zod_1.z.enum([
        exports.NotificationPriority.CRITICAL,
        exports.NotificationPriority.HIGH,
        exports.NotificationPriority.MEDIUM,
        exports.NotificationPriority.LOW,
    ]).default(exports.NotificationPriority.MEDIUM),
    title: zod_1.z.string().min(1).max(255),
    message: zod_1.z.string().min(1),
    data: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    created_by: zod_1.z.number().int().positive().optional(),
});
// Update Notification Schema
exports.UpdateNotificationSchema = zod_1.z.object({
    title: zod_1.z.string().min(1).max(255).optional(),
    message: zod_1.z.string().min(1).optional(),
    data: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    priority: zod_1.z.enum([
        exports.NotificationPriority.CRITICAL,
        exports.NotificationPriority.HIGH,
        exports.NotificationPriority.MEDIUM,
        exports.NotificationPriority.LOW,
    ]).optional(),
});
// List Notifications Query Schema
exports.ListNotificationsQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().positive().default(1),
    limit: zod_1.z.coerce.number().int().positive().max(100).default(20),
    type: zod_1.z.enum([
        exports.NotificationType.CRITICAL_ALERT,
        exports.NotificationType.APPOINTMENT_REMINDER,
        exports.NotificationType.LAB_RESULT,
        exports.NotificationType.BILLING_UPDATE,
        exports.NotificationType.STAFF_SCHEDULE,
        exports.NotificationType.INVENTORY_ALERT,
        exports.NotificationType.SYSTEM_MAINTENANCE,
        exports.NotificationType.GENERAL_INFO,
    ]).optional(),
    priority: zod_1.z.enum([
        exports.NotificationPriority.CRITICAL,
        exports.NotificationPriority.HIGH,
        exports.NotificationPriority.MEDIUM,
        exports.NotificationPriority.LOW,
    ]).optional(),
    read: zod_1.z.enum(['true', 'false']).optional(),
    archived: zod_1.z.enum(['true', 'false']).optional(),
    search: zod_1.z.string().optional(),
    sort_by: zod_1.z.enum(['created_at', 'priority', 'type']).default('created_at'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc'),
});
// Bulk Operation Schema
exports.BulkOperationSchema = zod_1.z.object({
    notification_ids: zod_1.z.array(zod_1.z.number().int().positive()).min(1).max(100),
});
// Notification Settings Schema
exports.NotificationSettingsSchema = zod_1.z.object({
    notification_type: zod_1.z.string().min(1).max(50),
    email_enabled: zod_1.z.boolean().default(true),
    sms_enabled: zod_1.z.boolean().default(false),
    push_enabled: zod_1.z.boolean().default(true),
    in_app_enabled: zod_1.z.boolean().default(true),
    quiet_hours_start: zod_1.z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).optional(),
    quiet_hours_end: zod_1.z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).optional(),
    digest_mode: zod_1.z.boolean().default(false),
    digest_frequency: zod_1.z.enum([
        exports.DigestFrequency.HOURLY,
        exports.DigestFrequency.DAILY,
        exports.DigestFrequency.WEEKLY,
    ]).optional(),
});
// Update Multiple Settings Schema
exports.UpdateMultipleSettingsSchema = zod_1.z.object({
    settings: zod_1.z.array(exports.NotificationSettingsSchema).min(1),
});
// Notification Template Schema (Admin)
exports.CreateNotificationTemplateSchema = zod_1.z.object({
    template_key: zod_1.z.string().min(1).max(100).regex(/^[a-z0-9_]+$/),
    name: zod_1.z.string().min(1).max(255),
    description: zod_1.z.string().optional(),
    subject_template: zod_1.z.string().optional(),
    body_template: zod_1.z.string().optional(),
    sms_template: zod_1.z.string().optional(),
    push_template: zod_1.z.string().optional(),
    variables: zod_1.z.array(zod_1.z.string()).optional(),
});
// Update Template Schema
exports.UpdateNotificationTemplateSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(255).optional(),
    description: zod_1.z.string().optional(),
    subject_template: zod_1.z.string().optional(),
    body_template: zod_1.z.string().optional(),
    sms_template: zod_1.z.string().optional(),
    push_template: zod_1.z.string().optional(),
    variables: zod_1.z.array(zod_1.z.string()).optional(),
});
