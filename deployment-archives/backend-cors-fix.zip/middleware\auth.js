"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authMiddleware = exports.hospitalAuthMiddleware = exports.adminAuthMiddleware = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwk_to_pem_1 = __importDefault(require("jwk-to-pem"));
const node_fetch_1 = __importDefault(require("node-fetch"));
const userService_1 = require("../services/userService");
let pems = {};
const fetchJWKS = () => __awaiter(void 0, void 0, void 0, function* () {
    const url = `https://cognito-idp.${process.env.AWS_REGION}.amazonaws.com/${process.env.COGNITO_USER_POOL_ID}/.well-known/jwks.json`;
    try {
        const response = yield (0, node_fetch_1.default)(url);
        const jwks = yield response.json();
        if (jwks && jwks.keys) {
            pems = jwks.keys.reduce((acc, key) => {
                if (key.kty === 'RSA') {
                    acc[key.kid] = (0, jwk_to_pem_1.default)({ kty: key.kty, n: key.n, e: key.e });
                }
                return acc;
            }, {});
        }
    }
    catch (error) {
        console.error('Error fetching JWKS:', error);
    }
});
fetchJWKS();
const adminAuthMiddleware = (req, res, next) => {
    var _a;
    const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'Authorization token is required' });
    }
    const decodedToken = jsonwebtoken_1.default.decode(token, { complete: true });
    if (!decodedToken || !decodedToken.header.kid) {
        return res.status(401).json({ message: 'Invalid token' });
    }
    // Handle Cognito tokens
    const kid = decodedToken.header.kid;
    const pem = pems[kid];
    if (!pem) {
        return res.status(401).json({ message: 'Invalid token' });
    }
    jsonwebtoken_1.default.verify(token, pem, { algorithms: ['RS256'] }, (err, payload) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b;
        if (err) {
            return res.status(401).json({ message: 'Invalid token' });
        }
        const groups = payload['cognito:groups'];
        if (!groups || !(groups.includes('system-admin') || groups.includes('admin'))) {
            return res.status(403).json({ message: 'Forbidden: Admins only' });
        }
        req.user = payload;
        // Map JWT to local DB user id when possible
        try {
            const email = payload.email || payload['cognito:username'];
            const user = email ? yield (0, userService_1.getUserByEmail)(email) : null;
            req.userId = (_b = (_a = user === null || user === void 0 ? void 0 : user.id) !== null && _a !== void 0 ? _a : payload.sub) !== null && _b !== void 0 ? _b : payload['cognito:username'];
        }
        catch (mapErr) {
            req.userId = payload.sub || payload['cognito:username'];
        }
        next();
    }));
};
exports.adminAuthMiddleware = adminAuthMiddleware;
const hospitalAuthMiddleware = (req, res, next) => {
    var _a;
    const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'Authorization token is required' });
    }
    const decodedToken = jsonwebtoken_1.default.decode(token, { complete: true });
    if (!decodedToken || !decodedToken.header.kid) {
        return res.status(401).json({ message: 'Invalid token' });
    }
    const kid = decodedToken.header.kid;
    const pem = pems[kid];
    if (!pem) {
        return res.status(401).json({ message: 'Invalid token' });
    }
    jsonwebtoken_1.default.verify(token, pem, { algorithms: ['RS256'] }, (err, payload) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b;
        if (err) {
            return res.status(401).json({ message: 'Invalid token' });
        }
        req.user = payload;
        // Map JWT to local DB user id
        try {
            const email = payload.email || payload['cognito:username'];
            const user = email ? yield (0, userService_1.getUserByEmail)(email) : null;
            req.userId = (_b = (_a = user === null || user === void 0 ? void 0 : user.id) !== null && _a !== void 0 ? _a : payload.sub) !== null && _b !== void 0 ? _b : payload['cognito:username'];
            // Check database roles instead of Cognito groups for hospital access
            // This allows users with database roles to access hospital system
            // even if they don't have Cognito groups set
            if (user === null || user === void 0 ? void 0 : user.id) {
                // User found in database - allow access (role-based permissions will be checked by requirePermission middleware)
                return next();
            }
            // Fallback to Cognito groups check if user not in database
            const groups = payload['cognito:groups'];
            if (groups && (groups.includes('hospital-admin') || groups.includes('system-admin') || groups.includes('admin'))) {
                return next();
            }
            // If no database user and no Cognito groups, deny access
            return res.status(403).json({
                message: 'Forbidden: User not authorized for hospital system',
                hint: 'User must have a database account with assigned roles or be in a Cognito group'
            });
        }
        catch (mapErr) {
            console.error('Error mapping user:', mapErr);
            req.userId = payload.sub || payload['cognito:username'];
            // Fallback to Cognito groups check
            const groups = payload['cognito:groups'];
            if (!groups || (!groups.includes('hospital-admin') && !groups.includes('system-admin') && !groups.includes('admin'))) {
                return res.status(403).json({ message: 'Forbidden: Hospital admins only' });
            }
            next();
        }
    }));
};
exports.hospitalAuthMiddleware = hospitalAuthMiddleware;
exports.authMiddleware = exports.adminAuthMiddleware;
