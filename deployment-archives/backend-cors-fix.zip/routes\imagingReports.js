"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createImagingReportsRouter = void 0;
const express_1 = require("express");
const imagingReport_controller_1 = require("../controllers/imagingReport.controller");
const createImagingReportsRouter = () => {
    const router = (0, express_1.Router)();
    // Search reports
    router.get('/search', imagingReport_controller_1.searchImagingReports);
    // Report CRUD
    router.post('/', imagingReport_controller_1.createImagingReport);
    router.get('/', imagingReport_controller_1.getImagingReports);
    router.get('/:id', imagingReport_controller_1.getImagingReport);
    router.put('/:id', imagingReport_controller_1.updateImagingReport);
    router.delete('/:id', imagingReport_controller_1.deleteImagingReport);
    // Get reports by patient
    router.get('/patient/:patientId', imagingReport_controller_1.getPatientImagingReports);
    // File operations
    router.post('/:id/files', imagingReport_controller_1.addReportFile);
    router.get('/:id/files', imagingReport_controller_1.getReportFiles);
    router.delete('/:id/files/:fileId', imagingReport_controller_1.deleteReportFile);
    return router;
};
exports.createImagingReportsRouter = createImagingReportsRouter;
