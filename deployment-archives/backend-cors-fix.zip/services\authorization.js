"use strict";
/**
 * Authorization Service
 * Handles role-based application access control
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllPermissions = exports.getRolePermissions = exports.getAllRoles = exports.revokeUserRole = exports.assignUserRole = exports.getUserAccessibleApplications = exports.canUserAccessApplication = exports.getUserApplicationAccess = exports.checkUserPermission = exports.getUserPermissions = exports.getUserRoles = void 0;
const database_1 = __importDefault(require("../database"));
/**
 * Get user roles
 */
const getUserRoles = (userId) => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    SELECT 
      r.id,
      r.name,
      r.description
    FROM user_roles ur
    JOIN roles r ON ur.role_id = r.id
    WHERE ur.user_id = $1
    ORDER BY r.name
  `;
    const result = yield database_1.default.query(query, [userId]);
    return result.rows;
});
exports.getUserRoles = getUserRoles;
/**
 * Get user permissions
 */
const getUserPermissions = (userId) => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    SELECT resource, action
    FROM get_user_permissions($1)
  `;
    const result = yield database_1.default.query(query, [userId]);
    return result.rows;
});
exports.getUserPermissions = getUserPermissions;
/**
 * Check if user has specific permission
 */
const checkUserPermission = (userId, resource, action) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    // If userId is a UUID string (from Cognito), grant access
    // This handles cases where user is authenticated via Cognito but not in local DB
    if (typeof userId === 'string' && userId.includes('-')) {
        return true;
    }
    try {
        // Try using the database function first
        const query = `SELECT check_user_permission($1, $2, $3) as has_permission`;
        const result = yield database_1.default.query(query, [userId, resource, action]);
        return ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.has_permission) || false;
    }
    catch (error) {
        // If the function doesn't exist, fall back to direct query
        if (error.code === '42883' || ((_b = error.message) === null || _b === void 0 ? void 0 : _b.includes('does not exist'))) {
            console.warn('[Authorization] check_user_permission function not found, using fallback query');
            try {
                const fallbackQuery = `
          SELECT EXISTS (
            SELECT 1 FROM user_roles ur
            JOIN role_permissions rp ON ur.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE ur.user_id = $1 AND p.resource = $2 AND p.action = $3
          ) as has_permission
        `;
                const result = yield database_1.default.query(fallbackQuery, [userId, resource, action]);
                return ((_c = result.rows[0]) === null || _c === void 0 ? void 0 : _c.has_permission) || false;
            }
            catch (fallbackError) {
                // If even the fallback fails (tables don't exist), return true for development
                console.warn('[Authorization] Permission tables not found, granting access for development');
                return true;
            }
        }
        // For invalid input syntax errors (UUID passed as integer), grant access
        if (error.code === '22P02') {
            console.warn('[Authorization] UUID user ID detected, granting access');
            return true;
        }
        throw error;
    }
});
exports.checkUserPermission = checkUserPermission;
/**
 * Get applications user can access
 */
const getUserApplicationAccess = (userId) => __awaiter(void 0, void 0, void 0, function* () {
    // Get all applications
    const appsQuery = `
    SELECT id, name, url, port, required_permissions, status
    FROM applications
    WHERE status = 'active'
    ORDER BY name
  `;
    const appsResult = yield database_1.default.query(appsQuery);
    const applications = appsResult.rows;
    // Get user permissions
    const permissions = yield (0, exports.getUserPermissions)(userId);
    const userPermissions = new Set(permissions.map(p => `${p.resource}:${p.action}`));
    // Check access for each application
    const applicationAccess = [];
    for (const app of applications) {
        const requiredPerms = app.required_permissions || [];
        const hasAccess = requiredPerms.length === 0 ||
            requiredPerms.some((perm) => userPermissions.has(perm));
        applicationAccess.push({
            application_id: app.id,
            name: app.name,
            url: app.url,
            port: app.port,
            has_access: hasAccess,
            required_permissions: requiredPerms
        });
    }
    return applicationAccess;
});
exports.getUserApplicationAccess = getUserApplicationAccess;
/**
 * Check if user can access application
 */
const canUserAccessApplication = (userId, applicationId) => __awaiter(void 0, void 0, void 0, function* () {
    // If userId is a UUID string (from Cognito), allow access
    // This handles cases where user is authenticated via Cognito but not in local DB
    if (typeof userId === 'string' && userId.includes('-')) {
        // UUID format - user authenticated via Cognito, allow access
        return true;
    }
    // Get application requirements
    const appQuery = `
    SELECT required_permissions 
    FROM applications 
    WHERE id = $1 AND status = 'active'
  `;
    const appResult = yield database_1.default.query(appQuery, [applicationId]);
    if (appResult.rows.length === 0) {
        return false; // Application not found or inactive
    }
    const requiredPermissions = appResult.rows[0].required_permissions || [];
    // If no permissions required, allow access
    if (requiredPermissions.length === 0) {
        return true;
    }
    // Check if user has any of the required permissions
    for (const permission of requiredPermissions) {
        const [resource, action] = permission.split(':');
        const hasPermission = yield (0, exports.checkUserPermission)(userId, resource, action);
        if (hasPermission) {
            return true;
        }
    }
    return false;
});
exports.canUserAccessApplication = canUserAccessApplication;
/**
 * Get user's accessible applications with details
 */
const getUserAccessibleApplications = (userId) => __awaiter(void 0, void 0, void 0, function* () {
    const applications = yield (0, exports.getUserApplicationAccess)(userId);
    return applications.filter(app => app.has_access);
});
exports.getUserAccessibleApplications = getUserAccessibleApplications;
/**
 * Assign role to user
 */
const assignUserRole = (userId, roleId) => __awaiter(void 0, void 0, void 0, function* () {
    // Check if assignment already exists
    const existingQuery = `
    SELECT id FROM user_roles 
    WHERE user_id = $1 AND role_id = $2
  `;
    const existingResult = yield database_1.default.query(existingQuery, [userId, roleId]);
    if (existingResult.rows.length > 0) {
        throw new Error('User already has this role');
    }
    // Insert new role assignment
    const insertQuery = `
    INSERT INTO user_roles (user_id, role_id)
    VALUES ($1, $2)
  `;
    yield database_1.default.query(insertQuery, [userId, roleId]);
});
exports.assignUserRole = assignUserRole;
/**
 * Revoke role from user
 */
const revokeUserRole = (userId, roleId) => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    DELETE FROM user_roles 
    WHERE user_id = $1 AND role_id = $2
  `;
    const result = yield database_1.default.query(query, [userId, roleId]);
    if (result.rowCount === 0) {
        throw new Error('Role assignment not found');
    }
});
exports.revokeUserRole = revokeUserRole;
/**
 * Get all available roles
 */
const getAllRoles = () => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    SELECT 
      r.id,
      r.name,
      r.description,
      COUNT(rp.permission_id) as permission_count
    FROM roles r
    LEFT JOIN role_permissions rp ON r.id = rp.role_id
    GROUP BY r.id, r.name, r.description
    ORDER BY r.name
  `;
    const result = yield database_1.default.query(query);
    return result.rows;
});
exports.getAllRoles = getAllRoles;
/**
 * Get role permissions
 */
const getRolePermissions = (roleId) => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    SELECT p.resource, p.action
    FROM role_permissions rp
    JOIN permissions p ON rp.permission_id = p.id
    WHERE rp.role_id = $1
    ORDER BY p.resource, p.action
  `;
    const result = yield database_1.default.query(query, [roleId]);
    return result.rows;
});
exports.getRolePermissions = getRolePermissions;
/**
 * Get all permissions
 */
const getAllPermissions = () => __awaiter(void 0, void 0, void 0, function* () {
    const query = `
    SELECT id, resource, action, description
    FROM permissions
    ORDER BY resource, action
  `;
    const result = yield database_1.default.query(query);
    return result.rows;
});
exports.getAllPermissions = getAllPermissions;
