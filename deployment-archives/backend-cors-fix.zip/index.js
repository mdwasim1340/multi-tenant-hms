"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const tenant_1 = require("./middleware/tenant");
const authorization_1 = require("./middleware/authorization");
const auth_1 = __importDefault(require("./routes/auth"));
const users_1 = __importDefault(require("./routes/users"));
const roles_1 = __importDefault(require("./routes/roles"));
const subscriptions_1 = __importDefault(require("./routes/subscriptions"));
const usage_1 = __importDefault(require("./routes/usage"));
const billing_1 = __importDefault(require("./routes/billing"));
const payment_plans_1 = __importDefault(require("./routes/payment-plans"));
const insurance_claims_1 = __importDefault(require("./routes/insurance-claims"));
const billing_adjustments_1 = __importDefault(require("./routes/billing-adjustments"));
const tax_configurations_1 = __importDefault(require("./routes/tax-configurations"));
const billing_reports_1 = __importDefault(require("./routes/billing-reports"));
const billing_integration_1 = __importDefault(require("./routes/billing-integration"));
const billing_jobs_1 = __importDefault(require("./routes/billing-jobs"));
const balance_reports_1 = __importDefault(require("./routes/balance-reports"));
const backup_1 = __importDefault(require("./routes/backup"));
const usageTracking_1 = require("./middleware/usageTracking");
const redis_1 = require("./config/redis");
const subdomain_cache_1 = require("./services/subdomain-cache");
dotenv_1.default.config();
(0, redis_1.connectRedis)().catch(err => {
    console.error('Failed to connect to Redis:', err);
    process.exit(1);
});
// Initialize subdomain cache
subdomain_cache_1.subdomainCache.connect().catch(err => {
    console.warn('⚠️  Subdomain cache (Redis) not available:', err.message);
    console.warn('⚠️  Subdomain resolution will work without caching');
});
const app = (0, express_1.default)();
const port = process.env.PORT || 5000;
// CORS configuration for authorized applications only
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        const allowed = [
            // Development
            'http://localhost:3001', // Hospital Management System
            'http://localhost:3002', // Admin Dashboard
            'http://localhost:3003', // Future apps
            'http://10.66.66.8:3001',
            'http://10.66.66.8:3002',
            'http://10.66.66.8:3003',
            // Production
            'https://aajminpolyclinic.com.np',
            'https://www.aajminpolyclinic.com.np',
            'https://admin.aajminpolyclinic.com.np'
        ];
        // Allow requests with no origin (like mobile apps or curl)
        if (!origin)
            return callback(null, true);
        // Check exact match
        if (allowed.includes(origin))
            return callback(null, true);
        try {
            const url = new URL(origin);
            // Allow localhost subdomains for development
            const isLocalhostSubdomain = url.hostname.endsWith('.localhost') && (url.port === '3001' || url.port === '3002' || url.port === '3003');
            if (isLocalhostSubdomain)
                return callback(null, true);
            // Allow any subdomain of aajminpolyclinic.com.np for multi-tenant support
            if (url.hostname.endsWith('.aajminpolyclinic.com.np') || url.hostname === 'aajminpolyclinic.com.np') {
                return callback(null, true);
            }
        }
        catch (e) { }
        console.log(`CORS blocked origin: ${origin}`);
        callback(new Error('Not allowed by CORS'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Tenant-ID', 'X-API-Key', 'X-App-ID']
}));
// Middleware to parse JSON bodies
app.use(express_1.default.json());
// Request logging middleware - log all incoming requests
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path}`);
    console.log(`  Headers: X-Tenant-ID=${req.headers['x-tenant-id']}, X-App-ID=${req.headers['x-app-id']}`);
    next();
});
// App authentication middleware - protect against direct access
const appAuth_1 = require("./middleware/appAuth");
app.use('/api', appAuth_1.apiAppAuthMiddleware);
// Usage tracking middleware - track API calls
app.use('/api', usageTracking_1.trackApiCall);
// Health check routes - public, no authentication required
const health_1 = __importDefault(require("./routes/health"));
app.use('/health', health_1.default);
// Auth routes are public and do not require tenant context
app.use('/auth', auth_1.default);
// Global admin routes that operate on global data (no tenant context needed)
const tenants_1 = __importDefault(require("./routes/tenants"));
const branding_1 = __importDefault(require("./routes/branding"));
const system_analytics_1 = __importDefault(require("./routes/system-analytics"));
const analytics_1 = __importDefault(require("./routes/analytics"));
const admin_1 = __importDefault(require("./routes/admin"));
const auth_2 = require("./middleware/auth");
app.use('/api/tenants', tenants_1.default);
app.use('/api/tenants', branding_1.default); // Branding routes (/:id/branding)
app.use('/api/admin', admin_1.default);
app.use('/api/users', auth_2.adminAuthMiddleware, users_1.default);
app.use('/api/roles', auth_2.adminAuthMiddleware, roles_1.default);
app.use('/api/subscriptions', subscriptions_1.default);
app.use('/api/usage', usage_1.default);
app.use('/api/billing', billing_1.default);
app.use('/api/payment-plans', payment_plans_1.default);
app.use('/api/insurance-claims', insurance_claims_1.default);
app.use('/api/billing-adjustments', billing_adjustments_1.default);
app.use('/api/tax-configurations', tax_configurations_1.default);
app.use('/api/billing/reports', billing_reports_1.default);
app.use('/api/billing/integration', billing_integration_1.default);
app.use('/api/billing/jobs', billing_jobs_1.default);
app.use('/api/balance-reports', balance_reports_1.default);
app.use('/api/backups', backup_1.default);
app.use('/api/system-analytics', auth_2.adminAuthMiddleware, system_analytics_1.default);
app.use('/api/analytics', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), analytics_1.default);
// Routes that need tenant context - apply tenant middleware first
const files_1 = __importDefault(require("./routes/files"));
const realtime_1 = __importDefault(require("./routes/realtime"));
const customFields_1 = __importDefault(require("./routes/customFields"));
const patients_routes_1 = __importDefault(require("./routes/patients.routes"));
const appointments_routes_1 = __importDefault(require("./routes/appointments.routes"));
const medical_records_routes_1 = __importDefault(require("./routes/medical-records.routes"));
const prescriptions_routes_1 = __importDefault(require("./routes/prescriptions.routes"));
const diagnosis_treatment_routes_1 = __importDefault(require("./routes/diagnosis-treatment.routes"));
const lab_tests_routes_1 = __importDefault(require("./routes/lab-tests.routes"));
const lab_orders_routes_1 = __importDefault(require("./routes/lab-orders.routes"));
const lab_results_routes_1 = __importDefault(require("./routes/lab-results.routes"));
const imaging_routes_1 = __importDefault(require("./routes/imaging.routes"));
const lab_panels_routes_1 = __importDefault(require("./routes/lab-panels.routes"));
const bed_management_routes_1 = __importDefault(require("./routes/bed-management.routes"));
const bed_management_enhanced_1 = __importDefault(require("./routes/bed-management-enhanced"));
const departments_1 = __importDefault(require("./routes/departments"));
const staff_1 = __importDefault(require("./routes/staff"));
const audit_1 = __importDefault(require("./routes/audit"));
const storage_1 = __importDefault(require("./routes/storage"));
const lifecycle_1 = __importDefault(require("./routes/lifecycle"));
const templates_1 = __importDefault(require("./routes/templates"));
const staff_onboarding_1 = __importDefault(require("./routes/staff-onboarding"));
const notifications_1 = __importDefault(require("./routes/notifications"));
const n8n_routes_1 = __importDefault(require("./routes/n8n.routes"));
const clinicalNotes_1 = require("./routes/clinicalNotes");
const noteTemplates_1 = require("./routes/noteTemplates");
const imagingReports_1 = require("./routes/imagingReports");
const prescriptions_1 = require("./routes/prescriptions");
const medicalHistory_1 = require("./routes/medicalHistory");
const database_1 = __importDefault(require("./database"));
// Apply tenant middleware, authentication, and application access control to hospital routes
app.use('/files', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), files_1.default);
app.use('/api/realtime', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), realtime_1.default);
app.use('/api/custom-fields', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), customFields_1.default);
// Development vs Production middleware for patients
if (process.env.NODE_ENV === 'development') {
    const { devTenantMiddleware, devAuthMiddleware, devApplicationAccessMiddleware } = require('./middleware/devAuth');
    app.use('/api/patients', devTenantMiddleware, devAuthMiddleware, devApplicationAccessMiddleware('hospital_system'), patients_routes_1.default);
}
else {
    app.use('/api/patients', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), patients_routes_1.default);
}
// Development vs Production middleware for appointments
if (process.env.NODE_ENV === 'development') {
    const { devTenantMiddleware, devAuthMiddleware, devApplicationAccessMiddleware } = require('./middleware/devAuth');
    app.use('/api/appointments', devTenantMiddleware, devAuthMiddleware, devApplicationAccessMiddleware('hospital_system'), appointments_routes_1.default);
}
else {
    app.use('/api/appointments', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), appointments_routes_1.default);
}
app.use('/api/medical-records', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), medical_records_routes_1.default);
app.use('/api/prescriptions', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), prescriptions_routes_1.default);
app.use('/api/medical-records', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), diagnosis_treatment_routes_1.default);
app.use('/api/lab-tests', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), lab_tests_routes_1.default);
app.use('/api/lab-orders', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), lab_orders_routes_1.default);
app.use('/api/lab-results', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), lab_results_routes_1.default);
app.use('/api/imaging', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), imaging_routes_1.default);
app.use('/api/lab-panels', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), lab_panels_routes_1.default);
app.use('/api/staff', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), staff_1.default);
app.use('/api/audit-logs', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), audit_1.default);
app.use('/api/storage', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), storage_1.default);
app.use('/api/lifecycle', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), lifecycle_1.default);
app.use('/api/templates', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), templates_1.default);
app.use('/api/staff-onboarding', staff_onboarding_1.default); // Public routes for staff onboarding
app.use('/api/notifications', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), notifications_1.default);
app.use('/api/clinical-notes', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), (0, clinicalNotes_1.createClinicalNotesRouter)(database_1.default));
app.use('/api/note-templates', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), (0, noteTemplates_1.createNoteTemplatesRouter)(database_1.default));
app.use('/api/imaging-reports', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), (0, imagingReports_1.createImagingReportsRouter)());
app.use('/api/emr-prescriptions', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), (0, prescriptions_1.createPrescriptionsRouter)());
app.use('/api/medical-history', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), (0, medicalHistory_1.createMedicalHistoryRouter)());
// Bed Management routes - Team Beta Sprint 1
app.use('/api/beds', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), bed_management_routes_1.default);
// Enhanced Bed Management routes - Real-time visualization and operations
app.use('/api/bed-management', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), bed_management_enhanced_1.default);
// Departments routes - Separate to avoid conflicts
app.use('/api/departments', tenant_1.tenantMiddleware, auth_2.hospitalAuthMiddleware, (0, authorization_1.requireApplicationAccess)('hospital_system'), departments_1.default);
// n8n AI Agent routes - Public access for chatbot (no tenant/auth required for chat widget)
app.use('/api/n8n', n8n_routes_1.default);
app.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const result = yield req.dbClient.query('SELECT NOW()');
        res.json({
            message: 'Hello, world! Tenant context is set.',
            timestamp: result.rows[0].now,
        });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'An error occurred' });
    }
}));
const errorHandler_1 = require("./middleware/errorHandler");
const server_1 = require("./websocket/server");
const notification_server_1 = require("./websocket/notification-server");
app.use(errorHandler_1.errorHandler);
const server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
// Initialize WebSocket servers
(0, server_1.initializeWebSocketServer)(server);
(0, notification_server_1.initializeNotificationWebSocket)(server);
