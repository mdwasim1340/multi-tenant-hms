"use strict";
/**
 * Bed Transfer Controller
 * HTTP request handlers for bed transfer endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPatientTransferHistory = exports.cancelBedTransfer = exports.completeBedTransfer = exports.updateBedTransfer = exports.createBedTransfer = exports.getBedTransferById = exports.getBedTransfers = void 0;
const bed_transfer_service_1 = __importDefault(require("../services/bed-transfer.service"));
const bed_validation_1 = require("../validation/bed.validation");
const bed_1 = require("../types/bed");
/**
 * GET /api/bed-transfers
 * List bed transfers with filtering
 */
const getBedTransfers = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Validate query parameters
        const params = bed_validation_1.BedTransferSearchSchema.parse(req.query);
        const result = yield bed_transfer_service_1.default.getBedTransfers(tenantId, params);
        res.json(result);
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Get transfers error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed transfers',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedTransfers = getBedTransfers;
/**
 * GET /api/bed-transfers/:id
 * Get bed transfer by ID
 */
const getBedTransferById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const transferId = parseInt(req.params.id);
        if (isNaN(transferId)) {
            return res.status(400).json({ error: 'Invalid transfer ID' });
        }
        const transfer = yield bed_transfer_service_1.default.getBedTransferById(tenantId, transferId);
        res.json({ transfer });
    }
    catch (error) {
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Get transfer error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed transfer',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedTransferById = getBedTransferById;
/**
 * POST /api/bed-transfers
 * Create bed transfer
 */
const createBedTransfer = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        // Validate request body
        const data = bed_validation_1.CreateBedTransferSchema.parse(req.body);
        const transfer = yield bed_transfer_service_1.default.createBedTransfer(tenantId, data, userId);
        res.status(201).json({
            message: 'Bed transfer initiated successfully',
            transfer,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.InvalidTransferError) {
            return res.status(400).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Create transfer error:', error);
        res.status(500).json({
            error: 'Failed to create bed transfer',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.createBedTransfer = createBedTransfer;
/**
 * PUT /api/bed-transfers/:id
 * Update bed transfer
 */
const updateBedTransfer = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const transferId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(transferId)) {
            return res.status(400).json({ error: 'Invalid transfer ID' });
        }
        // Validate request body
        const data = bed_validation_1.UpdateBedTransferSchema.parse(req.body);
        const transfer = yield bed_transfer_service_1.default.updateBedTransfer(tenantId, transferId, data, userId);
        res.json({
            message: 'Bed transfer updated successfully',
            transfer,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.InvalidTransferError) {
            return res.status(400).json({
                error: error.message,
                code: error.code,
            });
        }
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Update transfer error:', error);
        res.status(500).json({
            error: 'Failed to update bed transfer',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.updateBedTransfer = updateBedTransfer;
/**
 * POST /api/bed-transfers/:id/complete
 * Complete bed transfer
 */
const completeBedTransfer = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const transferId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(transferId)) {
            return res.status(400).json({ error: 'Invalid transfer ID' });
        }
        const transfer = yield bed_transfer_service_1.default.completeBedTransfer(tenantId, transferId, userId);
        res.json({
            message: 'Bed transfer completed successfully',
            transfer,
        });
    }
    catch (error) {
        if (error instanceof bed_1.InvalidTransferError) {
            return res.status(400).json({
                error: error.message,
                code: error.code,
            });
        }
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Complete transfer error:', error);
        res.status(500).json({
            error: 'Failed to complete bed transfer',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.completeBedTransfer = completeBedTransfer;
/**
 * POST /api/bed-transfers/:id/cancel
 * Cancel bed transfer
 */
const cancelBedTransfer = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const transferId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(transferId)) {
            return res.status(400).json({ error: 'Invalid transfer ID' });
        }
        // Validate request body
        const data = bed_validation_1.CancelBedTransferSchema.parse(req.body);
        const transfer = yield bed_transfer_service_1.default.cancelBedTransfer(tenantId, transferId, data.cancellation_reason, userId);
        res.json({
            message: 'Bed transfer cancelled successfully',
            transfer,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.InvalidTransferError) {
            return res.status(400).json({
                error: error.message,
                code: error.code,
            });
        }
        if (error instanceof Error && error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        console.error('Cancel transfer error:', error);
        res.status(500).json({
            error: 'Failed to cancel bed transfer',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.cancelBedTransfer = cancelBedTransfer;
/**
 * GET /api/bed-transfers/patient/:patientId/history
 * Get patient transfer history
 */
const getPatientTransferHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const history = yield bed_transfer_service_1.default.getPatientTransferHistory(tenantId, patientId);
        res.json({
            patient_id: patientId,
            history,
            count: history.length,
        });
    }
    catch (error) {
        console.error('Get patient transfer history error:', error);
        res.status(500).json({
            error: 'Failed to fetch patient transfer history',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getPatientTransferHistory = getPatientTransferHistory;
