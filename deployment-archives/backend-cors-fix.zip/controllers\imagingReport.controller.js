"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.searchImagingReports = exports.deleteReportFile = exports.getReportFiles = exports.addReportFile = exports.deleteImagingReport = exports.updateImagingReport = exports.getPatientImagingReports = exports.getImagingReports = exports.getImagingReport = exports.createImagingReport = void 0;
const zod_1 = require("zod");
const pg_1 = require("pg");
const imagingReport_service_1 = require("../services/imagingReport.service");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'multitenant_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});
const imagingReportService = new imagingReport_service_1.ImagingReportService(pool);
// Validation schemas
const CreateImagingReportSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    imaging_type: zod_1.z.string().min(1),
    body_part: zod_1.z.string().min(1).max(100).optional(),
    radiologist_id: zod_1.z.number().int().positive(),
    findings: zod_1.z.string().min(1),
    impression: zod_1.z.string().optional(),
    report_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    study_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    modality: zod_1.z.enum(['CT', 'MRI', 'X-Ray', 'Ultrasound', 'PET', 'Mammography', 'Fluoroscopy', 'Nuclear Medicine', 'Other']).optional(),
    contrast_used: zod_1.z.boolean().optional()
});
const UpdateImagingReportSchema = zod_1.z.object({
    imaging_type: zod_1.z.string().min(1).optional(),
    body_part: zod_1.z.string().min(1).max(100).optional(),
    findings: zod_1.z.string().min(1).optional(),
    impression: zod_1.z.string().optional(),
    status: zod_1.z.enum(['pending', 'completed', 'amended']).optional(),
    report_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    study_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    modality: zod_1.z.enum(['CT', 'MRI', 'X-Ray', 'Ultrasound', 'PET', 'Mammography', 'Fluoroscopy', 'Nuclear Medicine', 'Other']).optional(),
    contrast_used: zod_1.z.boolean().optional()
});
const AddReportFileSchema = zod_1.z.object({
    file_name: zod_1.z.string().min(1),
    file_type: zod_1.z.string().min(1),
    file_size: zod_1.z.number().int().positive(),
    s3_key: zod_1.z.string().min(1),
    s3_url: zod_1.z.string().url()
});
const createImagingReport = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Get user ID from auth - can be number or UUID string from Cognito
        const user = req.user;
        const userId = (user === null || user === void 0 ? void 0 : user.id) || (user === null || user === void 0 ? void 0 : user.sub) || (user === null || user === void 0 ? void 0 : user.userId) || 1; // Default to 1 if not found
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Convert userId to number if it's a valid number string, otherwise use 1
        const numericUserId = typeof userId === 'number' ? userId : (parseInt(userId) || 1);
        const validated = CreateImagingReportSchema.parse(req.body);
        const report = yield imagingReportService.createReport(tenantId, validated, numericUserId);
        res.status(201).json(report);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error creating imaging report:', error);
        res.status(500).json({ error: 'Failed to create imaging report' });
    }
});
exports.createImagingReport = createImagingReport;
const getImagingReport = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const reportId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(reportId)) {
            return res.status(400).json({ error: 'Invalid report ID' });
        }
        const report = yield imagingReportService.getReportById(tenantId, reportId);
        if (!report) {
            return res.status(404).json({ error: 'Imaging report not found' });
        }
        res.json(report);
    }
    catch (error) {
        console.error('Error fetching imaging report:', error);
        res.status(500).json({ error: 'Failed to fetch imaging report' });
    }
});
exports.getImagingReport = getImagingReport;
const getImagingReports = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        const filters = {
            patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
            imaging_type: req.query.imaging_type,
            body_part: req.query.body_part,
            status: req.query.status,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 10
        };
        const result = yield imagingReportService.getReports(tenantId, filters);
        res.json({
            reports: result.reports,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error fetching imaging reports:', error);
        res.status(500).json({ error: 'Failed to fetch imaging reports' });
    }
});
exports.getImagingReports = getImagingReports;
const getPatientImagingReports = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const filters = {
            imaging_type: req.query.imaging_type,
            body_part: req.query.body_part,
            status: req.query.status,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 10
        };
        const result = yield imagingReportService.getReportsByPatient(tenantId, patientId, filters);
        res.json({
            reports: result.reports,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error fetching patient imaging reports:', error);
        res.status(500).json({ error: 'Failed to fetch imaging reports' });
    }
});
exports.getPatientImagingReports = getPatientImagingReports;
const updateImagingReport = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const reportId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(reportId)) {
            return res.status(400).json({ error: 'Invalid report ID' });
        }
        const validated = UpdateImagingReportSchema.parse(req.body);
        const report = yield imagingReportService.updateReport(tenantId, reportId, validated, userId);
        if (!report) {
            return res.status(404).json({ error: 'Imaging report not found' });
        }
        res.json(report);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error updating imaging report:', error);
        res.status(500).json({ error: 'Failed to update imaging report' });
    }
});
exports.updateImagingReport = updateImagingReport;
const deleteImagingReport = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const reportId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(reportId)) {
            return res.status(400).json({ error: 'Invalid report ID' });
        }
        const deleted = yield imagingReportService.deleteReport(tenantId, reportId);
        if (!deleted) {
            return res.status(404).json({ error: 'Imaging report not found' });
        }
        res.status(204).send();
    }
    catch (error) {
        console.error('Error deleting imaging report:', error);
        res.status(500).json({ error: 'Failed to delete imaging report' });
    }
});
exports.deleteImagingReport = deleteImagingReport;
const addReportFile = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const reportId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(reportId)) {
            return res.status(400).json({ error: 'Invalid report ID' });
        }
        const validated = AddReportFileSchema.parse(req.body);
        const file = yield imagingReportService.addReportFile(tenantId, reportId, validated, userId);
        res.status(201).json(file);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error adding report file:', error);
        res.status(500).json({ error: 'Failed to add report file' });
    }
});
exports.addReportFile = addReportFile;
const getReportFiles = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const reportId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(reportId)) {
            return res.status(400).json({ error: 'Invalid report ID' });
        }
        const files = yield imagingReportService.getReportFiles(tenantId, reportId);
        res.json({ files });
    }
    catch (error) {
        console.error('Error fetching report files:', error);
        res.status(500).json({ error: 'Failed to fetch report files' });
    }
});
exports.getReportFiles = getReportFiles;
const deleteReportFile = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const fileId = parseInt(req.params.fileId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(fileId)) {
            return res.status(400).json({ error: 'Invalid file ID' });
        }
        const deleted = yield imagingReportService.deleteReportFile(tenantId, fileId);
        if (!deleted) {
            return res.status(404).json({ error: 'Report file not found' });
        }
        res.status(204).send();
    }
    catch (error) {
        console.error('Error deleting report file:', error);
        res.status(500).json({ error: 'Failed to delete report file' });
    }
});
exports.deleteReportFile = deleteReportFile;
const searchImagingReports = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const searchTerm = req.query.q;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!searchTerm) {
            return res.status(400).json({ error: 'Search term (q) is required' });
        }
        const filters = {
            imaging_type: req.query.imaging_type,
            status: req.query.status,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 10
        };
        const result = yield imagingReportService.searchReports(tenantId, searchTerm, filters);
        res.json({
            reports: result.reports,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error searching imaging reports:', error);
        res.status(500).json({ error: 'Failed to search imaging reports' });
    }
});
exports.searchImagingReports = searchImagingReports;
