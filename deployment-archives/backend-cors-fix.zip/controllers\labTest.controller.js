"use strict";
/**
 * Lab Test Controller
 *
 * HTTP request handlers for laboratory test management
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabTests = getLabTests;
exports.getLabTestById = getLabTestById;
exports.createLabTest = createLabTest;
exports.updateLabTest = updateLabTest;
exports.deactivateLabTest = deactivateLabTest;
exports.getLabTestCategories = getLabTestCategories;
exports.getSpecimenTypes = getSpecimenTypes;
const labTestService = __importStar(require("../services/labTest.service"));
const labTest_1 = require("../types/labTest");
/**
 * GET /api/lab-tests
 * Get all lab tests with optional filtering
 */
function getLabTests(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const filters = {
                category_id: req.query.category_id ? parseInt(req.query.category_id) : undefined,
                specimen_type: req.query.specimen_type,
                status: req.query.status,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 50
            };
            const result = yield labTestService.getLabTests(tenantId, filters);
            res.json(result);
        }
        catch (error) {
            console.error('Error getting lab tests:', error);
            res.status(500).json({ error: 'Failed to get lab tests' });
        }
    });
}
/**
 * GET /api/lab-tests/:id
 * Get lab test by ID
 */
function getLabTestById(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const testId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(testId)) {
                res.status(400).json({ error: 'Invalid test ID' });
                return;
            }
            const test = yield labTestService.getLabTestById(tenantId, testId);
            if (!test) {
                res.status(404).json({ error: 'Lab test not found' });
                return;
            }
            res.json(test);
        }
        catch (error) {
            console.error('Error getting lab test:', error);
            res.status(500).json({ error: 'Failed to get lab test' });
        }
    });
}
/**
 * POST /api/lab-tests
 * Create new lab test (admin only)
 */
function createLabTest(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.LabTestSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            // Check if test code already exists
            const existingTest = yield labTestService.getLabTestByCode(tenantId, req.body.test_code);
            if (existingTest) {
                res.status(409).json({ error: 'Test code already exists' });
                return;
            }
            const test = yield labTestService.createLabTest(tenantId, validationResult.data);
            res.status(201).json({
                message: 'Lab test created successfully',
                test
            });
        }
        catch (error) {
            console.error('Error creating lab test:', error);
            res.status(500).json({ error: 'Failed to create lab test' });
        }
    });
}
/**
 * PUT /api/lab-tests/:id
 * Update lab test (admin only)
 */
function updateLabTest(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const testId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(testId)) {
                res.status(400).json({ error: 'Invalid test ID' });
                return;
            }
            // Validate request body (partial)
            const validationResult = labTest_1.LabTestSchema.partial().safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const test = yield labTestService.updateLabTest(tenantId, testId, validationResult.data);
            if (!test) {
                res.status(404).json({ error: 'Lab test not found' });
                return;
            }
            res.json({
                message: 'Lab test updated successfully',
                test
            });
        }
        catch (error) {
            console.error('Error updating lab test:', error);
            res.status(500).json({ error: 'Failed to update lab test' });
        }
    });
}
/**
 * DELETE /api/lab-tests/:id
 * Deactivate lab test (admin only)
 */
function deactivateLabTest(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const testId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(testId)) {
                res.status(400).json({ error: 'Invalid test ID' });
                return;
            }
            const success = yield labTestService.deactivateLabTest(tenantId, testId);
            if (!success) {
                res.status(404).json({ error: 'Lab test not found' });
                return;
            }
            res.json({ message: 'Lab test deactivated successfully' });
        }
        catch (error) {
            console.error('Error deactivating lab test:', error);
            res.status(500).json({ error: 'Failed to deactivate lab test' });
        }
    });
}
/**
 * GET /api/lab-tests/categories
 * Get all test categories
 */
function getLabTestCategories(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const categories = yield labTestService.getLabTestCategories(tenantId);
            res.json({ categories });
        }
        catch (error) {
            console.error('Error getting lab test categories:', error);
            res.status(500).json({ error: 'Failed to get lab test categories' });
        }
    });
}
/**
 * GET /api/lab-tests/specimen-types
 * Get all specimen types
 */
function getSpecimenTypes(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const specimenTypes = yield labTestService.getSpecimenTypes(tenantId);
            res.json({ specimen_types: specimenTypes });
        }
        catch (error) {
            console.error('Error getting specimen types:', error);
            res.status(500).json({ error: 'Failed to get specimen types' });
        }
    });
}
