"use strict";
/**
 * Lab Test Service
 * Business logic for managing laboratory tests and test categories
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabTests = getLabTests;
exports.getLabTestById = getLabTestById;
exports.getLabTestByCode = getLabTestByCode;
exports.getLabTestsByCategory = getLabTestsByCategory;
exports.createLabTest = createLabTest;
exports.updateLabTest = updateLabTest;
exports.deactivateLabTest = deactivateLabTest;
exports.getLabTestCategories = getLabTestCategories;
exports.getLabTestCategoryById = getLabTestCategoryById;
exports.getSpecimenTypes = getSpecimenTypes;
const database_1 = __importDefault(require("../database"));
function getLabTests(tenantId_1) {
    return __awaiter(this, arguments, void 0, function* (tenantId, filters = {}) {
        const { category_id, specimen_type, status = 'active', search, page = 1, limit = 50 } = filters;
        const offset = (page - 1) * limit;
        // Set schema context
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        // Simple query without dynamic filters for now
        let query = `
    SELECT lt.*, ltc.name as category_name 
    FROM lab_test_definitions lt 
    LEFT JOIN lab_test_categories ltc ON lt.category_id = ltc.id 
    WHERE lt.status = $1 
    ORDER BY lt.test_name ASC 
    LIMIT $2 OFFSET $3
  `;
        const result = yield database_1.default.query(query, [status, limit, offset]);
        // Get total count
        const countResult = yield database_1.default.query(`SELECT COUNT(*) as total FROM lab_test_definitions WHERE status = $1`, [status]);
        const total = parseInt(countResult.rows[0].total);
        return {
            tests: result.rows,
            pagination: { page, limit, total, pages: Math.ceil(total / limit) }
        };
    });
}
function getLabTestById(tenantId, testId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query(`SELECT lt.*, ltc.name as category_name FROM lab_test_definitions lt LEFT JOIN lab_test_categories ltc ON lt.category_id = ltc.id WHERE lt.id = $1`, [testId]);
        return result.rows[0] || null;
    });
}
function getLabTestByCode(tenantId, testCode) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query('SELECT * FROM lab_test_definitions WHERE test_code = $1', [testCode]);
        return result.rows[0] || null;
    });
}
function getLabTestsByCategory(tenantId, categoryId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query('SELECT * FROM lab_test_definitions WHERE category_id = $1 AND status = $2 ORDER BY test_name ASC', [categoryId, 'active']);
        return result.rows;
    });
}
function createLabTest(tenantId, testData) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const { category_id, test_code, test_name, description, normal_range_min, normal_range_max, normal_range_text, unit, specimen_type, price, turnaround_time, preparation_instructions, status = 'active' } = testData;
        const result = yield database_1.default.query('INSERT INTO lab_test_definitions (category_id, test_code, test_name, description, normal_range_min, normal_range_max, normal_range_text, unit, specimen_type, price, turnaround_time, preparation_instructions, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *', [category_id, test_code, test_name, description, normal_range_min, normal_range_max, normal_range_text, unit, specimen_type, price, turnaround_time, preparation_instructions, status]);
        return result.rows[0];
    });
}
function updateLabTest(tenantId, testId, testData) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const updates = [];
        const params = [];
        let idx = 1;
        const fields = ['category_id', 'test_name', 'description', 'normal_range_min', 'normal_range_max', 'normal_range_text', 'unit', 'specimen_type', 'price', 'turnaround_time', 'preparation_instructions', 'status'];
        for (const f of fields) {
            if (f in testData) {
                updates.push(`${f} = $${idx}`);
                params.push(testData[f]);
                idx++;
            }
        }
        if (updates.length === 0)
            return getLabTestById(tenantId, testId);
        params.push(testId);
        const result = yield database_1.default.query(`UPDATE lab_test_definitions SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${idx} RETURNING *`, params);
        return result.rows[0] || null;
    });
}
function deactivateLabTest(tenantId, testId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query('UPDATE lab_test_definitions SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', ['inactive', testId]);
        return (result.rowCount || 0) > 0;
    });
}
function getLabTestCategories(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query('SELECT * FROM lab_test_categories WHERE is_active = true ORDER BY display_order ASC, name ASC');
        return result.rows;
    });
}
function getLabTestCategoryById(tenantId, categoryId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query('SELECT * FROM lab_test_categories WHERE id = $1', [categoryId]);
        return result.rows[0] || null;
    });
}
function getSpecimenTypes(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query(`SELECT DISTINCT specimen_type FROM lab_test_definitions WHERE specimen_type IS NOT NULL AND status = 'active' ORDER BY specimen_type ASC`);
        return result.rows.map(row => row.specimen_type);
    });
}
