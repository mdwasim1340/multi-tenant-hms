"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PatientSearchSchema = exports.UpdatePatientSchema = exports.CreatePatientSchema = void 0;
const zod_1 = require("zod");
// Base patient schema with all fields
const PatientBaseSchema = zod_1.z.object({
    patient_number: zod_1.z.string().min(1).max(50),
    first_name: zod_1.z.string().min(1).max(255),
    last_name: zod_1.z.string().min(1).max(255),
    middle_name: zod_1.z.string().max(255).optional(),
    preferred_name: zod_1.z.string().max(255).optional(),
    email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
    phone: zod_1.z.string().max(50).optional(),
    mobile_phone: zod_1.z.string().max(50).optional(),
    date_of_birth: zod_1.z.string().datetime(),
    gender: zod_1.z.enum(['male', 'female', 'other', 'prefer_not_to_say']).optional(),
    marital_status: zod_1.z.string().max(50).optional(),
    occupation: zod_1.z.string().max(255).optional(),
    address_line_1: zod_1.z.string().optional(),
    address_line_2: zod_1.z.string().optional(),
    city: zod_1.z.string().max(255).optional(),
    state: zod_1.z.string().max(255).optional(),
    postal_code: zod_1.z.string().max(20).optional(),
    country: zod_1.z.string().max(255).optional(),
    emergency_contact_name: zod_1.z.string().max(255).optional(),
    emergency_contact_relationship: zod_1.z.string().max(100).optional(),
    emergency_contact_phone: zod_1.z.string().max(50).optional(),
    emergency_contact_email: zod_1.z.string().email().optional().or(zod_1.z.literal('')).nullable(),
    blood_type: zod_1.z.enum(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']).optional().nullable(),
    allergies: zod_1.z.string().optional().nullable(),
    current_medications: zod_1.z.string().optional().nullable(),
    medical_history: zod_1.z.string().optional().nullable(),
    family_medical_history: zod_1.z.string().optional().nullable(),
    insurance_provider: zod_1.z.string().max(255).optional().nullable(),
    insurance_policy_number: zod_1.z.string().max(100).optional().nullable(),
    insurance_group_number: zod_1.z.string().max(100).optional().nullable(),
    insurance_info: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional().nullable(),
    status: zod_1.z.enum(['active', 'inactive', 'deceased', 'transferred']).default('active'),
    notes: zod_1.z.string().optional().nullable(),
    custom_fields: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional()
});
// Schema for creating a new patient (requires specific fields)
exports.CreatePatientSchema = zod_1.z.object({
    patient_number: zod_1.z.string().min(1).max(50),
    first_name: zod_1.z.string().min(1).max(255),
    last_name: zod_1.z.string().min(1).max(255),
    date_of_birth: zod_1.z.union([
        zod_1.z.string().datetime(),
        zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)
    ])
}).merge(PatientBaseSchema.partial().omit({
    patient_number: true,
    first_name: true,
    last_name: true,
    date_of_birth: true
}));
// Schema for updating a patient (all fields optional except patient_number cannot be changed)
exports.UpdatePatientSchema = PatientBaseSchema.partial().omit({
    patient_number: true
});
// Schema for search query parameters
exports.PatientSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().min(1).default(1),
    limit: zod_1.z.coerce.number().min(1).max(100).default(10),
    search: zod_1.z.string().optional(),
    status: zod_1.z.enum(['active', 'inactive', 'deceased', 'transferred']).optional(),
    gender: zod_1.z.enum(['male', 'female', 'other', 'prefer_not_to_say']).optional(),
    age_min: zod_1.z.coerce.number().min(0).max(150).optional(),
    age_max: zod_1.z.coerce.number().min(0).max(150).optional(),
    city: zod_1.z.string().optional(),
    state: zod_1.z.string().optional(),
    blood_type: zod_1.z.enum(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']).optional(),
    sort_by: zod_1.z.enum(['first_name', 'last_name', 'patient_number', 'date_of_birth', 'created_at']).default('created_at'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc'),
    created_at_from: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    created_at_to: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    custom_field_filters: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional()
});
