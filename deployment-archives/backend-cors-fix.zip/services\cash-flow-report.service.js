"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashFlowReportService = void 0;
const comparison_service_1 = require("./comparison.service");
/**
 * Service for generating Cash Flow Statement reports
 *
 * Validates: Requirements 9.1, 9.2, 9.3, 10.1, 10.2, 11.1, 11.2
 */
class CashFlowReportService {
    constructor(pool) {
        this.pool = pool;
        this.comparisonService = new comparison_service_1.ComparisonService();
    }
    /**
     * Generate a complete Cash Flow report
     *
     * Property: For any period, net cash flow = total inflows - total outflows
     * Validates: Requirements 9.1, 9.2, 9.3
     */
    generateReport(tenantId, params) {
        return __awaiter(this, void 0, void 0, function* () {
            // Validate date range
            const startDate = new Date(params.start_date);
            const endDate = new Date(params.end_date);
            if (startDate > endDate) {
                throw new Error('Start date must be before or equal to end date');
            }
            // Get beginning cash balance (cash at start of period)
            const beginningCash = yield this.getCashBalance(tenantId, params.start_date);
            // Calculate cash flows for each activity type
            const [operatingActivities, investingActivities, financingActivities] = yield Promise.all([
                this.calculateOperatingActivities(tenantId, params.start_date, params.end_date, params.department_id),
                this.calculateInvestingActivities(tenantId, params.start_date, params.end_date, params.department_id),
                this.calculateFinancingActivities(tenantId, params.start_date, params.end_date, params.department_id)
            ]);
            // Calculate total net cash flow
            const netCashFlow = operatingActivities.net +
                investingActivities.net +
                financingActivities.net;
            // Calculate ending cash balance
            const endingCash = beginningCash + netCashFlow;
            // Build the report
            const report = {
                reportType: 'cash-flow',
                period: {
                    startDate: params.start_date,
                    endDate: params.end_date
                },
                departmentId: params.department_id,
                operatingActivities,
                investingActivities,
                financingActivities,
                netCashFlow,
                beginningCash,
                endingCash,
                generatedAt: new Date().toISOString(),
                generatedBy: params.generated_by || 'system'
            };
            // Optionally save to audit log
            if (params.save_to_audit) {
                yield this.saveToAuditLog(tenantId, report);
            }
            return report;
        });
    }
    /**
     * Calculate operating activities cash flow
     *
     * Property: Operating net = Operating inflows - Operating outflows
     * Validates: Requirements 9.2, 10.1
     */
    calculateOperatingActivities(tenantId, startDate, endDate, departmentId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Build WHERE clause
                const conditions = [
                    'billing_period_start >= $1',
                    'billing_period_end <= $2',
                    'status = $3'
                ];
                const params = [startDate, endDate, 'paid'];
                let paramIndex = 4;
                if (departmentId) {
                    conditions.push(`department = $${paramIndex}`);
                    params.push(departmentId);
                    paramIndex++;
                }
                const whereClause = conditions.join(' AND ');
                // Get cash inflows from payments
                const inflowsQuery = `
        SELECT 
          COALESCE(SUM(CASE WHEN payment_method = 'cash' THEN amount ELSE 0 END), 0) as patient_payments,
          COALESCE(SUM(CASE WHEN payment_method = 'insurance' THEN amount ELSE 0 END), 0) as insurance_reimbursements,
          COALESCE(SUM(CASE WHEN payment_method NOT IN ('cash', 'insurance') THEN amount ELSE 0 END), 0) as other
        FROM invoices
        WHERE ${whereClause}
      `;
                const inflowsResult = yield client.query(inflowsQuery, params);
                const inflowsRow = inflowsResult.rows[0];
                const inflows = {
                    patientPayments: parseFloat(inflowsRow.patient_payments) || 0,
                    insuranceReimbursements: parseFloat(inflowsRow.insurance_reimbursements) || 0,
                    other: parseFloat(inflowsRow.other) || 0,
                    total: 0
                };
                inflows.total = inflows.patientPayments + inflows.insuranceReimbursements + inflows.other;
                // Get cash outflows from operating expenses
                const expenseConditions = [
                    'expense_date >= $1',
                    'expense_date <= $2',
                    'expense_type IN ($3, $4, $5)' // Operating expenses only
                ];
                const expenseParams = [startDate, endDate, 'salary', 'supplies', 'utilities'];
                let expenseParamIndex = 6;
                if (departmentId) {
                    expenseConditions.push(`department_id = $${expenseParamIndex}`);
                    expenseParams.push(departmentId);
                    expenseParamIndex++;
                }
                const expenseWhereClause = expenseConditions.join(' AND ');
                const outflowsQuery = `
        SELECT 
          COALESCE(SUM(CASE WHEN expense_type = 'salary' THEN amount ELSE 0 END), 0) as salaries,
          COALESCE(SUM(CASE WHEN expense_type = 'supplies' THEN amount ELSE 0 END), 0) as supplies,
          COALESCE(SUM(CASE WHEN expense_type = 'utilities' THEN amount ELSE 0 END), 0) as utilities,
          0 as equipment_purchases,
          0 as loan_repayments,
          0 as other
        FROM expenses
        WHERE ${expenseWhereClause}
      `;
                const outflowsResult = yield client.query(outflowsQuery, expenseParams);
                const outflowsRow = outflowsResult.rows[0];
                const outflows = {
                    salaries: parseFloat(outflowsRow.salaries) || 0,
                    supplies: parseFloat(outflowsRow.supplies) || 0,
                    utilities: parseFloat(outflowsRow.utilities) || 0,
                    equipmentPurchases: 0,
                    loanRepayments: 0,
                    other: 0,
                    total: 0
                };
                outflows.total = outflows.salaries + outflows.supplies + outflows.utilities;
                const net = inflows.total - outflows.total;
                return {
                    inflows,
                    outflows,
                    net
                };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Calculate investing activities cash flow
     *
     * Property: Investing net = Investing inflows - Investing outflows
     * Validates: Requirements 9.3, 10.2
     */
    calculateInvestingActivities(tenantId, startDate, endDate, departmentId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Investing inflows (asset sales - not common in hospitals)
                const inflows = {
                    patientPayments: 0,
                    insuranceReimbursements: 0,
                    other: 0,
                    total: 0
                };
                // Investing outflows (equipment purchases, capital expenditures)
                const conditions = [
                    'expense_date >= $1',
                    'expense_date <= $2',
                    'expense_type = $3' // maintenance as proxy for capital expenditures
                ];
                const params = [startDate, endDate, 'maintenance'];
                let paramIndex = 4;
                if (departmentId) {
                    conditions.push(`department_id = $${paramIndex}`);
                    params.push(departmentId);
                    paramIndex++;
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        SELECT COALESCE(SUM(amount), 0) as equipment_purchases
        FROM expenses
        WHERE ${whereClause}
      `;
                const result = yield client.query(query, params);
                const equipmentPurchases = parseFloat(result.rows[0].equipment_purchases) || 0;
                const outflows = {
                    salaries: 0,
                    supplies: 0,
                    utilities: 0,
                    equipmentPurchases,
                    loanRepayments: 0,
                    other: 0,
                    total: equipmentPurchases
                };
                const net = inflows.total - outflows.total;
                return {
                    inflows,
                    outflows,
                    net
                };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Calculate financing activities cash flow
     *
     * Property: Financing net = Financing inflows - Financing outflows
     * Validates: Requirements 9.3, 10.2
     */
    calculateFinancingActivities(tenantId, startDate, endDate, departmentId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Financing inflows (loans received - would need a loans table)
                const inflows = {
                    patientPayments: 0,
                    insuranceReimbursements: 0,
                    other: 0,
                    total: 0
                };
                // Financing outflows (loan repayments from liabilities table)
                const conditions = [
                    'as_of_date >= $1',
                    'as_of_date <= $2',
                    'liability_type IN ($3, $4)' // loans and mortgages
                ];
                const params = [startDate, endDate, 'loan', 'mortgage'];
                let paramIndex = 5;
                if (departmentId) {
                    conditions.push(`department_id = $${paramIndex}`);
                    params.push(departmentId);
                    paramIndex++;
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        SELECT COALESCE(SUM(amount), 0) as loan_repayments
        FROM liabilities
        WHERE ${whereClause}
      `;
                const result = yield client.query(query, params);
                const loanRepayments = parseFloat(result.rows[0].loan_repayments) || 0;
                const outflows = {
                    salaries: 0,
                    supplies: 0,
                    utilities: 0,
                    equipmentPurchases: 0,
                    loanRepayments,
                    other: 0,
                    total: loanRepayments
                };
                const net = inflows.total - outflows.total;
                return {
                    inflows,
                    outflows,
                    net
                };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get cash balance at a specific date
     *
     * Validates: Requirements 11.1, 11.2
     */
    getCashBalance(tenantId, asOfDate) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const client = yield this.pool.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Get cash from assets table - get the most recent cash balance as of the date
                const query = `
        SELECT COALESCE(value, 0) as cash_balance
        FROM assets
        WHERE asset_type = 'cash'
          AND as_of_date <= $1
        ORDER BY as_of_date DESC
        LIMIT 1
      `;
                const result = yield client.query(query, [asOfDate]);
                return parseFloat((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.cash_balance) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Compare two periods for trend analysis
     *
     * Property: For any two periods, percentage change is calculated consistently
     * Validates: Requirements 11.1, 11.2
     */
    comparePeriods(tenantId, currentPeriod, previousPeriod, generatedBy) {
        return __awaiter(this, void 0, void 0, function* () {
            // Generate reports for both periods
            const [currentReport, previousReport] = yield Promise.all([
                this.generateReport(tenantId, {
                    start_date: currentPeriod.start_date,
                    end_date: currentPeriod.end_date,
                    generated_by: generatedBy,
                    save_to_audit: false
                }),
                this.generateReport(tenantId, {
                    start_date: previousPeriod.start_date,
                    end_date: previousPeriod.end_date,
                    generated_by: generatedBy,
                    save_to_audit: false
                })
            ]);
            // Calculate changes
            const netCashFlowChange = currentReport.netCashFlow - previousReport.netCashFlow;
            const netCashFlowChangePercent = previousReport.netCashFlow !== 0
                ? (netCashFlowChange / Math.abs(previousReport.netCashFlow)) * 100
                : 0;
            const endingCashChange = currentReport.endingCash - previousReport.endingCash;
            const endingCashChangePercent = previousReport.endingCash > 0
                ? (endingCashChange / previousReport.endingCash) * 100
                : 0;
            return {
                current: currentReport,
                previous: previousReport,
                changes: {
                    net_cash_flow_change: netCashFlowChange,
                    net_cash_flow_change_percent: netCashFlowChangePercent,
                    ending_cash_change: endingCashChange,
                    ending_cash_change_percent: endingCashChangePercent
                }
            };
        });
    }
    /**
     * Get monthly cash flow breakdown for a year
     *
     * Property: For any year, sum of monthly net cash flows equals annual net cash flow
     * Validates: Requirements 11.1
     */
    getMonthlyBreakdown(tenantId, year, generatedBy) {
        return __awaiter(this, void 0, void 0, function* () {
            const reports = [];
            for (let month = 0; month < 12; month++) {
                const startDate = new Date(year, month, 1);
                const endDate = new Date(year, month + 1, 0); // Last day of month
                const report = yield this.generateReport(tenantId, {
                    start_date: startDate.toISOString().split('T')[0],
                    end_date: endDate.toISOString().split('T')[0],
                    generated_by: generatedBy,
                    save_to_audit: false
                });
                reports.push(report);
            }
            return reports;
        });
    }
    /**
     * Save report to audit log
     *
     * Validates: Requirements 12.1, 12.2
     */
    saveToAuditLog(tenantId, report) {
        return __awaiter(this, void 0, void 0, function* () {
            // Ensure tenant schema has proper prefix
            const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
            yield this.pool.query(`SET search_path TO "${schemaName}", public`);
            yield this.pool.query(`INSERT INTO balance_report_audit_logs (
        tenant_id,
        user_id,
        user_name,
        report_type,
        parameters,
        generated_at,
        success
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)`, [
                tenantId,
                1, // Default user ID
                report.generatedBy || 'system',
                'cash-flow',
                JSON.stringify({
                    period: report.period,
                    departmentId: report.departmentId
                }),
                report.generatedAt,
                true
            ]);
        });
    }
    /**
     * Get historical reports from audit log
     *
     * Validates: Requirements 12.1, 12.2
     */
    getHistoricalReports(tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, limit = 10) {
            // Ensure tenant schema has proper prefix
            const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
            yield this.pool.query(`SET search_path TO "${schemaName}", public`);
            const result = yield this.pool.query(`SELECT * 
       FROM balance_report_audit_logs 
       WHERE report_type = 'cash-flow'
       ORDER BY generated_at DESC
       LIMIT $1`, [limit]);
            return result.rows;
        });
    }
}
exports.CashFlowReportService = CashFlowReportService;
