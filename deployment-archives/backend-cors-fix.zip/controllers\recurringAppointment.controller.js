"use strict";
/**
 * Team Alpha - Recurring Appointment Controller
 * HTTP request handlers for recurring appointments
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelRecurringAppointment = exports.updateRecurringAppointment = exports.getRecurringAppointmentById = exports.getRecurringAppointments = exports.createRecurringAppointment = void 0;
const recurringAppointment_service_1 = require("../services/recurringAppointment.service");
const errorHandler_1 = require("../middleware/errorHandler");
const AppError_1 = require("../errors/AppError");
const pg_1 = require("pg");
const zod_1 = require("zod");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
});
const recurringAppointmentService = new recurringAppointment_service_1.RecurringAppointmentService(pool);
// Validation schemas
const CreateRecurringAppointmentSchema = zod_1.z.object({
    patient_id: zod_1.z.number(),
    doctor_id: zod_1.z.number(),
    recurrence_pattern: zod_1.z.enum(['daily', 'weekly', 'monthly', 'custom']),
    recurrence_interval: zod_1.z.number().min(1).optional().default(1),
    recurrence_days: zod_1.z.string().optional(),
    recurrence_day_of_month: zod_1.z.number().min(1).max(31).optional(),
    start_date: zod_1.z.string(),
    end_date: zod_1.z.string().optional(),
    max_occurrences: zod_1.z.number().min(1).optional(),
    start_time: zod_1.z.string(),
    duration_minutes: zod_1.z.number().min(5).optional().default(30),
    appointment_type: zod_1.z.string(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
    estimated_cost: zod_1.z.number().optional(),
});
const UpdateRecurringAppointmentSchema = zod_1.z.object({
    recurrence_pattern: zod_1.z.enum(['daily', 'weekly', 'monthly', 'custom']).optional(),
    recurrence_interval: zod_1.z.number().min(1).optional(),
    recurrence_days: zod_1.z.string().optional(),
    recurrence_day_of_month: zod_1.z.number().min(1).max(31).optional(),
    end_date: zod_1.z.string().optional(),
    max_occurrences: zod_1.z.number().min(1).optional(),
    start_time: zod_1.z.string().optional(),
    duration_minutes: zod_1.z.number().min(5).optional(),
    appointment_type: zod_1.z.string().optional(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
    estimated_cost: zod_1.z.number().optional(),
    status: zod_1.z.enum(['active', 'paused', 'cancelled', 'completed']).optional(),
});
const RecurringAppointmentSearchSchema = zod_1.z.object({
    page: zod_1.z.number().min(1).optional().default(1),
    limit: zod_1.z.number().min(1).max(100).optional().default(10),
    patient_id: zod_1.z.number().optional(),
    doctor_id: zod_1.z.number().optional(),
    status: zod_1.z.enum(['active', 'paused', 'cancelled', 'completed']).optional(),
    recurrence_pattern: zod_1.z.enum(['daily', 'weekly', 'monthly', 'custom']).optional(),
});
// POST /api/appointments/recurring - Create recurring appointment
exports.createRecurringAppointment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    // Validate request body
    const validatedData = CreateRecurringAppointmentSchema.parse(req.body);
    // Create recurring appointment
    const result = yield recurringAppointmentService.createRecurringAppointment(validatedData, tenantId, userId);
    res.status(201).json({
        success: true,
        data: {
            recurring_appointment: result.recurring,
            instances_created: result.instances.length,
            instances: result.instances.slice(0, 5), // Return first 5 instances
        },
        message: `Recurring appointment created successfully. ${result.instances.length} appointments scheduled.`,
    });
}));
// GET /api/appointments/recurring - List recurring appointments
exports.getRecurringAppointments = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    // Validate query parameters
    const query = RecurringAppointmentSearchSchema.parse({
        page: req.query.page ? parseInt(req.query.page) : 1,
        limit: req.query.limit ? parseInt(req.query.limit) : 10,
        patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
        doctor_id: req.query.doctor_id ? parseInt(req.query.doctor_id) : undefined,
        status: req.query.status,
        recurrence_pattern: req.query.recurrence_pattern,
    });
    const { page, limit, patient_id, doctor_id, status, recurrence_pattern } = query;
    const offset = (page - 1) * limit;
    const client = yield pool.connect();
    try {
        yield client.query(`SET search_path TO "${tenantId}"`);
        let whereConditions = ['1=1'];
        let queryParams = [];
        let paramIndex = 1;
        // Patient filter
        if (patient_id) {
            whereConditions.push(`ra.patient_id = $${paramIndex}`);
            queryParams.push(patient_id);
            paramIndex++;
        }
        // Doctor filter
        if (doctor_id) {
            whereConditions.push(`ra.doctor_id = $${paramIndex}`);
            queryParams.push(doctor_id);
            paramIndex++;
        }
        // Status filter
        if (status) {
            whereConditions.push(`ra.status = $${paramIndex}`);
            queryParams.push(status);
            paramIndex++;
        }
        // Pattern filter
        if (recurrence_pattern) {
            whereConditions.push(`ra.recurrence_pattern = $${paramIndex}`);
            queryParams.push(recurrence_pattern);
            paramIndex++;
        }
        const whereClause = whereConditions.join(' AND ');
        // Get recurring appointments with patient and doctor info
        const recurringQuery = `
        SELECT 
          ra.*,
          json_build_object(
            'id', p.id,
            'first_name', p.first_name,
            'last_name', p.last_name,
            'patient_number', p.patient_number,
            'phone', p.phone,
            'email', p.email
          ) as patient,
          json_build_object(
            'id', u.id,
            'name', u.name,
            'email', u.email
          ) as doctor
        FROM recurring_appointments ra
        JOIN patients p ON p.id = ra.patient_id
        LEFT JOIN public.users u ON u.id = ra.doctor_id
        WHERE ${whereClause}
        ORDER BY ra.created_at DESC
        LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
      `;
        queryParams.push(limit, offset);
        // Get total count
        const countQuery = `
        SELECT COUNT(*) as total
        FROM recurring_appointments ra
        WHERE ${whereClause}
      `;
        const [recurringResult, countResult] = yield Promise.all([
            client.query(recurringQuery, queryParams),
            client.query(countQuery, queryParams.slice(0, -2)),
        ]);
        const recurring_appointments = recurringResult.rows;
        const total = parseInt(countResult.rows[0].total);
        const pages = Math.ceil(total / limit);
        res.json({
            success: true,
            data: {
                recurring_appointments,
                pagination: {
                    page,
                    limit,
                    total,
                    pages,
                    has_next: page < pages,
                    has_prev: page > 1,
                },
            },
        });
    }
    finally {
        client.release();
    }
}));
// GET /api/appointments/recurring/:id - Get recurring appointment by ID
exports.getRecurringAppointmentById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const recurringId = parseInt(req.params.id);
    if (isNaN(recurringId)) {
        throw new AppError_1.ValidationError('Invalid recurring appointment ID');
    }
    const recurring = yield recurringAppointmentService.getRecurringAppointmentById(recurringId, tenantId);
    if (!recurring) {
        throw new AppError_1.NotFoundError('Recurring appointment');
    }
    res.json({
        success: true,
        data: { recurring_appointment: recurring },
    });
}));
// PUT /api/appointments/recurring/:id - Update recurring appointment
exports.updateRecurringAppointment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const recurringId = parseInt(req.params.id);
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    if (isNaN(recurringId)) {
        throw new AppError_1.ValidationError('Invalid recurring appointment ID');
    }
    // Validate request body
    const validatedData = UpdateRecurringAppointmentSchema.parse(req.body);
    // Update recurring appointment
    const recurring = yield recurringAppointmentService.updateRecurringAppointment(recurringId, validatedData, tenantId, userId);
    res.json({
        success: true,
        data: { recurring_appointment: recurring },
        message: 'Recurring appointment updated successfully',
    });
}));
// DELETE /api/appointments/recurring/:id - Cancel recurring appointment
exports.cancelRecurringAppointment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const recurringId = parseInt(req.params.id);
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const { reason, cancel_future_only } = req.body;
    if (isNaN(recurringId)) {
        throw new AppError_1.ValidationError('Invalid recurring appointment ID');
    }
    if (!reason) {
        throw new AppError_1.ValidationError('Cancellation reason is required');
    }
    // Cancel recurring appointment
    const recurring = yield recurringAppointmentService.cancelRecurringAppointment(recurringId, reason, cancel_future_only || false, tenantId, userId);
    res.json({
        success: true,
        data: { recurring_appointment: recurring },
        message: 'Recurring appointment cancelled successfully',
    });
}));
