"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportAnalyticsData = exports.generateCustomReport = exports.getDepartmentStatistics = exports.getCredentialsExpiry = exports.getPayrollAnalytics = exports.getPerformanceAnalytics = exports.getAttendanceAnalytics = exports.getScheduleAnalytics = exports.getStaffAnalytics = exports.getDashboardAnalytics = void 0;
const database_1 = __importDefault(require("../database"));
// Dashboard Analytics
const getDashboardAnalytics = () => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query('SELECT * FROM dashboard_analytics');
    return result.rows[0] || {
        total_staff: 0,
        active_staff: 0,
        staff_on_leave: 0,
        total_schedules: 0,
        scheduled_shifts: 0,
        completed_shifts: 0,
        total_attendance_records: 0,
        present_count: 0,
        absent_count: 0,
        avg_performance_score: 0
    };
});
exports.getDashboardAnalytics = getDashboardAnalytics;
// Staff Analytics
const getStaffAnalytics = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM staff_analytics WHERE 1=1';
    const params = [];
    if (filters.department) {
        params.push(filters.department);
        query += ` AND department = $${params.length}`;
    }
    if (filters.start_date) {
        params.push(filters.start_date);
        query += ` AND month >= $${params.length}`;
    }
    if (filters.end_date) {
        params.push(filters.end_date);
        query += ` AND month <= $${params.length}`;
    }
    query += ' ORDER BY month DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getStaffAnalytics = getStaffAnalytics;
// Schedule Analytics
const getScheduleAnalytics = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM schedule_analytics WHERE 1=1';
    const params = [];
    if (filters.start_date) {
        params.push(filters.start_date);
        query += ` AND week >= $${params.length}`;
    }
    if (filters.end_date) {
        params.push(filters.end_date);
        query += ` AND week <= $${params.length}`;
    }
    query += ' ORDER BY week DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getScheduleAnalytics = getScheduleAnalytics;
// Attendance Analytics
const getAttendanceAnalytics = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM attendance_analytics WHERE 1=1';
    const params = [];
    if (filters.start_date) {
        params.push(filters.start_date);
        query += ` AND month >= $${params.length}`;
    }
    if (filters.end_date) {
        params.push(filters.end_date);
        query += ` AND month <= $${params.length}`;
    }
    query += ' ORDER BY month DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getAttendanceAnalytics = getAttendanceAnalytics;
// Performance Analytics
const getPerformanceAnalytics = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM performance_analytics WHERE 1=1';
    const params = [];
    if (filters.start_date) {
        params.push(filters.start_date);
        query += ` AND quarter >= $${params.length}`;
    }
    if (filters.end_date) {
        params.push(filters.end_date);
        query += ` AND quarter <= $${params.length}`;
    }
    query += ' ORDER BY quarter DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getPerformanceAnalytics = getPerformanceAnalytics;
// Payroll Analytics
const getPayrollAnalytics = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM payroll_analytics WHERE 1=1';
    const params = [];
    if (filters.start_date) {
        params.push(filters.start_date);
        query += ` AND month >= $${params.length}`;
    }
    if (filters.end_date) {
        params.push(filters.end_date);
        query += ` AND month <= $${params.length}`;
    }
    query += ' ORDER BY month DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getPayrollAnalytics = getPayrollAnalytics;
// Credentials Expiry
const getCredentialsExpiry = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = 'SELECT * FROM credentials_expiry_view WHERE 1=1';
    const params = [];
    if (filters.expiry_status) {
        params.push(filters.expiry_status);
        query += ` AND expiry_status = $${params.length}`;
    }
    if (filters.department) {
        params.push(filters.department);
        query += ` AND staff_id IN (SELECT id FROM staff_profiles WHERE department = $${params.length})`;
    }
    query += ' ORDER BY expiry_date ASC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getCredentialsExpiry = getCredentialsExpiry;
// Department Statistics
const getDepartmentStatistics = (department) => __awaiter(void 0, void 0, void 0, function* () {
    let query = 'SELECT * FROM department_statistics WHERE 1=1';
    const params = [];
    if (department) {
        params.push(department);
        query += ` AND department = $${params.length}`;
    }
    query += ' ORDER BY total_staff DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getDepartmentStatistics = getDepartmentStatistics;
// Custom Report Generation
const generateCustomReport = (reportConfig) => __awaiter(void 0, void 0, void 0, function* () {
    const { metrics, filters, groupBy, dateRange } = reportConfig;
    // Build dynamic query based on configuration
    let query = 'SELECT ';
    const params = [];
    // Add metrics
    const metricClauses = metrics.map((metric) => {
        switch (metric) {
            case 'staff_count':
                return 'COUNT(DISTINCT sp.id) as staff_count';
            case 'avg_performance':
                return 'AVG(sper.performance_score) as avg_performance';
            case 'total_shifts':
                return 'COUNT(DISTINCT ss.id) as total_shifts';
            case 'attendance_rate':
                return 'ROUND(COUNT(CASE WHEN sa.status = \'present\' THEN 1 END)::numeric / NULLIF(COUNT(sa.id), 0) * 100, 2) as attendance_rate';
            case 'total_payroll':
                return 'SUM(spay.net_pay) as total_payroll';
            default:
                return null;
        }
    }).filter(Boolean);
    query += metricClauses.join(', ');
    // Add group by
    if (groupBy) {
        query += `, ${groupBy}`;
    }
    query += ` FROM staff_profiles sp
    LEFT JOIN staff_schedules ss ON sp.id = ss.staff_id
    LEFT JOIN staff_attendance sa ON sp.id = sa.staff_id
    LEFT JOIN staff_performance sper ON sp.id = sper.staff_id
    LEFT JOIN staff_payroll spay ON sp.id = spay.staff_id
    WHERE 1=1`;
    // Add filters
    if (filters.department) {
        params.push(filters.department);
        query += ` AND sp.department = $${params.length}`;
    }
    if (filters.status) {
        params.push(filters.status);
        query += ` AND sp.status = $${params.length}`;
    }
    if (dateRange === null || dateRange === void 0 ? void 0 : dateRange.start) {
        params.push(dateRange.start);
        query += ` AND sp.hire_date >= $${params.length}`;
    }
    if (dateRange === null || dateRange === void 0 ? void 0 : dateRange.end) {
        params.push(dateRange.end);
        query += ` AND sp.hire_date <= $${params.length}`;
    }
    // Add group by clause
    if (groupBy) {
        query += ` GROUP BY ${groupBy}`;
    }
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.generateCustomReport = generateCustomReport;
// Export Data
const exportAnalyticsData = (dataType_1, ...args_1) => __awaiter(void 0, [dataType_1, ...args_1], void 0, function* (dataType, format = 'json') {
    let data;
    switch (dataType) {
        case 'dashboard':
            data = yield (0, exports.getDashboardAnalytics)();
            break;
        case 'staff':
            data = yield (0, exports.getStaffAnalytics)();
            break;
        case 'schedule':
            data = yield (0, exports.getScheduleAnalytics)();
            break;
        case 'attendance':
            data = yield (0, exports.getAttendanceAnalytics)();
            break;
        case 'performance':
            data = yield (0, exports.getPerformanceAnalytics)();
            break;
        case 'payroll':
            data = yield (0, exports.getPayrollAnalytics)();
            break;
        case 'credentials':
            data = yield (0, exports.getCredentialsExpiry)();
            break;
        case 'departments':
            data = yield (0, exports.getDepartmentStatistics)();
            break;
        default:
            throw new Error('Invalid data type');
    }
    // Format conversion would happen here (CSV, Excel, PDF)
    // For now, return JSON
    return {
        format,
        data,
        timestamp: new Date(),
        recordCount: Array.isArray(data) ? data.length : 1
    };
});
exports.exportAnalyticsData = exportAnalyticsData;
