"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const prescription_controller_1 = require("../controllers/prescription.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// POST /api/prescriptions - Create prescription (requires write permission)
router.post('/', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.createPrescription);
// GET /api/prescriptions/:id - Get single prescription (requires read permission)
router.get('/:id', (0, authorization_1.requirePermission)('patients', 'read'), prescription_controller_1.getPrescription);
// GET /api/prescriptions/patient/:patientId - Get prescriptions by patient (requires read permission)
router.get('/patient/:patientId', (0, authorization_1.requirePermission)('patients', 'read'), prescription_controller_1.getPatientPrescriptions);
// PUT /api/prescriptions/:id - Update prescription (requires write permission)
router.put('/:id', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.updatePrescription);
// POST /api/prescriptions/:id/discontinue - Discontinue prescription (requires write permission)
router.post('/:id/discontinue', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.discontinuePrescription);
// DELETE /api/prescriptions/:id - Delete prescription (requires write permission)
router.delete('/:id', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.deletePrescription);
// GET /api/prescriptions/patient/:patientId/interactions - Check drug interactions (requires read permission)
router.get('/patient/:patientId/interactions', (0, authorization_1.requirePermission)('patients', 'read'), prescription_controller_1.checkDrugInteractions);
// POST /api/prescriptions/:id/refill - Process refill (requires write permission)
router.post('/:id/refill', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.processRefill);
// POST /api/prescriptions/update-expired - Update expired prescriptions (requires write permission)
router.post('/update-expired', (0, authorization_1.requirePermission)('patients', 'write'), prescription_controller_1.updateExpiredPrescriptions);
exports.default = router;
