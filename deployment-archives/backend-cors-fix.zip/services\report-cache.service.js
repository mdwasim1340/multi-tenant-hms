"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportCacheService = void 0;
exports.getReportCacheService = getReportCacheService;
exports.resetReportCacheService = resetReportCacheService;
const node_cache_1 = __importDefault(require("node-cache"));
const crypto_1 = __importDefault(require("crypto"));
class ReportCacheService {
    constructor(options) {
        this.defaultTTL = 300; // 5 minutes
        this.cache = new node_cache_1.default({
            stdTTL: (options === null || options === void 0 ? void 0 : options.ttl) || this.defaultTTL,
            checkperiod: (options === null || options === void 0 ? void 0 : options.checkperiod) || 60,
            useClones: true, // Clone objects to prevent external modifications
            deleteOnExpire: true
        });
        // Log cache events
        this.cache.on('set', (key) => {
            console.log(`[Cache] Set: ${key}`);
        });
        this.cache.on('expired', (key) => {
            console.log(`[Cache] Expired: ${key}`);
        });
        this.cache.on('del', (key) => {
            console.log(`[Cache] Deleted: ${key}`);
        });
    }
    /**
     * Generate cache key from report parameters
     *
     * Creates a unique, deterministic key based on:
     * - Report type
     * - Tenant ID
     * - Report parameters (dates, filters, etc.)
     */
    generateCacheKey(reportType, tenantId, parameters) {
        // Sort parameters to ensure consistent key generation
        const sortedParams = Object.keys(parameters)
            .sort()
            .reduce((acc, key) => {
            acc[key] = parameters[key];
            return acc;
        }, {});
        // Create a string representation
        const paramString = JSON.stringify(sortedParams);
        // Generate hash for shorter, consistent keys
        const hash = crypto_1.default
            .createHash('sha256')
            .update(`${reportType}:${tenantId}:${paramString}`)
            .digest('hex')
            .substring(0, 16);
        return `report:${reportType}:${tenantId}:${hash}`;
    }
    /**
     * Get cached report
     *
     * Returns cached report if available and not expired
     */
    getCachedReport(cacheKey) {
        const cached = this.cache.get(cacheKey);
        if (cached) {
            console.log(`[Cache] HIT: ${cacheKey}`);
        }
        else {
            console.log(`[Cache] MISS: ${cacheKey}`);
        }
        return cached;
    }
    /**
     * Cache report
     *
     * Stores report in cache with optional custom TTL
     */
    cacheReport(cacheKey, report, ttl) {
        try {
            const success = this.cache.set(cacheKey, report, ttl || this.defaultTTL);
            if (success) {
                console.log(`[Cache] Cached report: ${cacheKey} (TTL: ${ttl || this.defaultTTL}s)`);
            }
            else {
                console.error(`[Cache] Failed to cache report: ${cacheKey}`);
            }
            return success;
        }
        catch (error) {
            console.error(`[Cache] Error caching report:`, error);
            return false;
        }
    }
    /**
     * Invalidate cache for specific report
     */
    invalidateReport(cacheKey) {
        const deleted = this.cache.del(cacheKey);
        console.log(`[Cache] Invalidated ${deleted} key(s): ${cacheKey}`);
        return deleted;
    }
    /**
     * Invalidate all reports for a tenant
     *
     * Called when tenant data changes (new invoice, payment, expense, etc.)
     */
    invalidateTenantReports(tenantId) {
        const keys = this.cache.keys();
        const tenantKeys = keys.filter(key => key.includes(`:${tenantId}:`));
        let deleted = 0;
        tenantKeys.forEach(key => {
            deleted += this.cache.del(key);
        });
        console.log(`[Cache] Invalidated ${deleted} report(s) for tenant: ${tenantId}`);
        return deleted;
    }
    /**
     * Invalidate all reports of a specific type for a tenant
     */
    invalidateTenantReportsByType(tenantId, reportType) {
        const keys = this.cache.keys();
        const matchingKeys = keys.filter(key => key.includes(`report:${reportType}:${tenantId}:`));
        let deleted = 0;
        matchingKeys.forEach(key => {
            deleted += this.cache.del(key);
        });
        console.log(`[Cache] Invalidated ${deleted} ${reportType} report(s) for tenant: ${tenantId}`);
        return deleted;
    }
    /**
     * Invalidate all cached reports
     *
     * Use sparingly - typically only for maintenance or testing
     */
    invalidateAll() {
        this.cache.flushAll();
        console.log('[Cache] Invalidated all cached reports');
    }
    /**
     * Get cache statistics
     */
    getStats() {
        const stats = this.cache.getStats();
        return {
            hits: stats.hits,
            misses: stats.misses,
            keys: stats.keys,
            ksize: stats.ksize,
            vsize: stats.vsize
        };
    }
    /**
     * Get all cache keys
     */
    getKeys() {
        return this.cache.keys();
    }
    /**
     * Check if a key exists in cache
     */
    has(cacheKey) {
        return this.cache.has(cacheKey);
    }
    /**
     * Get TTL for a cached item
     */
    getTTL(cacheKey) {
        return this.cache.getTtl(cacheKey);
    }
    /**
     * Update TTL for a cached item
     */
    updateTTL(cacheKey, ttl) {
        return this.cache.ttl(cacheKey, ttl);
    }
    /**
     * Close cache and cleanup
     */
    close() {
        this.cache.close();
        console.log('[Cache] Cache service closed');
    }
}
exports.ReportCacheService = ReportCacheService;
// Singleton instance
let cacheServiceInstance = null;
/**
 * Get singleton cache service instance
 */
function getReportCacheService(options) {
    if (!cacheServiceInstance) {
        cacheServiceInstance = new ReportCacheService(options);
    }
    return cacheServiceInstance;
}
/**
 * Reset cache service instance (for testing)
 */
function resetReportCacheService() {
    if (cacheServiceInstance) {
        cacheServiceInstance.close();
        cacheServiceInstance = null;
    }
}
