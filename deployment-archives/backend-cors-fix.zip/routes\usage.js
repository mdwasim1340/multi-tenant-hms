"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const usage_1 = require("../services/usage");
const auth_1 = require("../middleware/auth");
// Helper function to check if user has access to tenant data
const checkTenantAccess = (req, tenantId) => {
    var _a, _b, _c, _d;
    const userTenantId = req.headers['x-tenant-id'];
    // Allow admin users to access any tenant's data
    const isAdmin = userTenantId === 'admin' ||
        ((_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a.email) === null || _b === void 0 ? void 0 : _b.includes('admin')) ||
        ((_d = (_c = req.user) === null || _c === void 0 ? void 0 : _c['cognito:groups']) === null || _d === void 0 ? void 0 : _d.includes('admin'));
    return !userTenantId || userTenantId === tenantId || isAdmin;
};
const router = express_1.default.Router();
// Get current usage for tenant
router.get('/tenant/:tenantId/current', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const usage = yield usage_1.usageService.getCurrentUsage(tenantId);
        if (!usage) {
            return res.status(404).json({
                error: 'Usage data not found for this tenant',
                code: 'USAGE_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            usage
        });
    }
    catch (error) {
        console.error('Error fetching current usage:', error);
        res.status(500).json({
            error: 'Failed to fetch usage data',
            code: 'FETCH_USAGE_ERROR'
        });
    }
}));
// Get usage report with limits and warnings
router.get('/tenant/:tenantId/report', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const report = yield usage_1.usageService.generateUsageReport(tenantId);
        res.json({
            success: true,
            report
        });
    }
    catch (error) {
        console.error('Error generating usage report:', error);
        res.status(500).json({
            error: 'Failed to generate usage report',
            code: 'GENERATE_REPORT_ERROR'
        });
    }
}));
// Get usage metrics for dashboard
router.get('/tenant/:tenantId/metrics', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const metrics = yield usage_1.usageService.getUsageMetrics(tenantId);
        res.json({
            success: true,
            metrics
        });
    }
    catch (error) {
        console.error('Error fetching usage metrics:', error);
        res.status(500).json({
            error: 'Failed to fetch usage metrics',
            code: 'FETCH_METRICS_ERROR'
        });
    }
}));
// Get usage trends (comparison with previous period)
router.get('/tenant/:tenantId/trends', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const trends = yield usage_1.usageService.getUsageTrends(tenantId);
        res.json({
            success: true,
            trends
        });
    }
    catch (error) {
        console.error('Error fetching usage trends:', error);
        res.status(500).json({
            error: 'Failed to fetch usage trends',
            code: 'FETCH_TRENDS_ERROR'
        });
    }
}));
// Get usage alerts
router.get('/tenant/:tenantId/alerts', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const alerts = yield usage_1.usageService.getUsageAlerts(tenantId);
        res.json({
            success: true,
            alerts
        });
    }
    catch (error) {
        console.error('Error fetching usage alerts:', error);
        res.status(500).json({
            error: 'Failed to fetch usage alerts',
            code: 'FETCH_ALERTS_ERROR'
        });
    }
}));
// Get usage for specific period
router.get('/tenant/:tenantId/period/:date', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId, date } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        // Parse date (expected format: YYYY-MM-DD)
        const periodStart = new Date(date);
        if (isNaN(periodStart.getTime())) {
            return res.status(400).json({
                error: 'Invalid date format. Use YYYY-MM-DD',
                code: 'INVALID_DATE_FORMAT'
            });
        }
        const usage = yield usage_1.usageService.getUsageForPeriod(tenantId, periodStart);
        if (!usage) {
            return res.status(404).json({
                error: 'Usage data not found for this period',
                code: 'USAGE_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            usage
        });
    }
    catch (error) {
        console.error('Error fetching period usage:', error);
        res.status(500).json({
            error: 'Failed to fetch period usage',
            code: 'FETCH_PERIOD_USAGE_ERROR'
        });
    }
}));
// Manually refresh usage summary (admin only)
router.post('/tenant/:tenantId/refresh', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // In production, add admin role check here
        // const userRole = req.user?.role;
        // if (userRole !== 'admin') { ... }
        yield usage_1.usageService.updateUsageSummary(tenantId);
        res.json({
            success: true,
            message: 'Usage summary refreshed successfully'
        });
    }
    catch (error) {
        console.error('Error refreshing usage summary:', error);
        res.status(500).json({
            error: 'Failed to refresh usage summary',
            code: 'REFRESH_USAGE_ERROR'
        });
    }
}));
// Track custom usage event (for manual tracking)
router.post('/tenant/:tenantId/track', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const { metric_type, value = 1, metadata = {} } = req.body;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        if (!metric_type) {
            return res.status(400).json({
                error: 'metric_type is required',
                code: 'MISSING_METRIC_TYPE'
            });
        }
        // Validate metric type
        const validMetricTypes = [
            'patients_count', 'users_count', 'storage_used_gb', 'api_call',
            'file_upload', 'appointment_created', 'patient_created',
            'user_created', 'medical_record_created'
        ];
        if (!validMetricTypes.includes(metric_type)) {
            return res.status(400).json({
                error: `Invalid metric_type. Valid types: ${validMetricTypes.join(', ')}`,
                code: 'INVALID_METRIC_TYPE'
            });
        }
        yield usage_1.usageService.trackUsage(tenantId, metric_type, value, metadata);
        res.json({
            success: true,
            message: 'Usage event tracked successfully'
        });
    }
    catch (error) {
        console.error('Error tracking usage event:', error);
        res.status(500).json({
            error: 'Failed to track usage event',
            code: 'TRACK_USAGE_ERROR'
        });
    }
}));
// Get all tenants usage summary (admin only)
router.get('/admin/summary', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // In production, add admin role check here
        // const userRole = req.user?.role;
        // if (userRole !== 'admin') { ... }
        const { limit = 50, offset = 0 } = req.query;
        const result = yield usage_1.usageService.getAllTenantsUsageSummary(parseInt(limit), parseInt(offset));
        res.json(Object.assign({ success: true }, result));
    }
    catch (error) {
        console.error('Error fetching admin usage summary:', error);
        res.status(500).json({
            error: 'Failed to fetch usage summary',
            code: 'FETCH_ADMIN_SUMMARY_ERROR'
        });
    }
}));
exports.default = router;
