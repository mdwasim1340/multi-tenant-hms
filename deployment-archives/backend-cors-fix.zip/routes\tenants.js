"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const tenant_1 = require("../services/tenant");
const auth_1 = require("../middleware/auth");
const tenantSchemaRunner_1 = require("../services/tenantSchemaRunner");
const router = express_1.default.Router();
// Public endpoint - no auth required for subdomain resolution
router.get('/by-subdomain/:subdomain', tenant_1.getTenantBySubdomain);
// Protected endpoints - require authentication
router.get('/', auth_1.adminAuthMiddleware, tenant_1.getAllTenants);
router.post('/', auth_1.adminAuthMiddleware, tenant_1.createTenant);
router.put('/:id', auth_1.adminAuthMiddleware, tenant_1.updateTenant);
router.delete('/:id', auth_1.adminAuthMiddleware, tenant_1.deleteTenant);
router.post('/:id/init-schema', auth_1.adminAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id } = req.params;
    try {
        const result = yield (0, tenantSchemaRunner_1.runSchemaInitialization)(id);
        res.json({ tenant_id: id, results: result });
    }
    catch (e) {
        res.status(500).json({ message: 'Schema initialization failed' });
    }
}));
router.post('/:id/rollback', auth_1.adminAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id } = req.params;
    const { file } = req.body;
    if (!file)
        return res.status(400).json({ message: 'file is required' });
    const result = yield (0, tenantSchemaRunner_1.rollbackSchemaFile)(id, file);
    res.json({ tenant_id: id, result });
}));
exports.default = router;
