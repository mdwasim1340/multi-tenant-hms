"use strict";
/**
 * Asset Calculator Service
 *
 * Calculates asset values from the assets table for Balance Sheet reports.
 * Categorizes assets into current and fixed categories.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assetCalculatorService = exports.AssetCalculatorService = void 0;
const database_1 = __importDefault(require("../database"));
class AssetCalculatorService {
    /**
     * Get total assets as of a specific date, broken down by category
     */
    getAssetsAsOfDate(options) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const { tenantId, asOfDate, departmentId } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required for asset calculation');
            }
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Build WHERE clause (no tenant_id filter needed since we're in tenant schema)
                const conditions = [
                    'as_of_date <= $1'
                ];
                const params = [asOfDate];
                let paramIndex = 2;
                if (departmentId) {
                    conditions.push(`department_id = $${paramIndex}`);
                    params.push(departmentId);
                    paramIndex++;
                }
                const whereClause = conditions.join(' AND ');
                // Query to get latest asset values by type
                // Uses window function to get the most recent value for each asset
                const query = `
        WITH latest_assets AS (
          SELECT DISTINCT ON (asset_type, asset_name)
            asset_type,
            asset_category,
            asset_name,
            value,
            accumulated_depreciation
          FROM assets
          WHERE ${whereClause}
          ORDER BY asset_type, asset_name, as_of_date DESC
        )
        SELECT 
          asset_type,
          asset_category,
          SUM(value - COALESCE(accumulated_depreciation, 0)) as net_value
        FROM latest_assets
        GROUP BY asset_type, asset_category
      `;
                const result = yield client.query(query, params);
                // Initialize breakdown with zeros
                const currentAssets = {
                    cash: 0,
                    accountsReceivable: 0,
                    inventory: 0,
                    total: 0
                };
                const fixedAssets = {
                    equipment: 0,
                    buildings: 0,
                    land: 0,
                    vehicles: 0,
                    total: 0
                };
                // Map asset types to breakdown categories
                result.rows.forEach(row => {
                    const netValue = parseFloat(row.net_value) || 0;
                    const assetType = row.asset_type;
                    const category = row.asset_category;
                    if (category === 'current') {
                        switch (assetType) {
                            case 'cash':
                                currentAssets.cash += netValue;
                                break;
                            case 'receivable':
                                currentAssets.accountsReceivable += netValue;
                                break;
                            case 'inventory':
                                currentAssets.inventory += netValue;
                                break;
                        }
                    }
                    else if (category === 'fixed') {
                        switch (assetType) {
                            case 'equipment':
                                fixedAssets.equipment += netValue;
                                break;
                            case 'building':
                                fixedAssets.buildings += netValue;
                                break;
                            case 'land':
                                fixedAssets.land += netValue;
                                break;
                            case 'vehicle':
                                fixedAssets.vehicles += netValue;
                                break;
                        }
                    }
                });
                // If no data from assets table, calculate from invoices
                if (result.rows.length === 0) {
                    // Get cash from paid invoices
                    const cashQuery = `
          SELECT COALESCE(SUM(amount), 0) as cash
          FROM public.invoices
          WHERE tenant_id = $1
            AND status = 'paid'
            AND COALESCE(paid_at, created_at)::date <= $2::date
        `;
                    const cashResult = yield client.query(cashQuery, [tenantId, asOfDate]);
                    currentAssets.cash = parseFloat((_a = cashResult.rows[0]) === null || _a === void 0 ? void 0 : _a.cash) || 0;
                    // Get accounts receivable from pending/overdue invoices
                    const receivableQuery = `
          SELECT COALESCE(SUM(amount), 0) as receivable
          FROM public.invoices
          WHERE tenant_id = $1
            AND status IN ('pending', 'overdue')
            AND created_at::date <= $2::date
        `;
                    const receivableResult = yield client.query(receivableQuery, [tenantId, asOfDate]);
                    currentAssets.accountsReceivable = parseFloat((_b = receivableResult.rows[0]) === null || _b === void 0 ? void 0 : _b.receivable) || 0;
                }
                // Calculate totals
                currentAssets.total = currentAssets.cash + currentAssets.accountsReceivable + currentAssets.inventory;
                fixedAssets.total = fixedAssets.equipment + fixedAssets.buildings + fixedAssets.land + fixedAssets.vehicles;
                const breakdown = {
                    current: currentAssets,
                    fixed: fixedAssets,
                    total: currentAssets.total + fixedAssets.total
                };
                return breakdown;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get assets by specific category (current or fixed)
     */
    getAssetsByCategory(tenantId, category, asOfDate, departmentId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                const conditions = [
                    'asset_category = $1',
                    'as_of_date <= $2'
                ];
                const params = [category, asOfDate];
                if (departmentId) {
                    conditions.push('department_id = $3');
                    params.push(departmentId);
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        WITH latest_assets AS (
          SELECT DISTINCT ON (asset_type, asset_name)
            value,
            accumulated_depreciation
          FROM assets
          WHERE ${whereClause}
          ORDER BY asset_type, asset_name, as_of_date DESC
        )
        SELECT COALESCE(SUM(value - COALESCE(accumulated_depreciation, 0)), 0) as total
        FROM latest_assets
      `;
                const result = yield client.query(query, params);
                return parseFloat(result.rows[0].total) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get assets by specific type
     */
    getAssetsByType(tenantId, assetType, asOfDate, departmentId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                const conditions = [
                    'asset_type = $1',
                    'as_of_date <= $2'
                ];
                const params = [assetType, asOfDate];
                if (departmentId) {
                    conditions.push('department_id = $3');
                    params.push(departmentId);
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        WITH latest_assets AS (
          SELECT DISTINCT ON (asset_name)
            value,
            accumulated_depreciation
          FROM assets
          WHERE ${whereClause}
          ORDER BY asset_name, as_of_date DESC
        )
        SELECT COALESCE(SUM(value - COALESCE(accumulated_depreciation, 0)), 0) as total
        FROM latest_assets
      `;
                const result = yield client.query(query, params);
                return parseFloat(result.rows[0].total) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get assets for a specific department
     */
    getAssetsByDepartment(tenantId, departmentId, asOfDate) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                const query = `
        WITH latest_assets AS (
          SELECT DISTINCT ON (asset_type, asset_name)
            value,
            accumulated_depreciation
          FROM assets
          WHERE department_id = $1
            AND as_of_date <= $2
          ORDER BY asset_type, asset_name, as_of_date DESC
        )
        SELECT COALESCE(SUM(value - COALESCE(accumulated_depreciation, 0)), 0) as total
        FROM latest_assets
      `;
                const result = yield client.query(query, [departmentId, asOfDate]);
                return parseFloat(result.rows[0].total) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get asset count
     */
    getAssetCount(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, asOfDate, departmentId } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required');
            }
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                const conditions = [
                    'as_of_date <= $1'
                ];
                const params = [asOfDate];
                if (departmentId) {
                    conditions.push('department_id = $2');
                    params.push(departmentId);
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        SELECT COUNT(DISTINCT asset_name) as count
        FROM assets
        WHERE ${whereClause}
      `;
                const result = yield client.query(query, params);
                return parseInt(result.rows[0].count) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get detailed asset list
     */
    getDetailedAssets(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, asOfDate, departmentId } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required');
            }
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                const conditions = [
                    'as_of_date <= $1'
                ];
                const params = [asOfDate];
                if (departmentId) {
                    conditions.push('department_id = $2');
                    params.push(departmentId);
                }
                const whereClause = conditions.join(' AND ');
                const query = `
        SELECT DISTINCT ON (asset_type, asset_name)
          asset_name,
          asset_type,
          asset_category,
          value,
          COALESCE(accumulated_depreciation, 0) as accumulated_depreciation
        FROM assets
        WHERE ${whereClause}
        ORDER BY asset_type, asset_name, as_of_date DESC
      `;
                const result = yield client.query(query, params);
                const assets = result.rows.map(row => ({
                    name: row.asset_name,
                    type: row.asset_type,
                    category: row.asset_category,
                    value: parseFloat(row.value) || 0,
                    depreciation: parseFloat(row.accumulated_depreciation) || 0,
                    netValue: (parseFloat(row.value) || 0) - (parseFloat(row.accumulated_depreciation) || 0)
                }));
                // Calculate summary
                const summary = yield this.getAssetsAsOfDate(options);
                return { assets, summary };
            }
            finally {
                client.release();
            }
        });
    }
}
exports.AssetCalculatorService = AssetCalculatorService;
exports.assetCalculatorService = new AssetCalculatorService();
