"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEVERITY_LEVELS = exports.ALLERGEN_TYPES = exports.FAMILY_RELATIONSHIPS = void 0;
// Common relationships for family history
exports.FAMILY_RELATIONSHIPS = [
    'Mother',
    'Father',
    'Sister',
    'Brother',
    'Maternal Grandmother',
    'Maternal Grandfather',
    'Paternal Grandmother',
    'Paternal Grandfather',
    'Aunt',
    'Uncle',
    'Cousin',
    'Child',
    'Other'
];
// Common allergen types
exports.ALLERGEN_TYPES = [
    'medication',
    'food',
    'environmental',
    'other'
];
// Severity levels
exports.SEVERITY_LEVELS = [
    'mild',
    'moderate',
    'severe',
    'life-threatening'
];
