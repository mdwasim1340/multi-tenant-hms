"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MEDICATION_FREQUENCIES = exports.MEDICATION_ROUTES = void 0;
// Common medication routes
exports.MEDICATION_ROUTES = [
    'Oral',
    'Sublingual',
    'Topical',
    'Transdermal',
    'Intravenous',
    'Intramuscular',
    'Subcutaneous',
    'Inhalation',
    'Rectal',
    'Ophthalmic',
    'Otic',
    'Nasal',
    'Other'
];
// Common frequencies
exports.MEDICATION_FREQUENCIES = [
    'Once daily',
    'Twice daily',
    'Three times daily',
    'Four times daily',
    'Every 4 hours',
    'Every 6 hours',
    'Every 8 hours',
    'Every 12 hours',
    'As needed',
    'Before meals',
    'After meals',
    'At bedtime',
    'Other'
];
