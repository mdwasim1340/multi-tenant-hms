"use strict";
/**
 * Team Alpha - Recurring Appointments Routes
 * API routes for recurring appointment management
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const recurringAppointment_controller_1 = require("../controllers/recurringAppointment.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// GET /api/appointments/recurring - List recurring appointments (requires read permission)
router.get('/', (0, authorization_1.requirePermission)('appointments', 'read'), recurringAppointment_controller_1.getRecurringAppointments);
// POST /api/appointments/recurring - Create recurring appointment (requires write permission)
router.post('/', (0, authorization_1.requirePermission)('appointments', 'write'), recurringAppointment_controller_1.createRecurringAppointment);
// GET /api/appointments/recurring/:id - Get recurring appointment by ID (requires read permission)
router.get('/:id', (0, authorization_1.requirePermission)('appointments', 'read'), recurringAppointment_controller_1.getRecurringAppointmentById);
// PUT /api/appointments/recurring/:id - Update recurring appointment (requires write permission)
router.put('/:id', (0, authorization_1.requirePermission)('appointments', 'write'), recurringAppointment_controller_1.updateRecurringAppointment);
// DELETE /api/appointments/recurring/:id - Cancel recurring appointment (requires write permission)
router.delete('/:id', (0, authorization_1.requirePermission)('appointments', 'write'), recurringAppointment_controller_1.cancelRecurringAppointment);
exports.default = router;
