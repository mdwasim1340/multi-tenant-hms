"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tenantMiddleware = void 0;
const database_1 = __importDefault(require("../database"));
const tenantMiddleware = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    if (!tenantId) {
        return res.status(400).json({ message: 'X-Tenant-ID header is required' });
    }
    const client = yield database_1.default.connect();
    try {
        // Ensure schema name has tenant_ prefix
        const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
        yield client.query(`SET search_path TO "${schemaName}", public`);
        req.dbClient = client;
        res.on('finish', () => {
            client.release();
        });
        next();
    }
    catch (error) {
        console.error('Tenant middleware error:', error);
        client.release();
        res.status(500).json({ message: 'Failed to set tenant context' });
    }
});
exports.tenantMiddleware = tenantMiddleware;
