"use strict";
/**
 * TypeScript Type Definitions for Bed Management Optimization System
 * AI-powered bed management with LOS prediction, discharge readiness, transfer optimization, and capacity forecasting
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIFeatureManagementSchema = exports.BedManagementFeature = exports.BedTurnoverSchema = exports.CapacityForecastSchema = exports.TransferPrioritySchema = exports.DischargeReadinessSchema = exports.BedAssignmentSchema = exports.BedRequirementsSchema = exports.LOSPredictionSchema = void 0;
const zod_1 = require("zod");
exports.LOSPredictionSchema = zod_1.z.object({
    admission_id: zod_1.z.number().int().positive(),
    patient_id: zod_1.z.number().int().positive(),
    predicted_los_days: zod_1.z.number().positive(),
    confidence_interval_lower: zod_1.z.number().positive().optional(),
    confidence_interval_upper: zod_1.z.number().positive().optional(),
    prediction_factors: zod_1.z.object({
        diagnosis: zod_1.z.string(),
        severity: zod_1.z.string(),
        age: zod_1.z.number().int().positive(),
        comorbidities: zod_1.z.array(zod_1.z.string()),
        admission_source: zod_1.z.string(),
    }).optional(),
});
exports.BedRequirementsSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    isolation_required: zod_1.z.boolean(),
    isolation_type: zod_1.z.enum(['contact', 'droplet', 'airborne']).optional(),
    telemetry_required: zod_1.z.boolean(),
    oxygen_required: zod_1.z.boolean(),
    specialty_unit: zod_1.z.string().optional(),
    proximity_preference: zod_1.z.string().optional(),
    gender_preference: zod_1.z.string().optional(),
});
exports.BedAssignmentSchema = zod_1.z.object({
    bed_id: zod_1.z.number().int().positive(),
    patient_id: zod_1.z.number().int().positive(),
    assignment_date: zod_1.z.string().datetime(),
    expected_discharge_date: zod_1.z.string().datetime().optional(),
    isolation_required: zod_1.z.boolean(),
    isolation_type: zod_1.z.enum(['contact', 'droplet', 'airborne']).optional(),
    assignment_score: zod_1.z.number().min(0).max(100).optional(),
    assignment_reasoning: zod_1.z.string().optional(),
});
exports.DischargeReadinessSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    admission_id: zod_1.z.number().int().positive(),
    medical_readiness_score: zod_1.z.number().min(0).max(100),
    social_readiness_score: zod_1.z.number().min(0).max(100),
    overall_readiness_score: zod_1.z.number().min(0).max(100),
    predicted_discharge_date: zod_1.z.string().date().optional(),
    barriers: zod_1.z.array(zod_1.z.object({
        type: zod_1.z.string(),
        description: zod_1.z.string(),
        severity: zod_1.z.enum(['low', 'medium', 'high', 'critical']),
        identified_date: zod_1.z.string().datetime(),
        resolved: zod_1.z.boolean(),
        resolved_date: zod_1.z.string().datetime().optional(),
    })),
    recommended_interventions: zod_1.z.array(zod_1.z.object({
        type: zod_1.z.string(),
        description: zod_1.z.string(),
        priority: zod_1.z.enum(['low', 'medium', 'high', 'urgent']),
        assigned_to: zod_1.z.string().optional(),
        due_date: zod_1.z.string().datetime().optional(),
        completed: zod_1.z.boolean(),
        completed_date: zod_1.z.string().datetime().optional(),
    })),
    discharge_planning_progress: zod_1.z.number().min(0).max(100),
});
exports.TransferPrioritySchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    ed_arrival_time: zod_1.z.string().datetime(),
    acuity_score: zod_1.z.number().min(0).max(100),
    wait_time_minutes: zod_1.z.number().int().nonnegative(),
    target_unit: zod_1.z.string().optional(),
    transfer_urgency: zod_1.z.enum(['critical', 'high', 'medium', 'low']),
});
exports.CapacityForecastSchema = zod_1.z.object({
    unit_name: zod_1.z.string(),
    forecast_date: zod_1.z.string().date(),
    forecast_hours_ahead: zod_1.z.number().int().positive(),
    predicted_census: zod_1.z.number().int().nonnegative(),
    predicted_admissions: zod_1.z.number().int().nonnegative().optional(),
    predicted_discharges: zod_1.z.number().int().nonnegative().optional(),
    predicted_transfers_in: zod_1.z.number().int().nonnegative().optional(),
    predicted_transfers_out: zod_1.z.number().int().nonnegative().optional(),
    bed_utilization_percentage: zod_1.z.number().min(0).max(100).optional(),
    surge_capacity_needed: zod_1.z.boolean(),
    staffing_recommendations: zod_1.z.array(zod_1.z.object({
        role: zod_1.z.string(),
        current_staff: zod_1.z.number().int().nonnegative(),
        recommended_staff: zod_1.z.number().int().nonnegative(),
        shift: zod_1.z.enum(['day', 'evening', 'night']),
        reasoning: zod_1.z.string(),
    })).optional(),
    confidence_level: zod_1.z.number().min(0).max(100).optional(),
});
exports.BedTurnoverSchema = zod_1.z.object({
    bed_id: zod_1.z.number().int().positive(),
    patient_discharged_at: zod_1.z.string().datetime(),
    cleaning_started_at: zod_1.z.string().datetime().optional(),
    cleaning_completed_at: zod_1.z.string().datetime().optional(),
    bed_ready_at: zod_1.z.string().datetime().optional(),
    target_turnover_time_minutes: zod_1.z.number().int().positive().default(120),
    housekeeping_priority: zod_1.z.enum(['critical', 'high', 'normal', 'low']),
    housekeeping_staff_id: zod_1.z.number().int().positive().optional(),
    notes: zod_1.z.string().optional(),
});
// ============================================================================
// AI Feature Management Types
// ============================================================================
var BedManagementFeature;
(function (BedManagementFeature) {
    BedManagementFeature["LOS_PREDICTION"] = "los_prediction";
    BedManagementFeature["BED_ASSIGNMENT_OPTIMIZATION"] = "bed_assignment_optimization";
    BedManagementFeature["DISCHARGE_READINESS"] = "discharge_readiness";
    BedManagementFeature["TRANSFER_OPTIMIZATION"] = "transfer_optimization";
    BedManagementFeature["CAPACITY_FORECASTING"] = "capacity_forecasting";
})(BedManagementFeature || (exports.BedManagementFeature = BedManagementFeature = {}));
exports.AIFeatureManagementSchema = zod_1.z.object({
    feature_name: zod_1.z.enum([
        'los_prediction',
        'bed_assignment_optimization',
        'discharge_readiness',
        'transfer_optimization',
        'capacity_forecasting',
    ]),
    enabled: zod_1.z.boolean(),
    disabled_reason: zod_1.z.string().optional(),
    configuration: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
});
// Types are already exported as interfaces above, no need for duplicate export
