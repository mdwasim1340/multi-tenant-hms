"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BalanceReportAuditService = void 0;
class BalanceReportAuditService {
    /**
     * Create an audit log entry for a balance report operation
     *
     * This operation is atomic and uses a transaction to ensure consistency.
     * If audit logging fails, the entire operation should fail to maintain
     * complete audit trail.
     *
     * @param pool - Database connection pool
     * @param entry - Audit log entry data
     * @returns Created audit log entry with ID
     * @throws Error if audit log creation fails
     */
    static createAuditLog(pool, entry) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield pool.connect();
            try {
                yield client.query('BEGIN');
                // Include action in parameters since the table doesn't have an action column
                const parametersWithAction = Object.assign(Object.assign({}, entry.parameters), { action: entry.action });
                const query = `
        INSERT INTO balance_report_audit_logs (
          tenant_id,
          user_id,
          user_name,
          user_email,
          report_type,
          parameters,
          generated_at,
          execution_time_ms,
          record_count,
          success,
          error_message,
          ip_address,
          user_agent
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *
      `;
                // Convert user_id to integer if it's a string
                const userId = typeof entry.user_id === 'string'
                    ? parseInt(entry.user_id, 10) || 0
                    : entry.user_id || 0;
                const values = [
                    entry.tenant_id,
                    userId,
                    entry.user_name || null,
                    entry.user_email || null,
                    entry.report_type,
                    JSON.stringify(parametersWithAction),
                    entry.timestamp || new Date(),
                    entry.execution_time_ms || null,
                    entry.record_count || null,
                    entry.success !== false, // Default to true
                    entry.error_message || null,
                    entry.ip_address || null,
                    entry.user_agent || null
                ];
                const result = yield client.query(query, values);
                yield client.query('COMMIT');
                const createdLog = result.rows[0];
                return Object.assign(Object.assign({}, createdLog), { parameters: typeof createdLog.parameters === 'string'
                        ? JSON.parse(createdLog.parameters)
                        : createdLog.parameters });
            }
            catch (error) {
                yield client.query('ROLLBACK');
                console.error('Failed to create audit log:', error);
                throw new Error('Audit log creation failed. Operation aborted for security.');
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Retrieve audit logs with filtering and pagination
     *
     * @param pool - Database connection pool
     * @param tenantId - Tenant ID for isolation
     * @param filters - Filter criteria
     * @returns Paginated audit logs
     */
    static getAuditLogs(pool_1, tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (pool, tenantId, filters = {}) {
            const { user_id, report_type, action, start_date, end_date, page = 1, limit = 50 } = filters;
            // Build WHERE clause dynamically
            const conditions = ['tenant_id = $1'];
            const values = [tenantId];
            let paramIndex = 2;
            if (user_id) {
                conditions.push(`user_id = $${paramIndex}`);
                values.push(user_id);
                paramIndex++;
            }
            if (report_type) {
                conditions.push(`report_type = $${paramIndex}`);
                values.push(report_type);
                paramIndex++;
            }
            if (action) {
                conditions.push(`action = $${paramIndex}`);
                values.push(action);
                paramIndex++;
            }
            if (start_date) {
                conditions.push(`timestamp >= $${paramIndex}`);
                values.push(start_date);
                paramIndex++;
            }
            if (end_date) {
                conditions.push(`timestamp <= $${paramIndex}`);
                values.push(end_date);
                paramIndex++;
            }
            const whereClause = conditions.join(' AND ');
            // Get total count
            const countQuery = `
      SELECT COUNT(*) as total
      FROM balance_report_audit_logs
      WHERE ${whereClause}
    `;
            const countResult = yield pool.query(countQuery, values);
            const total = parseInt(countResult.rows[0].total, 10);
            // Get paginated results
            const offset = (page - 1) * limit;
            const dataQuery = `
      SELECT *
      FROM balance_report_audit_logs
      WHERE ${whereClause}
      ORDER BY timestamp DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
            values.push(limit, offset);
            const dataResult = yield pool.query(dataQuery, values);
            // Parse JSON parameters
            const logs = dataResult.rows.map(row => (Object.assign(Object.assign({}, row), { parameters: typeof row.parameters === 'string'
                    ? JSON.parse(row.parameters)
                    : row.parameters })));
            return {
                logs,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit)
                }
            };
        });
    }
    /**
     * Verify audit log immutability
     *
     * Attempts to update an audit log entry should fail due to database constraints.
     * This method is for testing purposes to verify the immutability constraint.
     *
     * @param pool - Database connection pool
     * @param logId - Audit log ID to attempt update
     * @returns false (update should always fail)
     * @throws Error if update succeeds (immutability broken)
     */
    static verifyImmutability(pool, logId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Attempt to update - this should fail
                const query = `
        UPDATE balance_report_audit_logs
        SET action = 'modified'
        WHERE id = $1
      `;
                const result = yield pool.query(query, [logId]);
                // If we reach here without error, immutability is broken
                // Check if any rows were affected
                if (result.rowCount && result.rowCount > 0) {
                    throw new Error('Audit log immutability constraint is not enforced!');
                }
                // No rows affected (log doesn't exist), but no constraint error either
                // This is still a problem if the log should exist
                throw new Error('Audit log immutability constraint is not enforced!');
            }
            catch (error) {
                // Check if this is our intentional error about broken immutability
                if (error.message === 'Audit log immutability constraint is not enforced!') {
                    throw error; // Re-throw to fail the test
                }
                // Expected behavior - update should fail with constraint error
                if (error.message && (error.message.includes('immutability') ||
                    error.message.includes('trigger') ||
                    error.message.includes('constraint')) || error.code === '23514') {
                    return false; // Immutability is enforced
                }
                // Unexpected error - re-throw
                throw error;
            }
        });
    }
    /**
     * Get audit log statistics for a tenant
     *
     * @param pool - Database connection pool
     * @param tenantId - Tenant ID
     * @param startDate - Start date for statistics
     * @param endDate - End date for statistics
     * @returns Audit log statistics
     */
    static getAuditStatistics(pool, tenantId, startDate, endDate) {
        return __awaiter(this, void 0, void 0, function* () {
            const conditions = ['tenant_id = $1'];
            const values = [tenantId];
            let paramIndex = 2;
            if (startDate) {
                conditions.push(`timestamp >= $${paramIndex}`);
                values.push(startDate);
                paramIndex++;
            }
            if (endDate) {
                conditions.push(`timestamp <= $${paramIndex}`);
                values.push(endDate);
                paramIndex++;
            }
            const whereClause = conditions.join(' AND ');
            // Get total count
            const totalQuery = `
      SELECT COUNT(*) as total
      FROM balance_report_audit_logs
      WHERE ${whereClause}
    `;
            const totalResult = yield pool.query(totalQuery, values);
            const total_logs = parseInt(totalResult.rows[0].total, 10);
            // Get counts by report type
            const reportTypeQuery = `
      SELECT report_type, COUNT(*) as count
      FROM balance_report_audit_logs
      WHERE ${whereClause}
      GROUP BY report_type
    `;
            const reportTypeResult = yield pool.query(reportTypeQuery, values);
            const by_report_type = reportTypeResult.rows.reduce((acc, row) => {
                acc[row.report_type] = parseInt(row.count, 10);
                return acc;
            }, {});
            // Get counts by action
            const actionQuery = `
      SELECT action, COUNT(*) as count
      FROM balance_report_audit_logs
      WHERE ${whereClause}
      GROUP BY action
    `;
            const actionResult = yield pool.query(actionQuery, values);
            const by_action = actionResult.rows.reduce((acc, row) => {
                acc[row.action] = parseInt(row.count, 10);
                return acc;
            }, {});
            // Get counts by user
            const userQuery = `
      SELECT user_id, COUNT(*) as count
      FROM balance_report_audit_logs
      WHERE ${whereClause}
      GROUP BY user_id
      ORDER BY count DESC
      LIMIT 10
    `;
            const userResult = yield pool.query(userQuery, values);
            const by_user = userResult.rows.reduce((acc, row) => {
                acc[row.user_id] = parseInt(row.count, 10);
                return acc;
            }, {});
            return {
                total_logs,
                by_report_type,
                by_action,
                by_user
            };
        });
    }
}
exports.BalanceReportAuditService = BalanceReportAuditService;
