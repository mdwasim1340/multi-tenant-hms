"use strict";
/**
 * Lab Order Controller
 *
 * HTTP request handlers for laboratory order management
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabOrders = getLabOrders;
exports.getLabOrderById = getLabOrderById;
exports.createLabOrder = createLabOrder;
exports.updateLabOrder = updateLabOrder;
exports.cancelLabOrder = cancelLabOrder;
exports.collectSpecimen = collectSpecimen;
exports.startProcessing = startProcessing;
exports.getOrdersByPatient = getOrdersByPatient;
exports.getLabOrderStatistics = getLabOrderStatistics;
const labOrderService = __importStar(require("../services/labOrder.service"));
const labTest_1 = require("../types/labTest");
/**
 * GET /api/lab-orders
 * Get all lab orders with optional filtering
 */
function getLabOrders(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const filters = {
                patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
                medical_record_id: req.query.medical_record_id ? parseInt(req.query.medical_record_id) : undefined,
                appointment_id: req.query.appointment_id ? parseInt(req.query.appointment_id) : undefined,
                ordered_by: req.query.ordered_by ? parseInt(req.query.ordered_by) : undefined,
                priority: req.query.priority,
                status: req.query.status,
                order_date_from: req.query.order_date_from,
                order_date_to: req.query.order_date_to,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 20,
                sort_by: req.query.sort_by || 'order_date',
                sort_order: req.query.sort_order || 'desc'
            };
            const result = yield labOrderService.getLabOrders(tenantId, filters);
            res.json(result);
        }
        catch (error) {
            console.error('Error getting lab orders:', error);
            res.status(500).json({ error: 'Failed to get lab orders' });
        }
    });
}
/**
 * GET /api/lab-orders/:id
 * Get lab order by ID with full details
 */
function getLabOrderById(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            const order = yield labOrderService.getLabOrderById(tenantId, orderId);
            if (!order) {
                res.status(404).json({ error: 'Lab order not found' });
                return;
            }
            res.json(order);
        }
        catch (error) {
            console.error('Error getting lab order:', error);
            res.status(500).json({ error: 'Failed to get lab order' });
        }
    });
}
/**
 * POST /api/lab-orders
 * Create new lab order
 */
function createLabOrder(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.CreateLabOrderSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const order = yield labOrderService.createLabOrder(tenantId, validationResult.data);
            res.status(201).json({
                message: 'Lab order created successfully',
                order
            });
        }
        catch (error) {
            console.error('Error creating lab order:', error);
            res.status(500).json({ error: 'Failed to create lab order' });
        }
    });
}
/**
 * PUT /api/lab-orders/:id
 * Update lab order
 */
function updateLabOrder(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.UpdateLabOrderSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const order = yield labOrderService.updateLabOrder(tenantId, orderId, validationResult.data);
            if (!order) {
                res.status(404).json({ error: 'Lab order not found' });
                return;
            }
            res.json({
                message: 'Lab order updated successfully',
                order
            });
        }
        catch (error) {
            console.error('Error updating lab order:', error);
            res.status(500).json({ error: 'Failed to update lab order' });
        }
    });
}
/**
 * DELETE /api/lab-orders/:id
 * Cancel lab order
 */
function cancelLabOrder(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            const reason = req.body.reason;
            const success = yield labOrderService.cancelLabOrder(tenantId, orderId, reason);
            if (!success) {
                res.status(404).json({ error: 'Lab order not found' });
                return;
            }
            res.json({ message: 'Lab order cancelled successfully' });
        }
        catch (error) {
            console.error('Error cancelling lab order:', error);
            res.status(500).json({ error: 'Failed to cancel lab order' });
        }
    });
}
/**
 * POST /api/lab-orders/:id/collect
 * Mark specimen collected
 */
function collectSpecimen(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            const collectedBy = req.body.collected_by;
            if (!collectedBy) {
                res.status(400).json({ error: 'collected_by is required' });
                return;
            }
            const success = yield labOrderService.collectSpecimen(tenantId, orderId, collectedBy);
            if (!success) {
                res.status(404).json({ error: 'Lab order not found' });
                return;
            }
            res.json({ message: 'Specimen collected successfully' });
        }
        catch (error) {
            console.error('Error collecting specimen:', error);
            res.status(500).json({ error: 'Failed to collect specimen' });
        }
    });
}
/**
 * POST /api/lab-orders/:id/process
 * Start processing order
 */
function startProcessing(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            const success = yield labOrderService.startProcessing(tenantId, orderId);
            if (!success) {
                res.status(404).json({ error: 'Lab order not found' });
                return;
            }
            res.json({ message: 'Order processing started successfully' });
        }
        catch (error) {
            console.error('Error starting processing:', error);
            res.status(500).json({ error: 'Failed to start processing' });
        }
    });
}
/**
 * GET /api/lab-orders/patient/:patientId
 * Get orders by patient
 */
function getOrdersByPatient(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const patientId = parseInt(req.params.patientId);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(patientId)) {
                res.status(400).json({ error: 'Invalid patient ID' });
                return;
            }
            const orders = yield labOrderService.getOrdersByPatient(tenantId, patientId);
            res.json({ orders });
        }
        catch (error) {
            console.error('Error getting orders by patient:', error);
            res.status(500).json({ error: 'Failed to get orders by patient' });
        }
    });
}
/**
 * GET /api/lab-orders/statistics
 * Get order statistics
 */
function getLabOrderStatistics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const statistics = yield labOrderService.getLabOrderStatistics(tenantId);
            res.json(statistics);
        }
        catch (error) {
            console.error('Error getting lab order statistics:', error);
            res.status(500).json({ error: 'Failed to get lab order statistics' });
        }
    });
}
