"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const patient_controller_1 = require("../controllers/patient.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// GET /api/patients/export - Export patients to CSV (requires read permission)
router.get('/export', (0, authorization_1.requirePermission)('patients', 'read'), patient_controller_1.exportPatientsCSV);
// GET /api/patients - List patients (requires read permission)
router.get('/', (0, authorization_1.requirePermission)('patients', 'read'), patient_controller_1.getPatients);
// POST /api/patients - Create patient (requires write permission)
router.post('/', (0, authorization_1.requirePermission)('patients', 'write'), patient_controller_1.createPatient);
// GET /api/patients/:id - Get patient by ID (requires read permission)
router.get('/:id', (0, authorization_1.requirePermission)('patients', 'read'), patient_controller_1.getPatientById);
// PUT /api/patients/:id - Update patient (requires write permission)
router.put('/:id', (0, authorization_1.requirePermission)('patients', 'write'), patient_controller_1.updatePatient);
// DELETE /api/patients/:id - Soft delete patient (requires admin permission)
router.delete('/:id', (0, authorization_1.requirePermission)('patients', 'admin'), patient_controller_1.deletePatient);
exports.default = router;
