"use strict";
/**
 * Bed Management - LOS Prediction API Routes
 * Endpoints for length of stay prediction functionality
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const los_prediction_service_1 = require("../services/los-prediction-service");
const bed_management_1 = require("../types/bed-management");
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const router = express_1.default.Router();
// Apply middleware to all routes
router.use(auth_1.authMiddleware);
router.use(tenant_1.tenantMiddleware);
/**
 * POST /api/bed-management/predict-los
 * Create a new LOS prediction for a patient admission
 */
router.post('/predict-los', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        // Validate request body
        const validatedData = bed_management_1.LOSPredictionSchema.parse(req.body);
        // Create prediction
        const prediction = yield los_prediction_service_1.losPredictionService.predictLOS({
            admission_id: validatedData.admission_id,
            patient_id: validatedData.patient_id,
            diagnosis: ((_b = validatedData.prediction_factors) === null || _b === void 0 ? void 0 : _b.diagnosis) || '',
            severity: ((_c = validatedData.prediction_factors) === null || _c === void 0 ? void 0 : _c.severity) || 'moderate',
            age: ((_d = validatedData.prediction_factors) === null || _d === void 0 ? void 0 : _d.age) || 50,
            comorbidities: ((_e = validatedData.prediction_factors) === null || _e === void 0 ? void 0 : _e.comorbidities) || [],
            admission_source: ((_f = validatedData.prediction_factors) === null || _f === void 0 ? void 0 : _f.admission_source) || 'emergency',
        }, tenantId, userId);
        res.status(201).json({
            success: true,
            message: 'LOS prediction created successfully',
            data: prediction,
        });
    }
    catch (error) {
        console.error('Error creating LOS prediction:', error);
        if (error.name === 'ZodError') {
            return res.status(400).json({
                success: false,
                error: 'Validation error',
                details: error.issues,
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to create LOS prediction',
        });
    }
}));
/**
 * GET /api/bed-management/los/:admissionId
 * Get LOS prediction for a specific admission
 */
router.get('/los/:admissionId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const admissionId = parseInt(req.params.admissionId);
        if (isNaN(admissionId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid admission ID',
            });
        }
        const prediction = yield los_prediction_service_1.losPredictionService.getPrediction(admissionId, tenantId);
        if (!prediction) {
            return res.status(404).json({
                success: false,
                error: 'No prediction found for this admission',
            });
        }
        res.json({
            success: true,
            data: prediction,
        });
    }
    catch (error) {
        console.error('Error getting LOS prediction:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get LOS prediction',
        });
    }
}));
/**
 * PUT /api/bed-management/los/:admissionId/actual
 * Update actual LOS when patient is discharged
 */
router.put('/los/:admissionId/actual', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const admissionId = parseInt(req.params.admissionId);
        const { actual_los_days } = req.body;
        if (isNaN(admissionId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid admission ID',
            });
        }
        if (!actual_los_days || actual_los_days <= 0) {
            return res.status(400).json({
                success: false,
                error: 'Valid actual_los_days is required',
            });
        }
        yield los_prediction_service_1.losPredictionService.updateActualLOS(admissionId, actual_los_days, tenantId);
        res.json({
            success: true,
            message: 'Actual LOS updated successfully',
        });
    }
    catch (error) {
        console.error('Error updating actual LOS:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to update actual LOS',
        });
    }
}));
/**
 * GET /api/bed-management/los/accuracy-metrics
 * Get accuracy metrics for LOS predictions
 */
router.get('/los/accuracy-metrics', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const days = parseInt(req.query.days) || 30;
        const metrics = yield los_prediction_service_1.losPredictionService.getAccuracyMetrics(tenantId, days);
        res.json({
            success: true,
            data: metrics,
            period_days: days,
        });
    }
    catch (error) {
        console.error('Error getting accuracy metrics:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get accuracy metrics',
        });
    }
}));
/**
 * GET /api/bed-management/los/predictions
 * Get all predictions with optional filters
 */
router.get('/los/predictions', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { patient_id, start_date, end_date, limit = '50', offset = '0', } = req.query;
        const options = {
            limit: parseInt(limit),
            offset: parseInt(offset),
        };
        if (patient_id) {
            options.patientId = parseInt(patient_id);
        }
        if (start_date) {
            options.startDate = new Date(start_date);
        }
        if (end_date) {
            options.endDate = new Date(end_date);
        }
        const result = yield los_prediction_service_1.losPredictionService.getAllPredictions(tenantId, options);
        res.json({
            success: true,
            data: result.predictions,
            pagination: {
                total: result.total,
                limit: options.limit,
                offset: options.offset,
                pages: Math.ceil(result.total / options.limit),
            },
        });
    }
    catch (error) {
        console.error('Error getting predictions:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get predictions',
        });
    }
}));
/**
 * PUT /api/bed-management/los/:admissionId/update
 * Update prediction for an admission (recalculate)
 */
router.put('/los/:admissionId/update', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        const admissionId = parseInt(req.params.admissionId);
        if (isNaN(admissionId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid admission ID',
            });
        }
        const prediction = yield los_prediction_service_1.losPredictionService.updatePrediction(admissionId, tenantId, userId);
        if (!prediction) {
            return res.status(404).json({
                success: false,
                error: 'No existing prediction found for this admission',
            });
        }
        res.json({
            success: true,
            message: 'Prediction updated successfully',
            data: prediction,
        });
    }
    catch (error) {
        console.error('Error updating prediction:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to update prediction',
        });
    }
}));
exports.default = router;
