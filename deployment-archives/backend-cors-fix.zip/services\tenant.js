"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTenantBySubdomain = exports.deleteTenant = exports.updateTenant = exports.createTenant = exports.getAllTenants = void 0;
const database_1 = __importDefault(require("../database"));
const subdomain_validator_1 = require("../utils/subdomain-validator");
const subdomain_cache_1 = require("./subdomain-cache");
// Migration runner will be handled separately
// const runner = require('node-pg-migrate');
const getAllTenants = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Query the main database (public schema) for tenants table
        const result = yield database_1.default.query('SELECT * FROM public.tenants ORDER BY name');
        res.status(200).json(result.rows);
    }
    catch (error) {
        console.error('Error fetching tenants:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});
exports.getAllTenants = getAllTenants;
const createTenant = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    let { id, name, email, plan, status, subdomain } = req.body;
    // Auto-generate ID if not provided
    if (!id) {
        id = `tenant_${Date.now()}`;
    }
    // Validate required fields (id is now guaranteed to exist)
    if (!name || !email || !plan || !status) {
        return res.status(400).json({ message: 'Missing required fields: name, email, plan, and status are required' });
    }
    // Validate subdomain if provided
    if (subdomain) {
        const validation = (0, subdomain_validator_1.validateSubdomain)(subdomain);
        if (!validation.valid) {
            return res.status(400).json({
                message: validation.error,
                code: validation.code
            });
        }
    }
    const client = yield database_1.default.connect();
    try {
        yield client.query('BEGIN');
        // Check if subdomain already exists
        if (subdomain) {
            const existingSubdomain = yield client.query('SELECT id FROM public.tenants WHERE subdomain = $1', [subdomain.toLowerCase().trim()]);
            if (existingSubdomain.rows.length > 0) {
                yield client.query('ROLLBACK');
                return res.status(409).json({
                    message: `The subdomain "${subdomain}" is already taken. Please choose another.`,
                    code: 'SUBDOMAIN_TAKEN'
                });
            }
        }
        // First, insert the tenant record with subdomain
        const insertQuery = subdomain
            ? 'INSERT INTO public.tenants (id, name, email, plan, status, subdomain) VALUES ($1, $2, $3, $4, $5, $6)'
            : 'INSERT INTO public.tenants (id, name, email, plan, status) VALUES ($1, $2, $3, $4, $5)';
        const insertValues = subdomain
            ? [id, name, email, plan, status, subdomain.toLowerCase().trim()]
            : [id, name, email, plan, status];
        yield client.query(insertQuery, insertValues);
        // Then create the schema
        yield client.query(`CREATE SCHEMA "${id}"`);
        // Finally, assign default subscription (Basic tier) - now that tenant exists
        // Create subscription directly in the same transaction
        yield client.query(`
      INSERT INTO tenant_subscriptions (
        tenant_id, tier_id, usage_limits, billing_cycle, status
      )
      VALUES ($1, $2, $3, $4, $5)
    `, [
            id,
            'basic',
            JSON.stringify({ max_patients: 500, max_users: 5, storage_gb: 10, api_calls_per_day: 1000 }),
            'monthly',
            'active'
        ]);
        // Create default branding record for the tenant
        yield client.query(`
      INSERT INTO tenant_branding (
        tenant_id, primary_color, secondary_color, accent_color
      )
      VALUES ($1, $2, $3, $4)
    `, [id, '#1e40af', '#3b82f6', '#60a5fa']);
        yield client.query('COMMIT');
        console.log(`✅ Tenant created successfully: ${name} (${id})${subdomain ? ` with subdomain: ${subdomain}` : ''}`);
        res.status(201).json({
            message: `Tenant ${name} created successfully`,
            tenant_id: id,
            subscription: 'basic',
            subdomain: subdomain || null
        });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error creating tenant:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
    finally {
        client.release();
    }
});
exports.createTenant = createTenant;
const updateTenant = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id } = req.params;
    const { name, email, plan, status, subdomain } = req.body;
    // Build dynamic update query based on provided fields
    const updates = [];
    const values = [];
    let paramCount = 1;
    if (name) {
        updates.push(`name = $${paramCount}`);
        values.push(name);
        paramCount++;
    }
    if (email) {
        updates.push(`email = $${paramCount}`);
        values.push(email);
        paramCount++;
    }
    if (plan) {
        updates.push(`plan = $${paramCount}`);
        values.push(plan);
        paramCount++;
    }
    if (status) {
        updates.push(`status = $${paramCount}`);
        values.push(status);
        paramCount++;
    }
    if (subdomain !== undefined) {
        // Validate subdomain if provided
        if (subdomain) {
            const validation = (0, subdomain_validator_1.validateSubdomain)(subdomain);
            if (!validation.valid) {
                return res.status(400).json({
                    message: validation.error,
                    code: validation.code
                });
            }
            // Check if subdomain is already taken by another tenant
            const existingSubdomain = yield database_1.default.query('SELECT id FROM public.tenants WHERE subdomain = $1 AND id != $2', [subdomain.toLowerCase().trim(), id]);
            if (existingSubdomain.rows.length > 0) {
                return res.status(409).json({
                    message: `The subdomain "${subdomain}" is already taken. Please choose another.`,
                    code: 'SUBDOMAIN_TAKEN'
                });
            }
        }
        updates.push(`subdomain = $${paramCount}`);
        values.push(subdomain ? subdomain.toLowerCase().trim() : null);
        paramCount++;
    }
    if (updates.length === 0) {
        return res.status(400).json({ message: 'No fields to update' });
    }
    // Add tenant ID as the last parameter
    values.push(id);
    const client = yield database_1.default.connect();
    try {
        yield client.query('BEGIN');
        // Update tenant
        const query = `UPDATE public.tenants SET ${updates.join(', ')} WHERE id = $${paramCount}`;
        const result = yield client.query(query, values);
        if (result.rowCount === 0) {
            yield client.query('ROLLBACK');
            return res.status(404).json({ message: 'Tenant not found' });
        }
        // If subdomain was updated, invalidate cache
        if (subdomain !== undefined) {
            const { subdomainCache } = yield Promise.resolve().then(() => __importStar(require('./subdomain-cache')));
            if (subdomain) {
                // Cache will be populated on next lookup
                console.log(`🔄 Subdomain updated for tenant ${id}: ${subdomain}`);
            }
            else {
                console.log(`🔄 Subdomain removed for tenant ${id}`);
            }
        }
        yield client.query('COMMIT');
        res.status(200).json({
            message: `Tenant ${name || id} updated successfully`,
            subdomain: subdomain || null
        });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error updating tenant:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
    finally {
        client.release();
    }
});
exports.updateTenant = updateTenant;
const deleteTenant = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id } = req.params;
    const client = yield database_1.default.connect();
    try {
        yield client.query('BEGIN');
        yield client.query(`DROP SCHEMA "${id}" CASCADE`);
        yield client.query('DELETE FROM public.tenants WHERE id = $1', [id]);
        yield client.query('COMMIT');
        res.status(200).json({ message: `Tenant ${id} deleted successfully` });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error deleting tenant:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
    finally {
        client.release();
    }
});
exports.deleteTenant = deleteTenant;
/**
 * Resolve subdomain to tenant information
 * Requirements: 4.1, 4.2, 4.3
 *
 * GET /api/tenants/by-subdomain/:subdomain
 */
const getTenantBySubdomain = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { subdomain } = req.params;
    try {
        // Validate subdomain format
        const validation = (0, subdomain_validator_1.validateSubdomain)(subdomain);
        if (!validation.valid) {
            console.log(`❌ Invalid subdomain format: ${subdomain} - ${validation.error}`);
            return res.status(400).json({
                error: validation.error,
                code: validation.code,
                suggestions: (0, subdomain_validator_1.suggestAlternatives)(subdomain),
            });
        }
        // Normalize subdomain
        const normalizedSubdomain = subdomain.toLowerCase().trim();
        // Check cache first
        const cachedTenantId = yield subdomain_cache_1.subdomainCache.get(normalizedSubdomain);
        if (cachedTenantId) {
            // Get full tenant info from database
            const result = yield database_1.default.query(`SELECT 
          t.id as tenant_id,
          t.name,
          t.status,
          CASE WHEN tb.tenant_id IS NOT NULL THEN true ELSE false END as branding_enabled
        FROM tenants t
        LEFT JOIN tenant_branding tb ON t.id = tb.tenant_id
        WHERE t.id = $1 AND t.status = 'active'`, [cachedTenantId]);
            if (result.rows.length > 0) {
                console.log(`✅ Subdomain resolved (from cache): ${normalizedSubdomain} → ${cachedTenantId}`);
                return res.status(200).json(result.rows[0]);
            }
        }
        // Cache miss or invalid cached data - query database
        const result = yield database_1.default.query(`SELECT 
        t.id as tenant_id,
        t.name,
        t.status,
        CASE WHEN tb.tenant_id IS NOT NULL THEN true ELSE false END as branding_enabled
      FROM tenants t
      LEFT JOIN tenant_branding tb ON t.id = tb.tenant_id
      WHERE t.subdomain = $1 AND t.status = 'active'`, [normalizedSubdomain]);
        if (result.rows.length === 0) {
            // Subdomain not found
            console.log(`❌ Subdomain not found: ${normalizedSubdomain}`);
            // Log for monitoring
            console.log(`[SUBDOMAIN_LOOKUP_FAILED] subdomain=${normalizedSubdomain} timestamp=${new Date().toISOString()}`);
            return res.status(404).json({
                error: 'Hospital not found',
                message: `No hospital found with subdomain '${normalizedSubdomain}'. Please check your URL.`,
                code: 'SUBDOMAIN_NOT_FOUND',
                suggestions: [
                    'Verify the subdomain spelling',
                    'Contact your hospital administrator',
                    'Visit the main website to find your hospital',
                ],
            });
        }
        const tenant = result.rows[0];
        // Cache the result
        yield subdomain_cache_1.subdomainCache.set(normalizedSubdomain, tenant.tenant_id);
        console.log(`✅ Subdomain resolved (from database): ${normalizedSubdomain} → ${tenant.tenant_id}`);
        return res.status(200).json(tenant);
    }
    catch (error) {
        console.error('Error resolving subdomain:', error);
        // Log error for monitoring
        console.log(`[SUBDOMAIN_RESOLUTION_ERROR] subdomain=${subdomain} error=${error} timestamp=${new Date().toISOString()}`);
        return res.status(500).json({
            error: 'Internal server error',
            message: 'Failed to resolve subdomain. Please try again later.',
            code: 'SUBDOMAIN_RESOLUTION_ERROR',
        });
    }
});
exports.getTenantBySubdomain = getTenantBySubdomain;
