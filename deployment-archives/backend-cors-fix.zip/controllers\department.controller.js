"use strict";
/**
 * Department Controller
 * HTTP request handlers for department management endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDepartmentsWithOccupancy = exports.getDepartmentStats = exports.updateDepartment = exports.createDepartment = exports.getDepartmentById = exports.getDepartments = void 0;
const department_service_1 = __importDefault(require("../services/department.service"));
const bed_validation_1 = require("../validation/bed.validation");
const bed_1 = require("../types/bed");
/**
 * GET /api/departments
 * List all departments
 */
const getDepartments = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Validate query parameters
        const params = bed_validation_1.DepartmentSearchSchema.parse(req.query);
        const result = yield department_service_1.default.getDepartments(tenantId, params);
        res.json(result);
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Get departments error:', error);
        res.status(500).json({
            error: 'Failed to fetch departments',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getDepartments = getDepartments;
/**
 * GET /api/departments/:id
 * Get department by ID
 */
const getDepartmentById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const departmentId = parseInt(req.params.id);
        if (isNaN(departmentId)) {
            return res.status(400).json({ error: 'Invalid department ID' });
        }
        const department = yield department_service_1.default.getDepartmentById(tenantId, departmentId);
        res.json({ department });
    }
    catch (error) {
        if (error instanceof bed_1.DepartmentNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Get department error:', error);
        res.status(500).json({
            error: 'Failed to fetch department',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getDepartmentById = getDepartmentById;
/**
 * POST /api/departments
 * Create new department
 */
const createDepartment = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        // Validate request body
        const data = bed_validation_1.CreateDepartmentSchema.parse(req.body);
        const department = yield department_service_1.default.createDepartment(tenantId, data, userId);
        res.status(201).json({
            message: 'Department created successfully',
            department,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Create department error:', error);
        res.status(500).json({
            error: 'Failed to create department',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.createDepartment = createDepartment;
/**
 * PUT /api/departments/:id
 * Update department
 */
const updateDepartment = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const departmentId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(departmentId)) {
            return res.status(400).json({ error: 'Invalid department ID' });
        }
        // Validate request body
        const data = bed_validation_1.UpdateDepartmentSchema.parse(req.body);
        const department = yield department_service_1.default.updateDepartment(tenantId, departmentId, data, userId);
        res.json({
            message: 'Department updated successfully',
            department,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.DepartmentNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Update department error:', error);
        res.status(500).json({
            error: 'Failed to update department',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.updateDepartment = updateDepartment;
/**
 * GET /api/departments/:id/stats
 * Get department statistics
 */
const getDepartmentStats = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const departmentId = parseInt(req.params.id);
        if (isNaN(departmentId)) {
            return res.status(400).json({ error: 'Invalid department ID' });
        }
        const stats = yield department_service_1.default.getDepartmentStats(tenantId, departmentId);
        res.json(stats);
    }
    catch (error) {
        if (error instanceof bed_1.DepartmentNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Get department stats error:', error);
        res.status(500).json({
            error: 'Failed to fetch department statistics',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getDepartmentStats = getDepartmentStats;
/**
 * GET /api/departments/occupancy
 * Get all departments with occupancy metrics
 */
const getDepartmentsWithOccupancy = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const departments = yield department_service_1.default.getDepartmentsWithOccupancy(tenantId);
        res.json({
            departments,
            count: departments.length,
        });
    }
    catch (error) {
        console.error('Get departments occupancy error:', error);
        res.status(500).json({
            error: 'Failed to fetch departments with occupancy',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getDepartmentsWithOccupancy = getDepartmentsWithOccupancy;
