"use strict";
/**
 * Lab Result Service
 * Business logic for managing laboratory test results
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabResults = getLabResults;
exports.getLabResultById = getLabResultById;
exports.getResultsByOrder = getResultsByOrder;
exports.getResultByOrderItem = getResultByOrderItem;
exports.addLabResult = addLabResult;
exports.addDirectLabResult = addDirectLabResult;
exports.updateLabResult = updateLabResult;
exports.verifyLabResult = verifyLabResult;
exports.getAbnormalResults = getAbnormalResults;
exports.getCriticalResults = getCriticalResults;
exports.getResultHistory = getResultHistory;
exports.addResultAttachment = addResultAttachment;
exports.getLabResultStatistics = getLabResultStatistics;
const database_1 = __importDefault(require("../database"));
/**
 * Get lab results with optional filtering - includes direct results
 */
function getLabResults(tenantId_1) {
    return __awaiter(this, arguments, void 0, function* (tenantId, filters = {}) {
        const { patient_id, is_abnormal, page = 1, limit = 50 } = filters;
        const offset = (page - 1) * limit;
        yield database_1.default.query('SET search_path TO "' + tenantId + '"');
        // Try direct_lab_results table first
        try {
            const tableCheck = yield database_1.default.query("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_schema = '" + tenantId + "' AND table_name = 'direct_lab_results')");
            if (tableCheck.rows[0].exists) {
                let whereClause = '1=1';
                const params = [];
                let idx = 1;
                if (patient_id) {
                    whereClause += ' AND dlr.patient_id = $' + idx;
                    params.push(patient_id);
                    idx++;
                }
                if (is_abnormal !== undefined) {
                    whereClause += ' AND dlr.is_abnormal = $' + idx;
                    params.push(is_abnormal);
                    idx++;
                }
                const query = "SELECT dlr.id, dlr.patient_id, dlr.test_id, dlr.result_value, dlr.result_unit, " +
                    "dlr.reference_range, dlr.is_abnormal, dlr.abnormal_flag, dlr.result_date as report_date, " +
                    "dlr.notes, dlr.created_at, ltd.test_code, ltd.test_name, " +
                    "dlr.sample_type, dlr.ordering_doctor, COALESCE(dlr.result_status, 'final') as result_status, " +
                    "dlr.attachment_file_id, dlr.attachment_filename, " +
                    "p.first_name || ' ' || p.last_name as patient_name, p.patient_number, " +
                    "COALESCE(dlr.result_status, 'final') as status, dlr.is_abnormal as has_abnormal, COALESCE(dlr.ordering_doctor, 'N/A') as ordering_doctor_name " +
                    "FROM direct_lab_results dlr " +
                    "LEFT JOIN lab_test_definitions ltd ON dlr.test_id = ltd.id " +
                    "LEFT JOIN patients p ON dlr.patient_id = p.id " +
                    "WHERE " + whereClause + " ORDER BY dlr.result_date DESC LIMIT $" + idx + " OFFSET $" + (idx + 1);
                params.push(limit, offset);
                const result = yield database_1.default.query(query, params);
                // Count query
                let countWhere = '1=1';
                if (patient_id)
                    countWhere += ' AND patient_id = ' + patient_id;
                const countResult = yield database_1.default.query("SELECT COUNT(*) as total FROM direct_lab_results WHERE " + countWhere);
                const total = parseInt(countResult.rows[0].total);
                return {
                    results: result.rows,
                    pagination: { page, limit, total, pages: Math.ceil(total / limit) }
                };
            }
        }
        catch (err) {
            console.warn('Direct results query error:', err);
        }
        return { results: [], pagination: { page, limit, total: 0, pages: 0 } };
    });
}
function getLabResultById(tenantId, resultId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query('SET search_path TO "' + tenantId + '"');
        const result = yield database_1.default.query("SELECT dlr.*, ltd.test_code, ltd.test_name FROM direct_lab_results dlr " +
            "LEFT JOIN lab_test_definitions ltd ON dlr.test_id = ltd.id WHERE dlr.id = $1", [resultId]);
        return result.rows[0] || null;
    });
}
function getResultsByOrder(tenantId, orderId) {
    return __awaiter(this, void 0, void 0, function* () {
        return [];
    });
}
function getResultByOrderItem(tenantId, orderItemId) {
    return __awaiter(this, void 0, void 0, function* () {
        return null;
    });
}
function addLabResult(tenantId, resultData) {
    return __awaiter(this, void 0, void 0, function* () {
        throw new Error('Use addDirectLabResult instead');
    });
}
/**
 * Add direct lab result (without order)
 */
function addDirectLabResult(tenantId, data) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query('SET search_path TO "' + tenantId + '"');
        // Create table if not exists with new columns
        yield database_1.default.query("CREATE TABLE IF NOT EXISTS direct_lab_results (" +
            "id SERIAL PRIMARY KEY, patient_id INTEGER NOT NULL, test_id INTEGER NOT NULL, " +
            "result_value VARCHAR(500), result_unit VARCHAR(50), reference_range VARCHAR(255), " +
            "is_abnormal BOOLEAN DEFAULT false, abnormal_flag VARCHAR(10), " +
            "result_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, notes TEXT, " +
            "sample_type VARCHAR(50), ordering_doctor VARCHAR(100), result_status VARCHAR(20) DEFAULT 'final', " +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        // Add new columns if they don't exist (for existing tables)
        try {
            yield database_1.default.query("ALTER TABLE direct_lab_results ADD COLUMN IF NOT EXISTS sample_type VARCHAR(50)");
            yield database_1.default.query("ALTER TABLE direct_lab_results ADD COLUMN IF NOT EXISTS ordering_doctor VARCHAR(100)");
            yield database_1.default.query("ALTER TABLE direct_lab_results ADD COLUMN IF NOT EXISTS result_status VARCHAR(20) DEFAULT 'final'");
            yield database_1.default.query("ALTER TABLE direct_lab_results ADD COLUMN IF NOT EXISTS attachment_file_id VARCHAR(500)");
            yield database_1.default.query("ALTER TABLE direct_lab_results ADD COLUMN IF NOT EXISTS attachment_filename VARCHAR(255)");
        }
        catch (err) {
            // Columns may already exist, ignore error
        }
        // Get test info
        const testResult = yield database_1.default.query('SELECT test_code, test_name, unit, normal_range_min, normal_range_max, normal_range_text FROM lab_test_definitions WHERE id = $1', [data.test_id]);
        const test = testResult.rows[0];
        // Auto-detect abnormal
        let isAbnormal = data.is_abnormal || false;
        let abnormalFlag = data.abnormal_flag || null;
        if (test && !data.is_abnormal) {
            const numericValue = parseFloat(data.result_value);
            if (!isNaN(numericValue)) {
                const min = test.normal_range_min ? parseFloat(test.normal_range_min) : null;
                const max = test.normal_range_max ? parseFloat(test.normal_range_max) : null;
                if (min !== null && numericValue < min) {
                    isAbnormal = true;
                    abnormalFlag = 'L';
                }
                else if (max !== null && numericValue > max) {
                    isAbnormal = true;
                    abnormalFlag = 'H';
                }
            }
        }
        const refRange = data.reference_range || (test === null || test === void 0 ? void 0 : test.normal_range_text) ||
            ((test === null || test === void 0 ? void 0 : test.normal_range_min) && (test === null || test === void 0 ? void 0 : test.normal_range_max) ? test.normal_range_min + ' - ' + test.normal_range_max : null);
        const result = yield database_1.default.query("INSERT INTO direct_lab_results (patient_id, test_id, result_value, result_unit, reference_range, " +
            "is_abnormal, abnormal_flag, result_date, notes, sample_type, ordering_doctor, result_status, " +
            "attachment_file_id, attachment_filename) " +
            "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING *", [data.patient_id, data.test_id, data.result_value, data.result_unit || (test === null || test === void 0 ? void 0 : test.unit) || null,
            refRange, isAbnormal, abnormalFlag, data.result_date || new Date().toISOString(), data.notes || null,
            data.sample_type || null, data.ordering_doctor || null, data.result_status || 'final',
            data.attachment_file_id || null, data.attachment_filename || null]);
        return Object.assign(Object.assign({}, result.rows[0]), { test_code: test === null || test === void 0 ? void 0 : test.test_code, test_name: test === null || test === void 0 ? void 0 : test.test_name });
    });
}
function updateLabResult(tenantId, resultId, data) {
    return __awaiter(this, void 0, void 0, function* () {
        return null;
    });
}
function verifyLabResult(tenantId, resultId, verifiedBy) {
    return __awaiter(this, void 0, void 0, function* () {
        return null;
    });
}
function getAbnormalResults(tenantId, patientId) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield getLabResults(tenantId, { is_abnormal: true, patient_id: patientId, limit: 100 });
        return response.results;
    });
}
function getCriticalResults(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        return [];
    });
}
function getResultHistory(tenantId, patientId, testCode) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield getLabResults(tenantId, { patient_id: patientId, limit: 50 });
        return response.results;
    });
}
function addResultAttachment(tenantId, resultId, attachment) {
    return __awaiter(this, void 0, void 0, function* () {
        return null;
    });
}
function getLabResultStatistics(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query('SET search_path TO "' + tenantId + '"');
        try {
            const result = yield database_1.default.query("SELECT COUNT(*) as total_results, " +
                "COUNT(CASE WHEN is_abnormal = true THEN 1 END) as abnormal_results, " +
                "0 as verified_results, 0 as pending_verification, " +
                "COUNT(CASE WHEN abnormal_flag IN ('HH', 'LL') THEN 1 END) as critical_results " +
                "FROM direct_lab_results WHERE result_date >= CURRENT_DATE - INTERVAL '30 days'");
            return {
                total_results: parseInt(result.rows[0].total_results) || 0,
                abnormal_results: parseInt(result.rows[0].abnormal_results) || 0,
                verified_results: 0,
                pending_verification: 0,
                critical_results: parseInt(result.rows[0].critical_results) || 0
            };
        }
        catch (_a) {
            return { total_results: 0, abnormal_results: 0, verified_results: 0, pending_verification: 0, critical_results: 0 };
        }
    });
}
