"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const health_controller_1 = require("../controllers/health.controller");
const router = (0, express_1.Router)();
/**
 * Health Check Routes
 *
 * These endpoints are used to monitor the health and availability
 * of the application and its dependencies.
 *
 * No authentication required - used by monitoring tools and orchestrators
 */
// Basic health check - returns application status
router.get('/', health_controller_1.getHealth);
// Individual service health checks
router.get('/db', health_controller_1.getHealthDatabase);
router.get('/redis', health_controller_1.getHealthRedis);
router.get('/storage', health_controller_1.getHealthStorage);
// Comprehensive health check - all services
router.get('/all', health_controller_1.getHealthAll);
// Kubernetes-style health checks
router.get('/ready', health_controller_1.getHealthReady); // Readiness probe
router.get('/live', health_controller_1.getHealthLive); // Liveness probe
exports.default = router;
