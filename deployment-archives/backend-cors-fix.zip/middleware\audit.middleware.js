"use strict";
/**
 * Team Alpha - Audit Middleware
 * Automatically log all operations for HIPAA compliance
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditMedicalRecordOperation = auditMedicalRecordOperation;
exports.auditFileOperation = auditFileOperation;
exports.auditOperation = auditOperation;
exports.auditAccessDenied = auditAccessDenied;
const audit_service_1 = require("../services/audit.service");
/**
 * Extract user information from request
 */
function getUserInfo(req) {
    // User info should be attached by auth middleware
    const user = req.user;
    const tenantId = req.headers['x-tenant-id'];
    if (!user || !tenantId) {
        return null;
    }
    return {
        userId: user.id || user.userId,
        tenantId,
    };
}
/**
 * Extract IP address from request
 */
function getIpAddress(req) {
    var _a;
    return (((_a = req.headers['x-forwarded-for']) === null || _a === void 0 ? void 0 : _a.split(',')[0]) ||
        req.socket.remoteAddress ||
        'unknown');
}
/**
 * Middleware to audit medical record operations
 */
function auditMedicalRecordOperation(action) {
    return (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        const userInfo = getUserInfo(req);
        if (!userInfo) {
            return next(); // Skip audit if no user info (shouldn't happen with auth middleware)
        }
        // Store original send function
        const originalSend = res.send;
        // Override send to capture response
        res.send = function (data) {
            var _a, _b;
            // Only log successful operations (2xx status codes)
            if (res.statusCode >= 200 && res.statusCode < 300) {
                // Extract resource ID from response or request
                let resourceId;
                if (req.params.id) {
                    resourceId = parseInt(req.params.id);
                }
                else if (typeof data === 'string') {
                    try {
                        const jsonData = JSON.parse(data);
                        resourceId = jsonData.id || ((_a = jsonData.medical_record) === null || _a === void 0 ? void 0 : _a.id) || ((_b = jsonData.record) === null || _b === void 0 ? void 0 : _b.id);
                    }
                    catch (e) {
                        // Not JSON, skip
                    }
                }
                // Extract changes for UPDATE operations
                let changes;
                if (action === 'UPDATE' && req.body) {
                    changes = {
                        updated_fields: Object.keys(req.body),
                        new_values: req.body,
                    };
                }
                // Create audit log (async, don't wait)
                (0, audit_service_1.createAuditLog)({
                    tenant_id: userInfo.tenantId,
                    user_id: userInfo.userId,
                    action,
                    resource_type: 'medical_record',
                    resource_id: resourceId,
                    changes,
                    ip_address: getIpAddress(req),
                    user_agent: req.headers['user-agent'],
                }).catch((error) => {
                    console.error('Failed to create audit log:', error);
                });
            }
            // Call original send
            return originalSend.call(this, data);
        };
        next();
    });
}
/**
 * Middleware to audit file operations
 */
function auditFileOperation(action) {
    return (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        const userInfo = getUserInfo(req);
        if (!userInfo) {
            return next();
        }
        const originalSend = res.send;
        res.send = function (data) {
            var _a, _b, _c;
            if (res.statusCode >= 200 && res.statusCode < 300) {
                let resourceId;
                let changes;
                // Extract file information
                if (typeof data === 'string') {
                    try {
                        const jsonData = JSON.parse(data);
                        resourceId = jsonData.file_id || jsonData.attachment_id;
                        changes = {
                            file_name: jsonData.file_name || ((_a = req.body) === null || _a === void 0 ? void 0 : _a.file_name),
                            file_size: jsonData.file_size || ((_b = req.body) === null || _b === void 0 ? void 0 : _b.file_size),
                            file_type: jsonData.file_type || ((_c = req.body) === null || _c === void 0 ? void 0 : _c.file_type),
                        };
                    }
                    catch (e) {
                        // Not JSON
                    }
                }
                (0, audit_service_1.createAuditLog)({
                    tenant_id: userInfo.tenantId,
                    user_id: userInfo.userId,
                    action,
                    resource_type: 'record_attachment',
                    resource_id: resourceId,
                    changes,
                    ip_address: getIpAddress(req),
                    user_agent: req.headers['user-agent'],
                }).catch((error) => {
                    console.error('Failed to create audit log:', error);
                });
            }
            return originalSend.call(this, data);
        };
        next();
    });
}
/**
 * Generic audit middleware for any resource type
 */
function auditOperation(action, resourceType) {
    return (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        const userInfo = getUserInfo(req);
        if (!userInfo) {
            return next();
        }
        const originalSend = res.send;
        res.send = function (data) {
            if (res.statusCode >= 200 && res.statusCode < 300) {
                let resourceId;
                if (req.params.id) {
                    resourceId = parseInt(req.params.id);
                }
                let changes;
                if (action === 'UPDATE' && req.body) {
                    changes = {
                        updated_fields: Object.keys(req.body),
                    };
                }
                (0, audit_service_1.createAuditLog)({
                    tenant_id: userInfo.tenantId,
                    user_id: userInfo.userId,
                    action,
                    resource_type: resourceType,
                    resource_id: resourceId,
                    changes,
                    ip_address: getIpAddress(req),
                    user_agent: req.headers['user-agent'],
                }).catch((error) => {
                    console.error('Failed to create audit log:', error);
                });
            }
            return originalSend.call(this, data);
        };
        next();
    });
}
/**
 * Audit access denied attempts
 */
function auditAccessDenied(req, resourceType, resourceId) {
    return __awaiter(this, void 0, void 0, function* () {
        const userInfo = getUserInfo(req);
        if (!userInfo) {
            return;
        }
        try {
            yield (0, audit_service_1.createAuditLog)({
                tenant_id: userInfo.tenantId,
                user_id: userInfo.userId,
                action: 'ACCESS_DENIED',
                resource_type: resourceType,
                resource_id: resourceId,
                ip_address: getIpAddress(req),
                user_agent: req.headers['user-agent'],
            });
        }
        catch (error) {
            console.error('Failed to audit access denied:', error);
        }
    });
}
