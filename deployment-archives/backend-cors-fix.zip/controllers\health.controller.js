"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getHealthLive = exports.getHealthReady = exports.getHealthAll = exports.getHealthStorage = exports.getHealthRedis = exports.getHealthDatabase = exports.getHealth = void 0;
const database_1 = __importDefault(require("../database"));
const redis_1 = require("../config/redis");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
/**
 * Health Check Controller
 *
 * Provides endpoints to monitor system health including:
 * - Basic application health
 * - Database connectivity
 * - Redis connectivity
 * - Storage availability (local or S3)
 */
// Package version from package.json
const packageJson = require('../../package.json');
const APP_VERSION = packageJson.version || '1.0.0';
const APP_NAME = packageJson.name || 'hospital-backend';
/**
 * Basic health check
 * GET /health
 *
 * Returns:
 * - 200: Application is running
 * - Response: { status, timestamp, uptime, version, environment }
 */
const getHealth = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const healthData = {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            version: APP_VERSION,
            environment: process.env.NODE_ENV || 'development',
            name: APP_NAME,
        };
        res.status(200).json(healthData);
    }
    catch (error) {
        res.status(500).json({
            status: 'unhealthy',
            timestamp: new Date().toISOString(),
            error: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getHealth = getHealth;
/**
 * Database health check
 * GET /health/db
 *
 * Tests PostgreSQL connection
 *
 * Returns:
 * - 200: Database connected
 * - 503: Database unavailable
 * - Response: { status, responseTime, details }
 */
const getHealthDatabase = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const startTime = Date.now();
    try {
        // Test database connection with a simple query
        const result = yield database_1.default.query('SELECT NOW() as now, version() as version');
        const responseTime = Date.now() - startTime;
        const healthData = {
            status: 'healthy',
            service: 'postgresql',
            responseTime: `${responseTime}ms`,
            timestamp: new Date().toISOString(),
            details: {
                serverTime: result.rows[0].now,
                version: result.rows[0].version.split(' ')[0] + ' ' + result.rows[0].version.split(' ')[1],
                connected: true,
            },
        };
        res.status(200).json(healthData);
    }
    catch (error) {
        const responseTime = Date.now() - startTime;
        res.status(503).json({
            status: 'unhealthy',
            service: 'postgresql',
            responseTime: `${responseTime}ms`,
            timestamp: new Date().toISOString(),
            details: {
                connected: false,
                error: error instanceof Error ? error.message : 'Unknown error',
            },
        });
    }
});
exports.getHealthDatabase = getHealthDatabase;
/**
 * Redis health check
 * GET /health/redis
 *
 * Tests Redis connection
 *
 * Returns:
 * - 200: Redis connected
 * - 503: Redis unavailable
 * - Response: { status, responseTime, details }
 */
const getHealthRedis = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const startTime = Date.now();
    try {
        // Test Redis connection with PING
        const pingResult = yield redis_1.redisClient.ping();
        const responseTime = Date.now() - startTime;
        // Get Redis info
        const info = yield redis_1.redisClient.info('server');
        const versionMatch = info.match(/redis_version:([^\r\n]+)/);
        const version = versionMatch ? versionMatch[1] : 'unknown';
        const healthData = {
            status: 'healthy',
            service: 'redis',
            responseTime: `${responseTime}ms`,
            timestamp: new Date().toISOString(),
            details: {
                connected: pingResult === 'PONG',
                version: version,
                ping: pingResult,
            },
        };
        res.status(200).json(healthData);
    }
    catch (error) {
        const responseTime = Date.now() - startTime;
        res.status(503).json({
            status: 'unhealthy',
            service: 'redis',
            responseTime: `${responseTime}ms`,
            timestamp: new Date().toISOString(),
            details: {
                connected: false,
                error: error instanceof Error ? error.message : 'Unknown error',
            },
        });
    }
});
exports.getHealthRedis = getHealthRedis;
/**
 * Storage health check
 * GET /health/storage
 *
 * Tests storage availability (local or S3)
 *
 * Returns:
 * - 200: Storage available
 * - 503: Storage unavailable
 * - Response: { status, responseTime, details }
 */
const getHealthStorage = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const startTime = Date.now();
    const useLocalStorage = process.env.USE_LOCAL_STORAGE === 'true';
    try {
        if (useLocalStorage) {
            // Test local storage
            const uploadDir = path.join(__dirname, '..', '..', process.env.UPLOAD_DIR || 'uploads');
            // Check if directory exists
            const dirExists = fs.existsSync(uploadDir);
            if (!dirExists) {
                throw new Error(`Upload directory does not exist: ${uploadDir}`);
            }
            // Check if directory is writable
            try {
                const testFile = path.join(uploadDir, '.health-check');
                fs.writeFileSync(testFile, 'health check');
                fs.unlinkSync(testFile);
            }
            catch (writeError) {
                throw new Error('Upload directory is not writable');
            }
            const responseTime = Date.now() - startTime;
            const healthData = {
                status: 'healthy',
                service: 'local-storage',
                responseTime: `${responseTime}ms`,
                timestamp: new Date().toISOString(),
                details: {
                    type: 'local',
                    path: uploadDir,
                    writable: true,
                    available: true,
                },
            };
            res.status(200).json(healthData);
        }
        else {
            // Test S3 storage
            const AWS = require('aws-sdk');
            if (!process.env.AWS_ACCESS_KEY_ID || !process.env.S3_BUCKET_NAME) {
                throw new Error('S3 configuration missing (AWS_ACCESS_KEY_ID or S3_BUCKET_NAME)');
            }
            const s3 = new AWS.S3({
                accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION || 'us-east-1',
            });
            const bucketName = process.env.S3_BUCKET_NAME;
            // Test S3 access by checking bucket existence
            yield s3.headBucket({ Bucket: bucketName }).promise();
            const responseTime = Date.now() - startTime;
            const healthData = {
                status: 'healthy',
                service: 's3-storage',
                responseTime: `${responseTime}ms`,
                timestamp: new Date().toISOString(),
                details: {
                    type: 's3',
                    bucket: bucketName,
                    region: process.env.AWS_REGION || 'us-east-1',
                    available: true,
                },
            };
            res.status(200).json(healthData);
        }
    }
    catch (error) {
        const responseTime = Date.now() - startTime;
        res.status(503).json({
            status: 'unhealthy',
            service: useLocalStorage ? 'local-storage' : 's3-storage',
            responseTime: `${responseTime}ms`,
            timestamp: new Date().toISOString(),
            details: {
                type: useLocalStorage ? 'local' : 's3',
                available: false,
                error: error instanceof Error ? error.message : 'Unknown error',
            },
        });
    }
});
exports.getHealthStorage = getHealthStorage;
/**
 * Comprehensive health check
 * GET /health/all
 *
 * Tests all services (database, redis, storage)
 *
 * Returns:
 * - 200: All services healthy
 * - 503: One or more services unhealthy
 * - Response: { status, services: { database, redis, storage }, summary }
 */
const getHealthAll = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const startTime = Date.now();
    const results = {
        application: { status: 'healthy' },
        database: { status: 'unknown' },
        redis: { status: 'unknown' },
        storage: { status: 'unknown' },
    };
    // Test Database
    try {
        yield database_1.default.query('SELECT 1');
        results.database = { status: 'healthy' };
    }
    catch (error) {
        results.database = {
            status: 'unhealthy',
            error: error instanceof Error ? error.message : 'Unknown error',
        };
    }
    // Test Redis
    try {
        yield redis_1.redisClient.ping();
        results.redis = { status: 'healthy' };
    }
    catch (error) {
        results.redis = {
            status: 'unhealthy',
            error: error instanceof Error ? error.message : 'Unknown error',
        };
    }
    // Test Storage
    try {
        const useLocalStorage = process.env.USE_LOCAL_STORAGE === 'true';
        if (useLocalStorage) {
            const uploadDir = path.join(__dirname, '..', '..', process.env.UPLOAD_DIR || 'uploads');
            const dirExists = fs.existsSync(uploadDir);
            if (dirExists) {
                results.storage = { status: 'healthy', type: 'local' };
            }
            else {
                throw new Error('Upload directory does not exist');
            }
        }
        else {
            const AWS = require('aws-sdk');
            const s3 = new AWS.S3({
                accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION || 'us-east-1',
            });
            yield s3.headBucket({ Bucket: process.env.S3_BUCKET_NAME }).promise();
            results.storage = { status: 'healthy', type: 's3' };
        }
    }
    catch (error) {
        results.storage = {
            status: 'unhealthy',
            error: error instanceof Error ? error.message : 'Unknown error',
        };
    }
    const responseTime = Date.now() - startTime;
    // Determine overall status
    const allHealthy = Object.values(results).every((service) => service.status === 'healthy');
    const healthData = {
        status: allHealthy ? 'healthy' : 'degraded',
        timestamp: new Date().toISOString(),
        responseTime: `${responseTime}ms`,
        version: APP_VERSION,
        environment: process.env.NODE_ENV || 'development',
        services: results,
    };
    res.status(allHealthy ? 200 : 503).json(healthData);
});
exports.getHealthAll = getHealthAll;
/**
 * Readiness check
 * GET /health/ready
 *
 * Checks if the application is ready to serve traffic
 * Used by orchestrators like Kubernetes
 *
 * Returns:
 * - 200: Ready
 * - 503: Not ready
 */
const getHealthReady = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Check critical services only
        yield database_1.default.query('SELECT 1');
        yield redis_1.redisClient.ping();
        res.status(200).json({
            status: 'ready',
            timestamp: new Date().toISOString(),
        });
    }
    catch (error) {
        res.status(503).json({
            status: 'not ready',
            timestamp: new Date().toISOString(),
            error: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getHealthReady = getHealthReady;
/**
 * Liveness check
 * GET /health/live
 *
 * Checks if the application is alive
 * Used by orchestrators like Kubernetes
 *
 * Returns:
 * - 200: Alive
 */
const getHealthLive = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    res.status(200).json({
        status: 'alive',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
    });
});
exports.getHealthLive = getHealthLive;
