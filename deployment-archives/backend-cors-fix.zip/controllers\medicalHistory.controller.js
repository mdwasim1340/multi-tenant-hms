"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPatientSummary = exports.getCriticalAllergies = exports.deleteMedicalHistory = exports.updateMedicalHistory = exports.getPatientMedicalHistory = exports.getMedicalHistory = exports.createMedicalHistory = void 0;
const zod_1 = require("zod");
const medicalHistory_service_1 = require("../services/medicalHistory.service");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'multitenant_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});
const medicalHistoryService = new medicalHistory_service_1.MedicalHistoryService(pool);
// Validation schemas
const CreateMedicalHistorySchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    category: zod_1.z.enum(['condition', 'surgery', 'allergy', 'family_history']),
    name: zod_1.z.string().min(1).max(255),
    description: zod_1.z.string().optional(),
    date_diagnosed: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    date_resolved: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    status: zod_1.z.enum(['active', 'resolved', 'chronic']).optional(),
    notes: zod_1.z.string().optional(),
    // Condition
    icd_code: zod_1.z.string().optional(),
    severity: zod_1.z.enum(['mild', 'moderate', 'severe']).optional(),
    treatment: zod_1.z.string().optional(),
    // Surgery
    procedure_code: zod_1.z.string().optional(),
    surgeon: zod_1.z.string().optional(),
    hospital: zod_1.z.string().optional(),
    complications: zod_1.z.string().optional(),
    // Allergy
    allergen_type: zod_1.z.enum(['medication', 'food', 'environmental', 'other']).optional(),
    reaction: zod_1.z.string().optional(),
    is_critical: zod_1.z.boolean().optional(),
    // Family history
    relationship: zod_1.z.string().optional(),
    age_of_onset: zod_1.z.number().int().optional(),
    is_genetic: zod_1.z.boolean().optional()
});
const UpdateMedicalHistorySchema = CreateMedicalHistorySchema.partial().omit({ patient_id: true, category: true });
const createMedicalHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const validated = CreateMedicalHistorySchema.parse(req.body);
        const entry = yield medicalHistoryService.createEntry(tenantId, validated, userId);
        res.status(201).json(entry);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error creating medical history:', error);
        res.status(500).json({ error: 'Failed to create medical history entry' });
    }
});
exports.createMedicalHistory = createMedicalHistory;
const getMedicalHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const entryId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(entryId)) {
            return res.status(400).json({ error: 'Invalid entry ID' });
        }
        const entry = yield medicalHistoryService.getEntryById(tenantId, entryId);
        if (!entry) {
            return res.status(404).json({ error: 'Medical history entry not found' });
        }
        res.json(entry);
    }
    catch (error) {
        console.error('Error fetching medical history:', error);
        res.status(500).json({ error: 'Failed to fetch medical history entry' });
    }
});
exports.getMedicalHistory = getMedicalHistory;
const getPatientMedicalHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const filters = {
            category: req.query.category,
            status: req.query.status,
            severity: req.query.severity,
            is_critical: req.query.is_critical === 'true' ? true : req.query.is_critical === 'false' ? false : undefined,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 20
        };
        const result = yield medicalHistoryService.getPatientHistory(tenantId, patientId, filters);
        res.json({
            entries: result.entries,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error fetching patient medical history:', error);
        res.status(500).json({ error: 'Failed to fetch medical history' });
    }
});
exports.getPatientMedicalHistory = getPatientMedicalHistory;
const updateMedicalHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const entryId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(entryId)) {
            return res.status(400).json({ error: 'Invalid entry ID' });
        }
        const validated = UpdateMedicalHistorySchema.parse(req.body);
        const entry = yield medicalHistoryService.updateEntry(tenantId, entryId, validated, userId);
        if (!entry) {
            return res.status(404).json({ error: 'Medical history entry not found' });
        }
        res.json(entry);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error updating medical history:', error);
        res.status(500).json({ error: 'Failed to update medical history entry' });
    }
});
exports.updateMedicalHistory = updateMedicalHistory;
const deleteMedicalHistory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const entryId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(entryId)) {
            return res.status(400).json({ error: 'Invalid entry ID' });
        }
        const deleted = yield medicalHistoryService.deleteEntry(tenantId, entryId);
        if (!deleted) {
            return res.status(404).json({ error: 'Medical history entry not found' });
        }
        res.status(204).send();
    }
    catch (error) {
        console.error('Error deleting medical history:', error);
        res.status(500).json({ error: 'Failed to delete medical history entry' });
    }
});
exports.deleteMedicalHistory = deleteMedicalHistory;
const getCriticalAllergies = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const allergies = yield medicalHistoryService.getCriticalAllergies(tenantId, patientId);
        res.json({ allergies });
    }
    catch (error) {
        console.error('Error fetching critical allergies:', error);
        res.status(500).json({ error: 'Failed to fetch critical allergies' });
    }
});
exports.getCriticalAllergies = getCriticalAllergies;
const getPatientSummary = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const summary = yield medicalHistoryService.getPatientSummary(tenantId, patientId);
        res.json(summary);
    }
    catch (error) {
        console.error('Error fetching patient summary:', error);
        res.status(500).json({ error: 'Failed to fetch patient summary' });
    }
});
exports.getPatientSummary = getPatientSummary;
