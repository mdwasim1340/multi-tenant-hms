"use strict";
/**
 * Lab Results Routes
 *
 * API routes for laboratory result management
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const labResultController = __importStar(require("../controllers/labResult.controller"));
const router = (0, express_1.Router)();
/**
 * GET /api/lab-results
 * Get lab results with optional filtering
 */
router.get('/', labResultController.getLabResults);
/**
 * GET /api/lab-results/abnormal
 * Get abnormal results
 */
router.get('/abnormal', labResultController.getAbnormalResults);
/**
 * GET /api/lab-results/critical
 * Get critical results (HH/LL flags)
 */
router.get('/critical', labResultController.getCriticalResults);
/**
 * GET /api/lab-results/statistics
 * Get result statistics
 */
router.get('/statistics', labResultController.getLabResultStatistics);
/**
 * GET /api/lab-results/history/:patientId
 * Get result history for patient
 */
router.get('/history/:patientId', labResultController.getResultHistory);
/**
 * GET /api/lab-results/order/:orderId
 * Get results by order ID
 */
router.get('/order/:orderId', labResultController.getResultsByOrder);
/**
 * GET /api/lab-results/:id
 * Get lab result by ID
 */
router.get('/:id', labResultController.getLabResultById);
/**
 * POST /api/lab-results
 * Add new lab result
 */
router.post('/', labResultController.addLabResult);
/**
 * PUT /api/lab-results/:id
 * Update lab result
 */
router.put('/:id', labResultController.updateLabResult);
/**
 * POST /api/lab-results/:id/verify
 * Verify lab result
 */
router.post('/:id/verify', labResultController.verifyLabResult);
exports.default = router;
