"use strict";
/**
 * Team Alpha - S3 Lifecycle Management Routes
 * API endpoints for S3 lifecycle policies and optimization
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const lifecycle_service_1 = __importDefault(require("../services/lifecycle.service"));
const s3_service_1 = require("../services/s3.service");
const router = (0, express_1.Router)();
// Apply middleware to all routes
router.use(auth_1.authMiddleware);
router.use(tenant_1.tenantMiddleware);
/**
 * GET /api/lifecycle/status
 * Get current lifecycle policy status
 */
router.get('/status', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const status = yield lifecycle_service_1.default.getLifecyclePolicyStatus();
        res.json({
            success: true,
            data: status
        });
    }
    catch (error) {
        console.error('Error getting lifecycle status:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get lifecycle status',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/configuration
 * Get current lifecycle configuration
 */
router.get('/configuration', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const configuration = yield lifecycle_service_1.default.getCurrentLifecycleConfiguration();
        res.json({
            success: true,
            data: {
                rules: configuration,
                totalRules: configuration.length,
                activeRules: configuration.filter(rule => rule.status === 'Enabled').length
            }
        });
    }
    catch (error) {
        console.error('Error getting lifecycle configuration:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get lifecycle configuration',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * POST /api/lifecycle/apply
 * Apply comprehensive lifecycle configuration
 */
router.post('/apply', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const success = yield lifecycle_service_1.default.applyLifecycleConfiguration();
        if (success) {
            res.json({
                success: true,
                message: 'Lifecycle configuration applied successfully',
                data: {
                    applied: true,
                    timestamp: new Date().toISOString()
                }
            });
        }
        else {
            res.status(500).json({
                success: false,
                error: 'Failed to apply lifecycle configuration'
            });
        }
    }
    catch (error) {
        console.error('Error applying lifecycle configuration:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to apply lifecycle configuration',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/validate
 * Validate current lifecycle configuration
 */
router.get('/validate', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const validation = yield lifecycle_service_1.default.validateLifecycleConfiguration();
        res.json({
            success: true,
            data: validation
        });
    }
    catch (error) {
        console.error('Error validating lifecycle configuration:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to validate lifecycle configuration',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/savings
 * Calculate potential cost savings from lifecycle policies
 */
router.get('/savings', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const savings = yield lifecycle_service_1.default.calculateLifecycleSavings(tenantId);
        res.json({
            success: true,
            data: savings
        });
    }
    catch (error) {
        console.error('Error calculating lifecycle savings:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to calculate lifecycle savings',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/transitions
 * Monitor upcoming lifecycle transitions
 */
router.get('/transitions', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const transitions = yield lifecycle_service_1.default.monitorLifecycleTransitions(tenantId);
        res.json({
            success: true,
            data: {
                transitions,
                totalFiles: transitions.length,
                totalEstimatedSavings: transitions.reduce((sum, t) => sum + t.estimatedSavings, 0)
            }
        });
    }
    catch (error) {
        console.error('Error monitoring lifecycle transitions:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to monitor lifecycle transitions',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/access-patterns
 * Get file access patterns for optimization
 */
router.get('/access-patterns', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { limit = 100, offset = 0 } = req.query;
        const patterns = yield (0, s3_service_1.getAccessPatterns)(tenantId);
        // Apply pagination
        const paginatedPatterns = patterns.slice(Number(offset), Number(offset) + Number(limit));
        res.json({
            success: true,
            data: {
                patterns: paginatedPatterns,
                pagination: {
                    total: patterns.length,
                    limit: Number(limit),
                    offset: Number(offset),
                    hasMore: Number(offset) + Number(limit) < patterns.length
                }
            }
        });
    }
    catch (error) {
        console.error('Error getting access patterns:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get access patterns',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/recommendations
 * Get storage optimization recommendations
 */
router.get('/recommendations', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const recommendations = yield (0, s3_service_1.getStorageRecommendations)(tenantId);
        // Calculate total potential savings
        const totalSavings = recommendations.reduce((sum, rec) => {
            const fileSizeGB = (rec.file_size_bytes || 0) / (1024 * 1024 * 1024);
            const currentCost = fileSizeGB * 0.023; // Standard storage cost
            const savingsPercent = rec.potential_savings_percent / 100;
            return sum + (currentCost * savingsPercent);
        }, 0);
        res.json({
            success: true,
            data: {
                recommendations,
                summary: {
                    totalFiles: recommendations.length,
                    totalPotentialSavings: totalSavings,
                    averageSavingsPercent: recommendations.length > 0
                        ? recommendations.reduce((sum, rec) => sum + rec.potential_savings_percent, 0) / recommendations.length
                        : 0
                }
            }
        });
    }
    catch (error) {
        console.error('Error getting storage recommendations:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get storage recommendations',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/stats
 * Get tenant access statistics
 */
router.get('/stats', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const stats = yield (0, s3_service_1.getTenantAccessStats)(tenantId);
        res.json({
            success: true,
            data: stats
        });
    }
    catch (error) {
        console.error('Error getting tenant access stats:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get tenant access stats',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
/**
 * GET /api/lifecycle/storage-classes
 * Get information about S3 storage classes
 */
router.get('/storage-classes', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const storageClasses = lifecycle_service_1.default.STORAGE_CLASSES;
        res.json({
            success: true,
            data: {
                storageClasses,
                totalClasses: Object.keys(storageClasses).length,
                costComparison: Object.entries(storageClasses).map(([key, info]) => ({
                    name: key,
                    displayName: info.name,
                    costPerGB: info.costPerGB,
                    retrievalCostPerGB: info.retrievalCostPerGB,
                    minimumStorageDuration: info.minimumStorageDuration,
                    description: info.description,
                    savingsVsStandard: Math.round((1 - info.costPerGB / 0.023) * 100)
                }))
            }
        });
    }
    catch (error) {
        console.error('Error getting storage classes info:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get storage classes info',
            message: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}));
exports.default = router;
