"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const appointment_controller_1 = require("../controllers/appointment.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// Use conditional permission middleware based on environment
const permissionMiddleware = (resource, action) => {
    if (process.env.NODE_ENV === 'development') {
        // In development, skip permission checks (already handled by devAuth middleware)
        return (req, res, next) => next();
    }
    return (0, authorization_1.requirePermission)(resource, action);
};
// GET /api/appointments - List appointments (requires read permission)
router.get('/', permissionMiddleware('appointments', 'read'), appointment_controller_1.getAppointments);
// POST /api/appointments - Create appointment (requires write permission)
router.post('/', permissionMiddleware('appointments', 'write'), appointment_controller_1.createAppointment);
// GET /api/appointments/:id - Get appointment by ID (requires read permission)
router.get('/:id', permissionMiddleware('appointments', 'read'), appointment_controller_1.getAppointmentById);
// PUT /api/appointments/:id - Update appointment (requires write permission)
router.put('/:id', permissionMiddleware('appointments', 'write'), appointment_controller_1.updateAppointment);
// DELETE /api/appointments/:id - Cancel appointment (requires write permission)
router.delete('/:id', permissionMiddleware('appointments', 'write'), appointment_controller_1.cancelAppointment);
// GET /api/appointments/available-slots - Get available time slots (requires read permission)
router.get('/available-slots', permissionMiddleware('appointments', 'read'), appointment_controller_1.getAvailableSlots);
// POST /api/appointments/:id/confirm - Confirm appointment (requires write permission)
router.post('/:id/confirm', permissionMiddleware('appointments', 'write'), appointment_controller_1.confirmAppointment);
// POST /api/appointments/:id/complete - Mark appointment as complete (requires write permission)
router.post('/:id/complete', permissionMiddleware('appointments', 'write'), appointment_controller_1.completeAppointment);
// POST /api/appointments/:id/no-show - Mark appointment as no-show (requires write permission)
router.post('/:id/no-show', permissionMiddleware('appointments', 'write'), appointment_controller_1.markNoShow);
// POST /api/appointments/:id/reschedule - Reschedule appointment (requires write permission)
router.post('/:id/reschedule', permissionMiddleware('appointments', 'write'), appointment_controller_1.rescheduleAppointment);
// POST /api/appointments/:id/adjust-wait-time - Adjust wait time (requires write permission)
router.post('/:id/adjust-wait-time', permissionMiddleware('appointments', 'write'), appointment_controller_1.adjustWaitTime);
exports.default = router;
