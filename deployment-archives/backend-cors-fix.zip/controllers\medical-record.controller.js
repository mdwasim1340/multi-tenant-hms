"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.finalizeMedicalRecord = exports.updateMedicalRecord = exports.getMedicalRecordById = exports.createMedicalRecord = exports.getMedicalRecords = void 0;
const medical_record_service_1 = require("../services/medical-record.service");
const medical_record_validation_1 = require("../validation/medical-record.validation");
const errorHandler_1 = require("../middleware/errorHandler");
const AppError_1 = require("../errors/AppError");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
});
const medicalRecordService = new medical_record_service_1.MedicalRecordService(pool);
exports.getMedicalRecords = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    // Validate query parameters
    const query = medical_record_validation_1.MedicalRecordSearchSchema.parse(req.query);
    const { records, total } = yield medicalRecordService.searchMedicalRecords(query, tenantId);
    const { page, limit } = query;
    const pages = Math.ceil(total / limit);
    res.json({
        success: true,
        data: {
            records,
            pagination: {
                page,
                limit,
                total,
                pages,
                has_next: page < pages,
                has_prev: page > 1
            }
        }
    });
}));
exports.createMedicalRecord = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    // Validate request body
    const validatedData = medical_record_validation_1.CreateMedicalRecordSchema.parse(req.body);
    // Convert string dates to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { visit_date: new Date(validatedData.visit_date), follow_up_date: validatedData.follow_up_date ? new Date(validatedData.follow_up_date) : undefined });
    // Create medical record
    const record = yield medicalRecordService.createMedicalRecord(data, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { record },
        message: 'Medical record created successfully'
    });
}));
exports.getMedicalRecordById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const recordId = parseInt(req.params.id);
    if (isNaN(recordId)) {
        throw new AppError_1.ValidationError('Invalid medical record ID');
    }
    const record = yield medicalRecordService.getMedicalRecordById(recordId, tenantId);
    if (!record) {
        throw new AppError_1.NotFoundError('Medical record');
    }
    res.json({
        success: true,
        data: { record }
    });
}));
exports.updateMedicalRecord = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const recordId = parseInt(req.params.id);
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    if (isNaN(recordId)) {
        throw new AppError_1.ValidationError('Invalid medical record ID');
    }
    const validatedData = medical_record_validation_1.UpdateMedicalRecordSchema.parse(req.body);
    // Convert string dates to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { follow_up_date: validatedData.follow_up_date ? new Date(validatedData.follow_up_date) : undefined });
    const record = yield medicalRecordService.updateMedicalRecord(recordId, data, tenantId, userId);
    res.json({
        success: true,
        data: { record },
        message: 'Medical record updated successfully'
    });
}));
exports.finalizeMedicalRecord = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const recordId = parseInt(req.params.id);
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const record = yield medicalRecordService.finalizeMedicalRecord(recordId, tenantId, userId);
    res.json({
        success: true,
        data: { record },
        message: 'Medical record finalized successfully'
    });
}));
