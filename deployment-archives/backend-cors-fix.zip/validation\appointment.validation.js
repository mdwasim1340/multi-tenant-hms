"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DoctorAvailabilitySchema = exports.DoctorTimeOffSchema = exports.DoctorScheduleSchema = exports.AppointmentSearchSchema = exports.UpdateAppointmentSchema = exports.CreateAppointmentSchema = void 0;
const zod_1 = require("zod");
// Schema for creating appointment
exports.CreateAppointmentSchema = zod_1.z
    .object({
    patient_id: zod_1.z.number().int().positive(),
    doctor_id: zod_1.z.number().int().positive(),
    appointment_date: zod_1.z.string().datetime(),
    duration_minutes: zod_1.z.number().int().min(15).max(480).default(30),
    appointment_type: zod_1.z
        .enum(['consultation', 'follow_up', 'emergency', 'procedure'])
        .optional(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
    estimated_cost: zod_1.z.number().min(0).optional(),
})
    .refine((data) => {
    // Validate appointment is in the future
    const appointmentDate = new Date(data.appointment_date);
    const now = new Date();
    return appointmentDate > now;
}, {
    message: 'Appointment date must be in the future',
    path: ['appointment_date'],
});
// Schema for updating appointment
exports.UpdateAppointmentSchema = zod_1.z.object({
    appointment_date: zod_1.z.string().datetime().optional(),
    duration_minutes: zod_1.z.number().int().min(15).max(480).optional(),
    appointment_type: zod_1.z
        .enum(['consultation', 'follow_up', 'emergency', 'procedure'])
        .optional(),
    status: zod_1.z
        .enum([
        'scheduled',
        'confirmed',
        'checked_in',
        'in_progress',
        'completed',
        'cancelled',
        'no_show',
        'rescheduled',
    ])
        .optional(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
    estimated_cost: zod_1.z.number().min(0).optional(),
    actual_cost: zod_1.z.number().min(0).optional(),
    payment_status: zod_1.z
        .enum(['pending', 'paid', 'cancelled', 'refunded'])
        .optional(),
    cancellation_reason: zod_1.z.string().optional(),
});
// Schema for search query
exports.AppointmentSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().min(1).default(1),
    limit: zod_1.z.coerce.number().min(1).default(10).transform((n) => Math.min(n, 100)),
    patient_id: zod_1.z.coerce.number().int().positive().optional(),
    doctor_id: zod_1.z.coerce.number().int().positive().optional(),
    status: zod_1.z
        .enum([
        'scheduled',
        'confirmed',
        'checked_in',
        'in_progress',
        'completed',
        'cancelled',
        'no_show',
        'rescheduled',
    ])
        .optional(),
    appointment_type: zod_1.z
        .enum(['consultation', 'follow_up', 'emergency', 'procedure'])
        .optional(),
    date_from: zod_1.z.string().date().optional(),
    date_to: zod_1.z.string().date().optional(),
    sort_by: zod_1.z
        .enum(['appointment_date', 'created_at', 'patient_id', 'doctor_id'])
        .default('appointment_date'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('asc'),
});
// Schema for doctor schedule
exports.DoctorScheduleSchema = zod_1.z
    .object({
    doctor_id: zod_1.z.number().int().positive(),
    day_of_week: zod_1.z.number().int().min(0).max(6),
    start_time: zod_1.z
        .string()
        .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Invalid time format (HH:MM)'),
    end_time: zod_1.z
        .string()
        .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Invalid time format (HH:MM)'),
    slot_duration_minutes: zod_1.z.number().int().min(15).max(240).default(30),
    break_duration_minutes: zod_1.z.number().int().min(0).max(60).default(0),
    is_available: zod_1.z.boolean().default(true),
    effective_from: zod_1.z.string().date().optional(),
    effective_until: zod_1.z.string().date().optional(),
})
    .refine((data) => {
    // Validate end_time is after start_time
    const [startHour, startMin] = data.start_time.split(':').map(Number);
    const [endHour, endMin] = data.end_time.split(':').map(Number);
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    return endMinutes > startMinutes;
}, {
    message: 'End time must be after start time',
    path: ['end_time'],
});
// Schema for doctor time off
exports.DoctorTimeOffSchema = zod_1.z
    .object({
    doctor_id: zod_1.z.number().int().positive(),
    start_date: zod_1.z.string().date(),
    end_date: zod_1.z.string().date(),
    start_time: zod_1.z
        .string()
        .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
        .optional(),
    end_time: zod_1.z
        .string()
        .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
        .optional(),
    reason: zod_1.z
        .enum(['vacation', 'sick_leave', 'conference', 'emergency', 'other'])
        .optional(),
    notes: zod_1.z.string().optional(),
    status: zod_1.z.enum(['pending', 'approved', 'rejected']).default('approved'),
})
    .refine((data) => {
    // Validate end_date is not before start_date
    return new Date(data.end_date) >= new Date(data.start_date);
}, {
    message: 'End date must be on or after start date',
    path: ['end_date'],
});
// Schema for checking availability
exports.DoctorAvailabilitySchema = zod_1.z.object({
    doctor_id: zod_1.z.coerce.number().int().positive(),
    date: zod_1.z.string().date(),
    duration_minutes: zod_1.z.coerce.number().int().min(15).max(480).default(30),
});
