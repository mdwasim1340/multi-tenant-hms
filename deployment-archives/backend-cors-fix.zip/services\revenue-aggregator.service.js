"use strict";
/**
 * Revenue Aggregator Service
 *
 * Aggregates revenue data from invoices for Profit & Loss reports.
 * Fetches data from the existing billing/invoices table.
 * Categorizes revenue by analyzing line_items descriptions.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.revenueAggregatorService = exports.RevenueAggregatorService = void 0;
const database_1 = __importDefault(require("../database"));
// Keywords to categorize line items by description
const CATEGORY_KEYWORDS = {
    consultations: ['consultation', 'consult', 'visit', 'checkup', 'check-up', 'examination', 'opd', 'appointment', 'doctor fee', 'physician'],
    procedures: ['surgery', 'procedure', 'operation', 'imaging', 'x-ray', 'xray', 'mri', 'ct scan', 'ultrasound', 'ecg', 'ekg', 'endoscopy', 'dialysis'],
    medications: ['pharmacy', 'medication', 'medicine', 'drug', 'tablet', 'capsule', 'injection', 'syrup', 'prescription', 'antibiotic'],
    labTests: ['lab', 'laboratory', 'test', 'blood', 'urine', 'pathology', 'biopsy', 'culture', 'cbc', 'lipid', 'thyroid', 'glucose', 'hba1c', 'diagnostic']
};
class RevenueAggregatorService {
    /**
     * Categorize a line item description into revenue categories
     */
    categorizeLineItem(description) {
        if (!description)
            return 'other';
        const lowerDesc = description.toLowerCase();
        for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
            for (const keyword of keywords) {
                if (lowerDesc.includes(keyword)) {
                    return category;
                }
            }
        }
        return 'other';
    }
    /**
     * Get total revenue for a period, broken down by category
     * Queries the existing invoices table from the billing system
     * Parses line_items JSONB to categorize revenue
     */
    getRevenueByPeriod(options) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const { tenantId, dateRange } = options;
            if (!dateRange) {
                throw new Error('Date range is required for revenue aggregation');
            }
            const client = yield database_1.default.connect();
            try {
                // Initialize breakdown with zeros
                const breakdown = {
                    consultations: 0,
                    procedures: 0,
                    medications: 0,
                    labTests: 0,
                    other: 0,
                    total: 0
                };
                // Query invoices from public schema (where billing data is stored)
                // Filter by tenant_id and date range, get line_items for categorization
                const query = `
        SELECT 
          id,
          amount,
          line_items,
          status
        FROM invoices
        WHERE tenant_id = $1
          AND status IN ('paid', 'pending')
          AND created_at >= $2
          AND created_at <= $3
      `;
                const params = [tenantId, dateRange.startDate, dateRange.endDate + ' 23:59:59'];
                console.log('[RevenueAggregator] Query params:', {
                    tenantId,
                    startDate: dateRange.startDate,
                    endDate: dateRange.endDate + ' 23:59:59'
                });
                let result;
                try {
                    result = yield client.query(query, params);
                    console.log('[RevenueAggregator] Found', result.rows.length, 'invoices for tenant', tenantId);
                }
                catch (dbError) {
                    // Handle missing table errors gracefully
                    if (dbError.code === '42P01' || ((_a = dbError.message) === null || _a === void 0 ? void 0 : _a.includes('does not exist'))) {
                        console.warn('[RevenueAggregator] Invoices table does not exist, returning empty breakdown');
                        return breakdown;
                    }
                    throw dbError;
                }
                // Process each invoice and categorize line items
                for (const row of result.rows) {
                    let lineItems = row.line_items || [];
                    // If line_items is a string, parse it
                    if (typeof lineItems === 'string') {
                        try {
                            lineItems = JSON.parse(lineItems);
                        }
                        catch (_b) {
                            lineItems = [];
                        }
                    }
                    if (Array.isArray(lineItems) && lineItems.length > 0) {
                        // Categorize each line item
                        for (const item of lineItems) {
                            const amount = parseFloat(item.amount) || 0;
                            // Skip negative amounts (discounts, insurance coverage)
                            if (amount < 0)
                                continue;
                            const description = item.description || '';
                            const category = this.categorizeLineItem(description);
                            breakdown[category] += amount;
                        }
                    }
                    else {
                        // If no line items, add total amount to 'other'
                        const amount = parseFloat(row.amount) || 0;
                        breakdown.other += amount;
                    }
                }
                // Calculate total
                breakdown.total =
                    breakdown.consultations +
                        breakdown.procedures +
                        breakdown.medications +
                        breakdown.labTests +
                        breakdown.other;
                return breakdown;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get revenue by specific category
     */
    getRevenueByCategory(tenantId, category, dateRange) {
        return __awaiter(this, void 0, void 0, function* () {
            const breakdown = yield this.getRevenueByPeriod({
                tenantId,
                dateRange: { startDate: dateRange.startDate, endDate: dateRange.endDate }
            });
            return breakdown[category] || 0;
        });
    }
    /**
     * Get total revenue count (number of invoices)
     */
    getRevenueCount(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, dateRange } = options;
            if (!dateRange) {
                throw new Error('Date range is required');
            }
            const client = yield database_1.default.connect();
            try {
                const query = `
        SELECT COUNT(*) as count
        FROM invoices
        WHERE tenant_id = $1
          AND status IN ('paid', 'pending')
          AND created_at >= $2
          AND created_at <= $3
      `;
                const result = yield client.query(query, [
                    tenantId,
                    dateRange.startDate,
                    dateRange.endDate + ' 23:59:59'
                ]);
                return parseInt(result.rows[0].count) || 0;
            }
            catch (dbError) {
                if (dbError.code === '42P01') {
                    return 0;
                }
                throw dbError;
            }
            finally {
                client.release();
            }
        });
    }
}
exports.RevenueAggregatorService = RevenueAggregatorService;
exports.revenueAggregatorService = new RevenueAggregatorService();
