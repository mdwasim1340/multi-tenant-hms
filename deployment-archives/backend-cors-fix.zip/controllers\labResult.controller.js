"use strict";
/**
 * Lab Result Controller
 *
 * HTTP request handlers for laboratory result management
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabResults = getLabResults;
exports.getLabResultById = getLabResultById;
exports.getResultsByOrder = getResultsByOrder;
exports.addLabResult = addLabResult;
exports.updateLabResult = updateLabResult;
exports.verifyLabResult = verifyLabResult;
exports.getAbnormalResults = getAbnormalResults;
exports.getCriticalResults = getCriticalResults;
exports.getResultHistory = getResultHistory;
exports.getLabResultStatistics = getLabResultStatistics;
const labResultService = __importStar(require("../services/labResult.service"));
const labTest_1 = require("../types/labTest");
/**
 * GET /api/lab-results
 * Get lab results with optional filtering
 */
function getLabResults(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const filters = {
                order_id: req.query.order_id ? parseInt(req.query.order_id) : undefined,
                patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
                is_abnormal: req.query.is_abnormal === 'true' ? true : req.query.is_abnormal === 'false' ? false : undefined,
                verified: req.query.verified === 'true' ? true : req.query.verified === 'false' ? false : undefined,
                result_date_from: req.query.result_date_from,
                result_date_to: req.query.result_date_to,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 50
            };
            const result = yield labResultService.getLabResults(tenantId, filters);
            res.json(result);
        }
        catch (error) {
            console.error('Error getting lab results:', error);
            res.status(500).json({ error: 'Failed to get lab results' });
        }
    });
}
/**
 * GET /api/lab-results/:id
 * Get lab result by ID
 */
function getLabResultById(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const resultId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(resultId)) {
                res.status(400).json({ error: 'Invalid result ID' });
                return;
            }
            const result = yield labResultService.getLabResultById(tenantId, resultId);
            if (!result) {
                res.status(404).json({ error: 'Lab result not found' });
                return;
            }
            res.json(result);
        }
        catch (error) {
            console.error('Error getting lab result:', error);
            res.status(500).json({ error: 'Failed to get lab result' });
        }
    });
}
/**
 * GET /api/lab-results/order/:orderId
 * Get results by order ID
 */
function getResultsByOrder(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const orderId = parseInt(req.params.orderId);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(orderId)) {
                res.status(400).json({ error: 'Invalid order ID' });
                return;
            }
            const results = yield labResultService.getResultsByOrder(tenantId, orderId);
            res.json({ results });
        }
        catch (error) {
            console.error('Error getting results by order:', error);
            res.status(500).json({ error: 'Failed to get results by order' });
        }
    });
}
/**
 * POST /api/lab-results
 * Add new lab result
 */
function addLabResult(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.CreateLabResultSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const data = validationResult.data;
            // Support direct lab result creation without order
            if (!data.order_item_id && data.patient_id && data.test_id) {
                // Direct result creation - create a simple result record
                const directResult = yield labResultService.addDirectLabResult(tenantId, {
                    patient_id: data.patient_id,
                    test_id: data.test_id,
                    result_value: data.value || data.result_value || '',
                    result_unit: data.unit || data.result_unit,
                    reference_range: data.reference_range,
                    is_abnormal: data.is_abnormal || false,
                    abnormal_flag: data.abnormal_flag,
                    result_date: data.result_date || new Date().toISOString(),
                    notes: data.notes,
                    sample_type: data.sample_type,
                    ordering_doctor: data.ordering_doctor,
                    result_status: data.result_status || 'final',
                });
                res.status(201).json({
                    message: 'Lab result added successfully',
                    result: directResult
                });
                return;
            }
            // Traditional flow with order_item_id
            if (!data.order_item_id) {
                res.status(400).json({
                    error: 'Either order_item_id or (patient_id + test_id) is required'
                });
                return;
            }
            // Check if result already exists for this order item
            const existingResult = yield labResultService.getResultByOrderItem(tenantId, data.order_item_id);
            if (existingResult) {
                res.status(409).json({ error: 'Result already exists for this order item' });
                return;
            }
            const result = yield labResultService.addLabResult(tenantId, data);
            res.status(201).json({
                message: 'Lab result added successfully',
                result
            });
        }
        catch (error) {
            console.error('Error adding lab result:', error);
            res.status(500).json({ error: 'Failed to add lab result' });
        }
    });
}
/**
 * PUT /api/lab-results/:id
 * Update lab result
 */
function updateLabResult(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const resultId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(resultId)) {
                res.status(400).json({ error: 'Invalid result ID' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.UpdateLabResultSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const result = yield labResultService.updateLabResult(tenantId, resultId, validationResult.data);
            if (!result) {
                res.status(404).json({ error: 'Lab result not found' });
                return;
            }
            res.json({
                message: 'Lab result updated successfully',
                result
            });
        }
        catch (error) {
            console.error('Error updating lab result:', error);
            res.status(500).json({ error: 'Failed to update lab result' });
        }
    });
}
/**
 * POST /api/lab-results/:id/verify
 * Verify lab result
 */
function verifyLabResult(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const resultId = parseInt(req.params.id);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(resultId)) {
                res.status(400).json({ error: 'Invalid result ID' });
                return;
            }
            // Validate request body
            const validationResult = labTest_1.VerifyLabResultSchema.safeParse(req.body);
            if (!validationResult.success) {
                res.status(400).json({
                    error: 'Validation failed',
                    details: validationResult.error.issues
                });
                return;
            }
            const result = yield labResultService.verifyLabResult(tenantId, resultId, validationResult.data.verified_by);
            if (!result) {
                res.status(404).json({ error: 'Lab result not found' });
                return;
            }
            res.json({
                message: 'Lab result verified successfully',
                result
            });
        }
        catch (error) {
            console.error('Error verifying lab result:', error);
            res.status(500).json({ error: 'Failed to verify lab result' });
        }
    });
}
/**
 * GET /api/lab-results/abnormal
 * Get abnormal results
 */
function getAbnormalResults(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const patientId = req.query.patient_id ? parseInt(req.query.patient_id) : undefined;
            const results = yield labResultService.getAbnormalResults(tenantId, patientId);
            res.json({ results });
        }
        catch (error) {
            console.error('Error getting abnormal results:', error);
            res.status(500).json({ error: 'Failed to get abnormal results' });
        }
    });
}
/**
 * GET /api/lab-results/critical
 * Get critical results
 */
function getCriticalResults(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const results = yield labResultService.getCriticalResults(tenantId);
            res.json({ results });
        }
        catch (error) {
            console.error('Error getting critical results:', error);
            res.status(500).json({ error: 'Failed to get critical results' });
        }
    });
}
/**
 * GET /api/lab-results/history/:patientId
 * Get result history for patient
 */
function getResultHistory(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const patientId = parseInt(req.params.patientId);
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            if (isNaN(patientId)) {
                res.status(400).json({ error: 'Invalid patient ID' });
                return;
            }
            const testCode = req.query.test_code;
            const results = yield labResultService.getResultHistory(tenantId, patientId, testCode);
            res.json({ results });
        }
        catch (error) {
            console.error('Error getting result history:', error);
            res.status(500).json({ error: 'Failed to get result history' });
        }
    });
}
/**
 * GET /api/lab-results/statistics
 * Get result statistics
 */
function getLabResultStatistics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                res.status(400).json({ error: 'X-Tenant-ID header is required' });
                return;
            }
            const statistics = yield labResultService.getLabResultStatistics(tenantId);
            res.json(statistics);
        }
        catch (error) {
            console.error('Error getting lab result statistics:', error);
            res.status(500).json({ error: 'Failed to get lab result statistics' });
        }
    });
}
