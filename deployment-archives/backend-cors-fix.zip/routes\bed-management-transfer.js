"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const transfer_optimizer_1 = require("../services/transfer-optimizer");
const ai_feature_manager_1 = require("../services/ai-feature-manager");
/**
 * Transfer Optimization API Routes
 *
 * Provides endpoints for ED-to-ward transfer optimization.
 *
 * Requirements: 4.1, 4.2, 4.3, 4.4, 4.5
 */
const router = express_1.default.Router();
/**
 * GET /api/bed-management/transfer-priorities
 * Get prioritized list of ED patients awaiting transfer
 * Requirements: 4.1, 4.2
 */
router.get('/transfer-priorities', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const unit = req.query.unit;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'transfer_optimization');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Transfer optimization is not enabled for this tenant',
                feature: 'transfer_optimization'
            });
        }
        const patients = yield transfer_optimizer_1.transferOptimizer.prioritizeEDPatients(tenantId, unit);
        res.json({
            success: true,
            data: patients,
            count: patients.length,
            unit: unit || 'all'
        });
    }
    catch (error) {
        console.error('Error getting transfer priorities:', error);
        res.status(500).json({
            error: 'Failed to get transfer priorities',
            message: error.message
        });
    }
}));
/**
 * POST /api/bed-management/optimize-transfer
 * Optimize transfer timing for a specific patient
 * Requirements: 4.3, 4.4
 */
router.post('/optimize-transfer', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { patientId, admissionId } = req.body;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!patientId || !admissionId) {
            return res.status(400).json({
                error: 'patientId and admissionId are required'
            });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'transfer_optimization');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Transfer optimization is not enabled for this tenant',
                feature: 'transfer_optimization'
            });
        }
        const transferPriority = yield transfer_optimizer_1.transferOptimizer.optimizeTransferTiming(tenantId, patientId, admissionId);
        res.json({
            success: true,
            data: transferPriority
        });
    }
    catch (error) {
        console.error('Error optimizing transfer:', error);
        res.status(500).json({
            error: 'Failed to optimize transfer',
            message: error.message
        });
    }
}));
/**
 * GET /api/bed-management/bed-availability/:unit
 * Get bed availability prediction for a unit
 * Requirements: 4.3
 */
router.get('/bed-availability/:unit', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const unit = req.params.unit;
        const hours = parseInt(req.query.hours) || 8;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'transfer_optimization');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Transfer optimization is not enabled for this tenant',
                feature: 'transfer_optimization'
            });
        }
        const availability = yield transfer_optimizer_1.transferOptimizer.predictBedAvailability(tenantId, unit, hours);
        res.json({
            success: true,
            data: availability
        });
    }
    catch (error) {
        console.error('Error getting bed availability:', error);
        res.status(500).json({
            error: 'Failed to get bed availability',
            message: error.message
        });
    }
}));
/**
 * POST /api/bed-management/notify-transfer
 * Notify receiving unit of incoming transfer
 * Requirements: 4.5
 */
router.post('/notify-transfer', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { admissionId, receivingUnit, estimatedArrival } = req.body;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!admissionId || !receivingUnit || !estimatedArrival) {
            return res.status(400).json({
                error: 'admissionId, receivingUnit, and estimatedArrival are required'
            });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'transfer_optimization');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Transfer optimization is not enabled for this tenant',
                feature: 'transfer_optimization'
            });
        }
        yield transfer_optimizer_1.transferOptimizer.notifyTransfer(tenantId, admissionId, receivingUnit, new Date(estimatedArrival));
        res.json({
            success: true,
            message: 'Transfer notification sent successfully'
        });
    }
    catch (error) {
        console.error('Error notifying transfer:', error);
        res.status(500).json({
            error: 'Failed to notify transfer',
            message: error.message
        });
    }
}));
/**
 * GET /api/bed-management/transfer-metrics
 * Get transfer performance metrics
 * Requirements: 4.5
 */
router.get('/transfer-metrics', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'transfer_optimization');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Transfer optimization is not enabled for this tenant',
                feature: 'transfer_optimization'
            });
        }
        const metrics = yield transfer_optimizer_1.transferOptimizer.getTransferMetrics(tenantId, startDate, endDate);
        res.json({
            success: true,
            data: metrics,
            period: {
                start: startDate,
                end: endDate
            }
        });
    }
    catch (error) {
        console.error('Error getting transfer metrics:', error);
        res.status(500).json({
            error: 'Failed to get transfer metrics',
            message: error.message
        });
    }
}));
exports.default = router;
