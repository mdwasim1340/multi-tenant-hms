"use strict";
// Imaging Report Types and Interfaces
// Requirements: 4.1, 4.2 - Imaging report data structures
Object.defineProperty(exports, "__esModule", { value: true });
exports.BODY_PARTS = exports.IMAGING_TYPES = void 0;
// Common imaging types
exports.IMAGING_TYPES = [
    'Chest X-Ray',
    'Abdominal X-Ray',
    'CT Head',
    'CT Chest',
    'CT Abdomen',
    'CT Pelvis',
    'MRI Brain',
    'MRI Spine',
    'MRI Knee',
    'MRI Shoulder',
    'Ultrasound Abdomen',
    'Ultrasound Pelvis',
    'Echocardiogram',
    'Mammogram',
    'Bone Scan',
    'PET Scan',
    'Other'
];
exports.BODY_PARTS = [
    'Head',
    'Neck',
    'Chest',
    'Abdomen',
    'Pelvis',
    'Spine',
    'Upper Extremity',
    'Lower Extremity',
    'Whole Body',
    'Other'
];
