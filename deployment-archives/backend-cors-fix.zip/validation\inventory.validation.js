"use strict";
/**
 * Inventory Management System - Zod Validation Schemas
 * Team Beta - Sprint 1, Day 3
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.purchaseOrderSearchSchema = exports.inventorySearchSchema = exports.updateMaintenanceSchema = exports.createMaintenanceSchema = exports.receivePurchaseOrderItemSchema = exports.updatePurchaseOrderSchema = exports.createPurchaseOrderSchema = exports.updateSupplierSchema = exports.createSupplierSchema = exports.updateCategorySchema = exports.createCategorySchema = exports.adjustStockSchema = exports.updateInventoryItemSchema = exports.createInventoryItemSchema = void 0;
const zod_1 = require("zod");
// ==================== Inventory Items ====================
exports.createInventoryItemSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(200),
    sku: zod_1.z.string().min(1).max(100),
    category_id: zod_1.z.number().int().positive(),
    description: zod_1.z.string().optional(),
    unit_of_measure: zod_1.z.string().min(1).max(50),
    current_stock: zod_1.z.number().int().min(0).default(0),
    minimum_stock: zod_1.z.number().int().min(0),
    maximum_stock: zod_1.z.number().int().min(0),
    reorder_point: zod_1.z.number().int().min(0),
    unit_cost: zod_1.z.number().min(0).optional(),
    selling_price: zod_1.z.number().min(0).optional(),
    supplier_id: zod_1.z.number().int().positive().optional(),
    location: zod_1.z.string().max(100).optional(),
    barcode: zod_1.z.string().max(100).optional(),
    expiry_date: zod_1.z.string().datetime().optional(),
    batch_number: zod_1.z.string().max(100).optional(),
    status: zod_1.z.enum(['active', 'inactive']).default('active'),
    notes: zod_1.z.string().optional(),
});
exports.updateInventoryItemSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(200).optional(),
    category_id: zod_1.z.number().int().positive().optional(),
    description: zod_1.z.string().optional(),
    unit_of_measure: zod_1.z.string().min(1).max(50).optional(),
    minimum_stock: zod_1.z.number().int().min(0).optional(),
    maximum_stock: zod_1.z.number().int().min(0).optional(),
    reorder_point: zod_1.z.number().int().min(0).optional(),
    unit_cost: zod_1.z.number().min(0).optional(),
    selling_price: zod_1.z.number().min(0).optional(),
    supplier_id: zod_1.z.number().int().positive().optional(),
    location: zod_1.z.string().max(100).optional(),
    barcode: zod_1.z.string().max(100).optional(),
    expiry_date: zod_1.z.string().datetime().optional(),
    batch_number: zod_1.z.string().max(100).optional(),
    status: zod_1.z.enum(['active', 'inactive', 'discontinued']).optional(),
    notes: zod_1.z.string().optional(),
});
exports.adjustStockSchema = zod_1.z.object({
    transaction_type: zod_1.z.enum(['addition', 'removal', 'adjustment']),
    quantity: zod_1.z.number().int(),
    reason: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    reference_type: zod_1.z.string().optional(),
    reference_id: zod_1.z.number().int().optional(),
});
// ==================== Categories ====================
exports.createCategorySchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(100),
    code: zod_1.z.string().min(1).max(50),
    description: zod_1.z.string().optional(),
    parent_category_id: zod_1.z.number().int().positive().optional(),
    status: zod_1.z.enum(['active', 'inactive']).default('active'),
});
exports.updateCategorySchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(100).optional(),
    description: zod_1.z.string().optional(),
    parent_category_id: zod_1.z.number().int().positive().optional(),
    status: zod_1.z.enum(['active', 'inactive']).optional(),
});
// ==================== Suppliers ====================
exports.createSupplierSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(200),
    code: zod_1.z.string().max(50).optional(),
    contact_person: zod_1.z.string().max(100).optional(),
    email: zod_1.z.string().email().optional(),
    phone: zod_1.z.string().max(20).optional(),
    address: zod_1.z.string().optional(),
    city: zod_1.z.string().max(100).optional(),
    state: zod_1.z.string().max(100).optional(),
    country: zod_1.z.string().max(100).optional(),
    postal_code: zod_1.z.string().max(20).optional(),
    payment_terms: zod_1.z.string().max(100).optional(),
    lead_time_days: zod_1.z.number().int().min(0).default(0),
    rating: zod_1.z.number().min(0).max(5).optional(),
    status: zod_1.z.enum(['active', 'inactive', 'blocked']).default('active'),
    notes: zod_1.z.string().optional(),
});
exports.updateSupplierSchema = exports.createSupplierSchema.partial();
// ==================== Purchase Orders ====================
exports.createPurchaseOrderSchema = zod_1.z.object({
    supplier_id: zod_1.z.number().int().positive(),
    order_date: zod_1.z.string().datetime().optional(),
    expected_delivery_date: zod_1.z.string().datetime().optional(),
    items: zod_1.z.array(zod_1.z.object({
        item_id: zod_1.z.number().int().positive(),
        quantity: zod_1.z.number().int().positive(),
        unit_cost: zod_1.z.number().min(0),
    })).min(1),
    shipping_cost: zod_1.z.number().min(0).default(0),
    tax_amount: zod_1.z.number().min(0).default(0),
    notes: zod_1.z.string().optional(),
});
exports.updatePurchaseOrderSchema = zod_1.z.object({
    expected_delivery_date: zod_1.z.string().datetime().optional(),
    actual_delivery_date: zod_1.z.string().datetime().optional(),
    status: zod_1.z.enum(['pending', 'approved', 'in_transit', 'delivered', 'cancelled']).optional(),
    payment_status: zod_1.z.enum(['unpaid', 'partial', 'paid']).optional(),
    payment_method: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
});
exports.receivePurchaseOrderItemSchema = zod_1.z.object({
    quantity: zod_1.z.number().int().positive(),
    notes: zod_1.z.string().optional(),
});
// ==================== Equipment Maintenance ====================
exports.createMaintenanceSchema = zod_1.z.object({
    equipment_id: zod_1.z.number().int().positive(),
    maintenance_type: zod_1.z.enum(['preventive', 'corrective', 'calibration', 'inspection']),
    scheduled_date: zod_1.z.string().datetime(),
    technician_name: zod_1.z.string().max(100).optional(),
    cost: zod_1.z.number().min(0).optional(),
    description: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
});
exports.updateMaintenanceSchema = zod_1.z.object({
    scheduled_date: zod_1.z.string().datetime().optional(),
    completed_date: zod_1.z.string().datetime().optional(),
    next_maintenance_date: zod_1.z.string().datetime().optional(),
    status: zod_1.z.enum(['scheduled', 'in_progress', 'completed', 'cancelled', 'overdue']).optional(),
    technician_name: zod_1.z.string().max(100).optional(),
    cost: zod_1.z.number().min(0).optional(),
    description: zod_1.z.string().optional(),
    findings: zod_1.z.string().optional(),
    recommendations: zod_1.z.string().optional(),
    parts_replaced: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
});
// ==================== Search Parameters ====================
exports.inventorySearchSchema = zod_1.z.object({
    category_id: zod_1.z.number().int().positive().optional(),
    status: zod_1.z.string().optional(),
    stock_status: zod_1.z.string().optional(),
    supplier_id: zod_1.z.number().int().positive().optional(),
    search: zod_1.z.string().optional(),
    page: zod_1.z.number().int().min(1).default(1),
    limit: zod_1.z.number().int().min(1).max(100).default(20),
    sort_by: zod_1.z.string().optional(),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc'),
});
exports.purchaseOrderSearchSchema = zod_1.z.object({
    supplier_id: zod_1.z.number().int().positive().optional(),
    status: zod_1.z.string().optional(),
    payment_status: zod_1.z.string().optional(),
    from_date: zod_1.z.string().datetime().optional(),
    to_date: zod_1.z.string().datetime().optional(),
    search: zod_1.z.string().optional(),
    page: zod_1.z.number().int().min(1).default(1),
    limit: zod_1.z.number().int().min(1).max(100).default(20),
});
