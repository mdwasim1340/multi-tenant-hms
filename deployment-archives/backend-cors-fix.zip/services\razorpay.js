"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.razorpayService = exports.RazorpayService = void 0;
const razorpay_1 = __importDefault(require("razorpay"));
const crypto_1 = __importDefault(require("crypto"));
class RazorpayService {
    constructor() {
        // Initialize with environment variables or test keys
        const keyId = process.env.RAZORPAY_KEY_ID || 'rzp_test_demo_key';
        const keySecret = process.env.RAZORPAY_KEY_SECRET || 'demo_secret_key';
        this.razorpay = new razorpay_1.default({
            key_id: keyId,
            key_secret: keySecret
        });
    }
    // Create Razorpay order
    createOrder(amount_1) {
        return __awaiter(this, arguments, void 0, function* (amount, currency = 'INR', receiptId, notes) {
            try {
                const orderData = {
                    amount: Math.round(amount * 100), // Convert to paise
                    currency: currency,
                    receipt: receiptId,
                    notes: Object.assign({ receipt_id: receiptId }, notes)
                };
                console.log('Creating Razorpay order:', orderData);
                // In demo mode, return a mock order
                if (process.env.RAZORPAY_KEY_ID === 'rzp_test_demo_key' || !process.env.RAZORPAY_KEY_ID) {
                    return this.createMockOrder(orderData);
                }
                const order = yield this.razorpay.orders.create(orderData);
                return order;
            }
            catch (error) {
                console.error('Error creating Razorpay order:', error);
                // In case of error, return mock order for demo
                if (!process.env.RAZORPAY_KEY_ID) {
                    return this.createMockOrder({
                        amount: Math.round(amount * 100),
                        currency,
                        receipt: receiptId,
                        notes: notes || {}
                    });
                }
                throw error;
            }
        });
    }
    // Create mock order for demo purposes
    createMockOrder(orderData) {
        return {
            id: `order_${Date.now()}${Math.random().toString(36).substr(2, 9)}`,
            entity: 'order',
            amount: orderData.amount,
            amount_paid: 0,
            amount_due: orderData.amount,
            currency: orderData.currency,
            receipt: orderData.receipt,
            status: 'created',
            attempts: 0,
            notes: orderData.notes,
            created_at: Math.floor(Date.now() / 1000)
        };
    }
    // Verify payment signature
    verifyPaymentSignature(orderId, paymentId, signature) {
        try {
            // In demo mode, always return true for testing
            if (process.env.RAZORPAY_KEY_SECRET === 'demo_secret_key' || !process.env.RAZORPAY_KEY_SECRET) {
                console.log('Demo mode: Payment signature verification bypassed');
                return true;
            }
            const text = `${orderId}|${paymentId}`;
            const expectedSignature = crypto_1.default
                .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
                .update(text)
                .digest('hex');
            return expectedSignature === signature;
        }
        catch (error) {
            console.error('Error verifying signature:', error);
            return false;
        }
    }
    // Verify webhook signature
    verifyWebhookSignature(body, signature) {
        try {
            // In demo mode, always return true
            if (!process.env.RAZORPAY_WEBHOOK_SECRET) {
                console.log('Demo mode: Webhook signature verification bypassed');
                return true;
            }
            const expectedSignature = crypto_1.default
                .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
                .update(body)
                .digest('hex');
            return expectedSignature === signature;
        }
        catch (error) {
            console.error('Error verifying webhook signature:', error);
            return false;
        }
    }
    // Get payment details
    getPayment(paymentId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // In demo mode, return mock payment
                if (!process.env.RAZORPAY_KEY_ID) {
                    return this.createMockPayment(paymentId);
                }
                const payment = yield this.razorpay.payments.fetch(paymentId);
                return payment;
            }
            catch (error) {
                console.error('Error fetching payment:', error);
                // Return mock payment for demo
                if (!process.env.RAZORPAY_KEY_ID) {
                    return this.createMockPayment(paymentId);
                }
                throw error;
            }
        });
    }
    // Create mock payment for demo
    createMockPayment(paymentId) {
        return {
            id: paymentId,
            entity: 'payment',
            amount: 499900, // Rs. 4999
            currency: 'INR',
            status: 'captured',
            order_id: `order_${Date.now()}`,
            international: false,
            method: 'card',
            amount_refunded: 0,
            captured: true,
            description: 'Demo payment',
            email: 'demo@example.com',
            contact: '+919999999999',
            notes: {},
            created_at: Math.floor(Date.now() / 1000)
        };
    }
    // Capture payment
    capturePayment(paymentId, amount) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // In demo mode, return mock captured payment
                if (!process.env.RAZORPAY_KEY_ID) {
                    const mockPayment = this.createMockPayment(paymentId);
                    mockPayment.status = 'captured';
                    mockPayment.amount = Math.round(amount * 100);
                    return mockPayment;
                }
                const payment = yield this.razorpay.payments.capture(paymentId, Math.round(amount * 100), 'INR');
                return payment;
            }
            catch (error) {
                console.error('Error capturing payment:', error);
                throw error;
            }
        });
    }
    // Refund payment
    refundPayment(paymentId, amount) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // In demo mode, return mock refund
                if (!process.env.RAZORPAY_KEY_ID) {
                    return {
                        id: `rfnd_${Date.now()}${Math.random().toString(36).substr(2, 9)}`,
                        entity: 'refund',
                        amount: amount ? Math.round(amount * 100) : undefined,
                        payment_id: paymentId,
                        status: 'processed',
                        created_at: Math.floor(Date.now() / 1000)
                    };
                }
                const refundData = { payment_id: paymentId };
                if (amount) {
                    refundData.amount = Math.round(amount * 100);
                }
                return yield this.razorpay.payments.refund(paymentId, refundData);
            }
            catch (error) {
                console.error('Error refunding payment:', error);
                throw error;
            }
        });
    }
    // Get Razorpay configuration for frontend
    getConfig() {
        return {
            key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_demo_key',
            currency: 'INR',
            name: 'Hospital Management System',
            description: 'Subscription Payment',
            theme: {
                color: '#3399cc'
            }
        };
    }
    // Check if Razorpay is properly configured
    isConfigured() {
        return !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
    }
    // Get demo mode status
    isDemoMode() {
        return !this.isConfigured();
    }
}
exports.RazorpayService = RazorpayService;
exports.razorpayService = new RazorpayService();
