"use strict";
/**
 * Subdomain Cache Service
 * Purpose: Cache subdomain → tenant_id mappings for performance
 * Requirements: 4.6, 15.1
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.subdomainCache = void 0;
const redis_1 = require("redis");
// Cache TTL: 1 hour (3600 seconds)
const CACHE_TTL = 3600;
// Cache key prefix
const CACHE_KEY_PREFIX = 'subdomain:';
class SubdomainCacheService {
    constructor() {
        this.client = null;
        this.isConnected = false;
    }
    /**
     * Initialize Redis client
     */
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.isConnected) {
                return;
            }
            try {
                this.client = (0, redis_1.createClient)({
                    url: process.env.REDIS_URL || 'redis://localhost:6379',
                });
                this.client.on('error', (err) => {
                    console.error('Redis Client Error:', err);
                    this.isConnected = false;
                });
                this.client.on('connect', () => {
                    console.log('✅ Redis connected for subdomain caching');
                    this.isConnected = true;
                });
                yield this.client.connect();
            }
            catch (error) {
                console.error('Failed to connect to Redis:', error);
                this.isConnected = false;
                // Don't throw - allow app to work without cache
            }
        });
    }
    /**
     * Get tenant ID from cache by subdomain
     *
     * @param subdomain - The subdomain to lookup
     * @returns Tenant ID if found in cache, null otherwise
     */
    get(subdomain) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isConnected || !this.client) {
                console.log('⚠️  Redis not connected, cache miss');
                return null;
            }
            try {
                const key = `${CACHE_KEY_PREFIX}${subdomain}`;
                const tenantId = yield this.client.get(key);
                if (tenantId) {
                    console.log(`✅ Cache HIT: subdomain '${subdomain}' → tenant '${tenantId}'`);
                }
                else {
                    console.log(`❌ Cache MISS: subdomain '${subdomain}'`);
                }
                return tenantId;
            }
            catch (error) {
                console.error('Redis GET error:', error);
                return null;
            }
        });
    }
    /**
     * Set tenant ID in cache for subdomain
     *
     * @param subdomain - The subdomain
     * @param tenantId - The tenant ID to cache
     */
    set(subdomain, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isConnected || !this.client) {
                console.log('⚠️  Redis not connected, skipping cache set');
                return;
            }
            try {
                const key = `${CACHE_KEY_PREFIX}${subdomain}`;
                yield this.client.setEx(key, CACHE_TTL, tenantId);
                console.log(`✅ Cache SET: subdomain '${subdomain}' → tenant '${tenantId}' (TTL: ${CACHE_TTL}s)`);
            }
            catch (error) {
                console.error('Redis SET error:', error);
            }
        });
    }
    /**
     * Invalidate cache for a specific subdomain
     *
     * @param subdomain - The subdomain to invalidate
     */
    invalidate(subdomain) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isConnected || !this.client) {
                console.log('⚠️  Redis not connected, skipping cache invalidation');
                return;
            }
            try {
                const key = `${CACHE_KEY_PREFIX}${subdomain}`;
                yield this.client.del(key);
                console.log(`✅ Cache INVALIDATED: subdomain '${subdomain}'`);
            }
            catch (error) {
                console.error('Redis DEL error:', error);
            }
        });
    }
    /**
     * Invalidate cache for a tenant (when tenant is updated)
     * This requires looking up the subdomain first
     *
     * @param tenantId - The tenant ID
     * @param subdomain - The subdomain (if known)
     */
    invalidateByTenant(tenantId, subdomain) {
        return __awaiter(this, void 0, void 0, function* () {
            if (subdomain) {
                yield this.invalidate(subdomain);
            }
            else {
                // If subdomain not provided, we'd need to scan all keys
                // For now, just log a warning
                console.log(`⚠️  Cache invalidation for tenant '${tenantId}' requires subdomain`);
            }
        });
    }
    /**
     * Clear all subdomain cache entries
     * Use with caution - only for maintenance/testing
     */
    clearAll() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isConnected || !this.client) {
                console.log('⚠️  Redis not connected, skipping cache clear');
                return;
            }
            try {
                const keys = yield this.client.keys(`${CACHE_KEY_PREFIX}*`);
                if (keys.length > 0) {
                    yield this.client.del(keys);
                    console.log(`✅ Cache CLEARED: ${keys.length} subdomain entries removed`);
                }
                else {
                    console.log('ℹ️  No cache entries to clear');
                }
            }
            catch (error) {
                console.error('Redis CLEAR error:', error);
            }
        });
    }
    /**
     * Get cache statistics
     *
     * @returns Object with cache stats
     */
    getStats() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isConnected || !this.client) {
                return { connected: false, keyCount: 0 };
            }
            try {
                const keys = yield this.client.keys(`${CACHE_KEY_PREFIX}*`);
                return {
                    connected: true,
                    keyCount: keys.length,
                };
            }
            catch (error) {
                console.error('Redis STATS error:', error);
                return { connected: false, keyCount: 0 };
            }
        });
    }
    /**
     * Disconnect from Redis
     */
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.client && this.isConnected) {
                yield this.client.quit();
                this.isConnected = false;
                console.log('✅ Redis disconnected');
            }
        });
    }
}
// Export singleton instance
exports.subdomainCache = new SubdomainCacheService();
