"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rollbackSchemaFile = exports.runSchemaInitialization = void 0;
const database_1 = __importDefault(require("../database"));
const crypto_1 = require("crypto");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const files = [
    { file: 'migrations/schemas/patient-schema.sql', version: '1.0.0' },
    { file: 'migrations/schemas/appointment-schema.sql', version: '1.0.0' },
    { file: 'migrations/create-medical-records-schema.sql', version: '1.0.0' },
    { file: 'migrations/create-lab-tests-schema.sql', version: '1.0.0' },
];
const disallowedPatterns = [
    /DROP\s+SCHEMA/i,
    /ALTER\s+SYSTEM/i,
    /COPY\s+/i,
    /UNION\s+SELECT/i,
];
const whitelistDirs = ['migrations', 'migrations/schemas'];
const ensureAuditTable = () => __awaiter(void 0, void 0, void 0, function* () {
    yield database_1.default.query(`
    CREATE TABLE IF NOT EXISTS public.tenant_schema_audit (
      id SERIAL PRIMARY KEY,
      tenant_id VARCHAR(255) NOT NULL,
      schema_name VARCHAR(255) NOT NULL,
      file_name VARCHAR(500) NOT NULL,
      version VARCHAR(50) NOT NULL,
      checksum VARCHAR(128) NOT NULL,
      applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      status VARCHAR(20) NOT NULL,
      error_encrypted BYTEA
    )
  `);
});
const sha256 = (input) => (0, crypto_1.createHash)('sha256').update(input).digest('hex');
const validateSql = (sql) => {
    for (const p of disallowedPatterns) {
        if (p.test(sql))
            return false;
    }
    return true;
};
const encrypt = (text) => {
    const keyHex = process.env.SCHEMA_AUDIT_KEY || '';
    const key = Buffer.from(keyHex.padEnd(64, '0').slice(0, 64), 'hex');
    const iv = (0, crypto_1.randomBytes)(12);
    const cipher = (0, crypto_1.createCipheriv)('aes-256-gcm', key.slice(0, 32), iv);
    const enc = Buffer.concat([cipher.update(Buffer.from(text, 'utf8')), cipher.final()]);
    const tag = cipher.getAuthTag();
    return Buffer.concat([iv, tag, enc]);
};
const hasSuccessAudit = (tenantId, fileName, version, checksum) => __awaiter(void 0, void 0, void 0, function* () {
    const r = yield database_1.default.query('SELECT 1 FROM public.tenant_schema_audit WHERE tenant_id=$1 AND file_name=$2 AND version=$3 AND checksum=$4 AND status=$5 LIMIT 1', [tenantId, fileName, version, checksum, 'success']);
    return r.rows.length > 0;
});
const recordAudit = (tenantId, schemaName, fileName, version, checksum, status, errorEncrypted) => __awaiter(void 0, void 0, void 0, function* () {
    yield database_1.default.query('INSERT INTO public.tenant_schema_audit (tenant_id, schema_name, file_name, version, checksum, status, error_encrypted) VALUES ($1,$2,$3,$4,$5,$6,$7)', [tenantId, schemaName, fileName, version, checksum, status, errorEncrypted || null]);
});
const runSchemaInitialization = (tenantId) => __awaiter(void 0, void 0, void 0, function* () {
    yield ensureAuditTable();
    const client = yield database_1.default.connect();
    const results = [];
    try {
        for (const f of files) {
            const rel = f.file.replace(/\\/g, '/');
            const dir = rel.split('/').slice(0, -1).join('/');
            if (!whitelistDirs.includes(dir)) {
                results.push({ file: f.file, version: f.version, status: 'skipped', message: 'Not whitelisted' });
                continue;
            }
            const sqlPath = path_1.default.resolve(process.cwd(), rel);
            const sql = fs_1.default.readFileSync(sqlPath, 'utf8');
            const checksum = sha256(sql);
            const already = yield hasSuccessAudit(tenantId, f.file, f.version, checksum);
            if (already) {
                results.push({ file: f.file, version: f.version, status: 'skipped', message: 'Already applied' });
                continue;
            }
            if (!validateSql(sql)) {
                const enc = encrypt('validation_failed');
                yield recordAudit(tenantId, tenantId, f.file, f.version, checksum, 'failure', enc);
                results.push({ file: f.file, version: f.version, status: 'failed', message: 'Validation failed' });
                continue;
            }
            yield client.query('BEGIN');
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield client.query(sql);
                yield client.query('COMMIT');
                yield recordAudit(tenantId, tenantId, f.file, f.version, checksum, 'success');
                results.push({ file: f.file, version: f.version, status: 'success' });
            }
            catch (e) {
                yield client.query('ROLLBACK');
                const msg = String(e && e.message ? e.message : '');
                if (msg.toLowerCase().includes('already exists')) {
                    yield recordAudit(tenantId, tenantId, f.file, f.version, checksum, 'success');
                    results.push({ file: f.file, version: f.version, status: 'skipped', message: 'Already applied' });
                }
                else {
                    const enc = encrypt(msg || 'error');
                    yield recordAudit(tenantId, tenantId, f.file, f.version, checksum, 'failure', enc);
                    results.push({ file: f.file, version: f.version, status: 'failed', message: msg || 'Execution failed' });
                }
            }
        }
        return results;
    }
    finally {
        client.release();
    }
});
exports.runSchemaInitialization = runSchemaInitialization;
const rollbackMap = {
    'migrations/schemas/patient-schema.sql': ['patient_files', 'custom_field_values', 'patients'],
    'migrations/schemas/appointment-schema.sql': ['appointment_reminders', 'doctor_time_off', 'doctor_schedules', 'appointments'],
    'migrations/create-medical-records-schema.sql': ['prescriptions', 'treatments', 'diagnoses', 'medical_records'],
    'migrations/create-lab-tests-schema.sql': ['lab_results', 'lab_tests', 'imaging_studies', 'lab_panels'],
};
const rollbackSchemaFile = (tenantId, fileName) => __awaiter(void 0, void 0, void 0, function* () {
    const client = yield database_1.default.connect();
    try {
        const tables = rollbackMap[fileName] || [];
        yield client.query('BEGIN');
        yield client.query(`SET search_path TO "${tenantId}"`);
        for (const t of tables) {
            yield client.query(`DROP TABLE IF EXISTS ${t} CASCADE`);
        }
        yield client.query('COMMIT');
        return { success: true, dropped: tables };
    }
    catch (e) {
        yield client.query('ROLLBACK');
        return { success: false };
    }
    finally {
        client.release();
    }
});
exports.rollbackSchemaFile = rollbackSchemaFile;
