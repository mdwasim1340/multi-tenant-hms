"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usageCalculators = exports.addSubscriptionInfo = exports.requireFeatures = exports.requireUsageLimit = exports.requireFeature = void 0;
const subscription_1 = require("../services/subscription");
// Middleware to require specific feature access
const requireFeature = (feature) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                return res.status(400).json({
                    error: 'X-Tenant-ID header required',
                    code: 'MISSING_TENANT_ID'
                });
            }
            const accessResult = yield subscription_1.subscriptionService.hasFeatureAccess(tenantId, feature);
            if (!accessResult.hasAccess) {
                return res.status(403).json({
                    error: accessResult.reason || `Feature '${feature}' not available`,
                    code: 'FEATURE_NOT_AVAILABLE',
                    feature: feature,
                    upgrade_required: accessResult.upgradeRequired
                });
            }
            next();
        }
        catch (error) {
            console.error('Feature access check error:', error);
            res.status(500).json({
                error: 'Failed to verify feature access',
                code: 'FEATURE_CHECK_ERROR'
            });
        }
    });
};
exports.requireFeature = requireFeature;
// Middleware to check usage limits before allowing operations
const requireUsageLimit = (limitType, getCurrentValue) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                return res.status(400).json({
                    error: 'X-Tenant-ID header required',
                    code: 'MISSING_TENANT_ID'
                });
            }
            let currentValue;
            if (getCurrentValue) {
                currentValue = yield getCurrentValue(req);
            }
            const limitResult = yield subscription_1.subscriptionService.checkUsageLimit(tenantId, limitType, currentValue);
            if (!limitResult.withinLimit) {
                return res.status(403).json({
                    error: `Usage limit exceeded for ${limitType}`,
                    code: 'USAGE_LIMIT_EXCEEDED',
                    limit_type: limitType,
                    current_value: limitResult.currentValue,
                    limit: limitResult.limit,
                    percentage: limitResult.percentage
                });
            }
            // Add usage info to request for potential use in handlers
            req.usageInfo = {
                [limitType]: limitResult
            };
            next();
        }
        catch (error) {
            console.error('Usage limit check error:', error);
            res.status(500).json({
                error: 'Failed to verify usage limit',
                code: 'LIMIT_CHECK_ERROR'
            });
        }
    });
};
exports.requireUsageLimit = requireUsageLimit;
// Middleware to check multiple features at once
const requireFeatures = (features) => {
    return (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                return res.status(400).json({
                    error: 'X-Tenant-ID header required',
                    code: 'MISSING_TENANT_ID'
                });
            }
            const missingFeatures = [];
            for (const feature of features) {
                const accessResult = yield subscription_1.subscriptionService.hasFeatureAccess(tenantId, feature);
                if (!accessResult.hasAccess) {
                    missingFeatures.push(feature);
                }
            }
            if (missingFeatures.length > 0) {
                return res.status(403).json({
                    error: `Missing required features: ${missingFeatures.join(', ')}`,
                    code: 'FEATURES_NOT_AVAILABLE',
                    missing_features: missingFeatures,
                    upgrade_required: true
                });
            }
            next();
        }
        catch (error) {
            console.error('Features access check error:', error);
            res.status(500).json({
                error: 'Failed to verify features access',
                code: 'FEATURES_CHECK_ERROR'
            });
        }
    });
};
exports.requireFeatures = requireFeatures;
// Middleware to add subscription info to request
const addSubscriptionInfo = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (tenantId) {
            const subscription = yield subscription_1.subscriptionService.getTenantSubscriptionWithTier(tenantId);
            req.subscription = subscription;
        }
        next();
    }
    catch (error) {
        console.error('Error adding subscription info:', error);
        // Don't fail the request, just continue without subscription info
        next();
    }
});
exports.addSubscriptionInfo = addSubscriptionInfo;
// Helper functions for common usage calculations
exports.usageCalculators = {
    // Calculate current patient count for the tenant
    getCurrentPatientCount(req) {
        return __awaiter(this, void 0, void 0, function* () {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId || !req.dbClient)
                return 0;
            try {
                const result = yield req.dbClient.query('SELECT COUNT(*) FROM patients');
                return parseInt(result.rows[0].count) || 0;
            }
            catch (error) {
                // Table might not exist yet
                return 0;
            }
        });
    },
    // Calculate current user count for the tenant
    getCurrentUserCount(req) {
        return __awaiter(this, void 0, void 0, function* () {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId)
                return 0;
            try {
                const result = yield req.dbClient.query('SELECT COUNT(*) FROM users WHERE tenant_id = $1', [tenantId]);
                return parseInt(result.rows[0].count) || 0;
            }
            catch (error) {
                return 0;
            }
        });
    },
    // For API calls, we'll increment on each request
    incrementApiCall(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield subscription_1.subscriptionService.incrementUsage(tenantId, 'api_calls_today', 1);
        });
    }
};
