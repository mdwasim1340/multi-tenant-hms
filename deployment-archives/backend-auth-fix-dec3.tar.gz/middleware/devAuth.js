"use strict";
/**
 * Development Authentication Middleware
 * Provides bypass authentication for development environment
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.devTenantMiddleware = exports.devApplicationAccessMiddleware = exports.devPermissionMiddleware = exports.devAuthMiddleware = void 0;
/**
 * Development authentication bypass
 * Only works when NODE_ENV is 'development'
 */
const devAuthMiddleware = (req, res, next) => {
    // Only allow in development environment
    if (process.env.NODE_ENV !== 'development') {
        return res.status(403).json({
            error: 'Development middleware not allowed in production',
            message: 'This endpoint is only available in development mode'
        });
    }
    // Create a mock user for development
    const mockUser = {
        id: 1,
        sub: 'dev-user-123',
        email: 'dev@hospital.com',
        'cognito:groups': ['hospital-admin', 'admin'],
        'cognito:username': 'dev-user'
    };
    // Set user info on request
    req.user = mockUser;
    req.userId = mockUser.id;
    next();
};
exports.devAuthMiddleware = devAuthMiddleware;
/**
 * Development permission bypass
 * Grants all permissions in development
 */
const devPermissionMiddleware = (resource, action) => {
    return (req, res, next) => {
        // Only allow in development environment
        if (process.env.NODE_ENV !== 'development') {
            return res.status(403).json({
                error: 'Development middleware not allowed in production',
                message: 'This endpoint is only available in development mode'
            });
        }
        // Grant all permissions in development
        console.log(`[DEV] Granting permission ${resource}:${action} for development`);
        next();
    };
};
exports.devPermissionMiddleware = devPermissionMiddleware;
/**
 * Development application access bypass
 * Grants access to all applications in development
 */
const devApplicationAccessMiddleware = (applicationId) => {
    return (req, res, next) => {
        // Only allow in development environment
        if (process.env.NODE_ENV !== 'development') {
            return res.status(403).json({
                error: 'Development middleware not allowed in production',
                message: 'This endpoint is only available in development mode'
            });
        }
        // Grant application access in development
        console.log(`[DEV] Granting access to application ${applicationId} for development`);
        // Add permission helpers to request (same as authorization middleware)
        req.permissions = {
            canAccess: (resource, action) => __awaiter(void 0, void 0, void 0, function* () {
                console.log(`[DEV] Granting permission ${resource}:${action}`);
                return true;
            }),
            canAccessApp: (appId) => __awaiter(void 0, void 0, void 0, function* () {
                console.log(`[DEV] Granting access to app ${appId}`);
                return true;
            })
        };
        next();
    };
};
exports.devApplicationAccessMiddleware = devApplicationAccessMiddleware;
/**
 * Development tenant middleware bypass
 * Sets up mock tenant context in development
 */
const devTenantMiddleware = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    // Only allow in development environment
    if (process.env.NODE_ENV !== 'development') {
        return res.status(403).json({
            error: 'Development middleware not allowed in production',
            message: 'This endpoint is only available in development mode'
        });
    }
    // Set mock tenant ID
    const tenantId = req.headers['x-tenant-id'] || 'tenant_aajmin_polyclinic';
    // Set up real database connection like the real tenant middleware
    const { Pool } = require('pg');
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
    });
    const client = yield pool.connect();
    try {
        yield client.query(`SET search_path TO "${tenantId}", public`);
        req.dbClient = client;
        // Mock tenant info
        req.tenant = {
            id: tenantId,
            name: 'Development Tenant',
            subdomain: 'dev-tenant'
        };
        res.on('finish', () => {
            client.release();
            pool.end();
        });
        console.log(`[DEV] Using tenant: ${tenantId}`);
        next();
    }
    catch (error) {
        console.error('[DEV] Tenant middleware error:', error);
        client.release();
        pool.end();
        res.status(500).json({ message: 'Failed to set tenant context' });
    }
});
exports.devTenantMiddleware = devTenantMiddleware;
