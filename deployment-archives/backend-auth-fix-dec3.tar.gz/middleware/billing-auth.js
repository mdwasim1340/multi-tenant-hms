"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireBillingAdmin = exports.requireBillingWrite = exports.requireBillingRead = void 0;
const authorization_1 = require("../services/authorization");
/**
 * Middleware to check if user has billing:read permission
 * Required for viewing invoices and billing reports
 */
const requireBillingRead = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        if (!userId) {
            return res.status(401).json({
                error: 'Authentication required',
                code: 'AUTH_REQUIRED',
                message: 'You must be logged in to access billing data'
            });
        }
        const hasPermission = yield (0, authorization_1.checkUserPermission)(userId, 'billing', 'read');
        if (!hasPermission) {
            return res.status(403).json({
                error: 'Insufficient permissions',
                code: 'BILLING_READ_PERMISSION_REQUIRED',
                message: 'You do not have permission to view billing data. Contact your administrator.'
            });
        }
        next();
    }
    catch (error) {
        console.error('Billing read permission check error:', error);
        res.status(500).json({
            error: 'Authorization check failed',
            code: 'AUTH_CHECK_ERROR',
            message: 'An error occurred while checking permissions'
        });
    }
});
exports.requireBillingRead = requireBillingRead;
/**
 * Middleware to check if user has billing:write permission
 * Required for creating invoices and modifying billing data
 */
const requireBillingWrite = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        if (!userId) {
            return res.status(401).json({
                error: 'Authentication required',
                code: 'AUTH_REQUIRED',
                message: 'You must be logged in to modify billing data'
            });
        }
        const hasPermission = yield (0, authorization_1.checkUserPermission)(userId, 'billing', 'write');
        if (!hasPermission) {
            return res.status(403).json({
                error: 'Insufficient permissions',
                code: 'BILLING_WRITE_PERMISSION_REQUIRED',
                message: 'You do not have permission to create or modify invoices. Contact your administrator.'
            });
        }
        next();
    }
    catch (error) {
        console.error('Billing write permission check error:', error);
        res.status(500).json({
            error: 'Authorization check failed',
            code: 'AUTH_CHECK_ERROR',
            message: 'An error occurred while checking permissions'
        });
    }
});
exports.requireBillingWrite = requireBillingWrite;
/**
 * Middleware to check if user has billing:admin permission
 * Required for processing payments and administrative billing tasks
 */
const requireBillingAdmin = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        if (!userId) {
            return res.status(401).json({
                error: 'Authentication required',
                code: 'AUTH_REQUIRED',
                message: 'You must be logged in to perform billing administration'
            });
        }
        const hasPermission = yield (0, authorization_1.checkUserPermission)(userId, 'billing', 'admin');
        if (!hasPermission) {
            return res.status(403).json({
                error: 'Insufficient permissions',
                code: 'BILLING_ADMIN_PERMISSION_REQUIRED',
                message: 'You do not have permission to process payments or perform billing administration. Contact your administrator.'
            });
        }
        next();
    }
    catch (error) {
        console.error('Billing admin permission check error:', error);
        res.status(500).json({
            error: 'Authorization check failed',
            code: 'AUTH_CHECK_ERROR',
            message: 'An error occurred while checking permissions'
        });
    }
});
exports.requireBillingAdmin = requireBillingAdmin;
