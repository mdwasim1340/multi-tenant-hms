"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fc = __importStar(require("fast-check"));
const balance_reports_auth_1 = require("../balance-reports-auth");
const authService = __importStar(require("../../services/authorization"));
/**
 * Property-Based Tests for Balance Reports Authorization Middleware
 *
 * Tests permission checking with 100+ iterations to ensure correctness
 * across all possible permission combinations.
 */
// Mock the authorization service
jest.mock('../../services/authorization');
// Mock request/response/next
const createMockRequest = (overrides = {}) => {
    return Object.assign({ ip: '192.168.1.1', socket: { remoteAddress: '192.168.1.1' }, headers: { 'user-agent': 'Test Agent' }, path: '/api/balance-reports/profit-loss', method: 'GET' }, overrides);
};
const createMockResponse = () => {
    const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn().mockReturnThis()
    };
    return res;
};
const createMockNext = () => {
    return jest.fn();
};
// Generators for property-based testing
const userIdGen = fc.string({ minLength: 10, maxLength: 50 });
const permissionGen = fc.record({
    hasBillingAdmin: fc.boolean(),
    hasFinanceRead: fc.boolean()
});
describe('Balance Reports Authorization Middleware - Property-Based Tests', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        // Suppress console logs during tests
        jest.spyOn(console, 'log').mockImplementation();
        jest.spyOn(console, 'warn').mockImplementation();
        jest.spyOn(console, 'error').mockImplementation();
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    describe('Property 18: Permission-Based Access', () => {
        /**
         * Feature: billing-balance-reports, Property 18: Permission-Based Access
         * Validates: Requirements 10.1
         *
         * For any user with either billing:admin OR finance:read permission,
         * access to balance reports should be granted.
         *
         * For any user without either permission, access should be denied.
         */
        it('should grant access for any user with billing:admin permission', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: user has billing:admin
                authService.checkUserPermission
                    .mockResolvedValueOnce(true) // billing:admin
                    .mockResolvedValueOnce(false); // finance:read
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should call next() (access granted)
                expect(next).toHaveBeenCalled();
                expect(res.status).not.toHaveBeenCalled();
                // Should store permission info
                expect(req.balanceReportPermission).toEqual({
                    canExport: true,
                    canView: true,
                    level: 'admin'
                });
            })), { numRuns: 100 });
        }));
        it('should grant access for any user with finance:read permission', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: user has finance:read but not billing:admin
                authService.checkUserPermission
                    .mockResolvedValueOnce(false) // billing:admin
                    .mockResolvedValueOnce(true); // finance:read
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should call next() (access granted)
                expect(next).toHaveBeenCalled();
                expect(res.status).not.toHaveBeenCalled();
                // Should store permission info (no export)
                expect(req.balanceReportPermission).toEqual({
                    canExport: false,
                    canView: true,
                    level: 'read'
                });
            })), { numRuns: 100 });
        }));
        it('should deny access for any user without required permissions', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: user has neither permission
                authService.checkUserPermission
                    .mockResolvedValueOnce(false) // billing:admin
                    .mockResolvedValueOnce(false); // finance:read
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should return 403 (access denied)
                expect(res.status).toHaveBeenCalledWith(403);
                expect(res.json).toHaveBeenCalledWith({
                    error: 'Insufficient permissions',
                    code: 'BALANCE_REPORT_ACCESS_DENIED',
                    message: expect.stringContaining('billing:admin or finance:read')
                });
                expect(next).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
        it('should deny access for any request without userId', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(fc.constant(undefined), () => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest(); // No userId
                const res = createMockResponse();
                const next = createMockNext();
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should return 401 (authentication required)
                expect(res.status).toHaveBeenCalledWith(401);
                expect(res.json).toHaveBeenCalledWith({
                    error: 'Authentication required',
                    code: 'AUTH_REQUIRED',
                    message: expect.stringContaining('logged in')
                });
                expect(next).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
    });
    describe('Property 19: Permission-Based Export Restriction', () => {
        /**
         * Feature: billing-balance-reports, Property 19: Permission-Based Export Restriction
         * Validates: Requirements 10.2, 10.3
         *
         * For any user, export permission should ONLY be granted if they have
         * billing:admin permission. finance:read is NOT sufficient for export.
         */
        it('should allow export for any user with billing:admin permission', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: user has billing:admin
                authService.checkUserPermission
                    .mockResolvedValueOnce(true); // billing:admin
                yield (0, balance_reports_auth_1.requireExportPermission)(req, res, next);
                // Should call next() (export allowed)
                expect(next).toHaveBeenCalled();
                expect(res.status).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
        it('should deny export for any user without billing:admin permission', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: user does NOT have billing:admin
                authService.checkUserPermission
                    .mockResolvedValueOnce(false); // billing:admin
                yield (0, balance_reports_auth_1.requireExportPermission)(req, res, next);
                // Should return 403 (export denied)
                expect(res.status).toHaveBeenCalledWith(403);
                expect(res.json).toHaveBeenCalledWith({
                    error: 'Insufficient permissions',
                    code: 'BALANCE_REPORT_EXPORT_DENIED',
                    message: expect.stringContaining('billing:admin')
                });
                expect(next).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
        it('should deny export for any request without userId', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(fc.constant(undefined), () => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest(); // No userId
                const res = createMockResponse();
                const next = createMockNext();
                yield (0, balance_reports_auth_1.requireExportPermission)(req, res, next);
                // Should return 401 (authentication required)
                expect(res.status).toHaveBeenCalledWith(401);
                expect(res.json).toHaveBeenCalledWith({
                    error: 'Authentication required',
                    code: 'AUTH_REQUIRED',
                    message: expect.stringContaining('logged in')
                });
                expect(next).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
    });
    describe('Property: Access Logging', () => {
        /**
         * For any access attempt (authorized or unauthorized),
         * the middleware should log the attempt with relevant details.
         */
        it('should log all access attempts with user and request details', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'log');
            const consoleWarnSpy = jest.spyOn(console, 'warn');
            yield fc.assert(fc.asyncProperty(userIdGen, permissionGen, (userId, permissions) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock permissions
                authService.checkUserPermission
                    .mockResolvedValueOnce(permissions.hasBillingAdmin)
                    .mockResolvedValueOnce(permissions.hasFinanceRead);
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should log either success or failure
                const hasPermission = permissions.hasBillingAdmin || permissions.hasFinanceRead;
                if (hasPermission) {
                    expect(consoleSpy).toHaveBeenCalledWith(expect.stringContaining('Access granted'), expect.objectContaining({
                        userId,
                        path: req.path,
                        method: req.method
                    }));
                }
                else {
                    expect(consoleWarnSpy).toHaveBeenCalledWith(expect.stringContaining('Insufficient permissions'), expect.objectContaining({
                        userId,
                        path: req.path,
                        method: req.method
                    }));
                }
            })), { numRuns: 100 });
        }));
    });
    describe('Property: Helper Functions', () => {
        /**
         * Helper functions should correctly reflect the permission state
         * set by the middleware.
         */
        it('canExportReports should return true only for admin permission', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(permissionGen, (permissions) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest();
                // Simulate middleware setting permission
                req.balanceReportPermission = {
                    canExport: permissions.hasBillingAdmin,
                    canView: true,
                    level: permissions.hasBillingAdmin ? 'admin' : 'read'
                };
                const result = (0, balance_reports_auth_1.canExportReports)(req);
                // Should match the permission state
                expect(result).toBe(permissions.hasBillingAdmin);
            })), { numRuns: 100 });
        }));
        it('getPermissionLevel should return correct level', () => __awaiter(void 0, void 0, void 0, function* () {
            yield fc.assert(fc.asyncProperty(permissionGen, (permissions) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest();
                // Simulate middleware setting permission
                if (permissions.hasBillingAdmin || permissions.hasFinanceRead) {
                    req.balanceReportPermission = {
                        canExport: permissions.hasBillingAdmin,
                        canView: true,
                        level: permissions.hasBillingAdmin ? 'admin' : 'read'
                    };
                }
                const result = (0, balance_reports_auth_1.getPermissionLevel)(req);
                // Should match the permission level
                if (permissions.hasBillingAdmin) {
                    expect(result).toBe('admin');
                }
                else if (permissions.hasFinanceRead) {
                    expect(result).toBe('read');
                }
                else {
                    expect(result).toBeNull();
                }
            })), { numRuns: 100 });
        }));
    });
    describe('Property: Error Handling', () => {
        /**
         * For any error during permission checking, the middleware should
         * return 500 and log the error without exposing sensitive details.
         */
        it('should handle permission check errors gracefully', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleErrorSpy = jest.spyOn(console, 'error');
            yield fc.assert(fc.asyncProperty(userIdGen, (userId) => __awaiter(void 0, void 0, void 0, function* () {
                const req = createMockRequest({ userId });
                const res = createMockResponse();
                const next = createMockNext();
                // Mock: permission check throws error
                authService.checkUserPermission
                    .mockRejectedValueOnce(new Error('Database error'));
                yield (0, balance_reports_auth_1.requireBalanceReportAccess)(req, res, next);
                // Should return 500
                expect(res.status).toHaveBeenCalledWith(500);
                expect(res.json).toHaveBeenCalledWith({
                    error: 'Authorization check failed',
                    code: 'AUTH_CHECK_ERROR',
                    message: expect.stringContaining('error occurred')
                });
                // Should log error
                expect(consoleErrorSpy).toHaveBeenCalled();
                // Should not call next
                expect(next).not.toHaveBeenCalled();
            })), { numRuns: 100 });
        }));
    });
});
