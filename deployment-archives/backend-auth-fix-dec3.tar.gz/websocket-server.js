"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsWebSocketServer = void 0;
exports.getWebSocketServer = getWebSocketServer;
exports.closeWebSocketServer = closeWebSocketServer;
const ws_1 = require("ws");
const url_1 = require("url");
class AnalyticsWebSocketServer {
    constructor(port = 8080) {
        this.clients = new Map();
        this.wss = new ws_1.WebSocketServer({
            port,
            verifyClient: this.verifyClient.bind(this)
        });
        this.wss.on('connection', this.handleConnection.bind(this));
        console.log(`WebSocket server running on port ${port}`);
    }
    verifyClient(info) {
        try {
            const url = (0, url_1.parse)(info.req.url || '', true);
            const token = url.query.token;
            const tenantId = url.query.tenantId;
            if (!token || !tenantId) {
                return false;
            }
            // Verify JWT token (you'll need to implement proper JWT verification)
            // const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret');
            return true;
        }
        catch (error) {
            console.error('WebSocket authentication failed:', error);
            return false;
        }
    }
    handleConnection(ws, req) {
        const url = (0, url_1.parse)(req.url || '', true);
        const tenantId = url.query.tenantId;
        ws.tenantId = tenantId;
        // Add client to tenant group
        if (!this.clients.has(tenantId)) {
            this.clients.set(tenantId, new Set());
        }
        this.clients.get(tenantId).add(ws);
        console.log(`WebSocket client connected for tenant: ${tenantId}`);
        ws.on('message', (data) => {
            try {
                const message = JSON.parse(data.toString());
                this.handleMessage(ws, message);
            }
            catch (error) {
                console.error('Invalid WebSocket message:', error);
            }
        });
        ws.on('close', () => {
            if (ws.tenantId) {
                const tenantClients = this.clients.get(ws.tenantId);
                if (tenantClients) {
                    tenantClients.delete(ws);
                    if (tenantClients.size === 0) {
                        this.clients.delete(ws.tenantId);
                    }
                }
            }
            console.log(`WebSocket client disconnected for tenant: ${ws.tenantId}`);
        });
        // Send welcome message
        ws.send(JSON.stringify({
            type: 'connected',
            message: 'WebSocket connection established'
        }));
    }
    handleMessage(ws, message) {
        // Handle incoming messages from clients
        console.log('Received message:', message);
    }
    // Broadcast event to all clients of a specific tenant
    broadcastToTenant(tenantId, event) {
        const tenantClients = this.clients.get(tenantId);
        if (tenantClients) {
            const message = JSON.stringify({
                type: 'event',
                event: event
            });
            tenantClients.forEach(client => {
                if (client.readyState === ws_1.WebSocket.OPEN) {
                    client.send(message);
                }
            });
        }
    }
    // Broadcast event to all connected clients
    broadcastToAll(event) {
        const message = JSON.stringify({
            type: 'event',
            event: event
        });
        this.clients.forEach(tenantClients => {
            tenantClients.forEach(client => {
                if (client.readyState === ws_1.WebSocket.OPEN) {
                    client.send(message);
                }
            });
        });
    }
    close() {
        this.wss.close();
    }
}
exports.AnalyticsWebSocketServer = AnalyticsWebSocketServer;
// Export singleton instance
let wsServer = null;
function getWebSocketServer() {
    if (!wsServer) {
        wsServer = new AnalyticsWebSocketServer();
    }
    return wsServer;
}
function closeWebSocketServer() {
    if (wsServer) {
        wsServer.close();
        wsServer = null;
    }
}
