"use strict";
/**
 * Query Performance Logger
 *
 * Utility for logging database query performance metrics.
 * Helps identify slow queries and optimization opportunities.
 *
 * Requirements: 13.1
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryPerformanceLogger = void 0;
class QueryPerformanceLogger {
    /**
     * Log query performance
     */
    static log(metrics) {
        // Add to metrics array
        this.metrics.push(metrics);
        // Keep only last N metrics
        if (this.metrics.length > this.maxMetricsSize) {
            this.metrics.shift();
        }
        // Log slow queries
        if (metrics.duration > this.slowQueryThreshold) {
            console.warn(`[SLOW QUERY] ${metrics.duration}ms - ${this.truncateQuery(metrics.query)}`);
            console.warn(`  Tenant: ${metrics.tenantId || 'N/A'}, Rows: ${metrics.rowCount || 'N/A'}`);
        }
        else {
            console.log(`[Query] ${metrics.duration}ms - ${this.truncateQuery(metrics.query)}`);
        }
    }
    /**
     * Get performance statistics
     */
    static getStats() {
        if (this.metrics.length === 0) {
            return {
                totalQueries: 0,
                averageDuration: 0,
                slowQueries: 0,
                fastestQuery: 0,
                slowestQuery: 0
            };
        }
        const durations = this.metrics.map(m => m.duration);
        const slowQueries = this.metrics.filter(m => m.duration > this.slowQueryThreshold);
        return {
            totalQueries: this.metrics.length,
            averageDuration: durations.reduce((a, b) => a + b, 0) / durations.length,
            slowQueries: slowQueries.length,
            fastestQuery: Math.min(...durations),
            slowestQuery: Math.max(...durations)
        };
    }
    /**
     * Get recent slow queries
     */
    static getSlowQueries(limit = 10) {
        return this.metrics
            .filter(m => m.duration > this.slowQueryThreshold)
            .sort((a, b) => b.duration - a.duration)
            .slice(0, limit);
    }
    /**
     * Clear metrics
     */
    static clear() {
        this.metrics = [];
    }
    /**
     * Set slow query threshold
     */
    static setSlowQueryThreshold(milliseconds) {
        this.slowQueryThreshold = milliseconds;
    }
    /**
     * Truncate query for logging
     */
    static truncateQuery(query) {
        const maxLength = 100;
        const cleaned = query.replace(/\s+/g, ' ').trim();
        return cleaned.length > maxLength
            ? cleaned.substring(0, maxLength) + '...'
            : cleaned;
    }
    /**
     * Measure query execution time
     */
    static measureQuery(queryFn, queryDescription, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const startTime = Date.now();
            try {
                const result = yield queryFn();
                const duration = Date.now() - startTime;
                // Extract row count if result has rows
                let rowCount;
                if (result && typeof result === 'object' && 'rows' in result) {
                    rowCount = (_a = result.rows) === null || _a === void 0 ? void 0 : _a.length;
                }
                this.log({
                    query: queryDescription,
                    duration,
                    rowCount,
                    tenantId,
                    timestamp: new Date()
                });
                return result;
            }
            catch (error) {
                const duration = Date.now() - startTime;
                console.error(`[Query Error] ${duration}ms - ${queryDescription}`, error);
                throw error;
            }
        });
    }
}
exports.QueryPerformanceLogger = QueryPerformanceLogger;
QueryPerformanceLogger.slowQueryThreshold = 1000; // 1 second
QueryPerformanceLogger.metrics = [];
QueryPerformanceLogger.maxMetricsSize = 1000; // Keep last 1000 queries
