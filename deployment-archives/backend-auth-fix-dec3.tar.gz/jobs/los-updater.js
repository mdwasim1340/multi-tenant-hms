"use strict";
/**
 * LOS Updater Job
 * Scheduled job to update LOS predictions daily for all active admissions
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.losUpdaterJob = exports.LOSUpdaterJob = void 0;
const cron = __importStar(require("node-cron"));
const database_1 = __importDefault(require("../database"));
const los_prediction_service_1 = require("../services/los-prediction-service");
class LOSUpdaterJob {
    constructor() {
        this.isRunning = false;
        this.cronJob = null;
    }
    /**
     * Start the scheduled job
     * Runs daily at 2:00 AM
     */
    start() {
        // Run daily at 2:00 AM
        this.cronJob = cron.schedule('0 2 * * *', () => __awaiter(this, void 0, void 0, function* () {
            yield this.execute();
        }));
        console.log('✅ LOS Updater Job scheduled (daily at 2:00 AM)');
    }
    /**
     * Stop the scheduled job
     */
    stop() {
        if (this.cronJob) {
            this.cronJob.stop();
            console.log('🛑 LOS Updater Job stopped');
        }
    }
    /**
     * Execute the job manually (for testing or on-demand updates)
     */
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.isRunning) {
                console.log('⚠️  LOS Updater Job already running, skipping...');
                return;
            }
            this.isRunning = true;
            const startTime = Date.now();
            try {
                console.log('🚀 Starting LOS Updater Job...');
                // Get all tenants
                const tenantsResult = yield database_1.default.query('SELECT id, name FROM tenants WHERE status = $1', ['active']);
                const tenants = tenantsResult.rows;
                console.log(`📊 Found ${tenants.length} active tenants`);
                let totalUpdated = 0;
                let totalErrors = 0;
                // Process each tenant
                for (const tenant of tenants) {
                    try {
                        const updated = yield this.updateTenantPredictions(tenant.id, tenant.name);
                        totalUpdated += updated;
                        console.log(`  ✅ ${tenant.name}: ${updated} predictions updated`);
                    }
                    catch (error) {
                        totalErrors++;
                        console.error(`  ❌ ${tenant.name}: Error updating predictions`, error);
                    }
                }
                const duration = Date.now() - startTime;
                console.log(`\n✅ LOS Updater Job completed`);
                console.log(`   Total updated: ${totalUpdated}`);
                console.log(`   Total errors: ${totalErrors}`);
                console.log(`   Duration: ${duration}ms`);
                // Log job execution metrics
                yield this.logJobExecution(totalUpdated, totalErrors, duration);
            }
            catch (error) {
                console.error('❌ LOS Updater Job failed:', error);
            }
            finally {
                this.isRunning = false;
            }
        });
    }
    /**
     * Update predictions for a specific tenant
     */
    updateTenantPredictions(tenantId, tenantName) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get all active admissions with existing predictions
            // In a real system, you would query your admissions table
            // For now, we'll get admissions that have predictions but no actual LOS yet
            const result = yield database_1.default.query(`SELECT DISTINCT admission_id 
       FROM los_predictions 
       WHERE tenant_id = $1 
       AND actual_los_days IS NULL
       AND created_at >= CURRENT_DATE - INTERVAL '30 days'`, [tenantId]);
            const admissions = result.rows;
            let updated = 0;
            for (const admission of admissions) {
                try {
                    // Update prediction for this admission
                    const prediction = yield los_prediction_service_1.losPredictionService.updatePrediction(admission.admission_id, tenantId);
                    if (prediction) {
                        updated++;
                    }
                }
                catch (error) {
                    console.error(`    Error updating admission ${admission.admission_id}:`, error);
                }
            }
            return updated;
        });
    }
    /**
     * Log job execution metrics to database
     */
    logJobExecution(totalUpdated, totalErrors, duration) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Log to a job execution table (you may want to create this table)
                // For now, we'll just log to console
                const metrics = {
                    job_name: 'los_updater',
                    executed_at: new Date(),
                    total_updated: totalUpdated,
                    total_errors: totalErrors,
                    duration_ms: duration,
                    status: totalErrors === 0 ? 'success' : 'partial_success',
                };
                console.log('\n📊 Job Metrics:', JSON.stringify(metrics, null, 2));
                // Optionally store in database for monitoring
                // await pool.query(
                //   `INSERT INTO job_executions (job_name, executed_at, metrics, status)
                //    VALUES ($1, $2, $3, $4)`,
                //   [metrics.job_name, metrics.executed_at, JSON.stringify(metrics), metrics.status]
                // );
            }
            catch (error) {
                console.error('Error logging job execution:', error);
            }
        });
    }
    /**
     * Get job status
     */
    getStatus() {
        return {
            running: this.isRunning,
            scheduled: this.cronJob !== null,
        };
    }
}
exports.LOSUpdaterJob = LOSUpdaterJob;
// Export singleton instance
exports.losUpdaterJob = new LOSUpdaterJob();
