"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingJobs = void 0;
const billing_scheduler_service_1 = require("../services/billing-scheduler.service");
const billing_email_service_1 = require("../services/billing-email.service");
/**
 * Billing Jobs
 * Contains all scheduled billing tasks that should be run via cron
 */
class BillingJobs {
    constructor(pool) {
        this.schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        this.emailService = new billing_email_service_1.BillingEmailService();
    }
    /**
     * Run all daily billing jobs
     * Should be scheduled to run once daily (e.g., 6:00 AM)
     */
    runDailyJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('[BillingJobs] Starting daily billing jobs...');
            const startTime = Date.now();
            try {
                // 1. Mark overdue invoices
                const overdueResult = yield this.markOverdueInvoices();
                console.log(`[BillingJobs] Marked ${overdueResult.updated} invoices as overdue`);
                // 2. Send payment reminders
                yield this.sendPaymentReminders();
                // 3. Send overdue notices
                yield this.sendOverdueNotices();
                // 4. Process payment plan reminders
                yield this.processPaymentPlanReminders();
                // 5. Mark defaulted payment plans
                const defaultedResult = yield this.schedulerService.markDefaultedPaymentPlans();
                console.log(`[BillingJobs] Marked ${defaultedResult.updated} payment plans as defaulted`);
                // 6. Generate and send daily summary
                yield this.sendDailySummary();
                const duration = Date.now() - startTime;
                console.log(`[BillingJobs] Daily jobs completed in ${duration}ms`);
            }
            catch (error) {
                console.error('[BillingJobs] Error running daily jobs:', error);
                throw error;
            }
        });
    }
    /**
     * Run weekly billing jobs
     * Should be scheduled to run once weekly (e.g., Monday 7:00 AM)
     */
    runWeeklyJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('[BillingJobs] Starting weekly billing jobs...');
            try {
                // Apply late fees to invoices overdue > 30 days
                const lateFeeResult = yield this.schedulerService.applyLateFees(2); // 2% late fee
                console.log(`[BillingJobs] Applied late fees to ${lateFeeResult.applied} invoices. Total: ${lateFeeResult.totalFees}`);
                console.log('[BillingJobs] Weekly jobs completed');
            }
            catch (error) {
                console.error('[BillingJobs] Error running weekly jobs:', error);
                throw error;
            }
        });
    }
    /**
     * Mark overdue invoices
     */
    markOverdueInvoices() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.schedulerService.markOverdueInvoices();
            // Send notification for newly marked overdue invoices
            for (const invoice of result.invoices) {
                yield this.emailService.sendOverdueNotice(invoice, 1);
            }
            return { updated: result.updated };
        });
    }
    /**
     * Send payment reminders for upcoming due invoices
     */
    sendPaymentReminders() {
        return __awaiter(this, void 0, void 0, function* () {
            const reminders = yield this.schedulerService.getInvoicesForReminders();
            // Send 3-day reminders
            for (const invoice of reminders.dueIn3Days) {
                yield this.emailService.sendPaymentReminder(invoice, 3);
            }
            console.log(`[BillingJobs] Sent ${reminders.dueIn3Days.length} 3-day reminders`);
            // Send 1-day reminders
            for (const invoice of reminders.dueIn1Day) {
                yield this.emailService.sendPaymentReminder(invoice, 1);
            }
            console.log(`[BillingJobs] Sent ${reminders.dueIn1Day.length} 1-day reminders`);
            // Send due today reminders
            for (const invoice of reminders.dueToday) {
                yield this.emailService.sendPaymentReminder(invoice, 0);
            }
            console.log(`[BillingJobs] Sent ${reminders.dueToday.length} due-today reminders`);
        });
    }
    /**
     * Send overdue notices for past due invoices
     */
    sendOverdueNotices() {
        return __awaiter(this, void 0, void 0, function* () {
            const overdue = yield this.schedulerService.getOverdueInvoicesForReminders();
            // Send 7-day overdue notices
            for (const invoice of overdue.overdue7Days) {
                yield this.emailService.sendOverdueNotice(invoice, 7);
            }
            console.log(`[BillingJobs] Sent ${overdue.overdue7Days.length} 7-day overdue notices`);
            // Send 14-day overdue notices
            for (const invoice of overdue.overdue14Days) {
                yield this.emailService.sendOverdueNotice(invoice, 14);
            }
            console.log(`[BillingJobs] Sent ${overdue.overdue14Days.length} 14-day overdue notices`);
            // Send 30-day overdue notices
            for (const invoice of overdue.overdue30Days) {
                yield this.emailService.sendOverdueNotice(invoice, 30);
            }
            console.log(`[BillingJobs] Sent ${overdue.overdue30Days.length} 30-day overdue notices`);
        });
    }
    /**
     * Process payment plan reminders
     */
    processPaymentPlanReminders() {
        return __awaiter(this, void 0, void 0, function* () {
            const plans = yield this.schedulerService.getPaymentPlansDue();
            // Send due today reminders
            for (const plan of plans.dueToday) {
                yield this.emailService.sendPaymentPlanReminder(plan, false);
            }
            console.log(`[BillingJobs] Sent ${plans.dueToday.length} payment plan due reminders`);
            // Send overdue reminders
            for (const plan of plans.overdue) {
                yield this.emailService.sendPaymentPlanReminder(plan, true);
            }
            console.log(`[BillingJobs] Sent ${plans.overdue.length} payment plan overdue reminders`);
        });
    }
    /**
     * Send daily summary to admin
     */
    sendDailySummary() {
        return __awaiter(this, void 0, void 0, function* () {
            const adminEmail = process.env.BILLING_ADMIN_EMAIL;
            if (!adminEmail) {
                console.log('[BillingJobs] No admin email configured for daily summary');
                return;
            }
            const summary = yield this.schedulerService.generateDailySummary();
            yield this.emailService.sendDailySummary(adminEmail, summary);
            console.log(`[BillingJobs] Sent daily summary to ${adminEmail}`);
        });
    }
}
exports.BillingJobs = BillingJobs;
exports.default = BillingJobs;
