"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const diagnosis_treatment_controller_1 = require("../controllers/diagnosis-treatment.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// POST /api/medical-records/diagnoses - Create diagnosis (requires write permission)
router.post('/diagnoses', (0, authorization_1.requirePermission)('patients', 'write'), diagnosis_treatment_controller_1.createDiagnosis);
// POST /api/medical-records/treatments - Create treatment (requires write permission)
router.post('/treatments', (0, authorization_1.requirePermission)('patients', 'write'), diagnosis_treatment_controller_1.createTreatment);
// DELETE /api/medical-records/treatments/:id - Discontinue treatment (requires write permission)
router.delete('/treatments/:id', (0, authorization_1.requirePermission)('patients', 'write'), diagnosis_treatment_controller_1.discontinueTreatment);
exports.default = router;
