"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const analyticsService = __importStar(require("../services/analytics"));
const router = (0, express_1.Router)();
// Dashboard Analytics
router.get('/analytics/dashboard', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const analytics = yield analyticsService.getDashboardAnalytics();
        res.json({
            success: true,
            data: analytics
        });
    }
    catch (error) {
        console.error('Error fetching dashboard analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch dashboard analytics',
            message: error.message
        });
    }
}));
// Staff Analytics
router.get('/analytics/staff', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            department: req.query.department,
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getStaffAnalytics(filters);
        res.json({
            success: true,
            data: analytics,
            count: analytics.length
        });
    }
    catch (error) {
        console.error('Error fetching staff analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch staff analytics',
            message: error.message
        });
    }
}));
// Staff Trends
router.get('/analytics/staff/trends', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getStaffAnalytics(filters);
        // Calculate trends
        const trends = {
            hiring_trend: analytics.map(a => ({
                month: a.month,
                new_hires: a.new_hires
            })),
            employment_type_distribution: analytics.reduce((acc, curr) => {
                acc.full_time = (acc.full_time || 0) + curr.full_time_count;
                acc.part_time = (acc.part_time || 0) + curr.part_time_count;
                acc.contract = (acc.contract || 0) + curr.contract_count;
                return acc;
            }, {})
        };
        res.json({
            success: true,
            data: trends
        });
    }
    catch (error) {
        console.error('Error fetching staff trends:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch staff trends',
            message: error.message
        });
    }
}));
// Schedule Analytics
router.get('/analytics/schedules', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getScheduleAnalytics(filters);
        res.json({
            success: true,
            data: analytics,
            count: analytics.length
        });
    }
    catch (error) {
        console.error('Error fetching schedule analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch schedule analytics',
            message: error.message
        });
    }
}));
// Attendance Analytics
router.get('/analytics/attendance', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getAttendanceAnalytics(filters);
        res.json({
            success: true,
            data: analytics,
            count: analytics.length
        });
    }
    catch (error) {
        console.error('Error fetching attendance analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch attendance analytics',
            message: error.message
        });
    }
}));
// Performance Analytics
router.get('/analytics/performance', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getPerformanceAnalytics(filters);
        res.json({
            success: true,
            data: analytics,
            count: analytics.length
        });
    }
    catch (error) {
        console.error('Error fetching performance analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch performance analytics',
            message: error.message
        });
    }
}));
// Payroll Analytics
router.get('/analytics/payroll', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const analytics = yield analyticsService.getPayrollAnalytics(filters);
        res.json({
            success: true,
            data: analytics,
            count: analytics.length
        });
    }
    catch (error) {
        console.error('Error fetching payroll analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch payroll analytics',
            message: error.message
        });
    }
}));
// Financial Summary
router.get('/analytics/financial', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            start_date: req.query.start_date,
            end_date: req.query.end_date
        };
        const payrollAnalytics = yield analyticsService.getPayrollAnalytics(filters);
        // Calculate financial summary
        const summary = payrollAnalytics.reduce((acc, curr) => ({
            total_payroll: acc.total_payroll + Number(curr.total_net_pay || 0),
            total_overtime: acc.total_overtime + Number(curr.total_overtime_pay || 0),
            total_bonuses: acc.total_bonuses + Number(curr.total_bonuses || 0),
            total_deductions: acc.total_deductions + Number(curr.total_deductions || 0),
            avg_salary: acc.avg_salary + Number(curr.avg_net_pay || 0)
        }), {
            total_payroll: 0,
            total_overtime: 0,
            total_bonuses: 0,
            total_deductions: 0,
            avg_salary: 0
        });
        if (payrollAnalytics.length > 0) {
            summary.avg_salary = summary.avg_salary / payrollAnalytics.length;
        }
        res.json({
            success: true,
            data: {
                summary,
                monthly_breakdown: payrollAnalytics
            }
        });
    }
    catch (error) {
        console.error('Error fetching financial analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch financial analytics',
            message: error.message
        });
    }
}));
// Credentials Expiry
router.get('/analytics/credentials/expiry', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const filters = {
            expiry_status: req.query.expiry_status,
            department: req.query.department
        };
        const credentials = yield analyticsService.getCredentialsExpiry(filters);
        res.json({
            success: true,
            data: credentials,
            count: credentials.length
        });
    }
    catch (error) {
        console.error('Error fetching credentials expiry:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch credentials expiry',
            message: error.message
        });
    }
}));
// Department Statistics
router.get('/analytics/departments', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const department = req.query.department;
        const statistics = yield analyticsService.getDepartmentStatistics(department);
        res.json({
            success: true,
            data: statistics,
            count: statistics.length
        });
    }
    catch (error) {
        console.error('Error fetching department statistics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch department statistics',
            message: error.message
        });
    }
}));
// Operational Reports
router.get('/analytics/operational', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const [dashboardData, scheduleData, attendanceData, departmentData] = yield Promise.all([
            analyticsService.getDashboardAnalytics(),
            analyticsService.getScheduleAnalytics({
                start_date: req.query.start_date,
                end_date: req.query.end_date
            }),
            analyticsService.getAttendanceAnalytics({
                start_date: req.query.start_date,
                end_date: req.query.end_date
            }),
            analyticsService.getDepartmentStatistics()
        ]);
        res.json({
            success: true,
            data: {
                overview: dashboardData,
                schedules: scheduleData,
                attendance: attendanceData,
                departments: departmentData
            }
        });
    }
    catch (error) {
        console.error('Error fetching operational reports:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch operational reports',
            message: error.message
        });
    }
}));
// Custom Report Generation
router.post('/analytics/custom', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const reportConfig = req.body;
        // Validate report configuration
        if (!reportConfig.metrics || !Array.isArray(reportConfig.metrics)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid report configuration',
                message: 'metrics array is required'
            });
        }
        const reportData = yield analyticsService.generateCustomReport(reportConfig);
        res.json({
            success: true,
            data: reportData,
            config: reportConfig
        });
    }
    catch (error) {
        console.error('Error generating custom report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate custom report',
            message: error.message
        });
    }
}));
// Export Analytics Data
router.get('/analytics/export', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const dataType = req.query.type;
        const format = req.query.format || 'json';
        if (!dataType) {
            return res.status(400).json({
                success: false,
                error: 'Data type is required',
                message: 'Specify type parameter (dashboard, staff, schedule, attendance, performance, payroll, credentials, departments)'
            });
        }
        const exportData = yield analyticsService.exportAnalyticsData(dataType, format);
        res.json({
            success: true,
            export: exportData
        });
    }
    catch (error) {
        console.error('Error exporting analytics data:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to export analytics data',
            message: error.message
        });
    }
}));
// Business Intelligence Dashboard
router.get('/analytics/business-intelligence', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const [dashboard, staffTrends, performanceData, payrollData, departmentStats] = yield Promise.all([
            analyticsService.getDashboardAnalytics(),
            analyticsService.getStaffAnalytics({
                start_date: req.query.start_date,
                end_date: req.query.end_date
            }),
            analyticsService.getPerformanceAnalytics({
                start_date: req.query.start_date,
                end_date: req.query.end_date
            }),
            analyticsService.getPayrollAnalytics({
                start_date: req.query.start_date,
                end_date: req.query.end_date
            }),
            analyticsService.getDepartmentStatistics()
        ]);
        res.json({
            success: true,
            data: {
                overview: dashboard,
                staff_trends: staffTrends,
                performance: performanceData,
                financial: payrollData,
                departments: departmentStats
            }
        });
    }
    catch (error) {
        console.error('Error fetching business intelligence data:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch business intelligence data',
            message: error.message
        });
    }
}));
exports.default = router;
