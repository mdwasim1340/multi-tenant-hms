"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkN8NStatus = exports.chatWithAgent = void 0;
const express_1 = __importDefault(require("express"));
const axios_1 = __importDefault(require("axios"));
const errorHandler_1 = require("../middleware/errorHandler");
const router = express_1.default.Router();
/**
 * POST /api/n8n/chat
 * Universal endpoint to interact with n8n AI agents
 * Supports: OPD Agent, Ward Agent, Emergency Agent, General Query
 */
exports.chatWithAgent = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g;
    const { message, sessionId, department } = req.body;
    if (!message || !sessionId) {
        return res.status(400).json({
            success: false,
            error: 'Missing required fields: message, sessionId'
        });
    }
    // Default to general query if no department specified
    const dept = department || 'general';
    try {
        // Get n8n configuration from environment
        const n8nBaseUrl = process.env.N8N_BASE_URL;
        const n8nAuthHeader = process.env.N8N_WEBHOOK_AUTH_HEADER || 'cdss';
        const n8nAuthToken = process.env.N8N_WEBHOOK_AUTH_TOKEN;
        // Map department to webhook path
        const agentPaths = {
            opd: process.env.N8N_OPD_AGENT_PATH,
            ward: process.env.N8N_WARD_AGENT_PATH,
            emergency: process.env.N8N_EMERGENCY_AGENT_PATH,
            general: process.env.N8N_OPD_AGENT_PATH // Use OPD as fallback for general queries
        };
        const agentPath = agentPaths[dept.toLowerCase()];
        // Validate configuration
        if (!n8nBaseUrl || !n8nAuthToken || !agentPath) {
            console.error('n8n configuration missing:', {
                baseUrl: !!n8nBaseUrl,
                authToken: !!n8nAuthToken,
                agentPath: !!agentPath,
                department: dept
            });
            return res.status(500).json({
                success: false,
                error: 'n8n configuration not properly set up for this department',
                debug: {
                    baseUrl: !!n8nBaseUrl,
                    authToken: !!n8nAuthToken,
                    agentPath: !!agentPath,
                    department: dept
                }
            });
        }
        // Construct full webhook URL
        const webhookUrl = `${n8nBaseUrl}/webhook/${agentPath}`;
        console.log('Calling n8n Agent:', {
            department: dept,
            url: webhookUrl,
            sessionId: sessionId,
            messageLength: message.length
        });
        // Call n8n webhook
        const response = yield axios_1.default.post(webhookUrl, {
            chatInput: message,
            sessionId: sessionId
        }, {
            headers: {
                [n8nAuthHeader]: n8nAuthToken,
                'Content-Type': 'application/json'
            },
            timeout: parseInt(process.env.N8N_SESSION_TIMEOUT || '90000')
        });
        console.log('n8n Agent response received:', {
            department: dept,
            status: response.status,
            hasOutput: !!response.data.output,
            hasText: !!response.data.text
        });
        // Return response
        res.json({
            success: true,
            response: response.data.output || response.data.text || 'No response from AI agent',
            sessionId: sessionId,
            department: dept,
            timestamp: new Date().toISOString()
        });
    }
    catch (error) {
        console.error('n8n Agent chat failed:', {
            department: dept,
            error: error.message,
            status: (_a = error.response) === null || _a === void 0 ? void 0 : _a.status,
            statusText: (_b = error.response) === null || _b === void 0 ? void 0 : _b.statusText,
            data: (_c = error.response) === null || _c === void 0 ? void 0 : _c.data
        });
        // Determine error type
        let errorMessage = `Failed to connect to ${dept} agent`;
        let errorCode = 'N8N_CONNECTION_ERROR';
        if (((_d = error.response) === null || _d === void 0 ? void 0 : _d.status) === 401) {
            errorMessage = 'Authentication failed - check n8n token';
            errorCode = 'N8N_AUTH_ERROR';
        }
        else if (((_e = error.response) === null || _e === void 0 ? void 0 : _e.status) === 404) {
            errorMessage = 'n8n webhook not found - check webhook path';
            errorCode = 'N8N_NOT_FOUND';
        }
        else if (error.code === 'ECONNREFUSED') {
            errorMessage = 'Cannot connect to n8n instance - check N8N_BASE_URL';
            errorCode = 'N8N_CONNECTION_REFUSED';
        }
        else if (error.code === 'ETIMEDOUT') {
            errorMessage = 'n8n request timeout - server may be slow';
            errorCode = 'N8N_TIMEOUT';
        }
        // Get agent path for error reporting
        const agentPaths = {
            opd: process.env.N8N_OPD_AGENT_PATH,
            ward: process.env.N8N_WARD_AGENT_PATH,
            emergency: process.env.N8N_EMERGENCY_AGENT_PATH,
            general: process.env.N8N_OPD_AGENT_PATH
        };
        res.status(((_f = error.response) === null || _f === void 0 ? void 0 : _f.status) || 500).json({
            success: false,
            error: errorMessage,
            code: errorCode,
            debug: {
                message: error.message,
                status: (_g = error.response) === null || _g === void 0 ? void 0 : _g.status,
                department: dept,
                url: `${process.env.N8N_BASE_URL}/webhook/${agentPaths[dept.toLowerCase()]}`
            }
        });
    }
}));
/**
 * GET /api/n8n/status
 * Check n8n configuration status
 */
exports.checkN8NStatus = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const n8nBaseUrl = process.env.N8N_BASE_URL;
    const n8nAuthToken = process.env.N8N_WEBHOOK_AUTH_TOKEN;
    const n8nOPDPath = process.env.N8N_OPD_AGENT_PATH;
    const n8nWardPath = process.env.N8N_WARD_AGENT_PATH;
    const n8nEmergencyPath = process.env.N8N_EMERGENCY_AGENT_PATH;
    res.json({
        success: true,
        configured: {
            baseUrl: !!n8nBaseUrl,
            authToken: !!n8nAuthToken,
            opdPath: !!n8nOPDPath,
            wardPath: !!n8nWardPath,
            emergencyPath: !!n8nEmergencyPath
        },
        agents: {
            opd: {
                available: !!(n8nBaseUrl && n8nOPDPath),
                url: n8nBaseUrl && n8nOPDPath ? `${n8nBaseUrl}/webhook/${n8nOPDPath}` : 'Not configured'
            },
            ward: {
                available: !!(n8nBaseUrl && n8nWardPath),
                url: n8nBaseUrl && n8nWardPath ? `${n8nBaseUrl}/webhook/${n8nWardPath}` : 'Not configured'
            },
            emergency: {
                available: !!(n8nBaseUrl && n8nEmergencyPath),
                url: n8nBaseUrl && n8nEmergencyPath ? `${n8nBaseUrl}/webhook/${n8nEmergencyPath}` : 'Not configured'
            }
        },
        timestamp: new Date().toISOString()
    });
}));
// Routes
router.post('/chat', exports.chatWithAgent);
router.get('/status', exports.checkN8NStatus);
exports.default = router;
