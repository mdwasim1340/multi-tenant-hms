"use strict";
/**
 * Roles and Permissions API Routes
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authorization_1 = require("../services/authorization");
const authorization_2 = require("../middleware/authorization");
const router = (0, express_1.Router)();
/**
 * Get all roles
 */
router.get('/roles', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const roles = yield (0, authorization_1.getAllRoles)();
        res.json({ roles });
    }
    catch (error) {
        console.error('Error fetching roles:', error);
        res.status(500).json({ error: 'Failed to fetch roles' });
    }
}));
/**
 * Get role permissions
 */
router.get('/roles/:roleId/permissions', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const roleId = parseInt(req.params.roleId);
        const permissions = yield (0, authorization_1.getRolePermissions)(roleId);
        res.json({ permissions });
    }
    catch (error) {
        console.error('Error fetching role permissions:', error);
        res.status(500).json({ error: 'Failed to fetch role permissions' });
    }
}));
/**
 * Get all permissions
 */
router.get('/permissions', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const permissions = yield (0, authorization_1.getAllPermissions)();
        res.json({ permissions });
    }
    catch (error) {
        console.error('Error fetching permissions:', error);
        res.status(500).json({ error: 'Failed to fetch permissions' });
    }
}));
/**
 * Get user roles
 */
router.get('/users/:userId/roles', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const userId = parseInt(req.params.userId);
        const roles = yield (0, authorization_1.getUserRoles)(userId);
        res.json({ roles });
    }
    catch (error) {
        console.error('Error fetching user roles:', error);
        res.status(500).json({ error: 'Failed to fetch user roles' });
    }
}));
/**
 * Assign role to user (Admin only)
 */
router.post('/users/:userId/roles', (0, authorization_2.requirePermission)('system', 'admin'), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const userId = parseInt(req.params.userId);
        const { roleId } = req.body;
        if (!roleId) {
            return res.status(400).json({ error: 'roleId is required' });
        }
        yield (0, authorization_1.assignUserRole)(userId, roleId);
        res.json({ message: 'Role assigned successfully' });
    }
    catch (error) {
        console.error('Error assigning role:', error);
        if (error.message.includes('already has this role')) {
            return res.status(409).json({ error: error.message });
        }
        res.status(500).json({ error: 'Failed to assign role' });
    }
}));
/**
 * Revoke role from user (Admin only)
 */
router.delete('/users/:userId/roles/:roleId', (0, authorization_2.requirePermission)('system', 'admin'), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const userId = parseInt(req.params.userId);
        const roleId = parseInt(req.params.roleId);
        yield (0, authorization_1.revokeUserRole)(userId, roleId);
        res.json({ message: 'Role revoked successfully' });
    }
    catch (error) {
        console.error('Error revoking role:', error);
        if (error.message.includes('not found')) {
            return res.status(404).json({ error: error.message });
        }
        res.status(500).json({ error: 'Failed to revoke role' });
    }
}));
exports.default = router;
