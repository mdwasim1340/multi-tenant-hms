"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const database_1 = __importDefault(require("../database"));
const auth_1 = require("../middleware/auth");
const router = express_1.default.Router();
// Get system-wide statistics
router.get('/system-stats', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        // Get total tenants
        const tenantsResult = yield database_1.default.query('SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = $1) as active FROM tenants', ['active']);
        // Get total users
        const usersResult = yield database_1.default.query('SELECT COUNT(*) FROM users');
        // Get total patients (sum across all tenant schemas)
        let totalPatients = 0;
        try {
            const patientsResult = yield database_1.default.query(`
        SELECT SUM(patients_count) as total
        FROM usage_summary
        WHERE period_start = CURRENT_DATE
      `);
            totalPatients = parseInt(((_a = patientsResult.rows[0]) === null || _a === void 0 ? void 0 : _a.total) || 0);
        }
        catch (error) {
            console.log('usage_summary table not found, using 0 for patients');
        }
        res.json({
            success: true,
            data: {
                tenants: {
                    total: parseInt(tenantsResult.rows[0].total),
                    active: parseInt(tenantsResult.rows[0].active)
                },
                users: {
                    total: parseInt(usersResult.rows[0].count)
                },
                patients: {
                    total: totalPatients
                }
            }
        });
    }
    catch (error) {
        console.error('Error fetching system stats:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch system statistics',
            message: error.message
        });
    }
}));
// Get tenant-specific analytics
router.get('/tenant-analytics', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.query;
        if (!tenantId) {
            return res.status(400).json({
                success: false,
                error: 'Tenant ID is required'
            });
        }
        // Get tenant info
        const tenantResult = yield database_1.default.query('SELECT * FROM tenants WHERE id = $1', [tenantId]);
        if (tenantResult.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: 'Tenant not found'
            });
        }
        // Get usage data for tenant
        const usageResult = yield database_1.default.query('SELECT * FROM usage_summary WHERE tenant_id = $1 ORDER BY period_start DESC LIMIT 30', [tenantId]);
        res.json({
            success: true,
            data: {
                tenant: tenantResult.rows[0],
                usage: usageResult.rows
            }
        });
    }
    catch (error) {
        console.error('Error fetching tenant analytics:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch tenant analytics',
            message: error.message
        });
    }
}));
// Get usage trends
router.get('/usage-trends', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { days = 30 } = req.query;
        const result = yield database_1.default.query(`
      SELECT 
        period_start::date as date,
        SUM(patients_count) as total_patients,
        SUM(appointments_count) as total_appointments,
        SUM(api_calls) as total_api_calls
      FROM usage_summary
      WHERE period_start >= CURRENT_DATE - INTERVAL '${parseInt(days)} days'
      GROUP BY period_start::date
      ORDER BY date DESC
    `);
        res.json({
            success: true,
            data: result.rows
        });
    }
    catch (error) {
        console.error('Error fetching usage trends:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch usage trends',
            message: error.message
        });
    }
}));
exports.default = router;
