"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const zod_1 = require("zod");
const bed_assignment_optimizer_1 = require("../services/bed-assignment-optimizer");
const bedAssignmentOptimizer = new bed_assignment_optimizer_1.BedAssignmentOptimizer();
const isolation_checker_1 = __importDefault(require("../services/isolation-checker"));
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const router = express_1.default.Router();
// Apply middleware to all routes
router.use(auth_1.authMiddleware);
router.use(tenant_1.tenantMiddleware);
/**
 * Zod Schemas for Request Validation
 */
const BedRequirementsSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    isolation_required: zod_1.z.boolean().optional(),
    isolation_type: zod_1.z.enum(['contact', 'droplet', 'airborne', 'protective']).optional(),
    telemetry_required: zod_1.z.boolean().optional(),
    oxygen_required: zod_1.z.boolean().optional(),
    specialty_unit: zod_1.z.string().optional(),
    bariatric_bed: zod_1.z.boolean().optional(),
    proximity_to_nurses_station: zod_1.z.boolean().optional(),
    max_nurse_patient_ratio: zod_1.z.number().int().positive().optional()
});
const BedAssignmentSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    bed_id: zod_1.z.number().int().positive(),
    reasoning: zod_1.z.string().optional()
});
const IsolationCheckSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive()
});
const BedValidationSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    bed_id: zod_1.z.number().int().positive()
});
/**
 * POST /api/bed-management/recommend-beds
 * Get bed recommendations for a patient based on requirements
 */
router.post('/recommend-beds', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const requirements = BedRequirementsSchema.parse(req.body);
        const recommendations = yield bedAssignmentOptimizer.recommendBeds(tenantId, requirements);
        res.json({
            success: true,
            recommendations,
            count: recommendations.length,
            generated_at: new Date()
        });
    }
    catch (error) {
        console.error('Error recommending beds:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to generate bed recommendations'
        });
    }
}));
/**
 * POST /api/bed-management/assign-bed
 * Assign a bed to a patient
 */
router.post('/assign-bed', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        const data = BedAssignmentSchema.parse(req.body);
        // Validate the assignment first
        const validation = yield isolation_checker_1.default.validateBedAssignment(tenantId, data.patient_id, data.bed_id);
        if (!validation.valid) {
            return res.status(400).json({
                success: false,
                error: 'Invalid bed assignment',
                reason: validation.reason
            });
        }
        // Perform the assignment
        const assignment = yield bedAssignmentOptimizer.assignBed(tenantId, data.patient_id, data.bed_id, userId, data.reasoning || 'Manual assignment');
        res.json({
            success: true,
            assignment,
            message: 'Bed assigned successfully'
        });
    }
    catch (error) {
        console.error('Error assigning bed:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to assign bed'
        });
    }
}));
/**
 * GET /api/bed-management/beds/available
 * Get all available beds with their features
 */
router.get('/beds/available', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { unit_id, isolation_type, telemetry, oxygen } = req.query;
        const client = yield req.dbClient;
        let query = `
      SELECT 
        b.id,
        b.bed_number,
        b.unit_id,
        u.name as unit_name,
        u.unit_type,
        b.isolation_capable,
        b.isolation_type,
        b.telemetry_capable,
        b.oxygen_available,
        b.bariatric_capable,
        b.distance_to_nurses_station,
        b.cleaning_status,
        b.status
      FROM beds b
      JOIN departments u ON b.unit_id = u.id
      WHERE b.status = 'available'
    `;
        const params = [];
        let paramIndex = 1;
        if (unit_id) {
            query += ` AND b.unit_id = $${paramIndex}`;
            params.push(unit_id);
            paramIndex++;
        }
        if (isolation_type) {
            query += ` AND b.isolation_capable = true AND b.isolation_type = $${paramIndex}`;
            params.push(isolation_type);
            paramIndex++;
        }
        if (telemetry === 'true') {
            query += ` AND b.telemetry_capable = true`;
        }
        if (oxygen === 'true') {
            query += ` AND b.oxygen_available = true`;
        }
        query += ` ORDER BY u.name, b.bed_number`;
        const result = yield client.query(query, params);
        res.json({
            success: true,
            beds: result.rows,
            count: result.rows.length
        });
    }
    catch (error) {
        console.error('Error fetching available beds:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch available beds'
        });
    }
}));
/**
 * GET /api/bed-management/isolation-rooms
 * Get isolation room availability by type
 */
router.get('/isolation-rooms', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { isolation_type } = req.query;
        const availability = yield isolation_checker_1.default.getIsolationRoomAvailability(tenantId, isolation_type);
        res.json({
            success: true,
            availability,
            total_units: availability.length
        });
    }
    catch (error) {
        console.error('Error fetching isolation room availability:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch isolation room availability'
        });
    }
}));
/**
 * POST /api/bed-management/check-isolation
 * Check isolation requirements for a patient
 */
router.post('/check-isolation', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const data = IsolationCheckSchema.parse(req.body);
        const requirements = yield isolation_checker_1.default.checkIsolationRequirements(tenantId, data.patient_id);
        res.json({
            success: true,
            requirements
        });
    }
    catch (error) {
        console.error('Error checking isolation requirements:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to check isolation requirements'
        });
    }
}));
/**
 * POST /api/bed-management/validate-assignment
 * Validate a potential bed assignment
 */
router.post('/validate-assignment', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const data = BedValidationSchema.parse(req.body);
        const validation = yield isolation_checker_1.default.validateBedAssignment(tenantId, data.patient_id, data.bed_id);
        res.json({
            success: true,
            validation
        });
    }
    catch (error) {
        console.error('Error validating bed assignment:', error);
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({
                success: false,
                error: 'Invalid request data',
                details: error.issues
            });
        }
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to validate bed assignment'
        });
    }
}));
/**
 * POST /api/bed-management/clear-isolation/:patientId
 * Clear isolation status for a patient
 */
router.post('/clear-isolation/:patientId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        const patientId = parseInt(req.params.patientId);
        const { reason } = req.body;
        if (!reason) {
            return res.status(400).json({
                success: false,
                error: 'Reason is required to clear isolation'
            });
        }
        yield isolation_checker_1.default.clearIsolation(tenantId, patientId, userId, reason);
        res.json({
            success: true,
            message: 'Isolation cleared successfully'
        });
    }
    catch (error) {
        console.error('Error clearing isolation:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to clear isolation'
        });
    }
}));
exports.default = router;
