"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = require("../middleware/auth");
const billing_auth_1 = require("../middleware/billing-auth");
const database_1 = __importDefault(require("../database"));
const router = express_1.default.Router();
// Create tax configuration
router.post('/', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenant_id, tax_name, tax_rate, tax_type, applicable_services, effective_from, effective_to } = req.body;
        if (!tenant_id || !tax_name || tax_rate === undefined || !tax_type || !effective_from) {
            return res.status(400).json({
                error: 'Missing required fields',
                code: 'MISSING_REQUIRED_FIELDS'
            });
        }
        // Validate tax type
        const validTypes = ['percentage', 'fixed'];
        if (!validTypes.includes(tax_type)) {
            return res.status(400).json({
                error: `Invalid tax type. Valid types: ${validTypes.join(', ')}`,
                code: 'INVALID_TAX_TYPE'
            });
        }
        const result = yield database_1.default.query(`
      INSERT INTO tax_configurations (
        tenant_id, tax_name, tax_rate, tax_type,
        applicable_services, is_active, effective_from, effective_to
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `, [
            tenant_id,
            tax_name,
            tax_rate,
            tax_type,
            JSON.stringify(applicable_services || []),
            true,
            effective_from,
            effective_to || null
        ]);
        res.json({
            success: true,
            message: 'Tax configuration created successfully',
            tax_config: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error creating tax configuration:', error);
        res.status(500).json({
            error: error.message || 'Failed to create tax configuration',
            code: 'CREATE_TAX_CONFIG_ERROR'
        });
    }
}));
// Get all tax configurations for tenant
router.get('/', auth_1.hospitalAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { is_active, limit = 50, offset = 0 } = req.query;
        let query = 'SELECT * FROM tax_configurations WHERE tenant_id = $1';
        const params = [tenantId];
        let paramIndex = 2;
        if (is_active !== undefined) {
            query += ` AND is_active = $${paramIndex}`;
            params.push(is_active === 'true');
            paramIndex++;
        }
        query += ` ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
        params.push(parseInt(limit), parseInt(offset));
        const result = yield database_1.default.query(query, params);
        res.json({
            success: true,
            tax_configs: result.rows,
            pagination: {
                limit: parseInt(limit),
                offset: parseInt(offset),
                total: result.rows.length
            }
        });
    }
    catch (error) {
        console.error('Error fetching tax configurations:', error);
        res.status(500).json({
            error: error.message || 'Failed to fetch tax configurations',
            code: 'FETCH_TAX_CONFIGS_ERROR'
        });
    }
}));
// Get tax configuration by ID
router.get('/:configId', auth_1.hospitalAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { configId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const result = yield database_1.default.query('SELECT * FROM tax_configurations WHERE id = $1 AND tenant_id = $2', [configId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Tax configuration not found',
                code: 'TAX_CONFIG_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            tax_config: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error fetching tax configuration:', error);
        res.status(500).json({
            error: error.message || 'Failed to fetch tax configuration',
            code: 'FETCH_TAX_CONFIG_ERROR'
        });
    }
}));
// Update tax configuration
router.put('/:configId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { configId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const { tax_name, tax_rate, tax_type, applicable_services, is_active, effective_from, effective_to } = req.body;
        const result = yield database_1.default.query(`
      UPDATE tax_configurations
      SET tax_name = COALESCE($1, tax_name),
          tax_rate = COALESCE($2, tax_rate),
          tax_type = COALESCE($3, tax_type),
          applicable_services = COALESCE($4, applicable_services),
          is_active = COALESCE($5, is_active),
          effective_from = COALESCE($6, effective_from),
          effective_to = COALESCE($7, effective_to),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $8 AND tenant_id = $9
      RETURNING *
    `, [
            tax_name,
            tax_rate,
            tax_type,
            applicable_services ? JSON.stringify(applicable_services) : null,
            is_active,
            effective_from,
            effective_to,
            configId,
            tenantId
        ]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Tax configuration not found',
                code: 'TAX_CONFIG_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            message: 'Tax configuration updated successfully',
            tax_config: result.rows[0]
        });
    }
    catch (error) {
        console.error('Error updating tax configuration:', error);
        res.status(500).json({
            error: error.message || 'Failed to update tax configuration',
            code: 'UPDATE_TAX_CONFIG_ERROR'
        });
    }
}));
// Delete tax configuration
router.delete('/:configId', auth_1.hospitalAuthMiddleware, billing_auth_1.requireBillingAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { configId } = req.params;
        const tenantId = req.headers['x-tenant-id'];
        const result = yield database_1.default.query('DELETE FROM tax_configurations WHERE id = $1 AND tenant_id = $2 RETURNING id', [configId, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Tax configuration not found',
                code: 'TAX_CONFIG_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            message: 'Tax configuration deleted successfully'
        });
    }
    catch (error) {
        console.error('Error deleting tax configuration:', error);
        res.status(500).json({
            error: error.message || 'Failed to delete tax configuration',
            code: 'DELETE_TAX_CONFIG_ERROR'
        });
    }
}));
// Calculate tax for an amount
router.post('/calculate', auth_1.hospitalAuthMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { amount, service_type } = req.body;
        if (!amount) {
            return res.status(400).json({
                error: 'Amount is required',
                code: 'MISSING_AMOUNT'
            });
        }
        // Get active tax configurations for the tenant
        let query = `
      SELECT * FROM tax_configurations 
      WHERE tenant_id = $1 
        AND is_active = true
        AND effective_from <= CURRENT_DATE
        AND (effective_to IS NULL OR effective_to >= CURRENT_DATE)
    `;
        const params = [tenantId];
        const result = yield database_1.default.query(query, params);
        let totalTax = 0;
        const appliedTaxes = [];
        for (const config of result.rows) {
            // Check if tax applies to this service type
            const applicableServices = config.applicable_services || [];
            if (applicableServices.length > 0 && service_type && !applicableServices.includes(service_type)) {
                continue;
            }
            let taxAmount = 0;
            if (config.tax_type === 'percentage') {
                taxAmount = (parseFloat(amount) * parseFloat(config.tax_rate)) / 100;
            }
            else {
                taxAmount = parseFloat(config.tax_rate);
            }
            totalTax += taxAmount;
            appliedTaxes.push({
                tax_name: config.tax_name,
                tax_rate: config.tax_rate,
                tax_type: config.tax_type,
                tax_amount: taxAmount
            });
        }
        res.json({
            success: true,
            original_amount: parseFloat(amount),
            total_tax: totalTax,
            final_amount: parseFloat(amount) + totalTax,
            applied_taxes: appliedTaxes
        });
    }
    catch (error) {
        console.error('Error calculating tax:', error);
        res.status(500).json({
            error: error.message || 'Failed to calculate tax',
            code: 'CALCULATE_TAX_ERROR'
        });
    }
}));
exports.default = router;
