"use strict";
/**
 * Team Alpha - Audit Routes
 * API endpoints for audit trail system
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const audit_controller_1 = require("../controllers/audit.controller");
const router = express_1.default.Router();
// List audit logs with filters
router.get('/', audit_controller_1.listAuditLogs);
// Get audit statistics
router.get('/stats', audit_controller_1.getAuditStats);
// Export audit logs to CSV
router.get('/export', audit_controller_1.exportAuditLogsCSV);
// Get audit logs for a specific resource
router.get('/resource/:resourceType/:resourceId', audit_controller_1.getResourceAuditLog);
// Get a specific audit log
router.get('/:id', audit_controller_1.getAuditLog);
exports.default = router;
