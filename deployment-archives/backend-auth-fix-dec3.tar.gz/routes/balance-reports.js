"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = require("../middleware/auth");
const tenant_1 = require("../middleware/tenant");
const balance_reports_auth_1 = require("../middleware/balance-reports-auth");
const validate_balance_reports_1 = require("../middleware/validate-balance-reports");
const balance_reports_validation_1 = require("../validation/balance-reports.validation");
const profit_loss_report_service_1 = require("../services/profit-loss-report.service");
const balance_sheet_report_service_1 = require("../services/balance-sheet-report.service");
const cash_flow_report_service_1 = require("../services/cash-flow-report.service");
const balance_report_audit_service_1 = require("../services/balance-report-audit.service");
const report_cache_service_1 = require("../services/report-cache.service");
const database_1 = __importDefault(require("../database"));
/**
 * Balance Reports API Routes
 *
 * Provides endpoints for generating financial reports:
 * - Profit & Loss Statement
 * - Balance Sheet
 * - Cash Flow Statement
 * - Audit Logs
 *
 * All routes require authentication and appropriate permissions.
 */
const router = express_1.default.Router();
/**
 * GET /api/balance-reports/profit-loss
 *
 * Generate Profit & Loss report for a specified period
 *
 * Query Parameters:
 * - start_date (required): Start date (YYYY-MM-DD)
 * - end_date (required): End date (YYYY-MM-DD)
 * - department_id (optional): Filter by department
 * - enable_comparison (optional): Enable period comparison (true/false)
 * - comparison_type (optional): 'previous-period' or 'year-over-year'
 *
 * Permissions: billing:admin OR finance:read
 */
router.get('/profit-loss', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireBalanceReportAccess, (0, validate_balance_reports_1.validateQuery)(balance_reports_validation_1.ProfitLossQuerySchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const { start_date, end_date, department_id, enable_comparison, comparison_type } = req.query;
        // Validation is handled by middleware
        // Check cache first
        const cacheService = (0, report_cache_service_1.getReportCacheService)();
        const cacheKey = cacheService.generateCacheKey('profit-loss', tenantId, {
            start_date,
            end_date,
            department_id,
            enable_comparison,
            comparison_type
        });
        const cachedReport = cacheService.getCachedReport(cacheKey);
        if (cachedReport) {
            console.log('[Balance Reports] Returning cached Profit & Loss report');
            return res.json({
                success: true,
                report_type: 'profit_loss',
                report: cachedReport,
                generated_at: new Date().toISOString(),
                generated_by: userId,
                cached: true
            });
        }
        // Create audit log (non-blocking - don't fail if audit table doesn't exist)
        try {
            yield balance_report_audit_service_1.BalanceReportAuditService.createAuditLog(database_1.default, {
                tenant_id: tenantId,
                user_id: userId,
                report_type: 'profit_loss',
                action: 'generate',
                parameters: {
                    start_date,
                    end_date,
                    department_id,
                    enable_comparison,
                    comparison_type
                },
                timestamp: new Date(),
                ip_address: req.ip || req.socket.remoteAddress,
                user_agent: req.headers['user-agent']
            });
        }
        catch (auditError) {
            console.warn('[Balance Reports] Audit log creation failed (non-blocking):', auditError.message);
        }
        // Generate report
        const profitLossService = new profit_loss_report_service_1.ProfitLossReportService(database_1.default);
        const report = yield profitLossService.generateReport(tenantId, {
            start_date: start_date,
            end_date: end_date,
            department_id: department_id ? parseInt(department_id) : undefined,
            enable_comparison: enable_comparison === 'true',
            comparison_type: comparison_type
        });
        // Cache the report
        cacheService.cacheReport(cacheKey, report);
        // Check if report has data
        const hasData = report.revenue.total > 0 || report.expenses.total > 0;
        res.json({
            success: true,
            report_type: 'profit_loss',
            report,
            generated_at: new Date().toISOString(),
            generated_by: userId,
            cached: false,
            warnings: hasData ? [] : ['No financial data found for the specified period']
        });
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_b = req.user) === null || _b === void 0 ? void 0 : _b.id);
        console.error('[Balance Reports] Profit & Loss generation error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            userId,
            parameters: req.query
        });
        // Handle specific error types
        if ((_c = error.message) === null || _c === void 0 ? void 0 : _c.includes('date')) {
            return res.status(400).json({
                error: 'Invalid date range',
                code: 'INVALID_DATE_RANGE',
                message: error.message
            });
        }
        if ((_d = error.message) === null || _d === void 0 ? void 0 : _d.includes('department')) {
            return res.status(404).json({
                error: 'Department not found',
                code: 'DEPARTMENT_NOT_FOUND',
                message: error.message
            });
        }
        // Handle database errors (table doesn't exist, etc.) - return empty report
        if (((_e = error.message) === null || _e === void 0 ? void 0 : _e.includes('does not exist')) ||
            ((_f = error.message) === null || _f === void 0 ? void 0 : _f.includes('relation')) ||
            error.code === '42P01') {
            console.warn('[Balance Reports] Database table missing, returning empty report');
            const emptyReport = {
                reportType: 'profit-loss',
                period: {
                    startDate: req.query.start_date,
                    endDate: req.query.end_date
                },
                revenue: { consultations: 0, procedures: 0, medications: 0, labTests: 0, other: 0, total: 0 },
                expenses: { salaries: 0, supplies: 0, utilities: 0, maintenance: 0, other: 0, total: 0 },
                netProfitLoss: 0,
                generatedAt: new Date().toISOString(),
                generatedBy: userId
            };
            return res.json({
                success: true,
                report_type: 'profit_loss',
                report: emptyReport,
                generated_at: new Date().toISOString(),
                generated_by: userId,
                cached: false,
                warnings: ['No financial data available. Database tables may need to be initialized.']
            });
        }
        res.status(500).json({
            error: 'Failed to generate Profit & Loss report',
            code: 'PROFIT_LOSS_GENERATION_ERROR',
            message: error.message || 'An error occurred while generating the report',
            timestamp: new Date().toISOString()
        });
    }
}));
/**
 * GET /api/balance-reports/balance-sheet
 *
 * Generate Balance Sheet report as of a specified date
 *
 * Query Parameters:
 * - as_of_date (required): Report date (YYYY-MM-DD)
 * - department_id (optional): Filter by department
 * - enable_comparison (optional): Enable period comparison (true/false)
 * - comparison_date (optional): Comparison date (YYYY-MM-DD)
 *
 * Permissions: billing:admin OR finance:read
 */
router.get('/balance-sheet', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireBalanceReportAccess, (0, validate_balance_reports_1.validateQuery)(balance_reports_validation_1.BalanceSheetQuerySchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const { as_of_date, department_id, enable_comparison, comparison_date } = req.query;
        // Validation is handled by middleware
        // Create audit log (non-blocking - don't fail if audit table doesn't exist)
        try {
            yield balance_report_audit_service_1.BalanceReportAuditService.createAuditLog(database_1.default, {
                tenant_id: tenantId,
                user_id: userId,
                report_type: 'balance_sheet',
                action: 'generate',
                parameters: {
                    as_of_date,
                    department_id,
                    enable_comparison,
                    comparison_date
                },
                timestamp: new Date(),
                ip_address: req.ip || req.socket.remoteAddress,
                user_agent: req.headers['user-agent']
            });
        }
        catch (auditError) {
            console.warn('[Balance Reports] Audit log creation failed (non-blocking):', auditError.message);
        }
        // Generate report
        const balanceSheetService = new balance_sheet_report_service_1.BalanceSheetReportService(database_1.default);
        const report = yield balanceSheetService.generateReport(tenantId, {
            as_of_date: as_of_date,
            department_id: department_id ? parseInt(department_id) : undefined,
            enable_comparison: enable_comparison === 'true',
            comparison_date: comparison_date
        });
        // Check if report has data
        const hasData = report.assets.total > 0 || report.liabilities.total > 0;
        res.json({
            success: true,
            report_type: 'balance_sheet',
            report,
            generated_at: new Date().toISOString(),
            generated_by: userId,
            warnings: hasData ? [] : ['No financial data found for the specified date']
        });
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_b = req.user) === null || _b === void 0 ? void 0 : _b.id);
        console.error('[Balance Reports] Balance Sheet generation error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            userId,
            parameters: req.query
        });
        // Handle specific error types
        if ((_c = error.message) === null || _c === void 0 ? void 0 : _c.includes('date')) {
            return res.status(400).json({
                error: 'Invalid date',
                code: 'INVALID_DATE',
                message: error.message
            });
        }
        if ((_d = error.message) === null || _d === void 0 ? void 0 : _d.includes('department')) {
            return res.status(404).json({
                error: 'Department not found',
                code: 'DEPARTMENT_NOT_FOUND',
                message: error.message
            });
        }
        // Handle database errors (table doesn't exist, etc.) - return empty report
        if (((_e = error.message) === null || _e === void 0 ? void 0 : _e.includes('does not exist')) ||
            ((_f = error.message) === null || _f === void 0 ? void 0 : _f.includes('relation')) ||
            error.code === '42P01') {
            console.warn('[Balance Reports] Database table missing, returning empty balance sheet report');
            const emptyReport = {
                reportType: 'balance-sheet',
                asOfDate: req.query.as_of_date,
                assets: {
                    current: { cash: 0, accountsReceivable: 0, inventory: 0, total: 0 },
                    fixed: { equipment: 0, buildings: 0, land: 0, vehicles: 0, total: 0 },
                    total: 0
                },
                liabilities: {
                    current: { accountsPayable: 0, shortTermDebt: 0, accruedExpenses: 0, total: 0 },
                    longTerm: { longTermDebt: 0, mortgages: 0, total: 0 },
                    total: 0
                },
                equity: { retainedEarnings: 0, total: 0 },
                accountingEquationBalanced: true,
                generatedAt: new Date().toISOString(),
                generatedBy: userId
            };
            return res.json({
                success: true,
                report_type: 'balance_sheet',
                report: emptyReport,
                generated_at: new Date().toISOString(),
                generated_by: userId,
                warnings: ['No financial data available. Database tables may need to be initialized.']
            });
        }
        res.status(500).json({
            error: 'Failed to generate Balance Sheet report',
            code: 'BALANCE_SHEET_GENERATION_ERROR',
            message: error.message || 'An error occurred while generating the report',
            timestamp: new Date().toISOString()
        });
    }
}));
/**
 * GET /api/balance-reports/cash-flow
 *
 * Generate Cash Flow statement for a specified period
 *
 * Query Parameters:
 * - start_date (required): Start date (YYYY-MM-DD)
 * - end_date (required): End date (YYYY-MM-DD)
 * - department_id (optional): Filter by department
 * - enable_comparison (optional): Enable period comparison (true/false)
 * - comparison_type (optional): 'previous-period' or 'year-over-year'
 *
 * Permissions: billing:admin OR finance:read
 */
router.get('/cash-flow', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireBalanceReportAccess, (0, validate_balance_reports_1.validateQuery)(balance_reports_validation_1.CashFlowQuerySchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const { start_date, end_date, department_id, enable_comparison, comparison_type } = req.query;
        // Validation is handled by middleware
        // Create audit log (non-blocking - don't fail if audit table doesn't exist)
        try {
            yield balance_report_audit_service_1.BalanceReportAuditService.createAuditLog(database_1.default, {
                tenant_id: tenantId,
                user_id: userId,
                report_type: 'cash_flow',
                action: 'generate',
                parameters: {
                    start_date,
                    end_date,
                    department_id,
                    enable_comparison,
                    comparison_type
                },
                timestamp: new Date(),
                ip_address: req.ip || req.socket.remoteAddress,
                user_agent: req.headers['user-agent']
            });
        }
        catch (auditError) {
            console.warn('[Balance Reports] Audit log creation failed (non-blocking):', auditError.message);
        }
        // Generate report
        const cashFlowService = new cash_flow_report_service_1.CashFlowReportService(database_1.default);
        const report = yield cashFlowService.generateReport(tenantId, {
            start_date: start_date,
            end_date: end_date,
            department_id: department_id ? parseInt(department_id) : undefined,
            enable_comparison: enable_comparison === 'true',
            comparison_type: comparison_type
        });
        // Check if report has data
        const hasData = Math.abs(report.netCashFlow) > 0 ||
            Math.abs(report.operatingActivities.net) > 0 ||
            Math.abs(report.investingActivities.net) > 0 ||
            Math.abs(report.financingActivities.net) > 0;
        res.json({
            success: true,
            report_type: 'cash_flow',
            report,
            generated_at: new Date().toISOString(),
            generated_by: userId,
            warnings: hasData ? [] : ['No cash flow data found for the specified period']
        });
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_b = req.user) === null || _b === void 0 ? void 0 : _b.id);
        console.error('[Balance Reports] Cash Flow generation error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            userId,
            parameters: req.query
        });
        // Handle specific error types
        if ((_c = error.message) === null || _c === void 0 ? void 0 : _c.includes('date')) {
            return res.status(400).json({
                error: 'Invalid date range',
                code: 'INVALID_DATE_RANGE',
                message: error.message
            });
        }
        if ((_d = error.message) === null || _d === void 0 ? void 0 : _d.includes('department')) {
            return res.status(404).json({
                error: 'Department not found',
                code: 'DEPARTMENT_NOT_FOUND',
                message: error.message
            });
        }
        // Handle database errors (table doesn't exist, etc.) - return empty report
        if (((_e = error.message) === null || _e === void 0 ? void 0 : _e.includes('does not exist')) ||
            ((_f = error.message) === null || _f === void 0 ? void 0 : _f.includes('relation')) ||
            error.code === '42P01') {
            console.warn('[Balance Reports] Database table missing, returning empty cash flow report');
            const emptyReport = {
                reportType: 'cash-flow',
                period: {
                    startDate: req.query.start_date,
                    endDate: req.query.end_date
                },
                operatingActivities: {
                    inflows: { patientPayments: 0, insuranceReimbursements: 0, other: 0, total: 0 },
                    outflows: { salaries: 0, supplies: 0, utilities: 0, equipmentPurchases: 0, loanRepayments: 0, other: 0, total: 0 },
                    net: 0
                },
                investingActivities: {
                    inflows: { patientPayments: 0, insuranceReimbursements: 0, other: 0, total: 0 },
                    outflows: { salaries: 0, supplies: 0, utilities: 0, equipmentPurchases: 0, loanRepayments: 0, other: 0, total: 0 },
                    net: 0
                },
                financingActivities: {
                    inflows: { patientPayments: 0, insuranceReimbursements: 0, other: 0, total: 0 },
                    outflows: { salaries: 0, supplies: 0, utilities: 0, equipmentPurchases: 0, loanRepayments: 0, other: 0, total: 0 },
                    net: 0
                },
                netCashFlow: 0,
                beginningCash: 0,
                endingCash: 0,
                generatedAt: new Date().toISOString(),
                generatedBy: userId
            };
            return res.json({
                success: true,
                report_type: 'cash_flow',
                report: emptyReport,
                generated_at: new Date().toISOString(),
                generated_by: userId,
                warnings: ['No financial data available. Database tables may need to be initialized.']
            });
        }
        res.status(500).json({
            error: 'Failed to generate Cash Flow report',
            code: 'CASH_FLOW_GENERATION_ERROR',
            message: error.message || 'An error occurred while generating the report',
            timestamp: new Date().toISOString()
        });
    }
}));
/**
 * GET /api/balance-reports/audit-logs
 *
 * Retrieve audit logs for balance report access
 *
 * Query Parameters:
 * - user_id (optional): Filter by user
 * - report_type (optional): Filter by report type
 * - action (optional): Filter by action
 * - start_date (optional): Filter by start date
 * - end_date (optional): Filter by end date
 * - page (optional): Page number (default: 1)
 * - limit (optional): Items per page (default: 50)
 *
 * Permissions: billing:admin OR finance:read
 */
router.get('/audit-logs', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireBalanceReportAccess, (0, validate_balance_reports_1.validateQuery)(balance_reports_validation_1.AuditLogsQuerySchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { user_id, report_type, action, start_date, end_date, page, limit } = req.query;
        // Get audit logs
        const result = yield balance_report_audit_service_1.BalanceReportAuditService.getAuditLogs(database_1.default, tenantId, {
            user_id: user_id,
            report_type: report_type,
            action: action,
            start_date: start_date,
            end_date: end_date,
            page: page ? parseInt(page) : 1,
            limit: limit ? parseInt(limit) : 50
        });
        res.json(Object.assign(Object.assign({ success: true }, result), { warnings: result.logs.length === 0 ? ['No audit logs found for the specified criteria'] : [] }));
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        console.error('[Balance Reports] Audit logs retrieval error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            parameters: req.query
        });
        res.status(500).json({
            error: 'Failed to retrieve audit logs',
            code: 'AUDIT_LOGS_RETRIEVAL_ERROR',
            message: error.message || 'An error occurred while retrieving audit logs',
            timestamp: new Date().toISOString()
        });
    }
}));
/**
 * GET /api/balance-reports/audit-statistics
 *
 * Get audit log statistics for a tenant
 *
 * Query Parameters:
 * - start_date (optional): Filter by start date
 * - end_date (optional): Filter by end date
 *
 * Permissions: billing:admin OR finance:read
 */
router.get('/audit-statistics', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireBalanceReportAccess, (0, validate_balance_reports_1.validateQuery)(balance_reports_validation_1.AuditStatisticsQuerySchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { start_date, end_date } = req.query;
        // Get statistics
        const stats = yield balance_report_audit_service_1.BalanceReportAuditService.getAuditStatistics(database_1.default, tenantId, start_date, end_date);
        res.json({
            success: true,
            statistics: stats
        });
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        console.error('[Balance Reports] Audit statistics error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            parameters: req.query
        });
        res.status(500).json({
            error: 'Failed to retrieve audit statistics',
            code: 'AUDIT_STATISTICS_ERROR',
            message: error.message || 'An error occurred while retrieving statistics',
            timestamp: new Date().toISOString()
        });
    }
}));
/**
 * POST /api/balance-reports/export
 *
 * Export a balance report to CSV, Excel, or PDF
 *
 * Body Parameters:
 * - report_type (required): 'profit_loss', 'balance_sheet', or 'cash_flow'
 * - format (required): 'csv', 'excel', or 'pdf'
 * - report_data (required): The report data to export
 *
 * Permissions: billing:admin ONLY (finance:read cannot export)
 */
router.post('/export', auth_1.hospitalAuthMiddleware, tenant_1.tenantMiddleware, balance_reports_auth_1.requireExportPermission, (0, validate_balance_reports_1.validateBody)(balance_reports_validation_1.ExportRequestSchema), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id);
        const { report_type, format, report_data } = req.body;
        // Validation is handled by middleware
        // Create audit log for export (non-blocking)
        try {
            yield balance_report_audit_service_1.BalanceReportAuditService.createAuditLog(database_1.default, {
                tenant_id: tenantId,
                user_id: userId,
                report_type: report_type,
                action: 'export',
                parameters: {
                    format,
                    report_type
                },
                timestamp: new Date(),
                ip_address: req.ip || req.socket.remoteAddress,
                user_agent: req.headers['user-agent']
            });
        }
        catch (auditError) {
            console.warn('[Balance Reports] Export audit log creation failed (non-blocking):', auditError.message);
        }
        // Map report_type to export service format
        const exportReportType = report_type === 'profit_loss' ? 'profit-loss'
            : report_type === 'balance_sheet' ? 'balance-sheet'
                : 'cash-flow';
        let fileBuffer;
        let contentType;
        let filename;
        // Get date range for filename
        const startDate = ((_b = report_data.period) === null || _b === void 0 ? void 0 : _b.startDate) || report_data.asOfDate;
        const endDate = ((_c = report_data.period) === null || _c === void 0 ? void 0 : _c.endDate) || report_data.asOfDate;
        // Import export services dynamically to avoid circular dependencies
        const { CSVExportService } = yield Promise.resolve().then(() => __importStar(require('../services/export/csv-export.service')));
        const { ExcelExportService } = yield Promise.resolve().then(() => __importStar(require('../services/export/excel-export.service')));
        const { PDFExportService } = yield Promise.resolve().then(() => __importStar(require('../services/export/pdf-export.service')));
        switch (format) {
            case 'csv':
                fileBuffer = CSVExportService.exportToCSV(report_data, exportReportType);
                contentType = 'text/csv; charset=utf-8';
                filename = CSVExportService.getFilename(exportReportType, startDate, endDate);
                // Add UTF-8 BOM for Excel compatibility
                fileBuffer = '\uFEFF' + fileBuffer;
                break;
            case 'excel':
                fileBuffer = ExcelExportService.exportToExcel(report_data, exportReportType);
                contentType = ExcelExportService.getContentType();
                filename = ExcelExportService.getFilename(exportReportType, startDate, endDate);
                break;
            case 'pdf':
                fileBuffer = PDFExportService.exportToPDF(report_data, exportReportType);
                contentType = PDFExportService.getHTMLContentType();
                filename = PDFExportService.getFilename(exportReportType, startDate, endDate);
                break;
            default:
                return res.status(400).json({
                    error: 'Invalid export format',
                    code: 'INVALID_EXPORT_FORMAT',
                    message: `Unsupported format: ${format}. Supported formats: csv, excel, pdf`
                });
        }
        // Set response headers for file download
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('X-Export-Format', format);
        res.setHeader('X-Report-Type', report_type);
        // Send the file
        res.send(fileBuffer);
    }
    catch (error) {
        const tenantId = req.headers['x-tenant-id'];
        const userId = req.userId || ((_d = req.user) === null || _d === void 0 ? void 0 : _d.id);
        console.error('[Balance Reports] Export error:', {
            error: error.message,
            stack: error.stack,
            tenantId,
            userId,
            parameters: req.body
        });
        // Handle specific error types
        if ((_e = error.message) === null || _e === void 0 ? void 0 : _e.includes('format')) {
            return res.status(400).json({
                error: 'Invalid export format',
                code: 'INVALID_EXPORT_FORMAT',
                message: error.message
            });
        }
        if ((_f = error.message) === null || _f === void 0 ? void 0 : _f.includes('report_data')) {
            return res.status(400).json({
                error: 'Invalid report data',
                code: 'INVALID_REPORT_DATA',
                message: error.message
            });
        }
        res.status(500).json({
            error: 'Failed to export report',
            code: 'EXPORT_ERROR',
            message: error.message || 'An error occurred while exporting the report',
            timestamp: new Date().toISOString(),
            retry: true
        });
    }
}));
exports.default = router;
