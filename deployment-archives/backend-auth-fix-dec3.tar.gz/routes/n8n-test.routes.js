"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkN8NStatus = exports.testOPDAgent = exports.testN8NAgent = void 0;
const express_1 = __importDefault(require("express"));
const axios_1 = __importDefault(require("axios"));
const errorHandler_1 = require("../middleware/errorHandler");
const router = express_1.default.Router();
/**
 * POST /api/n8n/test-agent
 * Universal endpoint to test any n8n agent (OPD, Ward, Emergency)
 */
exports.testN8NAgent = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g;
    const { chatInput, sessionId, agentPath } = req.body;
    if (!chatInput || !sessionId || !agentPath) {
        return res.status(400).json({
            success: false,
            error: 'Missing required fields: chatInput, sessionId, agentPath'
        });
    }
    try {
        // Get n8n configuration from environment
        const n8nBaseUrl = process.env.N8N_BASE_URL;
        const n8nAuthHeader = process.env.N8N_WEBHOOK_AUTH_HEADER || 'Authorization';
        const n8nAuthToken = process.env.N8N_WEBHOOK_AUTH_TOKEN;
        // Validate configuration
        if (!n8nBaseUrl || !n8nAuthToken) {
            console.error('n8n configuration missing:', {
                baseUrl: !!n8nBaseUrl,
                authToken: !!n8nAuthToken
            });
            return res.status(500).json({
                success: false,
                error: 'n8n configuration not properly set up',
                debug: {
                    baseUrl: !!n8nBaseUrl,
                    authToken: !!n8nAuthToken
                }
            });
        }
        // Construct full webhook URL with provided agent path
        const webhookUrl = `${n8nBaseUrl}/webhook/${agentPath}`;
        console.log('Testing n8n Agent:', {
            url: webhookUrl,
            agentPath: agentPath,
            sessionId: sessionId,
            messageLength: chatInput.length
        });
        // Call n8n webhook
        const response = yield axios_1.default.post(webhookUrl, {
            chatInput: chatInput,
            sessionId: sessionId
        }, {
            headers: {
                [n8nAuthHeader]: n8nAuthToken,
                'Content-Type': 'application/json'
            },
            timeout: parseInt(process.env.N8N_SESSION_TIMEOUT || '60000')
        });
        console.log('n8n Agent response received:', {
            agentPath: agentPath,
            status: response.status,
            hasOutput: !!response.data.output,
            hasText: !!response.data.text
        });
        // Return response
        res.json({
            success: true,
            data: {
                output: response.data.output || response.data.text || 'No response from AI agent',
                sessionId: sessionId,
                agentPath: agentPath,
                timestamp: new Date().toISOString()
            }
        });
    }
    catch (error) {
        console.error('n8n Agent test failed:', {
            agentPath: agentPath,
            error: error.message,
            status: (_a = error.response) === null || _a === void 0 ? void 0 : _a.status,
            statusText: (_b = error.response) === null || _b === void 0 ? void 0 : _b.statusText,
            data: (_c = error.response) === null || _c === void 0 ? void 0 : _c.data
        });
        // Determine error type
        let errorMessage = `Failed to connect to n8n agent (${agentPath})`;
        let errorCode = 'N8N_CONNECTION_ERROR';
        if (((_d = error.response) === null || _d === void 0 ? void 0 : _d.status) === 401) {
            errorMessage = 'Authentication failed - check n8n token';
            errorCode = 'N8N_AUTH_ERROR';
        }
        else if (((_e = error.response) === null || _e === void 0 ? void 0 : _e.status) === 404) {
            errorMessage = 'n8n webhook not found - check webhook path';
            errorCode = 'N8N_NOT_FOUND';
        }
        else if (error.code === 'ECONNREFUSED') {
            errorMessage = 'Cannot connect to n8n instance - check N8N_BASE_URL';
            errorCode = 'N8N_CONNECTION_REFUSED';
        }
        else if (error.code === 'ETIMEDOUT') {
            errorMessage = 'n8n request timeout - server may be slow';
            errorCode = 'N8N_TIMEOUT';
        }
        res.status(((_f = error.response) === null || _f === void 0 ? void 0 : _f.status) || 500).json({
            success: false,
            error: errorMessage,
            code: errorCode,
            debug: {
                message: error.message,
                status: (_g = error.response) === null || _g === void 0 ? void 0 : _g.status,
                agentPath: agentPath,
                url: `${process.env.N8N_BASE_URL}/webhook/${agentPath}`
            }
        });
    }
}));
/**
 * POST /api/n8n/test-opd (Legacy - kept for backward compatibility)
 */
exports.testOPDAgent = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { chatInput, sessionId } = req.body;
    if (!chatInput || !sessionId) {
        return res.status(400).json({
            success: false,
            error: 'Missing required fields: chatInput, sessionId'
        });
    }
    // Use OPD agent path from environment
    req.body.agentPath = process.env.N8N_OPD_AGENT_PATH;
    // Call the universal agent handler
    const handler = exports.testN8NAgent;
    return handler(req, res);
}));
/**
 * GET /api/n8n/test-status
 * Check n8n configuration status
 */
exports.checkN8NStatus = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const n8nBaseUrl = process.env.N8N_BASE_URL;
    const n8nAuthToken = process.env.N8N_WEBHOOK_AUTH_TOKEN;
    const n8nOPDPath = process.env.N8N_OPD_AGENT_PATH;
    const n8nWardPath = process.env.N8N_WARD_AGENT_PATH;
    const n8nEmergencyPath = process.env.N8N_EMERGENCY_AGENT_PATH;
    res.json({
        success: true,
        data: {
            configured: {
                baseUrl: !!n8nBaseUrl,
                authToken: !!n8nAuthToken,
                opdPath: !!n8nOPDPath,
                wardPath: !!n8nWardPath,
                emergencyPath: !!n8nEmergencyPath
            },
            urls: {
                opd: n8nBaseUrl && n8nOPDPath ? `${n8nBaseUrl}/webhook/${n8nOPDPath}` : 'Not configured',
                ward: n8nBaseUrl && n8nWardPath ? `${n8nBaseUrl}/webhook/${n8nWardPath}` : 'Not configured',
                emergency: n8nBaseUrl && n8nEmergencyPath ? `${n8nBaseUrl}/webhook/${n8nEmergencyPath}` : 'Not configured'
            },
            timestamp: new Date().toISOString()
        }
    });
}));
// Routes
router.post('/test-agent', exports.testN8NAgent); // Universal agent endpoint
router.post('/test-opd', exports.testOPDAgent); // Legacy endpoint (backward compatibility)
router.get('/test-status', exports.checkN8NStatus);
exports.default = router;
