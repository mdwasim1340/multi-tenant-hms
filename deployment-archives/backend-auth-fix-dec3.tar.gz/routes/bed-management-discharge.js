"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const discharge_readiness_predictor_1 = require("../services/discharge-readiness-predictor");
const ai_feature_manager_1 = require("../services/ai-feature-manager");
/**
 * Discharge Readiness API Routes
 *
 * Provides endpoints for discharge planning and readiness prediction.
 *
 * Requirements: 3.1, 3.2, 3.3, 17.1, 17.2, 17.4, 17.5
 */
const router = express_1.default.Router();
/**
 * GET /api/bed-management/discharge-readiness/:patientId
 * Get discharge readiness prediction for a patient
 * Requirements: 3.1, 3.2, 3.3
 */
router.get('/discharge-readiness/:patientId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        const admissionId = parseInt(req.query.admissionId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId) || isNaN(admissionId)) {
            return res.status(400).json({ error: 'Invalid patient ID or admission ID' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'discharge_readiness');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Discharge readiness prediction is not enabled for this tenant',
                feature: 'discharge_readiness'
            });
        }
        const prediction = yield discharge_readiness_predictor_1.dischargeReadinessPredictor.predictDischargeReadiness(tenantId, patientId, admissionId);
        res.json({
            success: true,
            data: prediction
        });
    }
    catch (error) {
        console.error('Error predicting discharge readiness:', error);
        res.status(500).json({
            error: 'Failed to predict discharge readiness',
            message: error.message
        });
    }
}));
/**
 * GET /api/bed-management/discharge-ready-patients
 * Get list of patients ready for discharge
 * Requirements: 3.1, 17.2
 */
router.get('/discharge-ready-patients', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const minScore = parseInt(req.query.minScore) || 80;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'discharge_readiness');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Discharge readiness prediction is not enabled for this tenant',
                feature: 'discharge_readiness'
            });
        }
        const patients = yield discharge_readiness_predictor_1.dischargeReadinessPredictor.getDischargeReadyPatients(tenantId, minScore);
        res.json({
            success: true,
            data: patients,
            count: patients.length
        });
    }
    catch (error) {
        console.error('Error getting discharge-ready patients:', error);
        res.status(500).json({
            error: 'Failed to get discharge-ready patients',
            message: error.message
        });
    }
}));
/**
 * POST /api/bed-management/discharge-barriers/:admissionId
 * Update barrier status for an admission
 * Requirements: 3.4, 17.3
 */
router.post('/discharge-barriers/:admissionId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const admissionId = parseInt(req.params.admissionId);
        const { barrierId, resolved } = req.body;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(admissionId)) {
            return res.status(400).json({ error: 'Invalid admission ID' });
        }
        if (!barrierId || typeof resolved !== 'boolean') {
            return res.status(400).json({
                error: 'barrierId and resolved (boolean) are required'
            });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'discharge_readiness');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Discharge readiness prediction is not enabled for this tenant',
                feature: 'discharge_readiness'
            });
        }
        yield discharge_readiness_predictor_1.dischargeReadinessPredictor.updateBarrierStatus(tenantId, admissionId, barrierId, resolved);
        res.json({
            success: true,
            message: 'Barrier status updated successfully'
        });
    }
    catch (error) {
        console.error('Error updating barrier status:', error);
        res.status(500).json({
            error: 'Failed to update barrier status',
            message: error.message
        });
    }
}));
/**
 * GET /api/bed-management/discharge-metrics
 * Get discharge performance metrics
 * Requirements: 17.4, 17.5
 */
router.get('/discharge-metrics', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'discharge_readiness');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Discharge readiness prediction is not enabled for this tenant',
                feature: 'discharge_readiness'
            });
        }
        const metrics = yield discharge_readiness_predictor_1.dischargeReadinessPredictor.getDischargeMetrics(tenantId, startDate, endDate);
        res.json({
            success: true,
            data: metrics,
            period: {
                start: startDate,
                end: endDate
            }
        });
    }
    catch (error) {
        console.error('Error getting discharge metrics:', error);
        res.status(500).json({
            error: 'Failed to get discharge metrics',
            message: error.message
        });
    }
}));
/**
 * POST /api/bed-management/batch-discharge-predictions
 * Generate discharge predictions for multiple patients
 * Requirements: 3.1, 17.1
 */
router.post('/batch-discharge-predictions', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const { admissions } = req.body;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!Array.isArray(admissions) || admissions.length === 0) {
            return res.status(400).json({
                error: 'admissions array is required and must not be empty'
            });
        }
        // Check if feature is enabled
        const featureEnabled = yield ai_feature_manager_1.aiFeatureManager.isFeatureEnabled(tenantId, 'discharge_readiness');
        if (!featureEnabled) {
            return res.status(403).json({
                error: 'Discharge readiness prediction is not enabled for this tenant',
                feature: 'discharge_readiness'
            });
        }
        const predictions = [];
        const errors = [];
        for (const admission of admissions) {
            try {
                const prediction = yield discharge_readiness_predictor_1.dischargeReadinessPredictor.predictDischargeReadiness(tenantId, admission.patientId, admission.admissionId);
                predictions.push(prediction);
            }
            catch (error) {
                errors.push({
                    admissionId: admission.admissionId,
                    error: error.message
                });
            }
        }
        res.json({
            success: true,
            data: predictions,
            errors: errors.length > 0 ? errors : undefined,
            summary: {
                total: admissions.length,
                successful: predictions.length,
                failed: errors.length
            }
        });
    }
    catch (error) {
        console.error('Error generating batch discharge predictions:', error);
        res.status(500).json({
            error: 'Failed to generate batch discharge predictions',
            message: error.message
        });
    }
}));
exports.default = router;
