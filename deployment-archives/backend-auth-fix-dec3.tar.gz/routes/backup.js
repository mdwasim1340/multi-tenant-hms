"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const backup_1 = require("../services/backup");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../database"));
const router = express_1.default.Router();
// Helper function to check if user has access to tenant data
const checkTenantAccess = (req, tenantId) => {
    var _a, _b, _c, _d;
    const userTenantId = req.headers['x-tenant-id'];
    // Allow admin users to access any tenant's data
    const isAdmin = userTenantId === 'admin' ||
        ((_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a.email) === null || _b === void 0 ? void 0 : _b.includes('admin')) ||
        ((_d = (_c = req.user) === null || _c === void 0 ? void 0 : _c['cognito:groups']) === null || _d === void 0 ? void 0 : _d.includes('admin'));
    return !userTenantId || userTenantId === tenantId || isAdmin;
};
// Create manual backup
router.post('/create', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenant_id, backup_type = 'full', storage_tier = 's3_standard' } = req.body;
        if (!tenant_id) {
            return res.status(400).json({
                error: 'tenant_id is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenant_id)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        // Verify tenant exists
        const tenantResult = yield database_1.default.query('SELECT id FROM tenants WHERE id = $1', [tenant_id]);
        if (!tenantResult.rows.length) {
            return res.status(404).json({
                error: 'Tenant not found',
                code: 'TENANT_NOT_FOUND'
            });
        }
        const job = yield backup_1.backupService.createBackup({
            tenantId: tenant_id,
            backupType: backup_type,
            storageTier: storage_tier
        });
        res.json({
            success: true,
            message: 'Backup job created successfully',
            job
        });
    }
    catch (error) {
        console.error('Error creating backup:', error);
        res.status(500).json({
            error: 'Failed to create backup',
            code: 'CREATE_BACKUP_ERROR'
        });
    }
}));
// Get backup history for tenant
router.get('/tenant/:tenantId', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const { limit = 50 } = req.query;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const backups = yield backup_1.backupService.getBackupHistory(tenantId, parseInt(limit));
        res.json({
            success: true,
            backups
        });
    }
    catch (error) {
        console.error('Error fetching backup history:', error);
        res.status(500).json({
            error: 'Failed to fetch backup history',
            code: 'FETCH_BACKUPS_ERROR'
        });
    }
}));
// Get backup statistics for tenant
router.get('/tenant/:tenantId/stats', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const stats = yield backup_1.backupService.getBackupStats(tenantId);
        res.json({
            success: true,
            stats
        });
    }
    catch (error) {
        console.error('Error fetching backup stats:', error);
        res.status(500).json({
            error: 'Failed to fetch backup statistics',
            code: 'FETCH_STATS_ERROR'
        });
    }
}));
// Get backup schedules for tenant
router.get('/tenant/:tenantId/schedules', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const schedules = yield backup_1.backupService.getBackupSchedules(tenantId);
        res.json({
            success: true,
            schedules
        });
    }
    catch (error) {
        console.error('Error fetching backup schedules:', error);
        res.status(500).json({
            error: 'Failed to fetch backup schedules',
            code: 'FETCH_SCHEDULES_ERROR'
        });
    }
}));
// Setup backup schedules for tenant (admin only)
router.post('/tenant/:tenantId/setup-schedules', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const { tier_id } = req.body;
        // Verify user has access to this tenant
        if (!checkTenantAccess(req, tenantId)) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        if (!tier_id) {
            return res.status(400).json({
                error: 'tier_id is required',
                code: 'MISSING_TIER_ID'
            });
        }
        yield backup_1.backupService.setupBackupSchedules(tenantId, tier_id);
        res.json({
            success: true,
            message: 'Backup schedules set up successfully'
        });
    }
    catch (error) {
        console.error('Error setting up backup schedules:', error);
        res.status(500).json({
            error: 'Failed to set up backup schedules',
            code: 'SETUP_SCHEDULES_ERROR'
        });
    }
}));
// Process scheduled backups (internal endpoint)
router.post('/process-scheduled', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // In production, add admin role check here
        yield backup_1.backupService.processScheduledBackups();
        res.json({
            success: true,
            message: 'Scheduled backups processed successfully'
        });
    }
    catch (error) {
        console.error('Error processing scheduled backups:', error);
        res.status(500).json({
            error: 'Failed to process scheduled backups',
            code: 'PROCESS_SCHEDULED_ERROR'
        });
    }
}));
// Get all tenants backup summary (admin only)
router.get('/admin/summary', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // In production, add admin role check here
        const summary = yield backup_1.backupService.getAllTenantsBackupSummary();
        res.json({
            success: true,
            summary
        });
    }
    catch (error) {
        console.error('Error fetching admin backup summary:', error);
        res.status(500).json({
            error: 'Failed to fetch backup summary',
            code: 'FETCH_ADMIN_SUMMARY_ERROR'
        });
    }
}));
// Get backup retention policies
router.get('/retention-policies', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const result = yield database_1.default.query(`
      SELECT brp.*, st.name as tier_name, st.price as tier_price
      FROM backup_retention_policies brp
      JOIN subscription_tiers st ON brp.tier_id = st.id
      ORDER BY st.display_order
    `);
        res.json({
            success: true,
            policies: result.rows
        });
    }
    catch (error) {
        console.error('Error fetching retention policies:', error);
        res.status(500).json({
            error: 'Failed to fetch retention policies',
            code: 'FETCH_POLICIES_ERROR'
        });
    }
}));
exports.default = router;
