"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const imaging_controller_1 = require("../controllers/imaging.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// POST /api/imaging - Order imaging study (requires write permission)
router.post('/', (0, authorization_1.requirePermission)('patients', 'write'), imaging_controller_1.createImagingStudy);
// GET /api/imaging/:id - Get imaging study by ID (requires read permission)
router.get('/:id', (0, authorization_1.requirePermission)('patients', 'read'), imaging_controller_1.getImagingStudyById);
exports.default = router;
