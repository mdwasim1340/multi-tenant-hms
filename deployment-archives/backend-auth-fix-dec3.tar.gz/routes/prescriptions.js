"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPrescriptionsRouter = void 0;
const express_1 = require("express");
const prescription_controller_1 = require("../controllers/prescription.controller");
const createPrescriptionsRouter = () => {
    const router = (0, express_1.Router)();
    // Prescription CRUD
    router.post('/', prescription_controller_1.createPrescription);
    router.get('/', prescription_controller_1.getPrescriptions);
    router.get('/:id', prescription_controller_1.getPrescription);
    router.put('/:id', prescription_controller_1.updatePrescription);
    router.delete('/:id', prescription_controller_1.deletePrescription);
    // Get prescriptions by patient
    router.get('/patient/:patientId', prescription_controller_1.getPatientPrescriptions);
    // Discontinue prescription
    router.post('/:id/discontinue', prescription_controller_1.discontinuePrescription);
    // Process refill
    router.post('/:id/refill', prescription_controller_1.processRefill);
    // Check drug interactions
    router.get('/patient/:patientId/interactions', prescription_controller_1.checkDrugInteractions);
    // Update expired prescriptions (maintenance endpoint)
    router.post('/maintenance/update-expired', prescription_controller_1.updateExpiredPrescriptions);
    return router;
};
exports.createPrescriptionsRouter = createPrescriptionsRouter;
