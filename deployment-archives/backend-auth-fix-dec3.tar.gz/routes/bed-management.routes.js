"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bedController = __importStar(require("../controllers/bed.controller"));
const assignmentController = __importStar(require("../controllers/bed-assignment.controller"));
const transferController = __importStar(require("../controllers/bed-transfer.controller"));
const departmentController = __importStar(require("../controllers/department.controller"));
const bed_categories_controller_1 = require("../controllers/bed-categories.controller");
const database_1 = __importDefault(require("../database"));
const router = express_1.default.Router();
const bedCategoriesController = new bed_categories_controller_1.BedCategoriesController(database_1.default);
// ==========================================
// ALL SPECIFIC ROUTES MUST COME BEFORE PARAMETERIZED ROUTES
// ==========================================
// Bed Assignment Routes - /api/beds/assignments
router.get('/assignments', assignmentController.getBedAssignments);
router.post('/assignments', assignmentController.createBedAssignment);
router.get('/assignments/:id', assignmentController.getBedAssignmentById);
router.put('/assignments/:id', assignmentController.updateBedAssignment);
router.post('/assignments/:id/discharge', assignmentController.dischargeBedAssignment);
router.get('/assignments/patient/:patientId', assignmentController.getPatientBedHistory);
router.get('/assignments/bed/:bedId', assignmentController.getBedAssignmentHistory);
// Bed Transfer Routes - /api/beds/transfers
router.get('/transfers', transferController.getBedTransfers);
router.post('/transfers', transferController.createBedTransfer);
router.get('/transfers/:id', transferController.getBedTransferById);
router.post('/transfers/:id/complete', transferController.completeBedTransfer);
router.post('/transfers/:id/cancel', transferController.cancelBedTransfer);
router.get('/transfers/patient/:patientId/history', transferController.getPatientTransferHistory);
// Department Routes - /api/beds/departments  
router.get('/departments', departmentController.getDepartments);
router.post('/departments', departmentController.createDepartment);
router.get('/departments/:id', departmentController.getDepartmentById);
router.put('/departments/:id', departmentController.updateDepartment);
router.get('/departments/:id/stats', departmentController.getDepartmentStats);
// Bed Categories Routes - /api/beds/categories
router.get('/categories', bedCategoriesController.getCategories.bind(bedCategoriesController));
router.post('/categories', bedCategoriesController.createCategory.bind(bedCategoriesController));
router.get('/categories/:id', bedCategoriesController.getCategoryById.bind(bedCategoriesController));
router.put('/categories/:id', bedCategoriesController.updateCategory.bind(bedCategoriesController));
router.delete('/categories/:id', bedCategoriesController.deleteCategory.bind(bedCategoriesController));
router.get('/categories/:id/beds', bedCategoriesController.getBedsByCategory.bind(bedCategoriesController));
// Bed Routes - Specific routes first
router.get('/', bedController.getBeds);
router.post('/', bedController.createBed);
router.get('/occupancy', bedController.getBedOccupancy);
router.get('/availability', bedController.getAvailableBeds);
// PARAMETERIZED ROUTES MUST BE LAST
router.get('/:id', bedController.getBedById);
router.put('/:id', bedController.updateBed);
router.delete('/:id', bedController.deleteBed);
exports.default = router;
