"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const lab_panel_controller_1 = require("../controllers/lab-panel.controller");
const authorization_1 = require("../middleware/authorization");
const router = express_1.default.Router();
// GET /api/lab-panels - List lab panels (requires read permission)
router.get('/', (0, authorization_1.requirePermission)('patients', 'read'), lab_panel_controller_1.getLabPanels);
// GET /api/lab-panels/:id - Get lab panel by ID (requires read permission)
router.get('/:id', (0, authorization_1.requirePermission)('patients', 'read'), lab_panel_controller_1.getLabPanelById);
exports.default = router;
