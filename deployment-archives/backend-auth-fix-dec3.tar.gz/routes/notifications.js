"use strict";
/**
 * Notification Routes
 * Team: Epsilon
 * Purpose: API endpoints for notification management
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const notification_1 = require("../services/notification");
const notification_broadcaster_1 = require("../services/notification-broadcaster");
const notification_delivery_1 = require("../services/notification-delivery");
const notification_sse_1 = require("../services/notification-sse");
const notification_2 = require("../types/notification");
const zod_1 = require("zod");
const router = (0, express_1.Router)();
/**
 * Helper function to handle Zod validation errors
 */
function handleValidationError(error, res) {
    return res.status(400).json({
        error: 'Validation error',
        details: error.issues.map((err) => ({
            field: err.path.join('.'),
            message: err.message,
        })),
    });
}
/**
 * Helper function to get user ID from request
 */
function getUserId(req) {
    var _a;
    // Assuming auth middleware sets req.user
    return ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 0;
}
/**
 * Helper function to get tenant ID from request
 */
function getTenantId(req) {
    return req.headers['x-tenant-id'];
}
// ============================================================================
// Notification Management Endpoints
// ============================================================================
/**
 * GET /api/notifications
 * List notifications with filters and pagination
 */
router.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        // Validate query parameters
        const query = notification_2.ListNotificationsQuerySchema.parse(req.query);
        // Get notifications
        const result = yield notification_1.NotificationService.listNotifications(tenantId, userId, query);
        res.json(result);
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error listing notifications:', error);
        res.status(500).json({ error: 'Failed to list notifications' });
    }
}));
/**
 * POST /api/notifications
 * Create a new notification and deliver via all channels
 */
router.post('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        // Validate request body
        const data = notification_2.CreateNotificationSchema.parse(req.body);
        // Set created_by to current user if not provided
        if (!data.created_by) {
            data.created_by = userId;
        }
        // Check if multi-channel delivery is requested
        const multiChannel = req.query.multi_channel === 'true';
        if (multiChannel) {
            // Create notification in database
            const notification = yield notification_1.NotificationService.createNotification(tenantId, data);
            // Deliver via all enabled channels
            const deliveryReport = yield notification_delivery_1.NotificationDeliveryService.deliverNotification(tenantId, notification);
            // Update user statistics
            const stats = yield notification_1.NotificationService.getNotificationStats(tenantId, notification.user_id);
            yield notification_broadcaster_1.NotificationBroadcaster.sendStatsUpdate(tenantId, notification.user_id, stats);
            res.status(201).json({
                message: 'Notification created and delivered via all channels',
                notification,
                delivery: deliveryReport,
            });
        }
        else {
            // In-app only (WebSocket/SSE)
            const notification = yield notification_broadcaster_1.NotificationBroadcaster.createAndBroadcast(tenantId, data);
            res.status(201).json({
                message: 'Notification created and broadcast successfully',
                notification,
            });
        }
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error creating notification:', error);
        res.status(500).json({ error: 'Failed to create notification' });
    }
}));
/**
 * GET /api/notifications/stream
 * SSE endpoint for real-time notifications
 */
router.get('/stream', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        // Add client to SSE service
        const sseService = (0, notification_sse_1.getNotificationSSEService)();
        sseService.addClient(userId, tenantId, res);
        // Connection will be kept alive by SSE service
    }
    catch (error) {
        console.error('Error setting up SSE stream:', error);
        res.status(500).json({ error: 'Failed to establish SSE connection' });
    }
}));
/**
 * GET /api/notifications/connections
 * Get real-time connection statistics
 */
router.get('/connections', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        // Get connection statistics
        const globalStats = notification_broadcaster_1.NotificationBroadcaster.getConnectionStats();
        const tenantStats = notification_broadcaster_1.NotificationBroadcaster.getTenantConnectionStats(tenantId);
        const userStats = notification_broadcaster_1.NotificationBroadcaster.getUserConnectionStats(tenantId, userId);
        res.json({
            global: globalStats,
            tenant: tenantStats,
            user: userStats,
        });
    }
    catch (error) {
        console.error('Error getting connection stats:', error);
        res.status(500).json({ error: 'Failed to get connection statistics' });
    }
}));
/**
 * GET /api/notifications/stats
 * Get notification statistics
 */
router.get('/stats', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const stats = yield notification_1.NotificationService.getNotificationStats(tenantId, userId);
        res.json({ stats });
    }
    catch (error) {
        console.error('Error getting notification stats:', error);
        res.status(500).json({ error: 'Failed to get notification stats' });
    }
}));
/**
 * GET /api/notifications/:id
 * Get notification by ID
 */
router.get('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        const notification = yield notification_1.NotificationService.getNotificationById(tenantId, notificationId, userId);
        if (!notification) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json({ notification });
    }
    catch (error) {
        console.error('Error getting notification:', error);
        res.status(500).json({ error: 'Failed to get notification' });
    }
}));
/**
 * PUT /api/notifications/:id/read
 * Mark notification as read
 */
router.put('/:id/read', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        const notification = yield notification_1.NotificationService.markAsRead(tenantId, notificationId, userId);
        if (!notification) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json({
            message: 'Notification marked as read',
            notification,
        });
    }
    catch (error) {
        console.error('Error marking notification as read:', error);
        res.status(500).json({ error: 'Failed to mark notification as read' });
    }
}));
/**
 * PUT /api/notifications/:id/archive
 * Archive notification
 */
router.put('/:id/archive', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        const notification = yield notification_1.NotificationService.archiveNotification(tenantId, notificationId, userId);
        if (!notification) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json({
            message: 'Notification archived',
            notification,
        });
    }
    catch (error) {
        console.error('Error archiving notification:', error);
        res.status(500).json({ error: 'Failed to archive notification' });
    }
}));
/**
 * DELETE /api/notifications/:id
 * Delete notification (soft delete)
 */
router.delete('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        const success = yield notification_1.NotificationService.deleteNotification(tenantId, notificationId, userId);
        if (!success) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json({ message: 'Notification deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting notification:', error);
        res.status(500).json({ error: 'Failed to delete notification' });
    }
}));
/**
 * POST /api/notifications/bulk-read
 * Mark multiple notifications as read
 */
router.post('/bulk-read', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const data = notification_2.BulkOperationSchema.parse(req.body);
        const affectedCount = yield notification_1.NotificationService.bulkMarkAsRead(tenantId, userId, data);
        res.json({
            success: true,
            affected_count: affectedCount,
            message: `${affectedCount} notification(s) marked as read`,
        });
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error bulk marking as read:', error);
        res.status(500).json({ error: 'Failed to mark notifications as read' });
    }
}));
/**
 * POST /api/notifications/bulk-archive
 * Archive multiple notifications
 */
router.post('/bulk-archive', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const data = notification_2.BulkOperationSchema.parse(req.body);
        const affectedCount = yield notification_1.NotificationService.bulkArchive(tenantId, userId, data);
        res.json({
            success: true,
            affected_count: affectedCount,
            message: `${affectedCount} notification(s) archived`,
        });
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error bulk archiving:', error);
        res.status(500).json({ error: 'Failed to archive notifications' });
    }
}));
/**
 * POST /api/notifications/bulk-delete
 * Delete multiple notifications
 */
router.post('/bulk-delete', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const data = notification_2.BulkOperationSchema.parse(req.body);
        const affectedCount = yield notification_1.NotificationService.bulkDelete(tenantId, userId, data);
        res.json({
            success: true,
            affected_count: affectedCount,
            message: `${affectedCount} notification(s) deleted`,
        });
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error bulk deleting:', error);
        res.status(500).json({ error: 'Failed to delete notifications' });
    }
}));
/**
 * GET /api/notifications/:id/history
 * Get notification delivery history
 */
router.get('/:id/history', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        const history = yield notification_1.NotificationService.getNotificationHistory(tenantId, notificationId, userId);
        res.json({ history });
    }
    catch (error) {
        console.error('Error getting notification history:', error);
        res.status(500).json({ error: 'Failed to get notification history' });
    }
}));
/**
 * GET /api/notifications/:id/delivery-stats
 * Get notification delivery statistics
 */
router.get('/:id/delivery-stats', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        const notificationId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(notificationId)) {
            return res.status(400).json({ error: 'Invalid notification ID' });
        }
        // Verify notification belongs to user
        const notification = yield notification_1.NotificationService.getNotificationById(tenantId, notificationId, userId);
        if (!notification) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        const stats = yield notification_delivery_1.NotificationDeliveryService.getDeliveryStats(tenantId, notificationId);
        res.json({ stats });
    }
    catch (error) {
        console.error('Error getting delivery stats:', error);
        res.status(500).json({ error: 'Failed to get delivery statistics' });
    }
}));
// ============================================================================
// Notification Settings Endpoints
// ============================================================================
/**
 * GET /api/notification-settings
 * Get user notification settings
 */
router.get('/settings', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const settings = yield notification_1.NotificationService.getUserSettings(tenantId, userId);
        res.json({ settings });
    }
    catch (error) {
        console.error('Error getting notification settings:', error);
        res.status(500).json({ error: 'Failed to get notification settings' });
    }
}));
/**
 * PUT /api/notification-settings
 * Update notification settings
 */
router.put('/settings', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const data = notification_2.NotificationSettingsSchema.parse(req.body);
        const settings = yield notification_1.NotificationService.upsertSettings(tenantId, userId, data);
        res.json({
            message: 'Notification settings updated',
            settings,
        });
    }
    catch (error) {
        if (error instanceof zod_1.ZodError) {
            return handleValidationError(error, res);
        }
        console.error('Error updating notification settings:', error);
        res.status(500).json({ error: 'Failed to update notification settings' });
    }
}));
/**
 * POST /api/notification-settings/reset
 * Reset notification settings to defaults
 */
router.post('/settings/reset', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = getTenantId(req);
        const userId = getUserId(req);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        yield notification_1.NotificationService.resetSettings(tenantId, userId);
        res.json({ message: 'Notification settings reset to defaults' });
    }
    catch (error) {
        console.error('Error resetting notification settings:', error);
        res.status(500).json({ error: 'Failed to reset notification settings' });
    }
}));
// ============================================================================
// Notification Templates Endpoints (Global)
// ============================================================================
/**
 * GET /api/notification-templates
 * Get all notification templates
 */
router.get('/templates', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const templates = yield notification_1.NotificationService.getAllTemplates();
        res.json({ templates });
    }
    catch (error) {
        console.error('Error getting notification templates:', error);
        res.status(500).json({ error: 'Failed to get notification templates' });
    }
}));
/**
 * GET /api/notification-templates/:key
 * Get template by key
 */
router.get('/templates/:key', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const templateKey = req.params.key;
        const template = yield notification_1.NotificationService.getTemplateByKey(templateKey);
        if (!template) {
            return res.status(404).json({ error: 'Template not found' });
        }
        res.json({ template });
    }
    catch (error) {
        console.error('Error getting notification template:', error);
        res.status(500).json({ error: 'Failed to get notification template' });
    }
}));
exports.default = router;
