"use strict";
/**
 * Branding Routes
 * Purpose: API endpoints for managing tenant branding
 * Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const multer_1 = __importDefault(require("multer"));
const branding_1 = require("../services/branding");
const logo_processor_1 = require("../services/logo-processor");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../database"));
const router = express_1.default.Router();
// Configure multer for file uploads (memory storage)
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 2 * 1024 * 1024, // 2MB limit
    },
});
/**
 * Authorization middleware for branding endpoints
 * Verify user is super admin OR tenant admin for that tenant
 * Requirement: 9.4
 */
const brandingAuthMiddleware = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const { id: tenantId } = req.params;
    const user = req.user; // User from auth middleware
    if (!user) {
        console.log('❌ Authorization failed: No user in request');
        return res.status(401).json({
            error: 'Unauthorized',
            message: 'Authentication required',
            code: 'AUTH_REQUIRED',
        });
    }
    try {
        // Check if user is super admin (can manage all tenants)
        const userResult = yield database_1.default.query(`SELECT u.id, u.tenant_id, r.name as role_name
       FROM users u
       LEFT JOIN user_roles ur ON u.id = ur.user_id
       LEFT JOIN roles r ON ur.role_id = r.id
       WHERE u.id = $1`, [user.id || user.userId]);
        if (userResult.rows.length === 0) {
            console.log(`❌ Authorization failed: User not found - ${user.id || user.userId}`);
            return res.status(403).json({
                error: 'Forbidden',
                message: 'User not found',
                code: 'USER_NOT_FOUND',
            });
        }
        const userData = userResult.rows[0];
        // Super admin can manage all tenants (tenant_id = 'admin')
        if (userData.tenant_id === 'admin' || userData.role_name === 'Super Admin') {
            console.log(`✅ Authorization: Super admin access granted`);
            return next();
        }
        // Tenant admin can only manage their own tenant
        if (userData.tenant_id === tenantId && userData.role_name === 'Admin') {
            console.log(`✅ Authorization: Tenant admin access granted for ${tenantId}`);
            return next();
        }
        // Unauthorized
        console.log(`❌ Authorization failed: User ${user.id} cannot manage tenant ${tenantId}`);
        return res.status(403).json({
            error: 'Forbidden',
            message: 'You do not have permission to manage this tenant\'s branding',
            code: 'INSUFFICIENT_PERMISSIONS',
        });
    }
    catch (error) {
        console.error('Authorization error:', error);
        return res.status(500).json({
            error: 'Internal server error',
            message: 'Failed to verify authorization',
            code: 'AUTH_ERROR',
        });
    }
});
// GET /api/tenants/:id/branding - Get branding configuration
router.get('/:id/branding', auth_1.authMiddleware, branding_1.getBranding);
// PUT /api/tenants/:id/branding - Update branding configuration
router.put('/:id/branding', auth_1.authMiddleware, brandingAuthMiddleware, branding_1.updateBranding);
// POST /api/tenants/:id/branding/logo - Upload logo
router.post('/:id/branding/logo', auth_1.authMiddleware, brandingAuthMiddleware, upload.single('logo'), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id: tenantId } = req.params;
    const file = req.file;
    try {
        // Validate file exists
        if (!file) {
            return res.status(400).json({
                error: 'No file uploaded',
                message: 'Please provide a logo file',
                code: 'FILE_REQUIRED',
            });
        }
        // Validate file
        const validation = (0, logo_processor_1.validateLogoFile)(file);
        if (!validation.valid) {
            return res.status(400).json({
                error: validation.error,
                code: 'INVALID_FILE',
            });
        }
        // Process and upload logo
        const logoUrls = yield (0, logo_processor_1.processAndUploadLogo)(tenantId, file.buffer, file.originalname, file.mimetype);
        // Update tenant branding
        yield (0, logo_processor_1.updateTenantBrandingWithLogos)(tenantId, logoUrls);
        console.log(`✅ Logo uploaded successfully for tenant: ${tenantId}`);
        return res.status(200).json({
            message: 'Logo uploaded successfully',
            logo_urls: logoUrls,
        });
    }
    catch (error) {
        console.error('Error uploading logo:', error);
        return res.status(500).json({
            error: 'Internal server error',
            message: 'Failed to upload logo',
            code: 'LOGO_UPLOAD_ERROR',
        });
    }
}));
// DELETE /api/tenants/:id/branding/logo - Delete logo
router.delete('/:id/branding/logo', auth_1.authMiddleware, brandingAuthMiddleware, branding_1.deleteLogo);
exports.default = router;
