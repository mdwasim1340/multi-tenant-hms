"use strict";
/**
 * Team Alpha - Storage Cost Routes
 * API endpoints for storage cost monitoring system
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const storage_controller_1 = require("../controllers/storage.controller");
const router = express_1.default.Router();
// Get current storage metrics
router.get('/metrics', storage_controller_1.getCurrentMetrics);
// Get historical storage metrics
router.get('/metrics/history', storage_controller_1.getMetricsHistory);
// Get cost breakdown and trends
router.get('/costs', storage_controller_1.getCostBreakdown);
// Get cost trends over time
router.get('/trends', storage_controller_1.getCostTrendsData);
// Get active cost alerts
router.get('/alerts', storage_controller_1.getCostAlerts);
// Resolve a cost alert
router.post('/alerts/:id/resolve', storage_controller_1.resolveAlert);
// Generate comprehensive storage report
router.get('/report', storage_controller_1.getStorageReport);
// Refresh storage metrics (manual trigger)
router.post('/refresh', storage_controller_1.refreshMetrics);
// Log file access for optimization
router.post('/access-log', storage_controller_1.logAccess);
// Export storage metrics to CSV
router.get('/export', storage_controller_1.exportMetrics);
exports.default = router;
