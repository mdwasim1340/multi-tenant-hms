"use strict";
/**
 * Lab Tests Routes
 *
 * API routes for laboratory test management system
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const labTestController = __importStar(require("../controllers/labTest.controller"));
const router = (0, express_1.Router)();
// ============================================================================
// Lab Tests Routes
// ============================================================================
/**
 * GET /api/lab-tests
 * Get all lab tests with optional filtering
 * Query params: category_id, specimen_type, status, search, page, limit
 */
router.get('/', labTestController.getLabTests);
/**
 * GET /api/lab-tests/categories
 * Get all test categories
 */
router.get('/categories', labTestController.getLabTestCategories);
/**
 * GET /api/lab-tests/specimen-types
 * Get all specimen types
 */
router.get('/specimen-types', labTestController.getSpecimenTypes);
/**
 * GET /api/lab-tests/:id
 * Get lab test by ID
 */
router.get('/:id', labTestController.getLabTestById);
/**
 * POST /api/lab-tests
 * Create new lab test (admin only)
 */
router.post('/', labTestController.createLabTest);
/**
 * PUT /api/lab-tests/:id
 * Update lab test (admin only)
 */
router.put('/:id', labTestController.updateLabTest);
/**
 * DELETE /api/lab-tests/:id
 * Deactivate lab test (admin only)
 */
router.delete('/:id', labTestController.deactivateLabTest);
exports.default = router;
