"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const events_1 = require("../services/events");
const server_1 = require("../websocket/server");
const auth_1 = require("../middleware/auth");
const router = express_1.default.Router();
// Get recent events for tenant
router.get('/events/:tenantId', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const count = parseInt(req.query.count) || 50;
        const events = yield events_1.eventService.getRecentEvents(tenantId, count);
        res.json({ events });
    }
    catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
}));
// Get WebSocket connection stats
router.get('/stats', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const realtimeServer = (0, server_1.getRealtimeServer)();
        const totalConnections = realtimeServer.getTotalConnectionCount();
        res.json({
            total_connections: totalConnections,
            timestamp: new Date().toISOString()
        });
    }
    catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
}));
// Test endpoint to publish event
router.post('/test-event', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenant_id, event_type, data } = req.body;
        yield events_1.eventService.publishEvent({
            type: event_type,
            tenantId: tenant_id,
            data: data,
            timestamp: new Date()
        });
        res.json({ message: 'Event published successfully' });
    }
    catch (error) {
        console.error('Error publishing test event:', error);
        res.status(500).json({ error: 'Failed to publish event' });
    }
}));
exports.default = router;
