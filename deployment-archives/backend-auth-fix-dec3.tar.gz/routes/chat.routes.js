"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleChat = void 0;
const express_1 = __importDefault(require("express"));
const errorHandler_1 = require("../middleware/errorHandler");
const router = express_1.default.Router();
/**
 * POST /api/chat
 * Local chat endpoint for fallback responses when n8n is unavailable
 */
exports.handleChat = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { userMessage, messages, department } = req.body;
    if (!userMessage) {
        return res.status(400).json({
            success: false,
            error: 'Missing userMessage'
        });
    }
    try {
        // Simple local response logic
        const response = getLocalChatResponse(userMessage, department);
        res.json({
            success: true,
            response: response
        });
    }
    catch (error) {
        console.error('Chat error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to process chat message'
        });
    }
}));
/**
 * Generate a local chat response based on keywords and department
 */
function getLocalChatResponse(message, department) {
    const lowerMessage = message.toLowerCase();
    // Department-specific fallback messages
    if (department === 'opd') {
        return 'For medical consultations and symptom analysis, our AI-powered OPD assistant is currently unavailable. Please try again later or contact our OPD desk at +977-1-4123456.';
    }
    if (department === 'ward') {
        return 'For inpatient care inquiries, our AI-powered Ward assistant is currently unavailable. Please contact the ward desk at +977-1-4123457 for immediate assistance.';
    }
    if (department === 'emergency') {
        return 'For emergency situations, please call our emergency hotline immediately at +977-1-4123999 or visit our emergency department. Our AI assistant is currently unavailable.';
    }
    // General inquiry responses
    // Business hours
    if (lowerMessage.includes('hour') || lowerMessage.includes('open') || lowerMessage.includes('close')) {
        return 'Our hospital is open 24/7 for emergency services. Regular outpatient services are available from 8:00 AM to 6:00 PM, Monday through Friday. Ward visiting hours are 9:00 AM to 8:00 PM daily.';
    }
    // Contact information
    if (lowerMessage.includes('contact') || lowerMessage.includes('phone') || lowerMessage.includes('call')) {
        return 'You can reach us at:\n• Main Reception: +977-1-4123456\n• OPD Desk: +977-1-4123456\n• Ward Desk: +977-1-4123457\n• Emergency Hotline: +977-1-4123999\n• Email: info@hospital.com';
    }
    // Departments
    if (lowerMessage.includes('department') || lowerMessage.includes('specialist')) {
        return 'We have the following departments:\n• OPD (Outpatient Department)\n• Ward (Inpatient Care)\n• Emergency Department\n• General Medicine\n• Surgery\n• Pediatrics\n• Cardiology\n• Neurology\n• Orthopedics\n\nPlease let us know which department you need assistance with.';
    }
    // Appointments
    if (lowerMessage.includes('appointment') || lowerMessage.includes('book') || lowerMessage.includes('schedule')) {
        return 'You can book an appointment:\n• Online through our patient portal\n• By calling our appointment desk at +977-1-4123456\n• Walk-in during OPD hours (8 AM - 6 PM)\n\nWe typically have availability within 2-3 days. For urgent cases, please mention it when booking.';
    }
    // Insurance
    if (lowerMessage.includes('insurance') || lowerMessage.includes('payment') || lowerMessage.includes('cost')) {
        return 'We accept most major insurance plans. For specific information about your coverage, please contact our billing department at +977-1-4123789. We also accept cash, credit cards, and bank transfers.';
    }
    // Location/directions
    if (lowerMessage.includes('location') || lowerMessage.includes('address') || lowerMessage.includes('direction')) {
        return 'We are located at Kathmandu Medical Center, Kathmandu, Nepal. We have ample parking facilities and are easily accessible by public transportation. For detailed directions, please visit our website or call +977-1-4123456.';
    }
    // Services
    if (lowerMessage.includes('service') || lowerMessage.includes('facility') || lowerMessage.includes('treatment')) {
        return 'Our hospital offers comprehensive healthcare services including:\n• 24/7 Emergency Care\n• Outpatient Consultations\n• Inpatient Care\n• Diagnostic Services (Lab, Imaging)\n• Surgical Procedures\n• Pharmacy\n• Ambulance Services\n\nFor specific service inquiries, please contact the relevant department.';
    }
    // Default response
    return 'Thank you for your inquiry. I\'m here to help with general hospital information such as:\n• Business hours and contact information\n• Department information\n• Appointment booking\n• Services and facilities\n• Location and directions\n\nFor medical consultations, please select the appropriate department (OPD, Ward, or Emergency) to connect with our AI-powered medical assistants. How can I assist you today?';
}
// Routes
router.post('/', exports.handleChat);
exports.default = router;
