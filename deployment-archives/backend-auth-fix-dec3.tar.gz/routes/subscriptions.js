"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const subscription_1 = require("../services/subscription");
const auth_1 = require("../middleware/auth");
const router = express_1.default.Router();
// Get current tenant's subscription (H1 frontend compatibility endpoint)
router.get('/current', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({
                error: 'X-Tenant-ID header is required',
                code: 'MISSING_TENANT_ID'
            });
        }
        const usageStats = yield subscription_1.subscriptionService.getUsageStats(tenantId);
        if (!usageStats) {
            return res.status(404).json({
                error: 'Subscription not found for this tenant',
                code: 'SUBSCRIPTION_NOT_FOUND'
            });
        }
        // Generate warnings based on usage thresholds
        const warnings = [];
        Object.entries(usageStats.limits).forEach(([limitType, limitResult]) => {
            if (limitResult.percentage >= 80) {
                const limitLabel = limitType.replace('max_', '').replace('_', ' ');
                warnings.push(`Approaching ${limitLabel} limit`);
            }
        });
        // Format response to match H1 frontend expectations
        res.json({
            tier: usageStats.subscription.tier,
            usage: usageStats.usage,
            warnings
        });
    }
    catch (error) {
        console.error('Error fetching current subscription:', error);
        res.status(500).json({
            error: 'Failed to fetch subscription',
            code: 'FETCH_SUBSCRIPTION_ERROR'
        });
    }
}));
// Get all available subscription tiers (public endpoint)
router.get('/tiers', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tiers = yield subscription_1.subscriptionService.getAllTiers();
        res.json({
            success: true,
            tiers
        });
    }
    catch (error) {
        console.error('Error fetching subscription tiers:', error);
        res.status(500).json({
            error: 'Failed to fetch subscription tiers',
            code: 'FETCH_TIERS_ERROR'
        });
    }
}));
// Get specific tier details
router.get('/tiers/:tierId', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tierId } = req.params;
        const tier = yield subscription_1.subscriptionService.getTierById(tierId);
        if (!tier) {
            return res.status(404).json({
                error: 'Subscription tier not found',
                code: 'TIER_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            tier
        });
    }
    catch (error) {
        console.error('Error fetching tier:', error);
        res.status(500).json({
            error: 'Failed to fetch tier details',
            code: 'FETCH_TIER_ERROR'
        });
    }
}));
// Get tenant's current subscription (requires auth)
router.get('/tenant/:tenantId', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant (basic security check)
        const userTenantId = req.headers['x-tenant-id'];
        // Allow admin users to access any tenant's data
        const isAdmin = userTenantId === 'admin' ||
            ((_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a.email) === null || _b === void 0 ? void 0 : _b.includes('admin')) ||
            ((_d = (_c = req.user) === null || _c === void 0 ? void 0 : _c['cognito:groups']) === null || _d === void 0 ? void 0 : _d.includes('admin'));
        if (userTenantId && userTenantId !== tenantId && !isAdmin) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const subscription = yield subscription_1.subscriptionService.getTenantSubscriptionWithTier(tenantId);
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found for this tenant',
                code: 'SUBSCRIPTION_NOT_FOUND'
            });
        }
        res.json({
            success: true,
            subscription
        });
    }
    catch (error) {
        console.error('Error fetching tenant subscription:', error);
        res.status(500).json({
            error: 'Failed to fetch subscription',
            code: 'FETCH_SUBSCRIPTION_ERROR'
        });
    }
}));
// Get tenant's usage statistics
router.get('/tenant/:tenantId/usage', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    try {
        const { tenantId } = req.params;
        // Verify user has access to this tenant
        const userTenantId = req.headers['x-tenant-id'];
        // Allow admin users to access any tenant's data
        const isAdmin = userTenantId === 'admin' ||
            ((_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a.email) === null || _b === void 0 ? void 0 : _b.includes('admin')) ||
            ((_d = (_c = req.user) === null || _c === void 0 ? void 0 : _c['cognito:groups']) === null || _d === void 0 ? void 0 : _d.includes('admin'));
        if (userTenantId && userTenantId !== tenantId && !isAdmin) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const usageStats = yield subscription_1.subscriptionService.getUsageStats(tenantId);
        if (!usageStats) {
            return res.status(404).json({
                error: 'Usage statistics not found for this tenant',
                code: 'USAGE_STATS_NOT_FOUND'
            });
        }
        res.json(Object.assign({ success: true }, usageStats));
    }
    catch (error) {
        console.error('Error fetching usage statistics:', error);
        res.status(500).json({
            error: 'Failed to fetch usage statistics',
            code: 'FETCH_USAGE_ERROR'
        });
    }
}));
// Update tenant subscription (admin only - would need role check in production)
router.put('/tenant/:tenantId', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const { tier_id, billing_cycle, trial_days } = req.body;
        if (!tier_id) {
            return res.status(400).json({
                error: 'tier_id is required',
                code: 'MISSING_TIER_ID'
            });
        }
        // Validate tier exists
        const tier = yield subscription_1.subscriptionService.getTierById(tier_id);
        if (!tier) {
            return res.status(400).json({
                error: 'Invalid tier_id',
                code: 'INVALID_TIER_ID'
            });
        }
        const subscription = yield subscription_1.subscriptionService.updateTenantSubscription(tenantId, tier_id, {
            billingCycle: billing_cycle,
            trialDays: trial_days
        });
        res.json({
            success: true,
            message: 'Subscription updated successfully',
            subscription
        });
    }
    catch (error) {
        console.error('Error updating subscription:', error);
        res.status(500).json({
            error: 'Failed to update subscription',
            code: 'UPDATE_SUBSCRIPTION_ERROR'
        });
    }
}));
// Check feature access for a tenant
router.get('/tenant/:tenantId/features/:feature', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    try {
        const { tenantId, feature } = req.params;
        // Verify user has access to this tenant
        const userTenantId = req.headers['x-tenant-id'];
        // Allow admin users to access any tenant's data
        const isAdmin = userTenantId === 'admin' ||
            ((_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a.email) === null || _b === void 0 ? void 0 : _b.includes('admin')) ||
            ((_d = (_c = req.user) === null || _c === void 0 ? void 0 : _c['cognito:groups']) === null || _d === void 0 ? void 0 : _d.includes('admin'));
        if (userTenantId && userTenantId !== tenantId && !isAdmin) {
            return res.status(403).json({
                error: 'Access denied to this tenant',
                code: 'TENANT_ACCESS_DENIED'
            });
        }
        const accessResult = yield subscription_1.subscriptionService.hasFeatureAccess(tenantId, feature);
        res.json(Object.assign({ success: true, feature }, accessResult));
    }
    catch (error) {
        console.error('Error checking feature access:', error);
        res.status(500).json({
            error: 'Failed to check feature access',
            code: 'FEATURE_CHECK_ERROR'
        });
    }
}));
// Update usage for a tenant (internal API - would be called by other services)
router.post('/tenant/:tenantId/usage', auth_1.authMiddleware, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { tenantId } = req.params;
        const usage = req.body;
        // Validate usage object
        const validUsageKeys = ['patients_count', 'users_count', 'storage_used_gb', 'api_calls_today'];
        const invalidKeys = Object.keys(usage).filter(key => !validUsageKeys.includes(key));
        if (invalidKeys.length > 0) {
            return res.status(400).json({
                error: `Invalid usage keys: ${invalidKeys.join(', ')}`,
                code: 'INVALID_USAGE_KEYS',
                valid_keys: validUsageKeys
            });
        }
        yield subscription_1.subscriptionService.updateUsage(tenantId, usage);
        res.json({
            success: true,
            message: 'Usage updated successfully'
        });
    }
    catch (error) {
        console.error('Error updating usage:', error);
        res.status(500).json({
            error: 'Failed to update usage',
            code: 'UPDATE_USAGE_ERROR'
        });
    }
}));
// Get subscription comparison (for upgrade/downgrade decisions)
router.get('/compare', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { current_tier, target_tier } = req.query;
        if (!current_tier || !target_tier) {
            return res.status(400).json({
                error: 'current_tier and target_tier query parameters are required',
                code: 'MISSING_TIER_PARAMS'
            });
        }
        const currentTier = yield subscription_1.subscriptionService.getTierById(current_tier);
        const targetTier = yield subscription_1.subscriptionService.getTierById(target_tier);
        if (!currentTier || !targetTier) {
            return res.status(404).json({
                error: 'One or both tiers not found',
                code: 'TIER_NOT_FOUND'
            });
        }
        // Calculate differences
        const featureDifferences = Object.keys(targetTier.features).reduce((diff, feature) => {
            const current = currentTier.features[feature];
            const target = targetTier.features[feature];
            if (current !== target) {
                diff[feature] = { current, target, changed: true };
            }
            return diff;
        }, {});
        const limitDifferences = Object.keys(targetTier.limits).reduce((diff, limit) => {
            const current = currentTier.limits[limit];
            const target = targetTier.limits[limit];
            if (current !== target) {
                diff[limit] = { current, target, changed: true };
            }
            return diff;
        }, {});
        res.json({
            success: true,
            current_tier: currentTier,
            target_tier: targetTier,
            price_difference: targetTier.price - currentTier.price,
            feature_differences: featureDifferences,
            limit_differences: limitDifferences,
            is_upgrade: targetTier.price > currentTier.price
        });
    }
    catch (error) {
        console.error('Error comparing tiers:', error);
        res.status(500).json({
            error: 'Failed to compare tiers',
            code: 'COMPARE_TIERS_ERROR'
        });
    }
}));
exports.default = router;
