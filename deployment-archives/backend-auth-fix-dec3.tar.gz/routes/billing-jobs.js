"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const billing_jobs_1 = require("../jobs/billing-jobs");
const billing_scheduler_service_1 = require("../services/billing-scheduler.service");
const router = (0, express_1.Router)();
/**
 * Billing Jobs API Routes
 * Allows manual triggering and monitoring of billing scheduled tasks
 * Requires billing:admin permission
 */
// GET /api/billing/jobs/status - Get scheduler status
router.get('/status', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        res.json({
            success: true,
            status: {
                emailsEnabled: process.env.BILLING_EMAILS_ENABLED === 'true',
                adminEmail: process.env.BILLING_ADMIN_EMAIL || 'Not configured',
                lastRun: 'Check logs for last run time'
            }
        });
    }
    catch (error) {
        console.error('Error getting job status:', error);
        res.status(500).json({ error: 'Failed to get job status' });
    }
}));
// POST /api/billing/jobs/run-daily - Manually trigger daily jobs
router.post('/run-daily', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const billingJobs = new billing_jobs_1.BillingJobs(pool);
        // Run in background
        billingJobs.runDailyJobs().catch(err => {
            console.error('Daily jobs failed:', err);
        });
        res.json({
            success: true,
            message: 'Daily billing jobs triggered. Check logs for progress.'
        });
    }
    catch (error) {
        console.error('Error triggering daily jobs:', error);
        res.status(500).json({ error: 'Failed to trigger daily jobs' });
    }
}));
// POST /api/billing/jobs/run-weekly - Manually trigger weekly jobs
router.post('/run-weekly', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const billingJobs = new billing_jobs_1.BillingJobs(pool);
        // Run in background
        billingJobs.runWeeklyJobs().catch(err => {
            console.error('Weekly jobs failed:', err);
        });
        res.json({
            success: true,
            message: 'Weekly billing jobs triggered. Check logs for progress.'
        });
    }
    catch (error) {
        console.error('Error triggering weekly jobs:', error);
        res.status(500).json({ error: 'Failed to trigger weekly jobs' });
    }
}));
// POST /api/billing/jobs/mark-overdue - Mark overdue invoices
router.post('/mark-overdue', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        const result = yield schedulerService.markOverdueInvoices();
        res.json({
            success: true,
            message: `Marked ${result.updated} invoices as overdue`,
            invoices: result.invoices
        });
    }
    catch (error) {
        console.error('Error marking overdue invoices:', error);
        res.status(500).json({ error: 'Failed to mark overdue invoices' });
    }
}));
// POST /api/billing/jobs/apply-late-fees - Apply late fees
router.post('/apply-late-fees', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        const { lateFeePercent = 2 } = req.body;
        const result = yield schedulerService.applyLateFees(lateFeePercent);
        res.json({
            success: true,
            message: `Applied late fees to ${result.applied} invoices`,
            totalFees: result.totalFees
        });
    }
    catch (error) {
        console.error('Error applying late fees:', error);
        res.status(500).json({ error: 'Failed to apply late fees' });
    }
}));
// GET /api/billing/jobs/reminders-due - Get invoices due for reminders
router.get('/reminders-due', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        const reminders = yield schedulerService.getInvoicesForReminders();
        const overdue = yield schedulerService.getOverdueInvoicesForReminders();
        res.json({
            success: true,
            upcoming: {
                dueIn3Days: reminders.dueIn3Days.length,
                dueIn1Day: reminders.dueIn1Day.length,
                dueToday: reminders.dueToday.length
            },
            overdue: {
                overdue7Days: overdue.overdue7Days.length,
                overdue14Days: overdue.overdue14Days.length,
                overdue30Days: overdue.overdue30Days.length
            }
        });
    }
    catch (error) {
        console.error('Error getting reminders due:', error);
        res.status(500).json({ error: 'Failed to get reminders due' });
    }
}));
// GET /api/billing/jobs/daily-summary - Get daily billing summary
router.get('/daily-summary', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        const tenantId = req.headers['x-tenant-id'];
        const summary = yield schedulerService.generateDailySummary(tenantId);
        res.json({
            success: true,
            summary
        });
    }
    catch (error) {
        console.error('Error getting daily summary:', error);
        res.status(500).json({ error: 'Failed to get daily summary' });
    }
}));
// GET /api/billing/jobs/payment-plans-due - Get payment plans due
router.get('/payment-plans-due', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pool = req.app.get('pool');
        const schedulerService = new billing_scheduler_service_1.BillingSchedulerService(pool);
        const plans = yield schedulerService.getPaymentPlansDue();
        res.json({
            success: true,
            dueToday: plans.dueToday,
            overdue: plans.overdue
        });
    }
    catch (error) {
        console.error('Error getting payment plans due:', error);
        res.status(500).json({ error: 'Failed to get payment plans due' });
    }
}));
exports.default = router;
