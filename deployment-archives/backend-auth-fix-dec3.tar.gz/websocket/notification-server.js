"use strict";
/**
 * Notification WebSocket Server
 * Team: Epsilon
 * Purpose: Real-time notification delivery via WebSocket
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationWebSocketServer = void 0;
exports.initializeNotificationWebSocket = initializeNotificationWebSocket;
exports.getNotificationWebSocket = getNotificationWebSocket;
const ws_1 = __importStar(require("ws"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
class NotificationWebSocketServer {
    constructor(server) {
        this.clients = new Map();
        this.heartbeatInterval = null;
        this.wss = new ws_1.WebSocketServer({
            server,
            path: '/ws/notifications'
        });
        this.initialize();
    }
    initialize() {
        console.log('🔔 Notification WebSocket Server initialized');
        this.wss.on('connection', (ws, req) => {
            this.handleConnection(ws, req);
        });
        // Start heartbeat to detect dead connections
        this.startHeartbeat();
    }
    handleConnection(ws, req) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            console.log('📡 New WebSocket connection attempt');
            try {
                // Extract token from query string or headers
                const url = new URL(req.url, `http://${req.headers.host}`);
                const token = url.searchParams.get('token') || ((_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.replace('Bearer ', ''));
                const tenantId = url.searchParams.get('tenant_id') || req.headers['x-tenant-id'];
                if (!token || !tenantId) {
                    console.log('❌ WebSocket connection rejected: Missing token or tenant_id');
                    ws.close(1008, 'Missing authentication credentials');
                    return;
                }
                // Verify JWT token
                const decoded = yield this.verifyToken(token);
                if (!decoded || !decoded.userId) {
                    console.log('❌ WebSocket connection rejected: Invalid token');
                    ws.close(1008, 'Invalid authentication token');
                    return;
                }
                // Set client properties
                ws.userId = decoded.userId;
                ws.tenantId = tenantId;
                ws.isAlive = true;
                // Add client to tenant group
                const clientKey = `${tenantId}:${decoded.userId}`;
                if (!this.clients.has(clientKey)) {
                    this.clients.set(clientKey, new Set());
                }
                this.clients.get(clientKey).add(ws);
                console.log(`✅ WebSocket connected: User ${decoded.userId} in tenant ${tenantId}`);
                console.log(`📊 Active connections: ${this.getConnectionCount()}`);
                // Send connection success message
                this.sendMessage(ws, {
                    type: 'ping',
                    data: { message: 'Connected to notification server', timestamp: new Date().toISOString() }
                });
                // Handle incoming messages
                ws.on('message', (message) => {
                    this.handleMessage(ws, message);
                });
                // Handle pong responses
                ws.on('pong', () => {
                    ws.isAlive = true;
                });
                // Handle disconnection
                ws.on('close', () => {
                    this.handleDisconnection(ws);
                });
                // Handle errors
                ws.on('error', (error) => {
                    console.error('❌ WebSocket error:', error);
                    this.handleDisconnection(ws);
                });
            }
            catch (error) {
                console.error('❌ WebSocket connection error:', error);
                ws.close(1011, 'Internal server error');
            }
        });
    }
    verifyToken(token) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // For now, we'll use a simple JWT verification
                // In production, this should verify against Cognito JWKS
                const decoded = jsonwebtoken_1.default.decode(token);
                if (!decoded || !decoded.sub) {
                    return null;
                }
                // Extract user ID from token
                // Assuming the token has a 'sub' claim with user ID
                const userId = parseInt(decoded.sub) || decoded.userId;
                return { userId };
            }
            catch (error) {
                console.error('Token verification error:', error);
                return null;
            }
        });
    }
    handleMessage(ws, message) {
        try {
            const parsed = JSON.parse(message);
            switch (parsed.type) {
                case 'ping':
                    this.sendMessage(ws, { type: 'pong', data: { timestamp: new Date().toISOString() } });
                    break;
                case 'subscribe':
                    // Handle subscription to specific notification types
                    console.log(`📬 User ${ws.userId} subscribed to notifications`);
                    break;
                default:
                    console.log('Unknown message type:', parsed.type);
            }
        }
        catch (error) {
            console.error('Error handling message:', error);
        }
    }
    handleDisconnection(ws) {
        if (ws.userId && ws.tenantId) {
            const clientKey = `${ws.tenantId}:${ws.userId}`;
            const clientSet = this.clients.get(clientKey);
            if (clientSet) {
                clientSet.delete(ws);
                if (clientSet.size === 0) {
                    this.clients.delete(clientKey);
                }
            }
            console.log(`🔌 WebSocket disconnected: User ${ws.userId} in tenant ${ws.tenantId}`);
            console.log(`📊 Active connections: ${this.getConnectionCount()}`);
        }
    }
    sendMessage(ws, message) {
        if (ws.readyState === ws_1.default.OPEN) {
            ws.send(JSON.stringify(message));
        }
    }
    /**
     * Broadcast notification to specific user
     */
    broadcastToUser(tenantId, userId, notification) {
        const clientKey = `${tenantId}:${userId}`;
        const clientSet = this.clients.get(clientKey);
        if (clientSet && clientSet.size > 0) {
            const message = {
                type: 'notification',
                data: notification
            };
            clientSet.forEach(ws => {
                this.sendMessage(ws, message);
            });
            console.log(`📤 Notification sent to user ${userId} in tenant ${tenantId} (${clientSet.size} connections)`);
            return true;
        }
        console.log(`📭 No active connections for user ${userId} in tenant ${tenantId}`);
        return false;
    }
    /**
     * Broadcast notification to all users in a tenant
     */
    broadcastToTenant(tenantId, notification) {
        let sentCount = 0;
        this.clients.forEach((clientSet, clientKey) => {
            if (clientKey.startsWith(`${tenantId}:`)) {
                const message = {
                    type: 'notification',
                    data: notification
                };
                clientSet.forEach(ws => {
                    this.sendMessage(ws, message);
                    sentCount++;
                });
            }
        });
        console.log(`📤 Notification broadcast to tenant ${tenantId} (${sentCount} connections)`);
        return sentCount;
    }
    /**
     * Send statistics update to user
     */
    sendStatsUpdate(tenantId, userId, stats) {
        const clientKey = `${tenantId}:${userId}`;
        const clientSet = this.clients.get(clientKey);
        if (clientSet && clientSet.size > 0) {
            const message = {
                type: 'stats_update',
                data: stats
            };
            clientSet.forEach(ws => {
                this.sendMessage(ws, message);
            });
            return true;
        }
        return false;
    }
    /**
     * Start heartbeat to detect dead connections
     */
    startHeartbeat() {
        this.heartbeatInterval = setInterval(() => {
            this.wss.clients.forEach((ws) => {
                if (ws.isAlive === false) {
                    console.log('💀 Terminating dead connection');
                    return ws.terminate();
                }
                ws.isAlive = false;
                ws.ping();
            });
        }, 30000); // Check every 30 seconds
    }
    /**
     * Get total connection count
     */
    getConnectionCount() {
        let count = 0;
        this.clients.forEach(clientSet => {
            count += clientSet.size;
        });
        return count;
    }
    /**
     * Get connection count for specific tenant
     */
    getTenantConnectionCount(tenantId) {
        let count = 0;
        this.clients.forEach((clientSet, clientKey) => {
            if (clientKey.startsWith(`${tenantId}:`)) {
                count += clientSet.size;
            }
        });
        return count;
    }
    /**
     * Get connection count for specific user
     */
    getUserConnectionCount(tenantId, userId) {
        const clientKey = `${tenantId}:${userId}`;
        const clientSet = this.clients.get(clientKey);
        return clientSet ? clientSet.size : 0;
    }
    /**
     * Shutdown server
     */
    shutdown() {
        console.log('🛑 Shutting down Notification WebSocket Server');
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
        }
        this.wss.clients.forEach(ws => {
            ws.close(1001, 'Server shutting down');
        });
        this.wss.close();
        this.clients.clear();
    }
}
exports.NotificationWebSocketServer = NotificationWebSocketServer;
// Singleton instance
let notificationWSServer = null;
function initializeNotificationWebSocket(server) {
    if (!notificationWSServer) {
        notificationWSServer = new NotificationWebSocketServer(server);
    }
    return notificationWSServer;
}
function getNotificationWebSocket() {
    return notificationWSServer;
}
