"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeServer = void 0;
exports.initializeWebSocketServer = initializeWebSocketServer;
exports.getRealtimeServer = getRealtimeServer;
const ws_1 = require("ws");
const url_1 = require("url");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwk_to_pem_1 = __importDefault(require("jwk-to-pem"));
const node_fetch_1 = __importDefault(require("node-fetch"));
let pems = {};
const fetchJWKS = () => __awaiter(void 0, void 0, void 0, function* () {
    const url = `https://cognito-idp.${process.env.AWS_REGION}.amazonaws.com/${process.env.COGNITO_USER_POOL_ID}/.well-known/jwks.json`;
    try {
        const response = yield (0, node_fetch_1.default)(url);
        const jwks = yield response.json();
        if (jwks && jwks.keys) {
            pems = jwks.keys.reduce((acc, key) => {
                if (key.kty === 'RSA') {
                    acc[key.kid] = (0, jwk_to_pem_1.default)({ kty: key.kty, n: key.n, e: key.e });
                }
                return acc;
            }, {});
        }
    }
    catch (error) {
        console.error('Error fetching JWKS:', error);
    }
});
fetchJWKS();
const verifyToken = (token) => {
    return new Promise((resolve, reject) => {
        const decodedToken = jsonwebtoken_1.default.decode(token, { complete: true });
        if (!decodedToken || !decodedToken.header.kid) {
            try {
                const payload = jsonwebtoken_1.default.verify(token, 'test-secret-key');
                resolve(payload);
            }
            catch (err) {
                reject('Invalid local test token');
            }
            return;
        }
        const kid = decodedToken.header.kid;
        const pem = pems[kid];
        if (!pem) {
            reject('Invalid token');
            return;
        }
        jsonwebtoken_1.default.verify(token, pem, { algorithms: ['RS256'] }, (err, payload) => {
            if (err) {
                reject('Invalid token');
            }
            else {
                resolve(payload);
            }
        });
    });
};
class RealtimeServer {
    constructor(server) {
        this.clients = new Map();
        this.wss = new ws_1.WebSocketServer({
            server,
            path: '/ws'
        });
        this.setupWebSocketServer();
        this.setupHeartbeat();
    }
    setupWebSocketServer() {
        this.wss.on('connection', (ws, req) => __awaiter(this, void 0, void 0, function* () {
            console.log('New WebSocket connection');
            const { query } = (0, url_1.parse)(req.url || '', true);
            const token = query.token;
            const tenantId = query.tenantId;
            if (!token || !tenantId) {
                ws.close(1008, 'Authentication required');
                return;
            }
            try {
                const payload = yield verifyToken(token);
                ws.tenantId = tenantId;
                ws.userId = payload.sub; // Assuming 'sub' is the user ID
                ws.isAlive = true;
                if (!this.clients.has(tenantId)) {
                    this.clients.set(tenantId, new Set());
                }
                this.clients.get(tenantId).add(ws);
                ws.on('pong', () => {
                    ws.isAlive = true;
                });
                ws.on('message', (data) => {
                    try {
                        const message = JSON.parse(data.toString());
                        this.handleClientMessage(ws, message);
                    }
                    catch (error) {
                        console.error('Error parsing WebSocket message:', error);
                    }
                });
                ws.on('close', () => {
                    console.log('WebSocket connection closed');
                    if (ws.tenantId) {
                        const tenantClients = this.clients.get(ws.tenantId);
                        if (tenantClients) {
                            tenantClients.delete(ws);
                            if (tenantClients.size === 0) {
                                this.clients.delete(ws.tenantId);
                            }
                        }
                    }
                });
                ws.send(JSON.stringify({
                    type: 'connected',
                    message: 'Connected to real-time server',
                    timestamp: new Date().toISOString()
                }));
            }
            catch (error) {
                ws.close(1008, 'Authentication failed');
            }
        }));
    }
    setupHeartbeat() {
        setInterval(() => {
            this.wss.clients.forEach((ws) => {
                if (ws.isAlive === false) {
                    return ws.terminate();
                }
                ws.isAlive = false;
                ws.ping();
            });
        }, 30000);
    }
    handleClientMessage(ws, message) {
        console.log('Received message from client:', message);
        switch (message.type) {
            case 'ping':
                ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
                break;
            case 'subscribe':
                break;
            default:
                console.log('Unknown message type:', message.type);
        }
    }
    broadcastToTenant(tenantId, data) {
        const tenantClients = this.clients.get(tenantId);
        if (!tenantClients)
            return;
        const message = JSON.stringify(data);
        tenantClients.forEach((client) => {
            if (client.readyState === ws_1.WebSocket.OPEN) {
                client.send(message);
            }
        });
    }
    broadcastToAll(data) {
        const message = JSON.stringify(data);
        this.wss.clients.forEach((client) => {
            if (client.readyState === ws_1.WebSocket.OPEN) {
                client.send(message);
            }
        });
    }
    getTenantConnectionCount(tenantId) {
        var _a;
        return ((_a = this.clients.get(tenantId)) === null || _a === void 0 ? void 0 : _a.size) || 0;
    }
    getTotalConnectionCount() {
        return this.wss.clients.size;
    }
}
exports.RealtimeServer = RealtimeServer;
let realtimeServer;
function initializeWebSocketServer(server) {
    realtimeServer = new RealtimeServer(server);
    console.log('✅ WebSocket server initialized');
    return realtimeServer;
}
function getRealtimeServer() {
    if (!realtimeServer) {
        throw new Error('WebSocket server not initialized');
    }
    return realtimeServer;
}
