"use strict";
/**
 * Database Helper
 * Provides tenant-aware database query functions
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryWithTenant = queryWithTenant;
exports.transactionWithTenant = transactionWithTenant;
const database_1 = __importDefault(require("./database"));
/**
 * Execute a query with tenant schema context
 * This ensures the query runs in the correct tenant schema
 */
function queryWithTenant(tenantId, queryText, values) {
    return __awaiter(this, void 0, void 0, function* () {
        const client = yield database_1.default.connect();
        try {
            // Set the schema context for this connection
            yield client.query(`SET search_path TO "${tenantId}", public`);
            // Execute the actual query
            const result = yield client.query(queryText, values);
            return {
                rows: result.rows,
                rowCount: result.rowCount || 0
            };
        }
        finally {
            // Always release the client back to the pool
            client.release();
        }
    });
}
/**
 * Execute multiple queries in a transaction with tenant schema context
 */
function transactionWithTenant(tenantId, callback) {
    return __awaiter(this, void 0, void 0, function* () {
        const client = yield database_1.default.connect();
        try {
            yield client.query('BEGIN');
            yield client.query(`SET search_path TO "${tenantId}", public`);
            const result = yield callback(client);
            yield client.query('COMMIT');
            return result;
        }
        catch (error) {
            yield client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    });
}
