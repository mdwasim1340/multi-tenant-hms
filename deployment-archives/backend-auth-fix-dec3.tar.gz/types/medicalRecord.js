"use strict";
/**
 * Team Alpha - Medical Record Types
 * TypeScript interfaces for medical records system
 */
Object.defineProperty(exports, "__esModule", { value: true });
