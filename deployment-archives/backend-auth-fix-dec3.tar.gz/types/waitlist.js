"use strict";
/**
 * Team Alpha - Waitlist Types
 * TypeScript interfaces for appointment waitlist
 */
Object.defineProperty(exports, "__esModule", { value: true });
