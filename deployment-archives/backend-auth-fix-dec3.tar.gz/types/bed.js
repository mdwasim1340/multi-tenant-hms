"use strict";
/**
 * Bed Management Type Definitions
 * Complete TypeScript interfaces for bed management system
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DepartmentNotFoundError = exports.InvalidTransferError = exports.BedAssignmentConflictError = exports.BedUnavailableError = exports.BedNotFoundError = void 0;
class BedNotFoundError extends Error {
    constructor(bedId) {
        super(`Bed with ID ${bedId} not found`);
        this.code = 'BED_NOT_FOUND';
        this.name = 'BedNotFoundError';
    }
}
exports.BedNotFoundError = BedNotFoundError;
class BedUnavailableError extends Error {
    constructor(bedId, reason) {
        super(`Bed ${bedId} is unavailable: ${reason}`);
        this.code = 'BED_UNAVAILABLE';
        this.name = 'BedUnavailableError';
    }
}
exports.BedUnavailableError = BedUnavailableError;
class BedAssignmentConflictError extends Error {
    constructor(bedId) {
        super(`Bed ${bedId} already has an active assignment`);
        this.code = 'BED_ASSIGNMENT_CONFLICT';
        this.name = 'BedAssignmentConflictError';
    }
}
exports.BedAssignmentConflictError = BedAssignmentConflictError;
class InvalidTransferError extends Error {
    constructor(message) {
        super(message);
        this.code = 'INVALID_TRANSFER';
        this.name = 'InvalidTransferError';
    }
}
exports.InvalidTransferError = InvalidTransferError;
class DepartmentNotFoundError extends Error {
    constructor(departmentId) {
        super(`Department with ID ${departmentId} not found`);
        this.code = 'DEPARTMENT_NOT_FOUND';
        this.name = 'DepartmentNotFoundError';
    }
}
exports.DepartmentNotFoundError = DepartmentNotFoundError;
