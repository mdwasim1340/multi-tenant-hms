"use strict";
// Note Template Types and Interfaces
// Requirements: 2.4 - Template support for clinical notes
Object.defineProperty(exports, "__esModule", { value: true });
exports.TEMPLATE_CATEGORIES = void 0;
// Template categories
exports.TEMPLATE_CATEGORIES = [
    'General',
    'Follow-up',
    'Specialist',
    'Discharge',
    'Admission',
    'Procedure',
    'Consultation',
    'Emergency',
    'Other'
];
