"use strict";
/**
 * Team Alpha - Recurring Appointment Types
 * TypeScript interfaces for recurring appointments
 */
Object.defineProperty(exports, "__esModule", { value: true });
