"use strict";
/**
 * Team Alpha - Audit Trail Types
 * TypeScript interfaces for audit logging system
 */
Object.defineProperty(exports, "__esModule", { value: true });
