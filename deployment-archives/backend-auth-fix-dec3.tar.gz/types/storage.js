"use strict";
/**
 * Team Alpha - Storage Cost Monitoring Types
 * TypeScript interfaces for storage cost tracking system
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3_PRICING = void 0;
// S3 pricing per GB per month (US East 1)
exports.S3_PRICING = {
    STANDARD: 0.023,
    STANDARD_IA: 0.0125,
    INTELLIGENT_TIERING: 0.0125, // Average between frequent and infrequent
    GLACIER: 0.004,
    DEEP_ARCHIVE: 0.00099,
};
