"use strict";
// Clinical Note Types and Interfaces
// Requirements: 2.1, 2.2 - Clinical note data structures
Object.defineProperty(exports, "__esModule", { value: true });
