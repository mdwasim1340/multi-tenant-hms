"use strict";
/**
 * Team Alpha - Medical Record Template Types
 * TypeScript interfaces for medical record templates
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FIELD_TYPE_CONFIG = exports.TEMPLATE_TYPES = exports.MEDICAL_SPECIALTIES = void 0;
// Common medical specialties
exports.MEDICAL_SPECIALTIES = [
    'general',
    'cardiology',
    'neurology',
    'orthopedics',
    'pediatrics',
    'psychiatry',
    'dermatology',
    'gastroenterology',
    'pulmonology',
    'endocrinology',
    'oncology',
    'urology',
    'gynecology',
    'ophthalmology',
    'otolaryngology',
    'emergency',
    'surgery',
    'anesthesiology',
    'radiology',
    'pathology'
];
// Common template types with descriptions
exports.TEMPLATE_TYPES = {
    consultation: 'Initial consultation or new patient visit',
    follow_up: 'Follow-up visit for existing condition',
    emergency: 'Emergency department visit',
    procedure: 'Medical procedure documentation',
    discharge: 'Hospital discharge summary',
    admission: 'Hospital admission note',
    progress_note: 'Daily progress note',
    operative_note: 'Surgical procedure note'
};
// Field type configurations
exports.FIELD_TYPE_CONFIG = {
    text: {
        component: 'input',
        props: { type: 'text' },
        validation: ['minLength', 'maxLength', 'pattern']
    },
    textarea: {
        component: 'textarea',
        props: { rows: 4 },
        validation: ['minLength', 'maxLength']
    },
    number: {
        component: 'input',
        props: { type: 'number' },
        validation: ['min', 'max']
    },
    select: {
        component: 'select',
        props: {},
        validation: []
    },
    multiselect: {
        component: 'multiselect',
        props: {},
        validation: []
    },
    checkbox: {
        component: 'checkbox',
        props: {},
        validation: []
    },
    radio: {
        component: 'radio',
        props: {},
        validation: []
    },
    date: {
        component: 'input',
        props: { type: 'date' },
        validation: ['min', 'max']
    },
    datetime: {
        component: 'input',
        props: { type: 'datetime-local' },
        validation: ['min', 'max']
    },
    time: {
        component: 'input',
        props: { type: 'time' },
        validation: ['min', 'max']
    },
    object: {
        component: 'fieldset',
        props: {},
        validation: []
    },
    array: {
        component: 'array',
        props: {},
        validation: []
    }
};
