"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MedicalRecordSearchSchema = exports.CreatePrescriptionSchema = exports.CreateTreatmentSchema = exports.CreateDiagnosisSchema = exports.UpdateMedicalRecordSchema = exports.CreateMedicalRecordSchema = exports.ReviewOfSystemsSchema = exports.VitalSignsSchema = void 0;
const zod_1 = require("zod");
// Vital Signs Schema
exports.VitalSignsSchema = zod_1.z.object({
    temperature: zod_1.z.string().optional(),
    temperature_unit: zod_1.z.enum(['F', 'C']).optional(),
    blood_pressure_systolic: zod_1.z.string().optional(),
    blood_pressure_diastolic: zod_1.z.string().optional(),
    heart_rate: zod_1.z.string().optional(),
    respiratory_rate: zod_1.z.string().optional(),
    oxygen_saturation: zod_1.z.string().optional(),
    weight: zod_1.z.string().optional(),
    weight_unit: zod_1.z.enum(['kg', 'lbs']).optional(),
    height: zod_1.z.string().optional(),
    height_unit: zod_1.z.enum(['cm', 'in']).optional(),
    bmi: zod_1.z.string().optional()
});
// Review of Systems Schema
exports.ReviewOfSystemsSchema = zod_1.z.object({
    constitutional: zod_1.z.string().optional(),
    eyes: zod_1.z.string().optional(),
    ears_nose_throat: zod_1.z.string().optional(),
    cardiovascular: zod_1.z.string().optional(),
    respiratory: zod_1.z.string().optional(),
    gastrointestinal: zod_1.z.string().optional(),
    genitourinary: zod_1.z.string().optional(),
    musculoskeletal: zod_1.z.string().optional(),
    skin: zod_1.z.string().optional(),
    neurological: zod_1.z.string().optional(),
    psychiatric: zod_1.z.string().optional(),
    endocrine: zod_1.z.string().optional(),
    hematologic: zod_1.z.string().optional(),
    allergic_immunologic: zod_1.z.string().optional()
});
// Create Medical Record Schema
exports.CreateMedicalRecordSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    appointment_id: zod_1.z.number().int().positive().optional(),
    doctor_id: zod_1.z.number().int().positive(),
    visit_date: zod_1.z.string().datetime().or(zod_1.z.date()),
    chief_complaint: zod_1.z.string().max(1000).optional(),
    history_of_present_illness: zod_1.z.string().optional(),
    review_of_systems: exports.ReviewOfSystemsSchema.optional(),
    vital_signs: exports.VitalSignsSchema.optional(),
    physical_examination: zod_1.z.string().optional(),
    assessment: zod_1.z.string().optional(),
    plan: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    follow_up_required: zod_1.z.boolean().optional(),
    follow_up_date: zod_1.z.string().date().optional(),
    follow_up_instructions: zod_1.z.string().optional()
});
// Update Medical Record Schema
exports.UpdateMedicalRecordSchema = zod_1.z.object({
    chief_complaint: zod_1.z.string().max(1000).optional(),
    history_of_present_illness: zod_1.z.string().optional(),
    review_of_systems: exports.ReviewOfSystemsSchema.optional(),
    vital_signs: exports.VitalSignsSchema.optional(),
    physical_examination: zod_1.z.string().optional(),
    assessment: zod_1.z.string().optional(),
    plan: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    follow_up_required: zod_1.z.boolean().optional(),
    follow_up_date: zod_1.z.string().date().optional(),
    follow_up_instructions: zod_1.z.string().optional(),
    status: zod_1.z.enum(['draft', 'finalized', 'amended']).optional()
});
// Create Diagnosis Schema
exports.CreateDiagnosisSchema = zod_1.z.object({
    medical_record_id: zod_1.z.number().int().positive(),
    diagnosis_code: zod_1.z.string().max(20).optional(),
    diagnosis_name: zod_1.z.string().min(1).max(500),
    diagnosis_type: zod_1.z.enum(['primary', 'secondary', 'differential']).optional(),
    severity: zod_1.z.enum(['mild', 'moderate', 'severe', 'critical']).optional(),
    status: zod_1.z.enum(['active', 'resolved', 'chronic']).optional(),
    onset_date: zod_1.z.string().date().optional(),
    notes: zod_1.z.string().optional()
});
// Create Treatment Schema
exports.CreateTreatmentSchema = zod_1.z.object({
    medical_record_id: zod_1.z.number().int().positive(),
    treatment_type: zod_1.z.string().min(1).max(100),
    treatment_name: zod_1.z.string().min(1).max(500),
    description: zod_1.z.string().optional(),
    start_date: zod_1.z.string().date(),
    end_date: zod_1.z.string().date().optional(),
    frequency: zod_1.z.string().max(100).optional(),
    dosage: zod_1.z.string().max(200).optional(),
    route: zod_1.z.string().max(100).optional(),
    duration: zod_1.z.string().max(100).optional(),
    instructions: zod_1.z.string().optional()
});
// Create Prescription Schema
exports.CreatePrescriptionSchema = zod_1.z.object({
    medical_record_id: zod_1.z.number().int().positive(),
    patient_id: zod_1.z.number().int().positive(),
    doctor_id: zod_1.z.number().int().positive(),
    medication_name: zod_1.z.string().min(1).max(500),
    medication_code: zod_1.z.string().max(50).optional(),
    dosage: zod_1.z.string().min(1).max(200),
    frequency: zod_1.z.string().min(1).max(100),
    route: zod_1.z.string().min(1).max(100),
    duration: zod_1.z.string().max(100).optional(),
    quantity: zod_1.z.number().int().positive().optional(),
    refills: zod_1.z.number().int().min(0).max(12).optional(),
    instructions: zod_1.z.string().optional(),
    indication: zod_1.z.string().optional(),
    prescribed_date: zod_1.z.string().date().optional(),
    start_date: zod_1.z.string().date().optional(),
    end_date: zod_1.z.string().date().optional()
});
// Search Schema
exports.MedicalRecordSearchSchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().positive().default(1),
    limit: zod_1.z.coerce.number().int().positive().max(100).default(10),
    patient_id: zod_1.z.coerce.number().int().positive().optional(),
    doctor_id: zod_1.z.coerce.number().int().positive().optional(),
    status: zod_1.z.enum(['draft', 'finalized', 'amended']).optional(),
    date_from: zod_1.z.string().date().optional(),
    date_to: zod_1.z.string().date().optional(),
    search: zod_1.z.string().optional(),
    sort_by: zod_1.z.enum(['visit_date', 'created_at', 'updated_at']).default('visit_date'),
    sort_order: zod_1.z.enum(['asc', 'desc']).default('desc')
});
