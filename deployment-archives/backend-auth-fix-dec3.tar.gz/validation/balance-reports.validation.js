"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportRequestSchema = exports.AuditStatisticsQuerySchema = exports.AuditLogsQuerySchema = exports.CashFlowQuerySchema = exports.BalanceSheetQuerySchema = exports.ProfitLossQuerySchema = exports.AuditActionSchema = exports.ExportFormatSchema = exports.ComparisonTypeSchema = exports.ReportTypeSchema = void 0;
const zod_1 = require("zod");
/**
 * Balance Reports Validation Schemas
 *
 * Zod schemas for validating balance report API requests.
 * Ensures data integrity and provides clear error messages.
 *
 * Requirements: 4.3, 14.1
 */
// ==================
// Enum Schemas
// ==================
exports.ReportTypeSchema = zod_1.z.enum(['profit_loss', 'balance_sheet', 'cash_flow']);
exports.ComparisonTypeSchema = zod_1.z.enum(['previous-period', 'year-over-year']);
exports.ExportFormatSchema = zod_1.z.enum(['csv', 'excel', 'pdf']);
exports.AuditActionSchema = zod_1.z.enum(['generate', 'view', 'export']);
// ==================
// Date Validation Helpers
// ==================
/**
 * Validates ISO 8601 date format (YYYY-MM-DD)
 */
const ISO8601DateSchema = zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in ISO 8601 format (YYYY-MM-DD)').refine((date) => {
    const parsed = new Date(date);
    return !isNaN(parsed.getTime());
}, 'Invalid date value');
/**
 * Validates that end_date is after start_date
 */
const validateDateRange = (data) => {
    const start = new Date(data.start_date);
    const end = new Date(data.end_date);
    return end >= start;
};
// ==================
// Profit & Loss Query Schema
// ==================
exports.ProfitLossQuerySchema = zod_1.z.object({
    start_date: ISO8601DateSchema,
    end_date: ISO8601DateSchema,
    department_id: zod_1.z.string().regex(/^\d+$/, 'department_id must be a valid number').optional(),
    enable_comparison: zod_1.z.enum(['true', 'false']).optional(),
    comparison_type: exports.ComparisonTypeSchema.optional()
}).refine(validateDateRange, {
    message: 'end_date must be on or after start_date',
    path: ['end_date']
}).refine((data) => {
    // If comparison is enabled, comparison_type must be provided
    if (data.enable_comparison === 'true' && !data.comparison_type) {
        return false;
    }
    return true;
}, {
    message: 'comparison_type is required when enable_comparison is true',
    path: ['comparison_type']
});
// ==================
// Balance Sheet Query Schema
// ==================
exports.BalanceSheetQuerySchema = zod_1.z.object({
    as_of_date: ISO8601DateSchema,
    department_id: zod_1.z.string().regex(/^\d+$/, 'department_id must be a valid number').optional(),
    enable_comparison: zod_1.z.enum(['true', 'false']).optional(),
    comparison_date: ISO8601DateSchema.optional()
}).refine((data) => {
    // If comparison is enabled, comparison_date must be provided
    if (data.enable_comparison === 'true' && !data.comparison_date) {
        return false;
    }
    return true;
}, {
    message: 'comparison_date is required when enable_comparison is true',
    path: ['comparison_date']
}).refine((data) => {
    // If comparison_date is provided, it must be before as_of_date
    if (data.comparison_date) {
        const asOf = new Date(data.as_of_date);
        const comparison = new Date(data.comparison_date);
        return comparison < asOf;
    }
    return true;
}, {
    message: 'comparison_date must be before as_of_date',
    path: ['comparison_date']
});
// ==================
// Cash Flow Query Schema
// ==================
exports.CashFlowQuerySchema = zod_1.z.object({
    start_date: ISO8601DateSchema,
    end_date: ISO8601DateSchema,
    department_id: zod_1.z.string().regex(/^\d+$/, 'department_id must be a valid number').optional(),
    enable_comparison: zod_1.z.enum(['true', 'false']).optional(),
    comparison_type: exports.ComparisonTypeSchema.optional()
}).refine(validateDateRange, {
    message: 'end_date must be on or after start_date',
    path: ['end_date']
}).refine((data) => {
    // If comparison is enabled, comparison_type must be provided
    if (data.enable_comparison === 'true' && !data.comparison_type) {
        return false;
    }
    return true;
}, {
    message: 'comparison_type is required when enable_comparison is true',
    path: ['comparison_type']
});
// ==================
// Audit Logs Query Schema
// ==================
exports.AuditLogsQuerySchema = zod_1.z.object({
    user_id: zod_1.z.string().min(1).optional(),
    report_type: exports.ReportTypeSchema.optional(),
    action: exports.AuditActionSchema.optional(),
    start_date: ISO8601DateSchema.optional(),
    end_date: ISO8601DateSchema.optional(),
    page: zod_1.z.string().regex(/^\d+$/, 'page must be a positive number').optional(),
    limit: zod_1.z.string().regex(/^\d+$/, 'limit must be a positive number').optional()
}).refine((data) => {
    // If both dates are provided, validate range
    if (data.start_date && data.end_date) {
        return validateDateRange({
            start_date: data.start_date,
            end_date: data.end_date
        });
    }
    return true;
}, {
    message: 'end_date must be on or after start_date',
    path: ['end_date']
}).refine((data) => {
    // Validate page number range
    if (data.page) {
        const page = parseInt(data.page);
        return page >= 1 && page <= 10000;
    }
    return true;
}, {
    message: 'page must be between 1 and 10000',
    path: ['page']
}).refine((data) => {
    // Validate limit range
    if (data.limit) {
        const limit = parseInt(data.limit);
        return limit >= 1 && limit <= 1000;
    }
    return true;
}, {
    message: 'limit must be between 1 and 1000',
    path: ['limit']
});
// ==================
// Audit Statistics Query Schema
// ==================
exports.AuditStatisticsQuerySchema = zod_1.z.object({
    start_date: ISO8601DateSchema.optional(),
    end_date: ISO8601DateSchema.optional()
}).refine((data) => {
    // If both dates are provided, validate range
    if (data.start_date && data.end_date) {
        return validateDateRange({
            start_date: data.start_date,
            end_date: data.end_date
        });
    }
    return true;
}, {
    message: 'end_date must be on or after start_date',
    path: ['end_date']
});
// ==================
// Export Request Body Schema
// ==================
exports.ExportRequestSchema = zod_1.z.object({
    report_type: exports.ReportTypeSchema,
    format: exports.ExportFormatSchema,
    report_data: zod_1.z.record(zod_1.z.string(), zod_1.z.any())
});
