"use strict";
/**
 * Bed Controller
 * HTTP request handlers for bed management endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkBedAvailability = exports.getAvailableBeds = exports.getBedOccupancy = exports.deleteBed = exports.updateBed = exports.createBed = exports.getBedById = exports.getBeds = void 0;
const bed_service_1 = __importDefault(require("../services/bed.service"));
const bed_availability_service_1 = __importDefault(require("../services/bed-availability.service"));
const bed_validation_1 = require("../validation/bed.validation");
const bed_1 = require("../types/bed");
/**
 * GET /api/beds
 * List beds with filtering and pagination
 */
const getBeds = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Validate query parameters
        const params = bed_validation_1.BedSearchSchema.parse(req.query);
        console.log('🔍 BACKEND - getBeds called with params:', {
            limit: params.limit,
            page: params.page,
            rawQuery: req.query
        });
        const result = yield bed_service_1.default.getBeds(tenantId, params);
        console.log('🔍 BACKEND - getBeds returning:', {
            bedsCount: result.beds.length,
            total: result.pagination.total,
            limit: result.pagination.limit
        });
        res.json(result);
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Get beds error:', error);
        res.status(500).json({
            error: 'Failed to fetch beds',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBeds = getBeds;
/**
 * GET /api/beds/:id
 * Get bed by ID
 */
const getBedById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.id);
        if (isNaN(bedId)) {
            return res.status(400).json({ error: 'Invalid bed ID' });
        }
        const bed = yield bed_service_1.default.getBedById(tenantId, bedId);
        res.json({ bed });
    }
    catch (error) {
        if (error instanceof bed_1.BedNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Get bed error:', error);
        res.status(500).json({
            error: 'Failed to fetch bed',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedById = getBedById;
/**
 * POST /api/beds
 * Create new bed
 */
const createBed = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        // Validate request body
        const data = bed_validation_1.CreateBedSchema.parse(req.body);
        const bed = yield bed_service_1.default.createBed(tenantId, data, userId);
        res.status(201).json({
            message: 'Bed created successfully',
            bed,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Create bed error:', error);
        res.status(500).json({
            error: 'Failed to create bed',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.createBed = createBed;
/**
 * PUT /api/beds/:id
 * Update bed
 */
const updateBed = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(bedId)) {
            return res.status(400).json({ error: 'Invalid bed ID' });
        }
        // Validate request body
        const data = bed_validation_1.UpdateBedSchema.parse(req.body);
        const bed = yield bed_service_1.default.updateBed(tenantId, bedId, data, userId);
        res.json({
            message: 'Bed updated successfully',
            bed,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        if (error instanceof bed_1.BedNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Update bed error:', error);
        res.status(500).json({
            error: 'Failed to update bed',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.updateBed = updateBed;
/**
 * DELETE /api/beds/:id
 * Delete bed (soft delete)
 */
const deleteBed = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (isNaN(bedId)) {
            return res.status(400).json({ error: 'Invalid bed ID' });
        }
        yield bed_service_1.default.deleteBed(tenantId, bedId, userId);
        res.json({
            message: 'Bed deleted successfully',
        });
    }
    catch (error) {
        if (error instanceof bed_1.BedNotFoundError) {
            return res.status(404).json({
                error: error.message,
                code: error.code,
            });
        }
        console.error('Delete bed error:', error);
        res.status(500).json({
            error: 'Failed to delete bed',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.deleteBed = deleteBed;
/**
 * GET /api/beds/occupancy
 * Get bed occupancy metrics
 */
const getBedOccupancy = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const metrics = yield bed_service_1.default.getBedOccupancy(tenantId);
        res.json({
            occupancy: metrics,
        });
    }
    catch (error) {
        console.error('Get occupancy error:', error);
        res.status(500).json({
            error: 'Failed to fetch occupancy metrics',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getBedOccupancy = getBedOccupancy;
/**
 * GET /api/beds/available
 * Get available beds
 */
const getAvailableBeds = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        // Validate query parameters
        const query = bed_validation_1.AvailableBedsQuerySchema.parse(req.query);
        const beds = yield bed_availability_service_1.default.getAvailableBeds(tenantId, query);
        res.json({
            beds,
            count: beds.length,
        });
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ZodError') {
            return res.status(400).json({
                error: 'Validation error',
                details: error,
            });
        }
        console.error('Get available beds error:', error);
        res.status(500).json({
            error: 'Failed to fetch available beds',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.getAvailableBeds = getAvailableBeds;
/**
 * GET /api/beds/:id/availability
 * Check bed availability
 */
const checkBedAvailability = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const bedId = parseInt(req.params.id);
        if (isNaN(bedId)) {
            return res.status(400).json({ error: 'Invalid bed ID' });
        }
        const availability = yield bed_availability_service_1.default.checkBedAvailable(tenantId, bedId);
        res.json(availability);
    }
    catch (error) {
        console.error('Check availability error:', error);
        res.status(500).json({
            error: 'Failed to check bed availability',
            message: error instanceof Error ? error.message : 'Unknown error',
        });
    }
});
exports.checkBedAvailability = checkBedAvailability;
