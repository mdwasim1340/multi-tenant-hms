"use strict";
/**
 * Team Alpha - Audit Controller
 * HTTP handlers for audit trail endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listAuditLogs = listAuditLogs;
exports.getAuditLog = getAuditLog;
exports.getResourceAuditLog = getResourceAuditLog;
exports.getAuditStats = getAuditStats;
exports.exportAuditLogsCSV = exportAuditLogsCSV;
const audit_service_1 = require("../services/audit.service");
/**
 * GET /api/audit-logs
 * List audit logs with filters and pagination
 */
function listAuditLogs(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const filters = {
                tenant_id: tenantId,
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 50,
                user_id: req.query.user_id
                    ? parseInt(req.query.user_id)
                    : undefined,
                action: req.query.action,
                resource_type: req.query.resource_type,
                resource_id: req.query.resource_id
                    ? parseInt(req.query.resource_id)
                    : undefined,
                date_from: req.query.date_from,
                date_to: req.query.date_to,
                search: req.query.search,
            };
            const result = yield (0, audit_service_1.getAuditLogs)(filters);
            res.json(result);
        }
        catch (error) {
            console.error('Error listing audit logs:', error);
            res.status(500).json({
                error: 'Failed to list audit logs',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/audit-logs/:id
 * Get a specific audit log by ID
 */
function getAuditLog(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const id = parseInt(req.params.id);
            const log = yield (0, audit_service_1.getAuditLogById)(id, tenantId);
            if (!log) {
                res.status(404).json({
                    error: 'Audit log not found',
                });
                return;
            }
            res.json(log);
        }
        catch (error) {
            console.error('Error getting audit log:', error);
            res.status(500).json({
                error: 'Failed to get audit log',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/audit-logs/resource/:resourceType/:resourceId
 * Get audit logs for a specific resource
 */
function getResourceAuditLog(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const resourceType = req.params.resourceType;
            const resourceId = parseInt(req.params.resourceId);
            const logs = yield (0, audit_service_1.getResourceAuditLogs)(tenantId, resourceType, resourceId);
            res.json({
                logs,
                total: logs.length,
            });
        }
        catch (error) {
            console.error('Error getting resource audit logs:', error);
            res.status(500).json({
                error: 'Failed to get resource audit logs',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/audit-logs/stats
 * Get audit log statistics
 */
function getAuditStats(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const dateFrom = req.query.date_from;
            const dateTo = req.query.date_to;
            const stats = yield (0, audit_service_1.getAuditLogStats)(tenantId, dateFrom, dateTo);
            res.json(stats);
        }
        catch (error) {
            console.error('Error getting audit stats:', error);
            res.status(500).json({
                error: 'Failed to get audit statistics',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/audit-logs/export
 * Export audit logs to CSV
 */
function exportAuditLogsCSV(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const filters = {
                tenant_id: tenantId,
                user_id: req.query.user_id
                    ? parseInt(req.query.user_id)
                    : undefined,
                action: req.query.action,
                resource_type: req.query.resource_type,
                date_from: req.query.date_from,
                date_to: req.query.date_to,
            };
            const csv = yield (0, audit_service_1.exportAuditLogs)(filters);
            // Set headers for CSV download
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="audit-logs-${tenantId}-${Date.now()}.csv"`);
            // Send CSV with UTF-8 BOM for Excel compatibility
            res.send('\uFEFF' + csv);
        }
        catch (error) {
            console.error('Error exporting audit logs:', error);
            res.status(500).json({
                error: 'Failed to export audit logs',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
