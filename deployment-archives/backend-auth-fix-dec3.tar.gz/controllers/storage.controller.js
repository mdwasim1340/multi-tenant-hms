"use strict";
/**
 * Team Alpha - Storage Cost Controller
 * HTTP handlers for storage cost monitoring endpoints
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentMetrics = getCurrentMetrics;
exports.getMetricsHistory = getMetricsHistory;
exports.getCostBreakdown = getCostBreakdown;
exports.getCostTrendsData = getCostTrendsData;
exports.getCostAlerts = getCostAlerts;
exports.resolveAlert = resolveAlert;
exports.getStorageReport = getStorageReport;
exports.refreshMetrics = refreshMetrics;
exports.logAccess = logAccess;
exports.exportMetrics = exportMetrics;
const cost_service_1 = require("../services/cost.service");
/**
 * GET /api/storage/metrics
 * Get current storage metrics for tenant
 */
function getCurrentMetrics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const metrics = yield (0, cost_service_1.getLatestStorageMetrics)(tenantId);
            if (!metrics) {
                // If no metrics exist, create initial metrics
                const initialMetrics = yield (0, cost_service_1.updateTenantStorageMetrics)(tenantId);
                res.json(initialMetrics);
                return;
            }
            res.json(metrics);
        }
        catch (error) {
            console.error('Error getting current metrics:', error);
            res.status(500).json({
                error: 'Failed to get storage metrics',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/metrics/history
 * Get historical storage metrics
 */
function getMetricsHistory(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const filters = {
                tenant_id: tenantId,
                date_from: req.query.date_from,
                date_to: req.query.date_to,
                limit: req.query.limit ? parseInt(req.query.limit) : 30,
            };
            const metrics = yield (0, cost_service_1.getStorageMetrics)(filters);
            res.json({
                metrics,
                total: metrics.length,
            });
        }
        catch (error) {
            console.error('Error getting metrics history:', error);
            res.status(500).json({
                error: 'Failed to get metrics history',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/costs
 * Get cost breakdown and trends
 */
function getCostBreakdown(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const days = req.query.days ? parseInt(req.query.days) : 30;
            const [currentMetrics, costTrends] = yield Promise.all([
                (0, cost_service_1.getLatestStorageMetrics)(tenantId),
                (0, cost_service_1.getCostTrends)(tenantId, days),
            ]);
            res.json({
                current_metrics: currentMetrics,
                cost_trends: costTrends,
                period_days: days,
            });
        }
        catch (error) {
            console.error('Error getting cost breakdown:', error);
            res.status(500).json({
                error: 'Failed to get cost breakdown',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/trends
 * Get cost trends over time
 */
function getCostTrendsData(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const days = req.query.days ? parseInt(req.query.days) : 30;
            const trends = yield (0, cost_service_1.getCostTrends)(tenantId, days);
            res.json({
                trends,
                period_days: days,
            });
        }
        catch (error) {
            console.error('Error getting cost trends:', error);
            res.status(500).json({
                error: 'Failed to get cost trends',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/alerts
 * Get active cost alerts
 */
function getCostAlerts(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const alerts = yield (0, cost_service_1.getActiveCostAlerts)(tenantId);
            res.json({
                alerts,
                total: alerts.length,
            });
        }
        catch (error) {
            console.error('Error getting cost alerts:', error);
            res.status(500).json({
                error: 'Failed to get cost alerts',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * POST /api/storage/alerts/:id/resolve
 * Resolve a cost alert
 */
function resolveAlert(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const alertId = parseInt(req.params.id);
            yield (0, cost_service_1.resolveCostAlert)(alertId);
            res.json({
                message: 'Alert resolved successfully',
            });
        }
        catch (error) {
            console.error('Error resolving alert:', error);
            res.status(500).json({
                error: 'Failed to resolve alert',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/report
 * Generate comprehensive storage cost report
 */
function getStorageReport(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const report = yield (0, cost_service_1.generateStorageCostReport)(tenantId);
            res.json(report);
        }
        catch (error) {
            console.error('Error generating storage report:', error);
            res.status(500).json({
                error: 'Failed to generate storage report',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * POST /api/storage/refresh
 * Refresh storage metrics (manual trigger)
 */
function refreshMetrics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const metrics = yield (0, cost_service_1.updateTenantStorageMetrics)(tenantId);
            // Check thresholds after update
            const thresholds = {
                warning: req.body.warning_threshold || 50, // $50 warning
                critical: req.body.critical_threshold || 100, // $100 critical
            };
            yield (0, cost_service_1.checkCostThresholds)(tenantId, thresholds);
            res.json({
                message: 'Storage metrics refreshed successfully',
                metrics,
            });
        }
        catch (error) {
            console.error('Error refreshing metrics:', error);
            res.status(500).json({
                error: 'Failed to refresh metrics',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * POST /api/storage/access-log
 * Log file access for optimization
 */
function logAccess(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const tenantId = req.headers['x-tenant-id'];
            const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
            const { file_id, file_path, access_type, file_size_bytes, storage_class, } = req.body;
            if (!file_id || !file_path || !access_type) {
                res.status(400).json({
                    error: 'Missing required fields',
                    required: ['file_id', 'file_path', 'access_type'],
                });
                return;
            }
            const accessLog = yield (0, cost_service_1.logFileAccess)({
                tenant_id: tenantId,
                file_id,
                file_path,
                access_type,
                user_id: userId,
                file_size_bytes,
                storage_class,
            });
            res.json({
                message: 'File access logged successfully',
                access_log: accessLog,
            });
        }
        catch (error) {
            console.error('Error logging file access:', error);
            res.status(500).json({
                error: 'Failed to log file access',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
/**
 * GET /api/storage/export
 * Export storage metrics to CSV
 */
function exportMetrics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const days = req.query.days ? parseInt(req.query.days) : 30;
            const [metrics, trends] = yield Promise.all([
                (0, cost_service_1.getStorageMetrics)({
                    tenant_id: tenantId,
                    limit: 1000,
                }),
                (0, cost_service_1.getCostTrends)(tenantId, days),
            ]);
            // Create CSV content
            const headers = [
                'Date',
                'Total Size (GB)',
                'File Count',
                'Monthly Cost ($)',
                'Storage Cost ($)',
                'Compression Savings (GB)',
                'Compression Ratio',
            ];
            const rows = metrics.map((metric) => [
                metric.recorded_at.toISOString().split('T')[0],
                (metric.total_size_bytes / (1024 * 1024 * 1024)).toFixed(2),
                metric.file_count,
                metric.estimated_monthly_cost.toFixed(2),
                metric.cost_breakdown.storage_cost.toFixed(2),
                metric.compression_savings_bytes
                    ? (metric.compression_savings_bytes / (1024 * 1024 * 1024)).toFixed(2)
                    : '0',
                metric.compression_ratio ? (metric.compression_ratio * 100).toFixed(1) + '%' : '0%',
            ]);
            const csvContent = [headers, ...rows]
                .map((row) => row.map((cell) => `"${cell}"`).join(','))
                .join('\n');
            // Set headers for CSV download
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="storage-metrics-${tenantId}-${Date.now()}.csv"`);
            // Send CSV with UTF-8 BOM for Excel compatibility
            res.send('\uFEFF' + csvContent);
        }
        catch (error) {
            console.error('Error exporting metrics:', error);
            res.status(500).json({
                error: 'Failed to export metrics',
                message: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    });
}
