"use strict";
/**
 * Team Alpha - Waitlist Controller
 * HTTP request handlers for appointment waitlist
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.notifyWaitlistEntry = exports.convertWaitlistToAppointment = exports.removeFromWaitlist = exports.updateWaitlistEntry = exports.getWaitlistEntryById = exports.getWaitlist = exports.addToWaitlist = void 0;
const zod_1 = require("zod");
const waitlist_service_1 = require("../services/waitlist.service");
const errorHandler_1 = require("../middleware/errorHandler");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
});
const waitlistService = new waitlist_service_1.WaitlistService(pool);
// Validation schemas
const AddToWaitlistSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    doctor_id: zod_1.z.number().int().positive(),
    preferred_dates: zod_1.z.array(zod_1.z.string()).optional(),
    preferred_times: zod_1.z.array(zod_1.z.string()).optional(),
    preferred_time_slots: zod_1.z.array(zod_1.z.enum(['morning', 'afternoon', 'evening', 'any'])).optional(),
    duration_minutes: zod_1.z.number().int().positive().default(30),
    appointment_type: zod_1.z.string(),
    priority: zod_1.z.enum(['urgent', 'high', 'normal', 'low']).default('normal'),
    urgency_notes: zod_1.z.string().optional(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
});
const UpdateWaitlistSchema = zod_1.z.object({
    preferred_dates: zod_1.z.array(zod_1.z.string()).optional(),
    preferred_times: zod_1.z.array(zod_1.z.string()).optional(),
    preferred_time_slots: zod_1.z.array(zod_1.z.enum(['morning', 'afternoon', 'evening', 'any'])).optional(),
    duration_minutes: zod_1.z.number().int().positive().optional(),
    appointment_type: zod_1.z.string().optional(),
    priority: zod_1.z.enum(['urgent', 'high', 'normal', 'low']).optional(),
    urgency_notes: zod_1.z.string().optional(),
    chief_complaint: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    special_instructions: zod_1.z.string().optional(),
});
const ConvertToAppointmentSchema = zod_1.z.object({
    appointment_date: zod_1.z.string(),
    duration_minutes: zod_1.z.number().int().positive().optional(),
    notes: zod_1.z.string().optional(),
});
const RemoveFromWaitlistSchema = zod_1.z.object({
    reason: zod_1.z.string().optional(),
});
/**
 * Add patient to waitlist
 * POST /api/appointments/waitlist
 */
exports.addToWaitlist = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const validatedData = AddToWaitlistSchema.parse(req.body);
    const waitlistEntry = yield waitlistService.addToWaitlist(validatedData, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { waitlist_entry: waitlistEntry },
        message: 'Added to waitlist successfully',
    });
}));
/**
 * Get waitlist entries
 * GET /api/appointments/waitlist
 */
exports.getWaitlist = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const doctorId = req.query.doctor_id ? Number(req.query.doctor_id) : undefined;
    const status = req.query.status;
    const priority = req.query.priority;
    const page = req.query.page ? Number(req.query.page) : 1;
    const limit = req.query.limit ? Number(req.query.limit) : 10;
    const offset = (page - 1) * limit;
    // If doctor_id is provided, use getWaitlistByDoctor
    if (doctorId) {
        const result = yield waitlistService.getWaitlistByDoctor(doctorId, tenantId, {
            status,
            priority,
            limit,
            offset,
        });
        res.json({
            success: true,
            data: {
                waitlist_entries: result.entries,
                pagination: {
                    page,
                    limit,
                    total: result.total,
                    pages: Math.ceil(result.total / limit),
                },
            },
        });
    }
    else {
        // For now, return empty array if no doctor_id
        // TODO: Implement general getWaitlist method
        res.json({
            success: true,
            data: {
                waitlist_entries: [],
                pagination: {
                    page,
                    limit,
                    total: 0,
                    pages: 0,
                },
            },
        });
    }
}));
/**
 * Get waitlist entry by ID
 * GET /api/appointments/waitlist/:id
 */
exports.getWaitlistEntryById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const entryId = Number(req.params.id);
    const entry = yield waitlistService.getWaitlistEntryById(entryId, tenantId);
    if (!entry) {
        return res.status(404).json({
            success: false,
            error: 'Waitlist entry not found',
        });
    }
    res.json({
        success: true,
        data: { waitlist_entry: entry },
    });
}));
/**
 * Update waitlist entry
 * PUT /api/appointments/waitlist/:id
 */
exports.updateWaitlistEntry = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const entryId = Number(req.params.id);
    const validatedData = UpdateWaitlistSchema.parse(req.body);
    const updatedEntry = yield waitlistService.updateWaitlistEntry(entryId, validatedData, tenantId, userId);
    res.json({
        success: true,
        data: { waitlist_entry: updatedEntry },
        message: 'Waitlist entry updated successfully',
    });
}));
/**
 * Remove from waitlist
 * DELETE /api/appointments/waitlist/:id
 */
exports.removeFromWaitlist = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const entryId = Number(req.params.id);
    const { reason } = RemoveFromWaitlistSchema.parse(req.body);
    const removedEntry = yield waitlistService.removeFromWaitlist(entryId, reason || 'Cancelled by user', tenantId, userId);
    res.json({
        success: true,
        data: { waitlist_entry: removedEntry },
        message: 'Removed from waitlist successfully',
    });
}));
/**
 * Convert waitlist entry to appointment
 * POST /api/appointments/waitlist/:id/convert
 */
exports.convertWaitlistToAppointment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const entryId = Number(req.params.id);
    const validatedData = ConvertToAppointmentSchema.parse(req.body);
    const result = yield waitlistService.convertToAppointment(entryId, validatedData, tenantId, userId);
    res.json({
        success: true,
        data: {
            waitlist_entry: result.waitlist,
            appointment: result.appointment,
        },
        message: 'Waitlist entry converted to appointment successfully',
    });
}));
/**
 * Notify patient about available slot
 * POST /api/appointments/waitlist/:id/notify
 */
exports.notifyWaitlistEntry = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
    const entryId = Number(req.params.id);
    const notifiedEntry = yield waitlistService.notifyWaitlistEntry(entryId, tenantId, userId);
    res.json({
        success: true,
        data: { waitlist_entry: notifiedEntry },
        message: 'Patient notified successfully',
    });
}));
