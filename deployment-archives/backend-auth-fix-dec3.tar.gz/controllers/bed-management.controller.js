"use strict";
/**
 * Enhanced Bed Management Controller
 * Handles HTTP requests for comprehensive bed management operations
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedManagementController = void 0;
const bed_service_1 = require("../services/bed-service");
const bed_transfer_service_1 = require("../services/bed-transfer.service");
const bed_discharge_service_1 = require("../services/bed-discharge.service");
class BedManagementController {
    constructor(pool) {
        /**
         * GET /api/bed-management/departments/:departmentName/beds
         * Get all beds for a specific department
         */
        this.getDepartmentBeds = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const { departmentName } = req.params;
                // 🔍 DEBUG: Log which endpoint is being called
                console.log(`🔍 [BedManagementController] getDepartmentBeds called for department: ${departmentName}`);
                console.log(`🔍 [BedManagementController] Tenant: ${tenantId}`);
                console.log(`🔍 [BedManagementController] This should filter by category_id`);
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                // ✅ FIXED: Use category-based filtering instead of unit-based
                // Map department name to category ID for consistent filtering
                const categoryId = this.getDepartmentCategoryId(departmentName);
                console.log(`🔍 [BedManagementController] Category ID for ${departmentName}: ${categoryId}`);
                const params = {
                    page: req.query.page ? parseInt(req.query.page) : 1,
                    limit: req.query.limit ? parseInt(req.query.limit) : 50,
                    search: req.query.search,
                    category_id: categoryId, // ✅ Use category_id for filtering
                    bed_type: req.query.bed_type,
                    status: req.query.status,
                    sort_by: req.query.sort_by,
                    sort_order: req.query.sort_order,
                };
                const result = yield this.bedService.getBeds(params, tenantId);
                res.json(result);
            }
            catch (error) {
                console.error('Error fetching department beds:', error);
                res.status(500).json({
                    error: 'Failed to fetch department beds',
                    message: error.message
                });
            }
        });
        /**
         * GET /api/bed-management/departments/:departmentName/stats
         * Get department-specific bed statistics
         */
        this.getDepartmentStats = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const { departmentName } = req.params;
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                // ✅ FIXED: Get department-specific statistics directly from database
                const categoryId = this.getDepartmentCategoryId(departmentName);
                const departmentId = this.getDepartmentIdFromName(departmentName);
                // Set tenant context and get department-specific stats
                yield this.bedService.pool.query(`SET search_path TO "${tenantId}", public`);
                const statsResult = yield this.bedService.pool.query(`
        SELECT
          COUNT(*) as total_beds,
          SUM(CASE WHEN status = 'occupied' THEN 1 ELSE 0 END) as occupied_beds,
          SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_beds,
          SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_beds,
          SUM(CASE WHEN status = 'cleaning' THEN 1 ELSE 0 END) as cleaning_beds
        FROM beds
        WHERE category_id = $1
      `, [categoryId]);
                const stats = statsResult.rows[0];
                const totalBeds = parseInt(stats.total_beds) || 0;
                const occupiedBeds = parseInt(stats.occupied_beds) || 0;
                const availableBeds = parseInt(stats.available_beds) || 0;
                const maintenanceBeds = parseInt(stats.maintenance_beds) || 0;
                const occupancyRate = totalBeds > 0 ? (occupiedBeds / totalBeds) * 100 : 0;
                // Calculate additional metrics
                const avgOccupancyTime = yield this.calculateAvgOccupancyTime(departmentId, tenantId);
                const criticalPatients = yield this.getCriticalPatientsCount(departmentId, tenantId);
                res.json({
                    department_id: departmentId,
                    department_name: this.formatDepartmentName(departmentName),
                    total_beds: totalBeds,
                    occupied_beds: occupiedBeds,
                    available_beds: availableBeds,
                    maintenance_beds: maintenanceBeds,
                    occupancy_rate: Math.round(occupancyRate * 10) / 10, // Round to 1 decimal
                    avgOccupancyTime,
                    criticalPatients
                });
            }
            catch (error) {
                console.error('Error fetching department stats:', error);
                res.status(500).json({
                    error: 'Failed to fetch department stats',
                    message: error.message
                });
            }
        });
        /**
         * GET /api/bed-management/beds/:bedId/history
         * Get bed history
         */
        this.getBedHistory = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const bedId = parseInt(req.params.bedId);
                const limit = req.query.limit ? parseInt(req.query.limit) : 20;
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const history = yield this.dischargeService.getBedHistory(bedId, tenantId, limit);
                res.json({ history });
            }
            catch (error) {
                console.error('Error fetching bed history:', error);
                res.status(500).json({
                    error: 'Failed to fetch bed history',
                    message: error.message
                });
            }
        });
        /**
         * POST /api/bed-management/transfers
         * Create a new patient transfer
         */
        this.createTransfer = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const userId = req.userId;
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const transferData = Object.assign(Object.assign({}, req.body), { performed_by: userId, scheduled_time: req.body.scheduledTime ? new Date(req.body.scheduledTime) : undefined });
                const transfer = yield this.transferService.createBedTransfer(tenantId, transferData);
                res.status(201).json(transfer);
            }
            catch (error) {
                console.error('Error creating transfer:', error);
                res.status(500).json({
                    error: 'Failed to create transfer',
                    message: error.message
                });
            }
        });
        /**
         * POST /api/bed-management/transfers/:transferId/execute
         * Execute a scheduled transfer
         */
        this.executeTransfer = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const userId = req.userId;
                const transferId = parseInt(req.params.transferId);
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const transfer = yield this.transferService.completeBedTransfer(tenantId, transferId, userId);
                res.json(transfer);
            }
            catch (error) {
                console.error('Error executing transfer:', error);
                res.status(500).json({
                    error: 'Failed to execute transfer',
                    message: error.message
                });
            }
        });
        /**
         * GET /api/bed-management/transfers
         * Get transfer history
         */
        this.getTransfers = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const filters = {
                    patient_id: req.query.patientId ? parseInt(req.query.patientId) : undefined,
                    from_bed_id: req.query.bedId ? parseInt(req.query.bedId) : undefined,
                    status: req.query.status,
                    transfer_date_from: req.query.dateFrom,
                    transfer_date_to: req.query.dateTo,
                    page: req.query.page ? parseInt(req.query.page) : 1,
                    limit: req.query.limit ? parseInt(req.query.limit) : 10
                };
                const result = yield this.transferService.getBedTransfers(tenantId, filters);
                res.json(result);
            }
            catch (error) {
                console.error('Error fetching transfers:', error);
                res.status(500).json({
                    error: 'Failed to fetch transfers',
                    message: error.message
                });
            }
        });
        /**
         * POST /api/bed-management/discharges
         * Process patient discharge
         */
        this.dischargePatient = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                const userId = req.userId;
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                if (!userId) {
                    res.status(401).json({ error: 'User authentication required' });
                    return;
                }
                const dischargeData = Object.assign(Object.assign({}, req.body), { performedBy: userId, dischargeDate: new Date(req.body.dischargeDate), followUpDate: req.body.followUpDate ? new Date(req.body.followUpDate) : undefined });
                const discharge = yield this.dischargeService.dischargePatient(dischargeData, tenantId);
                res.status(201).json(discharge);
            }
            catch (error) {
                console.error('Error processing discharge:', error);
                res.status(500).json({
                    error: 'Failed to process discharge',
                    message: error.message
                });
            }
        });
        /**
         * GET /api/bed-management/discharges
         * Get discharge history
         */
        this.getDischarges = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const filters = {
                    patientId: req.query.patientId ? parseInt(req.query.patientId) : undefined,
                    bedId: req.query.bedId ? parseInt(req.query.bedId) : undefined,
                    dischargeType: req.query.dischargeType,
                    dateFrom: req.query.dateFrom ? new Date(req.query.dateFrom) : undefined,
                    dateTo: req.query.dateTo ? new Date(req.query.dateTo) : undefined,
                    limit: req.query.limit ? parseInt(req.query.limit) : undefined,
                    offset: req.query.offset ? parseInt(req.query.offset) : undefined
                };
                const result = yield this.dischargeService.getDischargeHistory(tenantId, filters);
                res.json(result);
            }
            catch (error) {
                console.error('Error fetching discharges:', error);
                res.status(500).json({
                    error: 'Failed to fetch discharges',
                    message: error.message
                });
            }
        });
        /**
         * GET /api/bed-management/available-beds
         * Get available beds for transfer
         */
        this.getAvailableBeds = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const tenantId = req.headers['x-tenant-id'];
                if (!tenantId) {
                    res.status(400).json({ error: 'X-Tenant-ID header is required' });
                    return;
                }
                const departmentId = req.query.departmentId ? parseInt(req.query.departmentId) : undefined;
                const bedType = req.query.bedType;
                const result = yield this.bedService.checkBedAvailability(tenantId, departmentId, bedType);
                res.json(result);
            }
            catch (error) {
                console.error('Error fetching available beds:', error);
                res.status(500).json({
                    error: 'Failed to fetch available beds',
                    message: error.message
                });
            }
        });
        this.bedService = new bed_service_1.BedService(pool);
        this.transferService = new bed_transfer_service_1.BedTransferService();
        this.dischargeService = new bed_discharge_service_1.BedDischargeService(pool);
    }
    /**
     * Helper method to get department ID from name - CORRECTED FOR ACTUAL DATABASE
     */
    getDepartmentIdFromName(departmentName) {
        const departmentMap = {
            'cardiology': 3, // Cardiology department ID from database
            'orthopedics': 4, // Orthopedics department ID
            'neurology': 7, // Neurology department ID
            'pediatrics': 5, // Pediatrics department ID
            'icu': 2, // ICU department ID
            'emergency': 1, // Emergency department ID
            'maternity': 6, // Maternity department ID
            'oncology': 8, // Oncology department ID
            'surgery': 9, // Surgery department ID
            'general': 10 // General Ward department ID
        };
        return departmentMap[departmentName.toLowerCase()] || 1;
    }
    /**
     * Helper method to get category ID from department name - FOR CONSISTENT FILTERING
     */
    getDepartmentCategoryId(departmentName) {
        const categoryMap = {
            'cardiology': 8, // Cardiology category ID
            'icu': 2, // ICU category ID
            'general': 1, // General category ID
            'pediatric': 4, // ✅ FIXED: Add singular form (URL uses this)
            'pediatrics': 4, // Pediatrics category ID (plural form)
            'emergency': 3, // Emergency category ID
            'maternity': 5, // Maternity category ID
            'orthopedic': 9, // ✅ FIXED: Add singular form
            'orthopedics': 9, // Orthopedics category ID (plural form)
            'neurology': 10, // Neurology category ID
            'oncology': 11, // Oncology category ID (if exists)
            'surgery': 12 // Surgery category ID (if exists)
        };
        return categoryMap[departmentName.toLowerCase()];
    }
    /**
     * Helper method to get unit name from department name - CORRECTED FOR ACTUAL DATABASE UNITS
     */
    getDepartmentUnitFromName(departmentName) {
        const unitMap = {
            'cardiology': 'Cardiology', // ✅ FIXED: Map cardiology to Cardiology (actual unit name)
            'orthopedics': 'General', // Map to General ward
            'neurology': 'ICU', // Map to ICU
            'pediatrics': 'Pediatrics', // This exists
            'icu': 'ICU', // This exists
            'emergency': 'General', // Map to General
            'maternity': 'Maternity', // ✅ FIXED: Map to Maternity (now exists)
            'oncology': 'General', // Map to General
            'surgery': 'General', // Map to General
            'general': 'General' // This exists
        };
        return unitMap[departmentName.toLowerCase()] || 'ICU';
    }
    /**
     * Helper method to format department name
     */
    formatDepartmentName(departmentName) {
        return departmentName.charAt(0).toUpperCase() + departmentName.slice(1).replace(/-/g, ' ');
    }
    /**
     * Calculate average occupancy time for a department
     */
    calculateAvgOccupancyTime(departmentId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            // This would calculate the average length of stay for patients in this department
            // For now, return a mock value
            return 4.2;
        });
    }
    /**
     * Get count of critical patients in a department
     */
    getCriticalPatientsCount(departmentId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            // This would count patients with critical condition in the department
            // For now, return a mock value
            return 3;
        });
    }
}
exports.BedManagementController = BedManagementController;
