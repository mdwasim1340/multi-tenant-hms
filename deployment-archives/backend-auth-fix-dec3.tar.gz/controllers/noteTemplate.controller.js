"use strict";
// Note Template Controller
// Requirements: 2.4 - HTTP request handling for templates
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NoteTemplateController = void 0;
const zod_1 = require("zod");
const noteTemplate_1 = require("../types/noteTemplate");
// Validation schemas
const CreateTemplateSchema = zod_1.z.object({
    name: zod_1.z.string().min(1, 'Name is required').max(255),
    category: zod_1.z.string().min(1, 'Category is required'),
    content: zod_1.z.string().min(1, 'Content is required'),
    description: zod_1.z.string().max(500).optional(),
    is_active: zod_1.z.boolean().optional()
});
const UpdateTemplateSchema = zod_1.z.object({
    name: zod_1.z.string().min(1).max(255).optional(),
    category: zod_1.z.string().min(1).optional(),
    content: zod_1.z.string().min(1).optional(),
    description: zod_1.z.string().max(500).optional(),
    is_active: zod_1.z.boolean().optional()
});
const DuplicateTemplateSchema = zod_1.z.object({
    new_name: zod_1.z.string().min(1, 'New name is required').max(255)
});
class NoteTemplateController {
    constructor(noteTemplateService) {
        this.noteTemplateService = noteTemplateService;
        /**
         * Create a new template
         * POST /api/note-templates
         */
        this.createTemplate = (req, res) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const validatedData = CreateTemplateSchema.parse(req.body);
                const createdBy = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
                const template = yield this.noteTemplateService.createTemplate(validatedData, createdBy, req.dbClient);
                res.status(201).json({
                    success: true,
                    data: template
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                console.error('Error creating template:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to create template'
                });
            }
        });
        /**
         * Get template by ID
         * GET /api/note-templates/:id
         */
        this.getTemplateById = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const templateId = parseInt(req.params.id);
                if (isNaN(templateId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid template ID'
                    });
                    return;
                }
                const template = yield this.noteTemplateService.getTemplateById(templateId, req.dbClient);
                if (!template) {
                    res.status(404).json({
                        success: false,
                        error: 'Template not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: template
                });
            }
            catch (error) {
                console.error('Error fetching template:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch template'
                });
            }
        });
        /**
         * Get templates with filtering
         * GET /api/note-templates
         */
        this.getTemplates = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const filters = {
                    category: req.query.category,
                    is_active: req.query.is_active === 'true' ? true : req.query.is_active === 'false' ? false : undefined,
                    search: req.query.search,
                    page: req.query.page ? parseInt(req.query.page) : 1,
                    limit: req.query.limit ? parseInt(req.query.limit) : 50
                };
                const result = yield this.noteTemplateService.getTemplates(filters, req.dbClient);
                res.json({
                    success: true,
                    data: result.templates,
                    pagination: {
                        page: filters.page,
                        limit: filters.limit,
                        total: result.total,
                        pages: Math.ceil(result.total / (filters.limit || 50))
                    }
                });
            }
            catch (error) {
                console.error('Error fetching templates:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch templates'
                });
            }
        });
        /**
         * Get active templates
         * GET /api/note-templates/active
         */
        this.getActiveTemplates = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const templates = yield this.noteTemplateService.getActiveTemplates(req.dbClient);
                res.json({
                    success: true,
                    data: templates
                });
            }
            catch (error) {
                console.error('Error fetching active templates:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch active templates'
                });
            }
        });
        /**
         * Get templates by category
         * GET /api/note-templates/category/:category
         */
        this.getTemplatesByCategory = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const category = req.params.category;
                const templates = yield this.noteTemplateService.getTemplatesByCategory(category, req.dbClient);
                res.json({
                    success: true,
                    data: templates
                });
            }
            catch (error) {
                console.error('Error fetching templates by category:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch templates'
                });
            }
        });
        /**
         * Get template categories
         * GET /api/note-templates/categories
         */
        this.getCategories = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const categories = yield this.noteTemplateService.getCategories(req.dbClient);
                res.json({
                    success: true,
                    data: categories,
                    available_categories: noteTemplate_1.TEMPLATE_CATEGORIES
                });
            }
            catch (error) {
                console.error('Error fetching categories:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch categories'
                });
            }
        });
        /**
         * Update template
         * PUT /api/note-templates/:id
         */
        this.updateTemplate = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const templateId = parseInt(req.params.id);
                if (isNaN(templateId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid template ID'
                    });
                    return;
                }
                const validatedData = UpdateTemplateSchema.parse(req.body);
                const template = yield this.noteTemplateService.updateTemplate(templateId, validatedData, req.dbClient);
                if (!template) {
                    res.status(404).json({
                        success: false,
                        error: 'Template not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: template
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                if (error instanceof Error && error.message === 'Cannot modify system templates') {
                    res.status(403).json({
                        success: false,
                        error: 'Cannot modify system templates'
                    });
                    return;
                }
                console.error('Error updating template:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to update template'
                });
            }
        });
        /**
         * Delete template
         * DELETE /api/note-templates/:id
         */
        this.deleteTemplate = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const templateId = parseInt(req.params.id);
                if (isNaN(templateId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid template ID'
                    });
                    return;
                }
                const deleted = yield this.noteTemplateService.deleteTemplate(templateId, req.dbClient);
                if (!deleted) {
                    res.status(404).json({
                        success: false,
                        error: 'Template not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    message: 'Template deleted successfully'
                });
            }
            catch (error) {
                if (error instanceof Error && error.message === 'Cannot delete system templates') {
                    res.status(403).json({
                        success: false,
                        error: 'Cannot delete system templates'
                    });
                    return;
                }
                console.error('Error deleting template:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to delete template'
                });
            }
        });
        /**
         * Duplicate template
         * POST /api/note-templates/:id/duplicate
         */
        this.duplicateTemplate = (req, res) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const templateId = parseInt(req.params.id);
                if (isNaN(templateId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid template ID'
                    });
                    return;
                }
                const validatedData = DuplicateTemplateSchema.parse(req.body);
                const createdBy = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
                const template = yield this.noteTemplateService.duplicateTemplate(templateId, validatedData.new_name, createdBy, req.dbClient);
                if (!template) {
                    res.status(404).json({
                        success: false,
                        error: 'Template not found'
                    });
                    return;
                }
                res.status(201).json({
                    success: true,
                    data: template
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                console.error('Error duplicating template:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to duplicate template'
                });
            }
        });
    }
}
exports.NoteTemplateController = NoteTemplateController;
