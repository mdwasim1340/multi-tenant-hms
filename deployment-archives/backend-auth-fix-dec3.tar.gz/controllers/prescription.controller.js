"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateExpiredPrescriptions = exports.processRefill = exports.checkDrugInteractions = exports.deletePrescription = exports.discontinuePrescription = exports.updatePrescription = exports.getPatientPrescriptions = exports.getPrescriptions = exports.getPrescription = exports.createPrescription = void 0;
const zod_1 = require("zod");
const prescription_service_1 = require("../services/prescription.service");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'multitenant_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});
const prescriptionService = new prescription_service_1.PrescriptionService(pool);
// Validation schemas
const CreatePrescriptionSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    prescriber_id: zod_1.z.number().int().positive(),
    medication_name: zod_1.z.string().min(1).max(255),
    dosage: zod_1.z.string().min(1).max(100),
    frequency: zod_1.z.string().min(1).max(100),
    route: zod_1.z.string().min(1).max(50),
    duration_days: zod_1.z.number().int().positive(),
    quantity: zod_1.z.number().int().positive(),
    refills: zod_1.z.number().int().min(0),
    instructions: zod_1.z.string().optional(),
    indication: zod_1.z.string().optional(),
    start_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)
});
const UpdatePrescriptionSchema = zod_1.z.object({
    medication_name: zod_1.z.string().min(1).max(255).optional(),
    dosage: zod_1.z.string().min(1).max(100).optional(),
    frequency: zod_1.z.string().min(1).max(100).optional(),
    route: zod_1.z.string().min(1).max(50).optional(),
    duration_days: zod_1.z.number().int().positive().optional(),
    quantity: zod_1.z.number().int().positive().optional(),
    refills: zod_1.z.number().int().min(0).optional(),
    instructions: zod_1.z.string().optional(),
    indication: zod_1.z.string().optional(),
    status: zod_1.z.enum(['active', 'completed', 'discontinued', 'expired']).optional(),
    start_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    end_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional()
});
const DiscontinuePrescriptionSchema = zod_1.z.object({
    reason: zod_1.z.string().min(1)
});
const createPrescription = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        const validated = CreatePrescriptionSchema.parse(req.body);
        const prescription = yield prescriptionService.createPrescription(tenantId, validated, userId);
        res.status(201).json(prescription);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error creating prescription:', error);
        res.status(500).json({ error: 'Failed to create prescription' });
    }
});
exports.createPrescription = createPrescription;
const getPrescription = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prescriptionId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(prescriptionId)) {
            return res.status(400).json({ error: 'Invalid prescription ID' });
        }
        const prescription = yield prescriptionService.getPrescriptionById(tenantId, prescriptionId);
        if (!prescription) {
            return res.status(404).json({ error: 'Prescription not found' });
        }
        res.json(prescription);
    }
    catch (error) {
        console.error('Error fetching prescription:', error);
        res.status(500).json({ error: 'Failed to fetch prescription' });
    }
});
exports.getPrescription = getPrescription;
const getPrescriptions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        const filters = {
            patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
            status: req.query.status,
            medication_name: req.query.medication_name,
            prescriber_id: req.query.prescriber_id ? parseInt(req.query.prescriber_id) : undefined,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 10
        };
        const result = yield prescriptionService.getPrescriptions(tenantId, filters);
        res.json({
            prescriptions: result.prescriptions,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error fetching prescriptions:', error);
        res.status(500).json({ error: 'Failed to fetch prescriptions' });
    }
});
exports.getPrescriptions = getPrescriptions;
const getPatientPrescriptions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        const filters = {
            status: req.query.status,
            medication_name: req.query.medication_name,
            prescriber_id: req.query.prescriber_id ? parseInt(req.query.prescriber_id) : undefined,
            date_from: req.query.date_from,
            date_to: req.query.date_to,
            page: req.query.page ? parseInt(req.query.page) : 1,
            limit: req.query.limit ? parseInt(req.query.limit) : 10
        };
        const result = yield prescriptionService.getPrescriptionsByPatient(tenantId, patientId, filters);
        res.json({
            prescriptions: result.prescriptions,
            pagination: {
                page: filters.page,
                limit: filters.limit,
                total: result.total,
                pages: Math.ceil(result.total / filters.limit)
            }
        });
    }
    catch (error) {
        console.error('Error fetching patient prescriptions:', error);
        res.status(500).json({ error: 'Failed to fetch prescriptions' });
    }
});
exports.getPatientPrescriptions = getPatientPrescriptions;
const updatePrescription = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prescriptionId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(prescriptionId)) {
            return res.status(400).json({ error: 'Invalid prescription ID' });
        }
        const validated = UpdatePrescriptionSchema.parse(req.body);
        const prescription = yield prescriptionService.updatePrescription(tenantId, prescriptionId, validated, userId);
        if (!prescription) {
            return res.status(404).json({ error: 'Prescription not found' });
        }
        res.json(prescription);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error updating prescription:', error);
        res.status(500).json({ error: 'Failed to update prescription' });
    }
});
exports.updatePrescription = updatePrescription;
const discontinuePrescription = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prescriptionId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(prescriptionId)) {
            return res.status(400).json({ error: 'Invalid prescription ID' });
        }
        const validated = DiscontinuePrescriptionSchema.parse(req.body);
        const prescription = yield prescriptionService.discontinuePrescription(tenantId, prescriptionId, validated, userId);
        if (!prescription) {
            return res.status(404).json({ error: 'Prescription not found' });
        }
        res.json(prescription);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return res.status(400).json({ error: 'Validation failed', details: error.issues });
        }
        console.error('Error discontinuing prescription:', error);
        res.status(500).json({ error: 'Failed to discontinue prescription' });
    }
});
exports.discontinuePrescription = discontinuePrescription;
const deletePrescription = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prescriptionId = parseInt(req.params.id);
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(prescriptionId)) {
            return res.status(400).json({ error: 'Invalid prescription ID' });
        }
        const deleted = yield prescriptionService.deletePrescription(tenantId, prescriptionId);
        if (!deleted) {
            return res.status(404).json({ error: 'Prescription not found' });
        }
        res.status(204).send();
    }
    catch (error) {
        console.error('Error deleting prescription:', error);
        res.status(500).json({ error: 'Failed to delete prescription' });
    }
});
exports.deletePrescription = deletePrescription;
const checkDrugInteractions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        const patientId = parseInt(req.params.patientId);
        const medication = req.query.medication;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (isNaN(patientId)) {
            return res.status(400).json({ error: 'Invalid patient ID' });
        }
        if (!medication) {
            return res.status(400).json({ error: 'Medication parameter is required' });
        }
        const result = yield prescriptionService.checkDrugInteractions(tenantId, patientId, medication);
        res.json(result);
    }
    catch (error) {
        console.error('Error checking drug interactions:', error);
        res.status(500).json({ error: 'Failed to check drug interactions' });
    }
});
exports.checkDrugInteractions = checkDrugInteractions;
const processRefill = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const tenantId = req.headers['x-tenant-id'];
        const prescriptionId = parseInt(req.params.id);
        const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        if (!userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if (isNaN(prescriptionId)) {
            return res.status(400).json({ error: 'Invalid prescription ID' });
        }
        const prescription = yield prescriptionService.processRefill(tenantId, prescriptionId, userId);
        if (!prescription) {
            return res.status(404).json({ error: 'Prescription not found' });
        }
        res.json(prescription);
    }
    catch (error) {
        if (error.message === 'No refills remaining') {
            return res.status(400).json({ error: error.message });
        }
        console.error('Error processing refill:', error);
        res.status(500).json({ error: 'Failed to process refill' });
    }
});
exports.processRefill = processRefill;
const updateExpiredPrescriptions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const tenantId = req.headers['x-tenant-id'];
        if (!tenantId) {
            return res.status(400).json({ error: 'X-Tenant-ID header is required' });
        }
        const count = yield prescriptionService.updateExpiredPrescriptions(tenantId);
        res.json({ updated: count });
    }
    catch (error) {
        console.error('Error updating expired prescriptions:', error);
        res.status(500).json({ error: 'Failed to update expired prescriptions' });
    }
});
exports.updateExpiredPrescriptions = updateExpiredPrescriptions;
