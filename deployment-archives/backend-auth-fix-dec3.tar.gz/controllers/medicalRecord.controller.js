"use strict";
/**
 * Team Alpha - Medical Record Controller
 * HTTP request handlers for medical records API
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMedicalRecords = getMedicalRecords;
exports.getMedicalRecordById = getMedicalRecordById;
exports.createMedicalRecord = createMedicalRecord;
exports.updateMedicalRecord = updateMedicalRecord;
exports.deleteMedicalRecord = deleteMedicalRecord;
exports.finalizeMedicalRecord = finalizeMedicalRecord;
exports.getRecordAttachments = getRecordAttachments;
exports.addRecordAttachment = addRecordAttachment;
exports.getUploadUrl = getUploadUrl;
exports.getDownloadUrl = getDownloadUrl;
exports.deleteRecordAttachment = deleteRecordAttachment;
exports.uploadFile = uploadFile;
const medicalRecordService = __importStar(require("../services/medicalRecord.service"));
const s3Service = __importStar(require("../services/s3.service"));
/**
 * GET /api/medical-records
 * List medical records with filters and pagination
 */
function getMedicalRecords(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            const filters = {
                page: req.query.page ? parseInt(req.query.page) : 1,
                limit: req.query.limit ? parseInt(req.query.limit) : 10,
                patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
                doctor_id: req.query.doctor_id ? parseInt(req.query.doctor_id) : undefined,
                status: req.query.status,
                date_from: req.query.date_from,
                date_to: req.query.date_to,
                search: req.query.search,
            };
            const { records, total } = yield medicalRecordService.getMedicalRecords(tenantId, filters);
            const page = filters.page || 1;
            const limit = filters.limit || 10;
            const pages = Math.ceil(total / limit);
            return res.json({
                success: true,
                data: {
                    records,
                    pagination: {
                        page,
                        limit,
                        total,
                        pages,
                        has_next: page < pages,
                        has_prev: page > 1,
                    },
                },
            });
        }
        catch (error) {
            console.error('Error getting medical records:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to get medical records',
                message: error.message,
            });
        }
    });
}
/**
 * GET /api/medical-records/:id
 * Get medical record by ID
 */
function getMedicalRecordById(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            const record = yield medicalRecordService.getMedicalRecordById(tenantId, recordId);
            if (!record) {
                return res.status(404).json({
                    success: false,
                    error: 'Medical record not found',
                });
            }
            // Get attachments
            const attachments = yield medicalRecordService.getRecordAttachments(tenantId, recordId);
            return res.json({
                success: true,
                data: {
                    record,
                    attachments,
                },
            });
        }
        catch (error) {
            console.error('Error getting medical record:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to get medical record',
                message: error.message,
            });
        }
    });
}
/**
 * POST /api/medical-records
 * Create new medical record
 */
function createMedicalRecord(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            const data = req.body;
            // Validate required fields
            if (!data.patient_id || !data.doctor_id || !data.visit_date) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: patient_id, doctor_id, visit_date',
                });
            }
            const record = yield medicalRecordService.createMedicalRecord(tenantId, data);
            return res.status(201).json({
                success: true,
                data: { record },
                message: 'Medical record created successfully',
            });
        }
        catch (error) {
            console.error('Error creating medical record:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to create medical record',
                message: error.message,
            });
        }
    });
}
/**
 * PUT /api/medical-records/:id
 * Update medical record
 */
function updateMedicalRecord(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            const data = req.body;
            const record = yield medicalRecordService.updateMedicalRecord(tenantId, recordId, data);
            if (!record) {
                return res.status(404).json({
                    success: false,
                    error: 'Medical record not found',
                });
            }
            return res.json({
                success: true,
                data: { record },
                message: 'Medical record updated successfully',
            });
        }
        catch (error) {
            console.error('Error updating medical record:', error);
            if (error.message === 'Cannot update finalized medical record') {
                return res.status(403).json({
                    success: false,
                    error: error.message,
                });
            }
            return res.status(500).json({
                success: false,
                error: 'Failed to update medical record',
                message: error.message,
            });
        }
    });
}
/**
 * DELETE /api/medical-records/:id
 * Delete medical record
 */
function deleteMedicalRecord(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            const deleted = yield medicalRecordService.deleteMedicalRecord(tenantId, recordId);
            if (!deleted) {
                return res.status(404).json({
                    success: false,
                    error: 'Medical record not found',
                });
            }
            return res.json({
                success: true,
                message: 'Medical record deleted successfully',
            });
        }
        catch (error) {
            console.error('Error deleting medical record:', error);
            if (error.message === 'Cannot delete finalized medical record') {
                return res.status(403).json({
                    success: false,
                    error: error.message,
                });
            }
            return res.status(500).json({
                success: false,
                error: 'Failed to delete medical record',
                message: error.message,
            });
        }
    });
}
/**
 * POST /api/medical-records/:id/finalize
 * Finalize medical record (lock from further edits)
 */
function finalizeMedicalRecord(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id; // From auth middleware
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: 'User authentication required',
                });
            }
            const record = yield medicalRecordService.finalizeMedicalRecord(tenantId, recordId, userId);
            if (!record) {
                return res.status(404).json({
                    success: false,
                    error: 'Medical record not found or already finalized',
                });
            }
            return res.json({
                success: true,
                data: { record },
                message: 'Medical record finalized successfully',
            });
        }
        catch (error) {
            console.error('Error finalizing medical record:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to finalize medical record',
                message: error.message,
            });
        }
    });
}
/**
 * GET /api/medical-records/:id/attachments
 * Get attachments for a medical record
 */
function getRecordAttachments(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            const attachments = yield medicalRecordService.getRecordAttachments(tenantId, recordId);
            return res.json({
                success: true,
                data: { attachments },
            });
        }
        catch (error) {
            console.error('Error getting attachments:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to get attachments',
                message: error.message,
            });
        }
    });
}
/**
 * POST /api/medical-records/:id/attachments
 * Add attachment to medical record
 */
function addRecordAttachment(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: 'User authentication required',
                });
            }
            const { file_name, file_type, file_size, s3_key, s3_bucket, description } = req.body;
            if (!file_name || !file_type || !file_size || !s3_key || !s3_bucket) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: file_name, file_type, file_size, s3_key, s3_bucket',
                });
            }
            const attachment = yield medicalRecordService.addRecordAttachment(tenantId, recordId, userId, { file_name, file_type, file_size, s3_key, s3_bucket, description });
            return res.status(201).json({
                success: true,
                data: { attachment },
                message: 'Attachment added successfully',
            });
        }
        catch (error) {
            console.error('Error adding attachment:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to add attachment',
                message: error.message,
            });
        }
    });
}
/**
 * POST /api/medical-records/upload-url
 * Get presigned URL for uploading a file
 */
function getUploadUrl(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const { record_id, filename, content_type } = req.body;
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (!record_id || !filename || !content_type) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: record_id, filename, content_type',
                });
            }
            const { uploadUrl, s3Key } = yield s3Service.generateUploadUrl(tenantId, record_id, filename, content_type);
            return res.json({
                success: true,
                data: {
                    uploadUrl,
                    s3Key,
                },
                message: 'Upload URL generated successfully',
            });
        }
        catch (error) {
            console.error('Error generating upload URL:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to generate upload URL',
                message: error.message,
            });
        }
    });
}
/**
 * GET /api/medical-records/download-url/:attachmentId
 * Get presigned URL for downloading a file
 */
function getDownloadUrl(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const attachmentId = parseInt(req.params.attachmentId);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(attachmentId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid attachment ID',
                });
            }
            const attachment = yield medicalRecordService.getAttachmentById(tenantId, attachmentId);
            if (!attachment) {
                return res.status(404).json({
                    success: false,
                    error: 'Attachment not found',
                });
            }
            const downloadUrl = yield s3Service.generateDownloadUrl(attachment.s3_key);
            return res.json({
                success: true,
                data: {
                    downloadUrl,
                    fileName: attachment.file_name,
                    fileType: attachment.file_type,
                    fileSize: attachment.file_size,
                },
                message: 'Download URL generated successfully',
            });
        }
        catch (error) {
            console.error('Error generating download URL:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to generate download URL',
                message: error.message,
            });
        }
    });
}
/**
 * DELETE /api/medical-records/attachments/:attachmentId
 * Delete attachment
 */
function deleteRecordAttachment(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const attachmentId = parseInt(req.params.attachmentId);
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (isNaN(attachmentId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid attachment ID',
                });
            }
            // Get attachment to get S3 key
            const attachment = yield medicalRecordService.getAttachmentById(tenantId, attachmentId);
            if (!attachment) {
                return res.status(404).json({
                    success: false,
                    error: 'Attachment not found',
                });
            }
            // Delete from database
            const deleted = yield medicalRecordService.deleteRecordAttachment(tenantId, attachmentId);
            if (deleted) {
                // Delete from S3
                try {
                    yield s3Service.deleteFile(attachment.s3_key);
                }
                catch (s3Error) {
                    console.error('Error deleting file from S3:', s3Error);
                    // Continue even if S3 deletion fails
                }
            }
            return res.json({
                success: true,
                message: 'Attachment deleted successfully',
            });
        }
        catch (error) {
            console.error('Error deleting attachment:', error);
            return res.status(500).json({
                success: false,
                error: 'Failed to delete attachment',
                message: error.message,
            });
        }
    });
}
/**
 * POST /api/medical-records/:id/upload
 * Upload file directly through backend (avoids CORS issues)
 */
function uploadFile(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const recordId = parseInt(req.params.id);
            const file = req.file;
            console.log('Upload request received:', {
                tenantId,
                recordId,
                hasFile: !!file,
                fileName: file === null || file === void 0 ? void 0 : file.originalname,
                fileSize: file === null || file === void 0 ? void 0 : file.size,
            });
            if (!tenantId) {
                return res.status(400).json({
                    success: false,
                    error: 'X-Tenant-ID header is required',
                });
            }
            if (!file) {
                return res.status(400).json({
                    success: false,
                    error: 'No file uploaded',
                });
            }
            if (isNaN(recordId)) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid record ID',
                });
            }
            // Generate S3 key using timestamp and filename
            const timestamp = Date.now();
            const sanitizedFilename = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
            const s3Key = `${tenantId}/medical-records/${recordId}/${timestamp}-${sanitizedFilename}`;
            console.log('Generated S3 key:', s3Key);
            // Upload to S3 using AWS SDK
            const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
            const s3Client = new S3Client({
                region: process.env.AWS_REGION || 'us-east-1',
                credentials: {
                    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                },
            });
            const bucketName = process.env.S3_BUCKET_NAME || 'multi-tenant-12';
            console.log('Uploading to S3 bucket:', bucketName);
            const command = new PutObjectCommand({
                Bucket: bucketName,
                Key: s3Key,
                Body: file.buffer,
                ContentType: file.mimetype,
                ServerSideEncryption: 'AES256',
                StorageClass: 'INTELLIGENT_TIERING',
                Metadata: {
                    'tenant-id': tenantId,
                    'record-id': String(recordId),
                    'uploaded-at': new Date().toISOString(),
                },
            });
            yield s3Client.send(command);
            console.log('File uploaded to S3 successfully');
            // Add attachment record to database
            const description = req.body.description || '';
            const uploadedBy = 1; // TODO: Get from auth context
            console.log('Adding attachment record to database...');
            const attachment = yield medicalRecordService.addRecordAttachment(tenantId, recordId, uploadedBy, {
                file_name: file.originalname,
                file_type: file.mimetype,
                file_size: file.size,
                s3_key: s3Key,
                s3_bucket: bucketName,
                description,
            });
            console.log('Attachment record created:', attachment.id);
            return res.status(201).json({
                success: true,
                data: attachment,
                message: 'File uploaded successfully',
            });
        }
        catch (error) {
            console.error('Error uploading file - Full error:', error);
            console.error('Error stack:', error.stack);
            return res.status(500).json({
                success: false,
                error: 'Failed to upload file',
                message: error.message,
                details: error.toString(),
            });
        }
    });
}
