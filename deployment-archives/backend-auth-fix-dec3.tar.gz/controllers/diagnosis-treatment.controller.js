"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.discontinueTreatment = exports.createTreatment = exports.createDiagnosis = void 0;
const diagnosis_service_1 = require("../services/diagnosis.service");
const treatment_service_1 = require("../services/treatment.service");
const medical_record_validation_1 = require("../validation/medical-record.validation");
const errorHandler_1 = require("../middleware/errorHandler");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
});
const diagnosisService = new diagnosis_service_1.DiagnosisService(pool);
const treatmentService = new treatment_service_1.TreatmentService(pool);
exports.createDiagnosis = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const validatedData = medical_record_validation_1.CreateDiagnosisSchema.parse(req.body);
    // Convert string dates to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { onset_date: validatedData.onset_date ? new Date(validatedData.onset_date) : undefined });
    const diagnosis = yield diagnosisService.createDiagnosis(data, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { diagnosis },
        message: 'Diagnosis added successfully'
    });
}));
exports.createTreatment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const validatedData = medical_record_validation_1.CreateTreatmentSchema.parse(req.body);
    // Convert string dates to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { start_date: new Date(validatedData.start_date), end_date: validatedData.end_date ? new Date(validatedData.end_date) : undefined });
    const treatment = yield treatmentService.createTreatment(data, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { treatment },
        message: 'Treatment added successfully'
    });
}));
exports.discontinueTreatment = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const treatmentId = parseInt(req.params.id);
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const { reason } = req.body;
    const treatment = yield treatmentService.discontinueTreatment(treatmentId, reason, tenantId, userId);
    res.json({
        success: true,
        data: { treatment },
        message: 'Treatment discontinued successfully'
    });
}));
