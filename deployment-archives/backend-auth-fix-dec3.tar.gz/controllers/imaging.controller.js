"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getImagingStudyById = exports.createImagingStudy = void 0;
const imaging_service_1 = require("../services/imaging.service");
const lab_test_validation_1 = require("../validation/lab-test.validation");
const errorHandler_1 = require("../middleware/errorHandler");
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
});
const imagingService = new imaging_service_1.ImagingService(pool);
exports.createImagingStudy = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const tenantId = req.headers['x-tenant-id'];
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a.id) || 1;
    const validatedData = lab_test_validation_1.CreateImagingStudySchema.parse(req.body);
    // Convert date strings to Date objects
    const data = Object.assign(Object.assign({}, validatedData), { scheduled_date: validatedData.scheduled_date
            ? new Date(validatedData.scheduled_date)
            : undefined });
    const study = yield imagingService.createImagingStudy(data, tenantId, userId);
    res.status(201).json({
        success: true,
        data: { study },
        message: 'Imaging study ordered successfully'
    });
}));
exports.getImagingStudyById = (0, errorHandler_1.asyncHandler)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const tenantId = req.headers['x-tenant-id'];
    const studyId = parseInt(req.params.id);
    const study = yield imagingService.getImagingStudyById(studyId, tenantId);
    if (!study) {
        return res.status(404).json({
            success: false,
            error: 'Imaging study not found'
        });
    }
    res.json({
        success: true,
        data: { study }
    });
}));
