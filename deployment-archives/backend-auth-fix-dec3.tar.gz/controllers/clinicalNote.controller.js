"use strict";
// Clinical Note Controller
// Requirements: 2.2 - HTTP request handling with validation
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClinicalNoteController = void 0;
const zod_1 = require("zod");
// Validation schemas
const NoteTypeSchema = zod_1.z.enum([
    'progress_note',
    'discharge_summary',
    'consultation',
    'admission_note',
    'operative_note',
    'procedure_note',
    'follow_up',
    'other'
]);
const CreateClinicalNoteSchema = zod_1.z.object({
    patient_id: zod_1.z.number().int().positive(),
    provider_id: zod_1.z.number().int().positive(),
    note_type: NoteTypeSchema,
    content: zod_1.z.string().min(1, 'Content is required'),
    summary: zod_1.z.string().optional(),
    template_id: zod_1.z.number().int().positive().optional()
});
const UpdateClinicalNoteSchema = zod_1.z.object({
    content: zod_1.z.string().min(1).optional(),
    summary: zod_1.z.string().optional(),
    note_type: NoteTypeSchema.optional()
});
const SignClinicalNoteSchema = zod_1.z.object({
    signed_by: zod_1.z.number().int().positive()
});
class ClinicalNoteController {
    constructor(clinicalNoteService) {
        this.clinicalNoteService = clinicalNoteService;
        /**
         * Create a new clinical note
         * POST /api/clinical-notes
         */
        this.createClinicalNote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                console.log('Creating clinical note with body:', JSON.stringify(req.body, null, 2));
                // Validate request body
                const validatedData = CreateClinicalNoteSchema.parse(req.body);
                console.log('Validated data:', JSON.stringify(validatedData, null, 2));
                // Create clinical note
                const note = yield this.clinicalNoteService.createClinicalNote(validatedData, req.dbClient);
                res.status(201).json({
                    success: true,
                    data: note
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    console.error('Zod validation error:', JSON.stringify(error.issues, null, 2));
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                console.error('Error creating clinical note:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to create clinical note',
                    details: error instanceof Error ? error.message : 'Unknown error'
                });
            }
        });
        /**
         * Get clinical note by ID
         * GET /api/clinical-notes/:id
         */
        this.getClinicalNoteById = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                const includeVersions = req.query.include_versions === 'true';
                if (isNaN(noteId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID'
                    });
                    return;
                }
                const note = yield this.clinicalNoteService.getClinicalNoteById(noteId, includeVersions, req.dbClient);
                if (!note) {
                    res.status(404).json({
                        success: false,
                        error: 'Clinical note not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: note
                });
            }
            catch (error) {
                console.error('Error fetching clinical note:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch clinical note'
                });
            }
        });
        /**
         * Get clinical notes with filtering
         * GET /api/clinical-notes
         */
        this.getClinicalNotes = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const filters = {
                    patient_id: req.query.patient_id ? parseInt(req.query.patient_id) : undefined,
                    provider_id: req.query.provider_id ? parseInt(req.query.provider_id) : undefined,
                    note_type: req.query.note_type,
                    status: req.query.status,
                    date_from: req.query.date_from,
                    date_to: req.query.date_to,
                    search: req.query.search,
                    page: req.query.page ? parseInt(req.query.page) : 1,
                    limit: req.query.limit ? parseInt(req.query.limit) : 10
                };
                const result = yield this.clinicalNoteService.getClinicalNotes(filters, req.dbClient);
                res.json({
                    success: true,
                    data: result.notes,
                    pagination: {
                        page: filters.page,
                        limit: filters.limit,
                        total: result.total,
                        pages: Math.ceil(result.total / (filters.limit || 10))
                    }
                });
            }
            catch (error) {
                console.error('Error fetching clinical notes:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch clinical notes'
                });
            }
        });
        /**
         * Update clinical note
         * PUT /api/clinical-notes/:id
         */
        this.updateClinicalNote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                if (isNaN(noteId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID'
                    });
                    return;
                }
                // Validate request body
                const validatedData = UpdateClinicalNoteSchema.parse(req.body);
                // Update clinical note
                const note = yield this.clinicalNoteService.updateClinicalNote(noteId, validatedData, req.dbClient);
                if (!note) {
                    res.status(404).json({
                        success: false,
                        error: 'Clinical note not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: note
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                console.error('Error updating clinical note:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to update clinical note'
                });
            }
        });
        /**
         * Sign a clinical note
         * POST /api/clinical-notes/:id/sign
         */
        this.signClinicalNote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                if (isNaN(noteId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID'
                    });
                    return;
                }
                // Validate request body
                const validatedData = SignClinicalNoteSchema.parse(req.body);
                // Sign clinical note
                const note = yield this.clinicalNoteService.signClinicalNote(noteId, validatedData.signed_by, req.dbClient);
                if (!note) {
                    res.status(404).json({
                        success: false,
                        error: 'Clinical note not found or already signed'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: note
                });
            }
            catch (error) {
                if (error instanceof zod_1.z.ZodError) {
                    res.status(400).json({
                        success: false,
                        error: 'Validation error',
                        details: error.issues
                    });
                    return;
                }
                console.error('Error signing clinical note:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to sign clinical note'
                });
            }
        });
        /**
         * Delete clinical note
         * DELETE /api/clinical-notes/:id
         */
        this.deleteClinicalNote = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                if (isNaN(noteId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID'
                    });
                    return;
                }
                const deleted = yield this.clinicalNoteService.deleteClinicalNote(noteId, req.dbClient);
                if (!deleted) {
                    res.status(404).json({
                        success: false,
                        error: 'Clinical note not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    message: 'Clinical note deleted successfully'
                });
            }
            catch (error) {
                console.error('Error deleting clinical note:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to delete clinical note'
                });
            }
        });
        /**
         * Get version history for a clinical note
         * GET /api/clinical-notes/:id/versions
         */
        this.getClinicalNoteVersions = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                if (isNaN(noteId)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID'
                    });
                    return;
                }
                const versions = yield this.clinicalNoteService.getClinicalNoteVersions(noteId, req.dbClient);
                res.json({
                    success: true,
                    data: versions
                });
            }
            catch (error) {
                console.error('Error fetching clinical note versions:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch clinical note versions'
                });
            }
        });
        /**
         * Get a specific version of a clinical note
         * GET /api/clinical-notes/:id/versions/:versionNumber
         */
        this.getClinicalNoteVersion = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const noteId = parseInt(req.params.id);
                const versionNumber = parseInt(req.params.versionNumber);
                if (isNaN(noteId) || isNaN(versionNumber)) {
                    res.status(400).json({
                        success: false,
                        error: 'Invalid note ID or version number'
                    });
                    return;
                }
                const version = yield this.clinicalNoteService.getClinicalNoteVersion(noteId, versionNumber, req.dbClient);
                if (!version) {
                    res.status(404).json({
                        success: false,
                        error: 'Clinical note version not found'
                    });
                    return;
                }
                res.json({
                    success: true,
                    data: version
                });
            }
            catch (error) {
                console.error('Error fetching clinical note version:', error);
                res.status(500).json({
                    success: false,
                    error: 'Failed to fetch clinical note version'
                });
            }
        });
    }
}
exports.ClinicalNoteController = ClinicalNoteController;
