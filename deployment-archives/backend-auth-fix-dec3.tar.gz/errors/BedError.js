"use strict";
/**
 * Custom Error Classes for Bed Management System
 * Team: Beta
 * System: Bed Management + Inventory
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedPermissionDeniedError = exports.BedValidationError = exports.DestinationBedOccupiedError = exports.SameBedTransferError = exports.TransferAlreadyCompletedError = exports.InvalidTransferError = exports.BedTransferNotFoundError = exports.AssignmentAlreadyDischargedError = exports.PatientAlreadyAssignedError = exports.BedAssignmentConflictError = exports.BedAssignmentNotFoundError = exports.BedAlreadyOccupiedError = exports.BedUnavailableError = exports.BedNumberExistsError = exports.BedNotFoundError = exports.DepartmentCodeExistsError = exports.DepartmentNotFoundError = exports.BedError = void 0;
// Base Bed Error
class BedError extends Error {
    constructor(message, statusCode, code) {
        super(message);
        this.name = this.constructor.name;
        this.statusCode = statusCode;
        this.code = code;
        this.timestamp = new Date().toISOString();
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.BedError = BedError;
// ==================== Department Errors ====================
class DepartmentNotFoundError extends BedError {
    constructor(departmentId) {
        super(`Department with ID ${departmentId} not found`, 404, 'DEPARTMENT_NOT_FOUND');
    }
}
exports.DepartmentNotFoundError = DepartmentNotFoundError;
class DepartmentCodeExistsError extends BedError {
    constructor(departmentCode) {
        super(`Department with code ${departmentCode} already exists`, 409, 'DEPARTMENT_CODE_EXISTS');
    }
}
exports.DepartmentCodeExistsError = DepartmentCodeExistsError;
// ==================== Bed Errors ====================
class BedNotFoundError extends BedError {
    constructor(bedId) {
        super(`Bed with ID ${bedId} not found`, 404, 'BED_NOT_FOUND');
    }
}
exports.BedNotFoundError = BedNotFoundError;
class BedNumberExistsError extends BedError {
    constructor(bedNumber) {
        super(`Bed with number ${bedNumber} already exists`, 409, 'BED_NUMBER_EXISTS');
    }
}
exports.BedNumberExistsError = BedNumberExistsError;
class BedUnavailableError extends BedError {
    constructor(bedId, currentStatus) {
        super(`Bed ${bedId} is not available (current status: ${currentStatus})`, 409, 'BED_UNAVAILABLE');
    }
}
exports.BedUnavailableError = BedUnavailableError;
class BedAlreadyOccupiedError extends BedError {
    constructor(bedId) {
        super(`Bed ${bedId} is already occupied by another patient`, 409, 'BED_ALREADY_OCCUPIED');
    }
}
exports.BedAlreadyOccupiedError = BedAlreadyOccupiedError;
// ==================== Bed Assignment Errors ====================
class BedAssignmentNotFoundError extends BedError {
    constructor(assignmentId) {
        super(`Bed assignment with ID ${assignmentId} not found`, 404, 'BED_ASSIGNMENT_NOT_FOUND');
    }
}
exports.BedAssignmentNotFoundError = BedAssignmentNotFoundError;
class BedAssignmentConflictError extends BedError {
    constructor(message) {
        super(message, 409, 'BED_ASSIGNMENT_CONFLICT');
    }
}
exports.BedAssignmentConflictError = BedAssignmentConflictError;
class PatientAlreadyAssignedError extends BedError {
    constructor(patientId) {
        super(`Patient ${patientId} already has an active bed assignment`, 409, 'PATIENT_ALREADY_ASSIGNED');
    }
}
exports.PatientAlreadyAssignedError = PatientAlreadyAssignedError;
class AssignmentAlreadyDischargedError extends BedError {
    constructor(message) {
        super(message, 400, 'ASSIGNMENT_ALREADY_DISCHARGED');
    }
}
exports.AssignmentAlreadyDischargedError = AssignmentAlreadyDischargedError;
// ==================== Bed Transfer Errors ====================
class BedTransferNotFoundError extends BedError {
    constructor(transferId) {
        super(`Bed transfer with ID ${transferId} not found`, 404, 'BED_TRANSFER_NOT_FOUND');
    }
}
exports.BedTransferNotFoundError = BedTransferNotFoundError;
class InvalidTransferError extends BedError {
    constructor(message) {
        super(message, 400, 'INVALID_TRANSFER');
    }
}
exports.InvalidTransferError = InvalidTransferError;
class TransferAlreadyCompletedError extends BedError {
    constructor(message) {
        super(message, 400, 'TRANSFER_ALREADY_COMPLETED');
    }
}
exports.TransferAlreadyCompletedError = TransferAlreadyCompletedError;
class SameBedTransferError extends BedError {
    constructor(message) {
        super(message, 400, 'SAME_BED_TRANSFER');
    }
}
exports.SameBedTransferError = SameBedTransferError;
class DestinationBedOccupiedError extends BedError {
    constructor(message) {
        super(message, 409, 'DESTINATION_BED_OCCUPIED');
    }
}
exports.DestinationBedOccupiedError = DestinationBedOccupiedError;
// ==================== Validation Errors ====================
class BedValidationError extends BedError {
    constructor(message, field) {
        const errorMessage = field
            ? `Validation error on field '${field}': ${message}`
            : `Validation error: ${message}`;
        super(errorMessage, 400, 'BED_VALIDATION_ERROR');
    }
}
exports.BedValidationError = BedValidationError;
// ==================== Authorization Errors ====================
class BedPermissionDeniedError extends BedError {
    constructor(action) {
        super(`You do not have permission to ${action}`, 403, 'BED_PERMISSION_DENIED');
    }
}
exports.BedPermissionDeniedError = BedPermissionDeniedError;
