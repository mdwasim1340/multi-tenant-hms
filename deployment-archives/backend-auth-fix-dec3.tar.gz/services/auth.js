"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assignUserToGroup = exports.refreshToken = exports.respondToChallenge = exports.signIn = exports.forgotPassword = exports.resetPassword = exports.verifyEmail = exports.signUp = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const crypto_1 = require("crypto");
const email_1 = require("./email");
const database_1 = __importDefault(require("../database"));
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: process.env.AWS_REGION,
});
// Generate secret hash for Cognito client with secret
const generateSecretHash = (username) => {
    const clientId = process.env.COGNITO_CLIENT_ID;
    const clientSecret = process.env.COGNITO_SECRET;
    return (0, crypto_1.createHmac)('sha256', clientSecret)
        .update(username + clientId)
        .digest('base64');
};
const generateVerificationCode = () => {
    return (0, crypto_1.randomBytes)(3).toString('hex').toUpperCase();
};
// Check if user exists in Cognito
const checkUserExists = (email) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const username = email.replace('@', '_').replace(/\./g, '_');
        const command = new client_cognito_identity_provider_1.AdminGetUserCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username,
        });
        yield cognitoClient.send(command);
        return true; // User exists
    }
    catch (error) {
        if (error.name === 'UserNotFoundException') {
            return false; // User does not exist
        }
        // For other errors, we'll assume user might exist to avoid security issues
        console.error('Error checking user existence:', error.message);
        return true;
    }
});
const signUp = (user, tenantId) => __awaiter(void 0, void 0, void 0, function* () {
    const username = user.email.replace('@', '_').replace(/\./g, '_');
    const secretHash = generateSecretHash(username);
    const command = new client_cognito_identity_provider_1.SignUpCommand({
        ClientId: process.env.COGNITO_CLIENT_ID,
        Username: username,
        Password: user.password,
        SecretHash: secretHash,
        UserAttributes: [{ Name: 'email', Value: user.email }],
    });
    const cognitoResponse = yield cognitoClient.send(command);
    const verificationCode = generateVerificationCode();
    const client = yield database_1.default.connect();
    try {
        yield client.query('INSERT INTO user_verification (email, code, type) VALUES ($1, $2, $3)', [user.email, verificationCode, 'verification']);
    }
    finally {
        client.release();
    }
    const fromEmail = tenantId === 'admin' ? 'noreply@exo.com.np' : process.env.EMAIL_SENDER || 'noreply@exo.com.np';
    yield (0, email_1.sendEmail)(fromEmail, user.email, 'Verify your email address', `Your verification code is: ${verificationCode}`);
    return cognitoResponse;
});
exports.signUp = signUp;
const verifyEmail = (email, code) => __awaiter(void 0, void 0, void 0, function* () {
    const client = yield database_1.default.connect();
    try {
        const result = yield client.query('SELECT * FROM user_verification WHERE email = $1 AND code = $2 AND type = $3 AND expires_at > NOW()', [email, code, 'verification']);
        if (result.rows.length === 0) {
            throw new Error('Invalid verification code');
        }
        const username = email.replace('@', '_').replace(/\./g, '_');
        const command = new client_cognito_identity_provider_1.AdminConfirmSignUpCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username,
        });
        yield cognitoClient.send(command);
        yield client.query('DELETE FROM user_verification WHERE email = $1 AND code = $2 AND type = $3', [
            email,
            code,
            'verification',
        ]);
    }
    finally {
        client.release();
    }
});
exports.verifyEmail = verifyEmail;
const resetPassword = (email, code, newPassword) => __awaiter(void 0, void 0, void 0, function* () {
    const client = yield database_1.default.connect();
    try {
        const result = yield client.query('SELECT * FROM user_verification WHERE email = $1 AND code = $2 AND type = $3 AND expires_at > NOW()', [email, code, 'reset']);
        if (result.rows.length === 0) {
            throw new Error('Invalid or expired reset token');
        }
        const username = email.replace('@', '_').replace(/\./g, '_');
        const command = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username,
            Password: newPassword,
            Permanent: true,
        });
        try {
            yield cognitoClient.send(command);
            console.log(`✅ Password reset successfully for user: ${email}`);
        }
        catch (cognitoError) {
            console.error(`❌ Cognito password reset error for ${email}:`, cognitoError.message);
            // Handle specific Cognito password policy errors
            if (cognitoError.name === 'InvalidPasswordException') {
                throw new Error('Password does not meet security requirements. Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
            }
            else if (cognitoError.name === 'InvalidParameterException') {
                throw new Error('Invalid password format. Please ensure your password meets the security requirements.');
            }
            else if (cognitoError.name === 'UserNotFoundException') {
                throw new Error('User account not found. Please contact support.');
            }
            else if (cognitoError.name === 'NotAuthorizedException') {
                throw new Error('Not authorized to reset password. Please try requesting a new reset code.');
            }
            else {
                // Re-throw with a more user-friendly message
                throw new Error(`Password reset failed: ${cognitoError.message}`);
            }
        }
        // Only clean up the verification record if password reset was successful
        yield client.query('DELETE FROM user_verification WHERE email = $1 AND code = $2 AND type = $3', [
            email,
            code,
            'reset',
        ]);
    }
    finally {
        client.release();
    }
});
exports.resetPassword = resetPassword;
const forgotPassword = (email, tenantId) => __awaiter(void 0, void 0, void 0, function* () {
    // First, check if user exists in Cognito
    const userExists = yield checkUserExists(email);
    if (!userExists) {
        throw new Error(`No account found with email address ${email}. Please check your email address or create an account first.`);
    }
    const resetToken = generateVerificationCode();
    const client = yield database_1.default.connect();
    try {
        // Insert verification record first
        yield client.query('INSERT INTO user_verification (email, code, type) VALUES ($1, $2, $3)', [email, resetToken, 'reset']);
        // Try to send email
        const fromEmail = tenantId === 'admin' ? 'noreply@exo.com.np' : process.env.EMAIL_SENDER || 'noreply@exo.com.np';
        try {
            yield (0, email_1.sendEmail)(fromEmail, email, 'Reset your password', `Your password reset token is: ${resetToken}`);
            console.log(`✅ Password reset email sent successfully to ${email}`);
        }
        catch (emailError) {
            const error = emailError;
            console.error(`❌ Failed to send password reset email to ${email}:`, error.message);
            // Clean up the verification record if email fails
            yield client.query('DELETE FROM user_verification WHERE email = $1 AND code = $2 AND type = $3', [
                email, resetToken, 'reset'
            ]);
            // Check if it's a SES sandbox issue
            if (error.name === 'MessageRejected' || error.message.includes('Email address not verified')) {
                throw new Error(`Email address ${email} is not verified. In SES sandbox mode, only verified email addresses can receive emails. Please verify this email address in the AWS SES console or contact your administrator.`);
            }
            // Re-throw other email errors
            throw new Error(`Failed to send password reset email: ${error.message}`);
        }
    }
    finally {
        client.release();
    }
});
exports.forgotPassword = forgotPassword;
const signIn = (user) => __awaiter(void 0, void 0, void 0, function* () {
    // Cognito authentication
    // Use email directly since Cognito is configured with email alias
    const username = user.email; // Use email as-is for email alias configuration
    const secretHash = generateSecretHash(username);
    // Use USER_PASSWORD_AUTH flow (now enabled in Cognito)
    const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: process.env.COGNITO_CLIENT_ID,
        AuthFlow: 'USER_PASSWORD_AUTH',
        AuthParameters: {
            USERNAME: username,
            PASSWORD: user.password,
            SECRET_HASH: secretHash,
        },
    });
    const res = yield cognitoClient.send(command);
    return res;
});
exports.signIn = signIn;
const respondToChallenge = (email, mfaCode, session) => __awaiter(void 0, void 0, void 0, function* () {
    const username = email.replace('@', '_').replace(/\./g, '_');
    const secretHash = generateSecretHash(username);
    const cmd = new client_cognito_identity_provider_1.RespondToAuthChallengeCommand({
        ClientId: process.env.COGNITO_CLIENT_ID,
        ChallengeName: 'SMS_MFA',
        Session: session,
        ChallengeResponses: {
            USERNAME: username,
            SMS_MFA_CODE: mfaCode,
            SECRET_HASH: secretHash,
        },
    });
    const res = yield cognitoClient.send(cmd);
    return res.AuthenticationResult;
});
exports.respondToChallenge = respondToChallenge;
const refreshToken = (email, refreshToken) => __awaiter(void 0, void 0, void 0, function* () {
    const username = email.replace('@', '_').replace(/\./g, '_');
    const secretHash = generateSecretHash(username);
    const cmd = new client_cognito_identity_provider_1.InitiateAuthCommand({
        ClientId: process.env.COGNITO_CLIENT_ID,
        AuthFlow: 'REFRESH_TOKEN_AUTH',
        AuthParameters: {
            REFRESH_TOKEN: refreshToken,
            SECRET_HASH: secretHash,
            USERNAME: username,
        },
    });
    const res = yield cognitoClient.send(cmd);
    return res.AuthenticationResult;
});
exports.refreshToken = refreshToken;
const assignUserToGroup = (email, group) => __awaiter(void 0, void 0, void 0, function* () {
    const username = email.replace('@', '_').replace(/\./g, '_');
    const poolId = process.env.COGNITO_USER_POOL_ID;
    try {
        // Ensure group exists
        const createGroup = new client_cognito_identity_provider_1.CreateGroupCommand({
            GroupName: group,
            UserPoolId: poolId,
            Description: group === 'hospital-admin' ? 'Hospital administrators' : 'System administrators',
        });
        try {
            yield cognitoClient.send(createGroup);
        }
        catch (e) {
            // ignore if exists
        }
        const addCmd = new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
            UserPoolId: poolId,
            Username: username,
            GroupName: group,
        });
        yield cognitoClient.send(addCmd);
    }
    catch (e) {
        throw e;
    }
});
exports.assignUserToGroup = assignUserToGroup;
