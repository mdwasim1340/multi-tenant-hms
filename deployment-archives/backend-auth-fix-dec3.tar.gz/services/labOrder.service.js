"use strict";
/**
 * Lab Order Service
 *
 * Business logic for managing laboratory test orders
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLabOrders = getLabOrders;
exports.getLabOrderById = getLabOrderById;
exports.createLabOrder = createLabOrder;
exports.updateLabOrder = updateLabOrder;
exports.cancelLabOrder = cancelLabOrder;
exports.collectSpecimen = collectSpecimen;
exports.startProcessing = startProcessing;
exports.getOrdersByPatient = getOrdersByPatient;
exports.getLabOrderStatistics = getLabOrderStatistics;
const database_1 = __importDefault(require("../database"));
/**
 * Get all lab orders with optional filtering
 */
function getLabOrders(tenantId_1) {
    return __awaiter(this, arguments, void 0, function* (tenantId, filters = {}) {
        const { patient_id, medical_record_id, appointment_id, ordered_by, priority, status, order_date_from, order_date_to, search, page = 1, limit = 20, sort_by = 'order_date', sort_order = 'desc' } = filters;
        const offset = (page - 1) * limit;
        const params = [];
        let paramIndex = 1;
        // Build WHERE clause
        let whereConditions = ['1=1'];
        if (patient_id) {
            whereConditions.push(`lo.patient_id = $${paramIndex}`);
            params.push(patient_id);
            paramIndex++;
        }
        if (medical_record_id) {
            whereConditions.push(`lo.medical_record_id = $${paramIndex}`);
            params.push(medical_record_id);
            paramIndex++;
        }
        if (appointment_id) {
            whereConditions.push(`lo.appointment_id = $${paramIndex}`);
            params.push(appointment_id);
            paramIndex++;
        }
        if (ordered_by) {
            whereConditions.push(`lo.ordered_by = $${paramIndex}`);
            params.push(ordered_by);
            paramIndex++;
        }
        if (priority) {
            whereConditions.push(`lo.priority = $${paramIndex}`);
            params.push(priority);
            paramIndex++;
        }
        if (status) {
            whereConditions.push(`lo.status = $${paramIndex}`);
            params.push(status);
            paramIndex++;
        }
        if (order_date_from) {
            whereConditions.push(`lo.order_date >= $${paramIndex}`);
            params.push(order_date_from);
            paramIndex++;
        }
        if (order_date_to) {
            whereConditions.push(`lo.order_date <= $${paramIndex}`);
            params.push(order_date_to);
            paramIndex++;
        }
        if (search) {
            whereConditions.push(`(
      lo.order_number ILIKE $${paramIndex} OR
      p.first_name ILIKE $${paramIndex} OR
      p.last_name ILIKE $${paramIndex} OR
      p.patient_number ILIKE $${paramIndex}
    )`);
            params.push(`%${search}%`);
            paramIndex++;
        }
        // Set schema context
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        // Get orders with patient info
        const query = `
    SELECT 
      lo.*,
      p.first_name || ' ' || p.last_name as patient_name,
      p.patient_number,
      (SELECT COUNT(*) FROM lab_order_items WHERE order_id = lo.id) as items_count,
      (SELECT COUNT(*) FROM lab_order_items WHERE order_id = lo.id AND status = 'completed') as completed_items_count
    FROM lab_orders lo
    JOIN patients p ON lo.patient_id = p.id
    WHERE ${whereConditions.join(' AND ')}
    ORDER BY lo.${sort_by} ${sort_order}
    LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
  `;
        params.push(limit, offset);
        const result = yield database_1.default.query(query, params);
        // Get total count
        const countQuery = `
    SELECT COUNT(*) as total
    FROM lab_orders lo
    JOIN patients p ON lo.patient_id = p.id
    WHERE ${whereConditions.join(' AND ')}
  `;
        const countResult = yield database_1.default.query(countQuery, params.slice(0, -2));
        const total = parseInt(countResult.rows[0].total);
        return {
            orders: result.rows,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        };
    });
}
/**
 * Get lab order by ID with full details
 */
function getLabOrderById(tenantId, orderId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        // Get order with patient info
        const orderResult = yield database_1.default.query(`
    SELECT 
      lo.*,
      p.first_name || ' ' || p.last_name as patient_name,
      p.patient_number
    FROM lab_orders lo
    JOIN patients p ON lo.patient_id = p.id
    WHERE lo.id = $1
  `, [orderId]);
        if (orderResult.rows.length === 0) {
            return null;
        }
        const order = orderResult.rows[0];
        // Get order items with test details
        const itemsResult = yield database_1.default.query(`
    SELECT 
      loi.*,
      lt.test_code,
      lt.test_name,
      lt.unit as test_unit,
      lt.specimen_type,
      lt.turnaround_time
    FROM lab_order_items loi
    JOIN lab_tests lt ON loi.test_id = lt.id
    WHERE loi.order_id = $1
    ORDER BY lt.test_name ASC
  `, [orderId]);
        order.items = itemsResult.rows;
        order.items_count = itemsResult.rows.length;
        order.completed_items_count = itemsResult.rows.filter((item) => item.status === 'completed').length;
        return order;
    });
}
/**
 * Create new lab order
 */
function createLabOrder(tenantId, orderData) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const client = yield database_1.default.connect();
        try {
            yield client.query('BEGIN');
            // Create order
            const orderResult = yield client.query(`
      INSERT INTO lab_orders (
        patient_id, medical_record_id, appointment_id,
        order_date, ordered_by, priority,
        clinical_notes, special_instructions, status
      ) VALUES ($1, $2, $3, CURRENT_TIMESTAMP, $4, $5, $6, $7, 'pending')
      RETURNING *
    `, [
                orderData.patient_id,
                orderData.medical_record_id || null,
                orderData.appointment_id || null,
                orderData.ordered_by,
                orderData.priority || 'routine',
                orderData.clinical_notes || null,
                orderData.special_instructions || null
            ]);
            const order = orderResult.rows[0];
            // Create order items
            for (const testId of orderData.test_ids) {
                // Get test price
                const testResult = yield client.query('SELECT price FROM lab_tests WHERE id = $1', [testId]);
                const price = ((_a = testResult.rows[0]) === null || _a === void 0 ? void 0 : _a.price) || null;
                yield client.query(`
        INSERT INTO lab_order_items (order_id, test_id, status, price)
        VALUES ($1, $2, 'pending', $3)
      `, [order.id, testId, price]);
            }
            // Calculate total price
            const totalResult = yield client.query('SELECT SUM(price) as total FROM lab_order_items WHERE order_id = $1', [order.id]);
            const totalPrice = totalResult.rows[0].total;
            yield client.query('UPDATE lab_orders SET total_price = $1 WHERE id = $2', [totalPrice, order.id]);
            yield client.query('COMMIT');
            // Return full order details
            return yield getLabOrderById(tenantId, order.id);
        }
        catch (error) {
            yield client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    });
}
/**
 * Update lab order
 */
function updateLabOrder(tenantId, orderId, orderData) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const updates = [];
        const params = [];
        let paramIndex = 1;
        const allowedFields = ['priority', 'clinical_notes', 'special_instructions'];
        for (const field of allowedFields) {
            if (field in orderData) {
                updates.push(`${field} = $${paramIndex}`);
                params.push(orderData[field]);
                paramIndex++;
            }
        }
        if (updates.length === 0) {
            const result = yield database_1.default.query('SELECT * FROM lab_orders WHERE id = $1', [orderId]);
            return result.rows[0] || null;
        }
        params.push(orderId);
        const result = yield database_1.default.query(`
    UPDATE lab_orders
    SET ${updates.join(', ')}
    WHERE id = $${paramIndex}
    RETURNING *
  `, params);
        return result.rows[0] || null;
    });
}
/**
 * Cancel lab order
 */
function cancelLabOrder(tenantId, orderId, reason) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const client = yield database_1.default.connect();
        try {
            yield client.query('BEGIN');
            // Update order status
            yield client.query('UPDATE lab_orders SET status = $1 WHERE id = $2', ['cancelled', orderId]);
            // Cancel all order items
            yield client.query(`
      UPDATE lab_order_items
      SET status = 'cancelled', cancelled_at = CURRENT_TIMESTAMP, cancellation_reason = $1
      WHERE order_id = $2 AND status NOT IN ('completed', 'cancelled')
    `, [reason || 'Order cancelled', orderId]);
            yield client.query('COMMIT');
            return true;
        }
        catch (error) {
            yield client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    });
}
/**
 * Mark specimen collected
 */
function collectSpecimen(tenantId, orderId, collectedBy) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const client = yield database_1.default.connect();
        try {
            yield client.query('BEGIN');
            // Update order
            yield client.query(`
      UPDATE lab_orders
      SET collection_date = CURRENT_TIMESTAMP, collected_by = $1
      WHERE id = $2
    `, [collectedBy, orderId]);
            // Update all pending items
            yield client.query(`
      UPDATE lab_order_items
      SET status = 'collected', specimen_collected_at = CURRENT_TIMESTAMP
      WHERE order_id = $1 AND status = 'pending'
    `, [orderId]);
            yield client.query('COMMIT');
            return true;
        }
        catch (error) {
            yield client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    });
}
/**
 * Start processing order
 */
function startProcessing(tenantId, orderId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        yield database_1.default.query(`
    UPDATE lab_order_items
    SET status = 'processing', processing_started_at = CURRENT_TIMESTAMP
    WHERE order_id = $1 AND status = 'collected'
  `, [orderId]);
        return true;
    });
}
/**
 * Get orders by patient
 */
function getOrdersByPatient(tenantId, patientId) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield getLabOrders(tenantId, {
            patient_id: patientId,
            limit: 100
        });
        return result.orders;
    });
}
/**
 * Get order statistics
 */
function getLabOrderStatistics(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield database_1.default.query(`SET search_path TO "${tenantId}"`);
        const result = yield database_1.default.query(`
    SELECT
      COUNT(*) as total_orders,
      COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
      COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_orders,
      COUNT(CASE WHEN priority = 'urgent' THEN 1 END) as urgent_orders,
      COUNT(CASE WHEN priority = 'stat' THEN 1 END) as stat_orders,
      AVG(EXTRACT(EPOCH FROM (updated_at - order_date))/3600) as avg_turnaround_time
    FROM lab_orders
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
  `);
        return {
            total_orders: parseInt(result.rows[0].total_orders),
            pending_orders: parseInt(result.rows[0].pending_orders),
            completed_orders: parseInt(result.rows[0].completed_orders),
            urgent_orders: parseInt(result.rows[0].urgent_orders),
            stat_orders: parseInt(result.rows[0].stat_orders),
            avg_turnaround_time: parseFloat(result.rows[0].avg_turnaround_time) || null
        };
    });
}
