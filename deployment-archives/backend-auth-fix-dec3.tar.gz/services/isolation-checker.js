"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IsolationChecker = void 0;
const database_1 = __importDefault(require("../database"));
/**
 * Isolation Requirements Checker Service
 *
 * Determines isolation requirements based on:
 * - Patient diagnoses (ICD-10 codes)
 * - Lab results (cultures, PCR tests)
 * - Clinical symptoms
 * - Infection control protocols
 *
 * Prevents inappropriate bed assignments that violate infection control.
 */
class IsolationChecker {
    constructor() {
        // ICD-10 codes requiring specific isolation types
        this.ISOLATION_DIAGNOSES = {
            contact: [
                'A04', // Bacterial intestinal infections (C. diff)
                'B95.6', // MRSA
                'B96.2', // E. coli
                'A41', // Sepsis (some types)
                'L08', // Skin infections
            ],
            droplet: [
                'J09', // Influenza
                'J10', // Influenza
                'J11', // Influenza
                'J18', // Pneumonia
                'A37', // Pertussis (whooping cough)
                'B05', // Measles
                'B06', // Rubella
            ],
            airborne: [
                'A15', // Tuberculosis (respiratory)
                'A16', // Tuberculosis (respiratory)
                'B05', // Measles
                'B01', // Varicella (chickenpox)
                'A48.1', // Legionnaires' disease
            ],
            protective: [
                'D70', // Neutropenia
                'C91', // Lymphoid leukemia
                'C92', // Myeloid leukemia
                'Z94', // Transplant status
            ]
        };
        // Lab results requiring isolation
        this.ISOLATION_LAB_RESULTS = {
            contact: ['MRSA', 'VRE', 'C.DIFF', 'CRE', 'ESBL'],
            droplet: ['INFLUENZA', 'RSV', 'ADENOVIRUS'],
            airborne: ['TB', 'MEASLES', 'VARICELLA'],
        };
    }
    /**
     * Check if a patient requires isolation and determine the type
     */
    checkIsolationRequirements(tenantId, patientId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Get patient diagnoses
                const diagnosesResult = yield client.query(`
        SELECT diagnosis_code, diagnosis_description
        FROM medical_records
        WHERE patient_id = $1
        AND diagnosis_code IS NOT NULL
        ORDER BY created_at DESC
        LIMIT 10
      `, [patientId]);
                // Get recent lab results
                const labsResult = yield client.query(`
        SELECT test_name, result, result_status
        FROM lab_tests
        WHERE patient_id = $1
        AND result_status = 'positive'
        AND created_at > NOW() - INTERVAL '30 days'
        ORDER BY created_at DESC
      `, [patientId]);
                // Determine isolation requirements
                const isolationTypes = new Set();
                const reasons = [];
                // Check diagnoses
                for (const diagnosis of diagnosesResult.rows) {
                    const code = diagnosis.diagnosis_code;
                    for (const [type, codes] of Object.entries(this.ISOLATION_DIAGNOSES)) {
                        if (codes.some(isoCode => code.startsWith(isoCode))) {
                            isolationTypes.add(type);
                            reasons.push(`Diagnosis: ${diagnosis.diagnosis_description} (${code})`);
                        }
                    }
                }
                // Check lab results
                for (const lab of labsResult.rows) {
                    const testName = lab.test_name.toUpperCase();
                    for (const [type, organisms] of Object.entries(this.ISOLATION_LAB_RESULTS)) {
                        if (organisms.some(org => testName.includes(org))) {
                            isolationTypes.add(type);
                            reasons.push(`Lab: ${lab.test_name} - ${lab.result}`);
                        }
                    }
                }
                // Determine primary isolation type (most restrictive)
                const isolationPriority = ['airborne', 'droplet', 'contact', 'protective'];
                let primaryType = null;
                for (const type of isolationPriority) {
                    if (isolationTypes.has(type)) {
                        primaryType = type;
                        break;
                    }
                }
                // Update patient isolation status if needed
                if (primaryType) {
                    yield client.query(`
          UPDATE patients
          SET 
            isolation_required = true,
            isolation_type = $1,
            isolation_start_date = COALESCE(isolation_start_date, NOW())
          WHERE id = $2
        `, [primaryType, patientId]);
                }
                return {
                    patient_id: patientId,
                    isolation_required: primaryType !== null,
                    isolation_type: primaryType,
                    reasons: reasons,
                    checked_at: new Date(),
                    requires_negative_pressure: primaryType === 'airborne',
                    requires_positive_pressure: primaryType === 'protective',
                    requires_anteroom: ['airborne', 'protective'].includes(primaryType || ''),
                    ppe_requirements: this.getPPERequirements(primaryType)
                };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get available isolation rooms by type
     */
    getIsolationRoomAvailability(tenantId, isolationType) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                let query = `
        SELECT 
          u.id as unit_id,
          u.name as unit_name,
          b.isolation_type,
          COUNT(*) FILTER (WHERE b.status = 'available') as available_count,
          COUNT(*) FILTER (WHERE b.status = 'occupied') as occupied_count,
          COUNT(*) as total_count
        FROM beds b
        JOIN departments u ON b.unit_id = u.id
        WHERE b.isolation_capable = true
      `;
                const params = [];
                if (isolationType) {
                    query += ` AND b.isolation_type = $1`;
                    params.push(isolationType);
                }
                query += `
        GROUP BY u.id, u.name, b.isolation_type
        ORDER BY u.name, b.isolation_type
      `;
                const result = yield client.query(query, params);
                return result.rows.map(row => ({
                    unit_id: row.unit_id,
                    unit_name: row.unit_name,
                    isolation_type: row.isolation_type,
                    available_rooms: parseInt(row.available_count),
                    available_count: parseInt(row.available_count),
                    occupied_count: parseInt(row.occupied_count),
                    total_rooms: parseInt(row.total_count),
                    total_count: parseInt(row.total_count),
                    availability_percentage: (parseInt(row.available_count) / parseInt(row.total_count)) * 100,
                    utilization_rate: (parseInt(row.occupied_count) / parseInt(row.total_count)) * 100
                }));
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Validate that a bed assignment meets isolation requirements
     */
    validateBedAssignment(tenantId, patientId, bedId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Get patient isolation requirements
                const patientResult = yield client.query(`
        SELECT isolation_required, isolation_type
        FROM patients
        WHERE id = $1
      `, [patientId]);
                if (patientResult.rows.length === 0) {
                    return { valid: false, reason: 'Patient not found' };
                }
                const patient = patientResult.rows[0];
                // Get bed capabilities
                const bedResult = yield client.query(`
        SELECT isolation_capable, isolation_type, status
        FROM beds
        WHERE id = $1
      `, [bedId]);
                if (bedResult.rows.length === 0) {
                    return { valid: false, reason: 'Bed not found' };
                }
                const bed = bedResult.rows[0];
                // Check if bed is available
                if (bed.status !== 'available') {
                    return { valid: false, reason: 'Bed is not available' };
                }
                // Check isolation requirements
                if (patient.isolation_required) {
                    if (!bed.isolation_capable) {
                        return {
                            valid: false,
                            reason: `Patient requires ${patient.isolation_type} isolation but bed is not isolation-capable`
                        };
                    }
                    if (bed.isolation_type !== patient.isolation_type) {
                        return {
                            valid: false,
                            reason: `Isolation type mismatch: patient needs ${patient.isolation_type}, bed provides ${bed.isolation_type}`
                        };
                    }
                }
                return { valid: true };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get PPE requirements for isolation type
     */
    getPPERequirements(isolationType) {
        if (!isolationType) {
            return ['Standard precautions'];
        }
        const ppeMap = {
            contact: ['Gloves', 'Gown'],
            droplet: ['Gloves', 'Gown', 'Surgical mask', 'Eye protection'],
            airborne: ['Gloves', 'Gown', 'N95 respirator', 'Eye protection'],
            protective: ['Gloves', 'Gown', 'Mask']
        };
        return ppeMap[isolationType] || ['Standard precautions'];
    }
    /**
     * Clear isolation status for a patient (when no longer needed)
     */
    clearIsolation(tenantId, patientId, clearedBy, reason) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield client.query(`
        UPDATE patients
        SET 
          isolation_required = false,
          isolation_type = NULL,
          isolation_end_date = NOW()
        WHERE id = $1
      `, [patientId]);
                // Log the clearance
                yield client.query(`
        INSERT INTO bed_management_audit_log (
          tenant_id,
          action,
          entity_type,
          entity_id,
          performed_by,
          details
        ) VALUES ($1, 'isolation_cleared', 'patient', $2, $3, $4)
      `, [tenantId, patientId, clearedBy, JSON.stringify({ reason })]);
            }
            finally {
                client.release();
            }
        });
    }
}
exports.IsolationChecker = IsolationChecker;
exports.default = new IsolationChecker();
