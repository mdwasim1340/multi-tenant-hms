"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PurchaseOrderService = exports.PurchaseOrderNotFoundError = void 0;
const inventory_validation_1 = require("../validation/inventory.validation");
const inventory_item_service_1 = require("./inventory-item.service");
class PurchaseOrderNotFoundError extends Error {
    constructor(poId) {
        super(`Purchase Order with ID ${poId} not found`);
        this.name = 'PurchaseOrderNotFoundError';
    }
}
exports.PurchaseOrderNotFoundError = PurchaseOrderNotFoundError;
class PurchaseOrderService {
    constructor(pool) {
        this.pool = pool;
    }
    /**
     * Create a new purchase order with items (atomic)
     */
    createPurchaseOrder(data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const validatedData = inventory_validation_1.createPurchaseOrderSchema.parse(data);
            const client = yield this.pool.connect();
            try {
                yield client.query('BEGIN');
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Compose order number
                const res = yield client.query('SELECT nextval(\'purchase_order_seq\') AS seq');
                const seq = res.rows[0].seq;
                const orderNumber = `PO-${new Date().getFullYear()}-${seq}`;
                // Aggregate totals
                const subtotal = validatedData.items.reduce((s, it) => s + it.unit_cost * it.quantity, 0);
                const total = subtotal + (validatedData.tax_amount || 0) + (validatedData.shipping_cost || 0);
                // Insert PO
                const poRes = yield client.query(`INSERT INTO purchase_orders (order_number,supplier_id,order_date,expected_delivery_date,status,subtotal,tax_amount,shipping_cost,total_amount,payment_status,notes,created_at,updated_at,created_by,updated_by) VALUES ($1,$2,$3,$4,'pending',$5,$6,$7,$8,'unpaid',$9,NOW(),NOW(),$10,$10) RETURNING *`, [orderNumber, validatedData.supplier_id, validatedData.order_date || new Date().toISOString(), validatedData.expected_delivery_date, subtotal, validatedData.tax_amount || 0, validatedData.shipping_cost || 0, total, validatedData.notes || null, userId]);
                const po = poRes.rows[0];
                // Insert items
                for (const item of validatedData.items) {
                    yield client.query(`INSERT INTO purchase_order_items (purchase_order_id,item_id,quantity,unit_cost,total_cost,received_quantity,status,created_at) VALUES ($1,$2,$3,$4,$5,0,'pending',NOW())`, [po.id, item.item_id, item.quantity, item.unit_cost, item.unit_cost * item.quantity]);
                }
                yield client.query('COMMIT');
                return yield this.getPurchaseOrderById(po.id, tenantId, client);
            }
            catch (error) {
                yield client.query('ROLLBACK');
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get purchase order by ID, including items and supplier
     */
    getPurchaseOrderById(poId, tenantId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || (yield this.pool.connect());
            try {
                if (!client)
                    yield dbClient.query(`SET search_path TO "${tenantId}"`);
                const poRes = yield dbClient.query('SELECT * FROM purchase_orders WHERE id = $1', [poId]);
                if (poRes.rows.length === 0)
                    throw new PurchaseOrderNotFoundError(poId);
                const po = poRes.rows[0];
                // Get supplier
                const suppRes = yield dbClient.query('SELECT * FROM suppliers WHERE id = $1', [po.supplier_id]);
                if (suppRes.rows.length)
                    po.supplier = suppRes.rows[0];
                // Get items
                const itemsRes = yield dbClient.query('SELECT * FROM purchase_order_items WHERE purchase_order_id = $1', [poId]);
                po.items = itemsRes.rows;
                return po;
            }
            finally {
                if (!client)
                    dbClient.release();
            }
        });
    }
    /**
     * Update purchase order fields
     */
    updatePurchaseOrder(poId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const validatedData = inventory_validation_1.updatePurchaseOrderSchema.parse(data);
            const updateData = Object.fromEntries(Object.entries(validatedData).filter(([_, v]) => v !== undefined));
            if (!Object.keys(updateData).length)
                throw new inventory_item_service_1.InventoryValidationError('No valid fields provided for update');
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield this.getPurchaseOrderById(poId, tenantId, client);
                const finalUpdate = Object.assign(Object.assign({}, updateData), { updated_by: userId, updated_at: new Date() });
                const entries = Object.entries(finalUpdate);
                const setClause = entries.map(([k], i) => `${k} = $${i + 2}`).join(', ');
                const values = entries.map(([_, v]) => v);
                yield client.query(`UPDATE purchase_orders SET ${setClause} WHERE id = $1`, [poId, ...values]);
                return yield this.getPurchaseOrderById(poId, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Approve an order (status transition + audit)
     */
    approvePurchaseOrder(poId, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield this.getPurchaseOrderById(poId, tenantId, client);
                yield client.query(`UPDATE purchase_orders SET status='approved', approved_by=$2, approved_at=NOW(), updated_by=$2, updated_at=NOW() WHERE id = $1`, [poId, userId]);
                return yield this.getPurchaseOrderById(poId, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Receive an item in purchase order (partial/complete)
     */
    receivePurchaseOrderItem(poId, itemId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            inventory_validation_1.receivePurchaseOrderItemSchema.parse(data);
            const client = yield this.pool.connect();
            try {
                yield client.query('BEGIN');
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Get PO item
                const itemRes = yield client.query('SELECT * FROM purchase_order_items WHERE purchase_order_id = $1 AND item_id = $2', [poId, itemId]);
                if (itemRes.rows.length === 0)
                    throw new Error('Purchase order item not found');
                const item = itemRes.rows[0];
                // Receive
                const receivedQty = item.received_quantity + data.quantity;
                const newStatus = receivedQty >= item.quantity ? 'received' : 'partial';
                yield client.query('UPDATE purchase_order_items SET received_quantity=$1, status=$2 WHERE id=$3', [receivedQty, newStatus, item.id]);
                // Update inventory stock!
                yield client.query('UPDATE inventory_items SET current_stock = current_stock + $1, updated_at = NOW(), updated_by = $2 WHERE id = $3', [data.quantity, userId, itemId]);
                yield client.query('COMMIT');
                // Return updated item
                const updatedRes = yield client.query('SELECT * FROM purchase_order_items WHERE id = $1', [item.id]);
                return { updatedItem: updatedRes.rows[0], completed: newStatus === 'received' };
            }
            catch (e) {
                yield client.query('ROLLBACK');
                throw e;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Cancel a PO
     */
    cancelPurchaseOrder(poId, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield this.getPurchaseOrderById(poId, tenantId, client);
                yield client.query('UPDATE purchase_orders SET status = $2, updated_by = $3, updated_at = NOW() WHERE id = $1', [poId, 'cancelled', userId]);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * List purchase orders with pagination/filtering
     */
    getPurchaseOrders(tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, params = {}) {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const page = params.page || 1;
                const limit = params.limit || 20;
                const offset = (page - 1) * limit;
                let where = [];
                let vals = [];
                let i = 1;
                if (params.supplier_id) {
                    where.push(`supplier_id = $${i}`);
                    vals.push(params.supplier_id);
                    i++;
                }
                if (params.status) {
                    where.push(`status = $${i}`);
                    vals.push(params.status);
                    i++;
                }
                if (params.payment_status) {
                    where.push(`payment_status = $${i}`);
                    vals.push(params.payment_status);
                    i++;
                }
                if (params.from_date) {
                    where.push(`order_date >= $${i}`);
                    vals.push(params.from_date);
                    i++;
                }
                if (params.to_date) {
                    where.push(`order_date <= $${i}`);
                    vals.push(params.to_date);
                    i++;
                }
                if (params.search) {
                    where.push(`(order_number ILIKE $${i})`);
                    vals.push(`%${params.search}%`);
                    i++;
                }
                const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
                const countRes = yield client.query(`SELECT COUNT(*) as total FROM purchase_orders ${whereClause}`, vals);
                const total = parseInt(countRes.rows[0].total);
                const poRes = yield client.query(`SELECT * FROM purchase_orders ${whereClause} ORDER BY order_date DESC, id DESC LIMIT $${i} OFFSET $${i + 1}`, [...vals, limit, offset]);
                const orders = poRes.rows;
                for (const po of orders) {
                    const itemsRes = yield client.query('SELECT * FROM purchase_order_items WHERE purchase_order_id = $1', [po.id]);
                    po.items = itemsRes.rows;
                }
                return { orders, total, page, limit, pages: Math.ceil(total / limit) };
            }
            finally {
                client.release();
            }
        });
    }
}
exports.PurchaseOrderService = PurchaseOrderService;
