"use strict";
/**
 * Team Alpha - S3 Lifecycle Management Service
 * Complete S3 lifecycle policies and optimization
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.STORAGE_CLASSES = void 0;
exports.getCurrentLifecycleConfiguration = getCurrentLifecycleConfiguration;
exports.applyLifecycleConfiguration = applyLifecycleConfiguration;
exports.calculateLifecycleSavings = calculateLifecycleSavings;
exports.monitorLifecycleTransitions = monitorLifecycleTransitions;
exports.getLifecyclePolicyStatus = getLifecyclePolicyStatus;
exports.validateLifecycleConfiguration = validateLifecycleConfiguration;
const client_s3_1 = require("@aws-sdk/client-s3");
const database_1 = __importDefault(require("../database"));
// Initialize S3 client
const s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
    },
});
const S3_BUCKET = process.env.S3_BUCKET_NAME || 'hospital-medical-records';
/**
 * S3 Storage Class Pricing (approximate, per GB per month)
 */
exports.STORAGE_CLASSES = {
    STANDARD: {
        name: 'Standard',
        costPerGB: 0.023,
        retrievalCostPerGB: 0,
        minimumStorageDuration: 0,
        description: 'Frequently accessed data'
    },
    STANDARD_IA: {
        name: 'Standard-Infrequent Access',
        costPerGB: 0.0125,
        retrievalCostPerGB: 0.01,
        minimumStorageDuration: 30,
        description: 'Infrequently accessed data'
    },
    INTELLIGENT_TIERING: {
        name: 'Intelligent-Tiering',
        costPerGB: 0.023, // Same as Standard for frequent access
        retrievalCostPerGB: 0,
        minimumStorageDuration: 0,
        description: 'Automatic cost optimization'
    },
    GLACIER: {
        name: 'Glacier',
        costPerGB: 0.004,
        retrievalCostPerGB: 0.03,
        minimumStorageDuration: 90,
        description: 'Long-term archival'
    },
    DEEP_ARCHIVE: {
        name: 'Deep Archive',
        costPerGB: 0.00099,
        retrievalCostPerGB: 0.02,
        minimumStorageDuration: 180,
        description: 'Lowest cost archival'
    }
};
/**
 * Get current lifecycle configuration
 */
function getCurrentLifecycleConfiguration() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const command = new client_s3_1.GetBucketLifecycleConfigurationCommand({
                Bucket: S3_BUCKET
            });
            const response = yield s3Client.send(command);
            return ((_a = response.Rules) === null || _a === void 0 ? void 0 : _a.map(rule => {
                var _a, _b, _c, _d;
                return ({
                    id: rule.ID || '',
                    status: rule.Status,
                    filter: rule.Filter ? {
                        prefix: rule.Filter.Prefix,
                        tags: rule.Filter.Tag ? { [rule.Filter.Tag.Key]: rule.Filter.Tag.Value || '' } : undefined
                    } : undefined,
                    transitions: (_a = rule.Transitions) === null || _a === void 0 ? void 0 : _a.map(t => ({
                        days: t.Days || 0,
                        storageClass: t.StorageClass || ''
                    })),
                    noncurrentVersionTransitions: (_b = rule.NoncurrentVersionTransitions) === null || _b === void 0 ? void 0 : _b.map(t => ({
                        noncurrentDays: t.NoncurrentDays || 0,
                        storageClass: t.StorageClass || ''
                    })),
                    abortIncompleteMultipartUpload: rule.AbortIncompleteMultipartUpload ? {
                        daysAfterInitiation: rule.AbortIncompleteMultipartUpload.DaysAfterInitiation || 7
                    } : undefined,
                    expiration: ((_c = rule.Expiration) === null || _c === void 0 ? void 0 : _c.Days) ? {
                        days: rule.Expiration.Days
                    } : undefined,
                    noncurrentVersionExpiration: ((_d = rule.NoncurrentVersionExpiration) === null || _d === void 0 ? void 0 : _d.NoncurrentDays) ? {
                        noncurrentDays: rule.NoncurrentVersionExpiration.NoncurrentDays
                    } : undefined
                });
            })) || [];
        }
        catch (error) {
            console.error('Failed to get lifecycle configuration:', error);
            return [];
        }
    });
}
/**
 * Apply comprehensive lifecycle configuration
 */
function applyLifecycleConfiguration() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const lifecycleRules = [
                {
                    ID: 'medical-records-lifecycle',
                    Status: 'Enabled',
                    Filter: {
                        Prefix: '' // Apply to all objects
                    },
                    Transitions: [
                        {
                            Days: 30,
                            StorageClass: 'STANDARD_IA'
                        },
                        {
                            Days: 90,
                            StorageClass: 'GLACIER'
                        },
                        {
                            Days: 180,
                            StorageClass: 'DEEP_ARCHIVE'
                        }
                    ],
                    NoncurrentVersionTransitions: [
                        {
                            NoncurrentDays: 30,
                            StorageClass: 'STANDARD_IA'
                        },
                        {
                            NoncurrentDays: 60,
                            StorageClass: 'GLACIER'
                        },
                        {
                            NoncurrentDays: 90,
                            StorageClass: 'DEEP_ARCHIVE'
                        }
                    ],
                    AbortIncompleteMultipartUpload: {
                        DaysAfterInitiation: 7
                    }
                },
                {
                    ID: 'intelligent-tiering-rule',
                    Status: 'Enabled',
                    Filter: {
                        Prefix: ''
                    },
                    Transitions: [
                        {
                            Days: 0,
                            StorageClass: 'INTELLIGENT_TIERING'
                        }
                    ]
                },
                {
                    ID: 'delete-old-versions',
                    Status: 'Enabled',
                    Filter: {
                        Prefix: ''
                    },
                    NoncurrentVersionExpiration: {
                        NoncurrentDays: 365 // Delete old versions after 1 year
                    }
                }
            ];
            const command = new client_s3_1.PutBucketLifecycleConfigurationCommand({
                Bucket: S3_BUCKET,
                LifecycleConfiguration: {
                    Rules: lifecycleRules
                }
            });
            yield s3Client.send(command);
            return true;
        }
        catch (error) {
            console.error('Failed to apply lifecycle configuration:', error);
            return false;
        }
    });
}
/**
 * Calculate potential cost savings from lifecycle policies
 */
function calculateLifecycleSavings(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Get file access patterns for the tenant
            const accessPatterns = yield database_1.default.query(`
      SELECT 
        file_id,
        file_path,
        avg_file_size,
        last_accessed,
        total_accesses,
        recommended_storage_class
      FROM file_access_patterns
      WHERE tenant_id = $1
    `, [tenantId]);
            let currentMonthlyCost = 0;
            let optimizedMonthlyCost = 0;
            const breakdown = [];
            for (const file of accessPatterns.rows) {
                const fileSizeGB = (file.avg_file_size || 0) / (1024 * 1024 * 1024);
                const currentStorageClass = 'STANDARD'; // Assume current is Standard
                const recommendedStorageClass = file.recommended_storage_class || 'STANDARD';
                const currentCost = fileSizeGB * exports.STORAGE_CLASSES[currentStorageClass].costPerGB;
                const optimizedCost = fileSizeGB * exports.STORAGE_CLASSES[recommendedStorageClass].costPerGB;
                const savings = currentCost - optimizedCost;
                currentMonthlyCost += currentCost;
                optimizedMonthlyCost += optimizedCost;
                breakdown.push({
                    storageClass: recommendedStorageClass,
                    fileSizeGB,
                    currentCost,
                    optimizedCost,
                    savings
                });
            }
            const monthlySavings = currentMonthlyCost - optimizedMonthlyCost;
            const savingsPercentage = currentMonthlyCost > 0 ? (monthlySavings / currentMonthlyCost) * 100 : 0;
            return {
                currentMonthlyCost,
                optimizedMonthlyCost,
                monthlySavings,
                savingsPercentage,
                breakdown
            };
        }
        catch (error) {
            console.error('Failed to calculate lifecycle savings:', error);
            return {
                currentMonthlyCost: 0,
                optimizedMonthlyCost: 0,
                monthlySavings: 0,
                savingsPercentage: 0,
                breakdown: []
            };
        }
    });
}
/**
 * Monitor lifecycle transitions
 */
function monitorLifecycleTransitions(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield database_1.default.query(`
      SELECT 
        file_id,
        file_path,
        last_accessed,
        recommended_storage_class,
        avg_file_size
      FROM file_access_patterns
      WHERE tenant_id = $1
        AND last_accessed IS NOT NULL
      ORDER BY last_accessed DESC
    `, [tenantId]);
            const transitions = [];
            const now = new Date();
            for (const file of result.rows) {
                const lastAccessed = new Date(file.last_accessed);
                const daysSinceAccess = Math.floor((now.getTime() - lastAccessed.getTime()) / (1000 * 60 * 60 * 24));
                let nextStorageClass = 'STANDARD';
                let daysUntilTransition = 0;
                let transitionDate = new Date();
                if (daysSinceAccess < 30) {
                    nextStorageClass = 'STANDARD_IA';
                    daysUntilTransition = 30 - daysSinceAccess;
                    transitionDate = new Date(lastAccessed.getTime() + (30 * 24 * 60 * 60 * 1000));
                }
                else if (daysSinceAccess < 90) {
                    nextStorageClass = 'GLACIER';
                    daysUntilTransition = 90 - daysSinceAccess;
                    transitionDate = new Date(lastAccessed.getTime() + (90 * 24 * 60 * 60 * 1000));
                }
                else if (daysSinceAccess < 180) {
                    nextStorageClass = 'DEEP_ARCHIVE';
                    daysUntilTransition = 180 - daysSinceAccess;
                    transitionDate = new Date(lastAccessed.getTime() + (180 * 24 * 60 * 60 * 1000));
                }
                const fileSizeGB = (file.avg_file_size || 0) / (1024 * 1024 * 1024);
                const currentCost = fileSizeGB * exports.STORAGE_CLASSES.STANDARD.costPerGB;
                const newCost = fileSizeGB * exports.STORAGE_CLASSES[nextStorageClass].costPerGB;
                const estimatedSavings = currentCost - newCost;
                if (nextStorageClass !== 'STANDARD') {
                    transitions.push({
                        fileId: file.file_id,
                        filePath: file.file_path,
                        currentStorageClass: 'STANDARD',
                        transitionDate,
                        nextStorageClass,
                        daysUntilTransition,
                        estimatedSavings
                    });
                }
            }
            return transitions;
        }
        catch (error) {
            console.error('Failed to monitor lifecycle transitions:', error);
            return [];
        }
    });
}
/**
 * Get lifecycle policy status
 */
function getLifecyclePolicyStatus() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const rules = yield getCurrentLifecycleConfiguration();
            const activeRules = rules.filter(rule => rule.status === 'Enabled').length;
            return {
                isConfigured: rules.length > 0,
                rules,
                totalRules: rules.length,
                activeRules,
                lastUpdated: new Date() // Would be actual last modified date in production
            };
        }
        catch (error) {
            console.error('Failed to get lifecycle policy status:', error);
            return {
                isConfigured: false,
                rules: [],
                totalRules: 0,
                activeRules: 0
            };
        }
    });
}
/**
 * Validate lifecycle configuration
 */
function validateLifecycleConfiguration() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const rules = yield getCurrentLifecycleConfiguration();
            const issues = [];
            const recommendations = [];
            if (rules.length === 0) {
                issues.push('No lifecycle rules configured');
                recommendations.push('Configure lifecycle rules for cost optimization');
            }
            const hasIntelligentTiering = rules.some(rule => { var _a; return (_a = rule.transitions) === null || _a === void 0 ? void 0 : _a.some(t => t.storageClass === 'INTELLIGENT_TIERING'); });
            if (!hasIntelligentTiering) {
                recommendations.push('Consider adding Intelligent-Tiering for automatic optimization');
            }
            const hasMultipartCleanup = rules.some(rule => rule.abortIncompleteMultipartUpload);
            if (!hasMultipartCleanup) {
                issues.push('No multipart upload cleanup configured');
                recommendations.push('Add multipart upload cleanup to prevent storage waste');
            }
            const hasVersionCleanup = rules.some(rule => rule.noncurrentVersionExpiration);
            if (!hasVersionCleanup) {
                recommendations.push('Consider adding old version cleanup for cost savings');
            }
            return {
                isValid: issues.length === 0,
                issues,
                recommendations
            };
        }
        catch (error) {
            console.error('Failed to validate lifecycle configuration:', error);
            return {
                isValid: false,
                issues: ['Failed to validate configuration'],
                recommendations: []
            };
        }
    });
}
exports.default = {
    getCurrentLifecycleConfiguration,
    applyLifecycleConfiguration,
    calculateLifecycleSavings,
    monitorLifecycleTransitions,
    getLifecyclePolicyStatus,
    validateLifecycleConfiguration,
    STORAGE_CLASSES: exports.STORAGE_CLASSES
};
