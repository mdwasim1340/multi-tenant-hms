"use strict";
/**
 * Logo Processor Service
 * Purpose: Process and resize uploaded logos for different use cases
 * Requirements: 5.5
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processLogo = processLogo;
exports.processAndUploadLogo = processAndUploadLogo;
exports.updateTenantBrandingWithLogos = updateTenantBrandingWithLogos;
exports.validateLogoFile = validateLogoFile;
const sharp_1 = __importDefault(require("sharp"));
const client_s3_1 = require("@aws-sdk/client-s3");
const database_1 = __importDefault(require("../database"));
const subdomain_cache_1 = require("./subdomain-cache");
const s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
    },
});
const S3_BUCKET = process.env.S3_BUCKET_NAME || 'your-bucket-name';
/**
 * Process logo and generate multiple sizes
 *
 * @param buffer - Original logo file buffer
 * @param mimeType - MIME type of the image
 * @returns Object with buffers for each size
 */
function processLogo(buffer, mimeType) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Determine output format based on input
            let format = 'png';
            if (mimeType.includes('jpeg') || mimeType.includes('jpg')) {
                format = 'jpeg';
            }
            else if (mimeType.includes('webp')) {
                format = 'webp';
            }
            // Generate small logo (64x64)
            const small = yield (0, sharp_1.default)(buffer)
                .resize(64, 64, {
                fit: 'contain',
                background: { r: 255, g: 255, b: 255, alpha: 0 },
            })
                .toFormat(format)
                .toBuffer();
            // Generate medium logo (128x128)
            const medium = yield (0, sharp_1.default)(buffer)
                .resize(128, 128, {
                fit: 'contain',
                background: { r: 255, g: 255, b: 255, alpha: 0 },
            })
                .toFormat(format)
                .toBuffer();
            // Generate large logo (256x256)
            const large = yield (0, sharp_1.default)(buffer)
                .resize(256, 256, {
                fit: 'contain',
                background: { r: 255, g: 255, b: 255, alpha: 0 },
            })
                .toFormat(format)
                .toBuffer();
            console.log('✅ Logo processed successfully (small, medium, large)');
            return { small, medium, large };
        }
        catch (error) {
            console.error('Error processing logo:', error);
            throw new Error('Failed to process logo');
        }
    });
}
/**
 * Upload logo to S3
 *
 * @param buffer - Image buffer
 * @param key - S3 object key
 * @param mimeType - MIME type of the image
 * @returns S3 URL
 */
function uploadToS3(buffer, key, mimeType) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const command = new client_s3_1.PutObjectCommand({
                Bucket: S3_BUCKET,
                Key: key,
                Body: buffer,
                ContentType: mimeType,
                ACL: 'private', // Private access, use presigned URLs for retrieval
            });
            yield s3Client.send(command);
            // Return S3 URL
            const url = `https://${S3_BUCKET}.s3.${process.env.AWS_REGION || 'us-east-1'}.amazonaws.com/${key}`;
            console.log(`✅ Uploaded to S3: ${key}`);
            return url;
        }
        catch (error) {
            console.error('Error uploading to S3:', error);
            throw new Error('Failed to upload logo to S3');
        }
    });
}
/**
 * Process and upload logo with all sizes
 *
 * @param tenantId - Tenant ID
 * @param originalBuffer - Original logo file buffer
 * @param filename - Original filename
 * @param mimeType - MIME type of the image
 * @returns Object with all logo URLs
 */
function processAndUploadLogo(tenantId, originalBuffer, filename, mimeType) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Get file extension
            const ext = filename.split('.').pop() || 'png';
            // Process logo to generate different sizes
            const sizes = yield processLogo(originalBuffer, mimeType);
            // Upload original
            const originalKey = `${tenantId}/branding/logo-original.${ext}`;
            const originalUrl = yield uploadToS3(originalBuffer, originalKey, mimeType);
            // Upload small
            const smallKey = `${tenantId}/branding/logo-small.${ext}`;
            const smallUrl = yield uploadToS3(sizes.small, smallKey, mimeType);
            // Upload medium
            const mediumKey = `${tenantId}/branding/logo-medium.${ext}`;
            const mediumUrl = yield uploadToS3(sizes.medium, mediumKey, mimeType);
            // Upload large
            const largeKey = `${tenantId}/branding/logo-large.${ext}`;
            const largeUrl = yield uploadToS3(sizes.large, largeKey, mimeType);
            console.log(`✅ All logo sizes uploaded for tenant: ${tenantId}`);
            return {
                original: originalUrl,
                small: smallUrl,
                medium: mediumUrl,
                large: largeUrl,
            };
        }
        catch (error) {
            console.error('Error processing and uploading logo:', error);
            throw error;
        }
    });
}
/**
 * Update tenant branding with logo URLs
 *
 * @param tenantId - Tenant ID
 * @param logoUrls - Object with all logo URLs
 */
function updateTenantBrandingWithLogos(tenantId, logoUrls) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield database_1.default.query(`UPDATE tenant_branding
       SET logo_url = $1,
           logo_small_url = $2,
           logo_medium_url = $3,
           logo_large_url = $4,
           updated_at = CURRENT_TIMESTAMP
       WHERE tenant_id = $5`, [logoUrls.original, logoUrls.small, logoUrls.medium, logoUrls.large, tenantId]);
            // Invalidate cache
            const tenantResult = yield database_1.default.query('SELECT subdomain FROM tenants WHERE id = $1', [tenantId]);
            if (tenantResult.rows.length > 0 && tenantResult.rows[0].subdomain) {
                yield subdomain_cache_1.subdomainCache.invalidate(tenantResult.rows[0].subdomain);
            }
            console.log(`✅ Tenant branding updated with logo URLs: ${tenantId}`);
        }
        catch (error) {
            console.error('Error updating tenant branding:', error);
            throw new Error('Failed to update tenant branding with logo URLs');
        }
    });
}
/**
 * Validate logo file
 *
 * @param file - Multer file object
 * @returns Validation result
 */
function validateLogoFile(file) {
    // Check file size (2MB max)
    const maxSize = 2 * 1024 * 1024; // 2MB in bytes
    if (file.size > maxSize) {
        return {
            valid: false,
            error: 'File size exceeds 2MB limit',
        };
    }
    // Check file type
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
    if (!allowedTypes.includes(file.mimetype)) {
        return {
            valid: false,
            error: 'Invalid file type. Only PNG, JPG, and SVG are allowed',
        };
    }
    return { valid: true };
}
