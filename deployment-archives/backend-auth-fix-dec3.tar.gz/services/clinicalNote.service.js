"use strict";
// Clinical Note Service
// Requirements: 2.3, 2.5 - CRUD operations with version history
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClinicalNoteService = void 0;
class ClinicalNoteService {
    constructor(pool) {
        this.pool = pool;
    }
    /**
     * Ensure clinical_notes table exists
     */
    ensureTableExists(dbClient) {
        return __awaiter(this, void 0, void 0, function* () {
            yield dbClient.query(`
      CREATE TABLE IF NOT EXISTS clinical_notes (
        id SERIAL PRIMARY KEY,
        patient_id INTEGER NOT NULL,
        provider_id INTEGER NOT NULL,
        note_type VARCHAR(50) NOT NULL,
        content TEXT NOT NULL,
        summary TEXT,
        template_id INTEGER,
        status VARCHAR(20) DEFAULT 'draft',
        signed_at TIMESTAMP,
        signed_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
            // Drop foreign key constraint if it exists (allows clinical notes for any patient_id)
            try {
                yield dbClient.query(`
        ALTER TABLE clinical_notes 
        DROP CONSTRAINT IF EXISTS clinical_notes_patient_id_fkey
      `);
            }
            catch (_a) {
                // Constraint may not exist, ignore error
            }
        });
    }
    /**
     * Create a new clinical note
     */
    createClinicalNote(data, client) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const dbClient = client || this.pool;
            console.log('ClinicalNoteService.createClinicalNote - Using client:', client ? 'PoolClient' : 'Pool');
            console.log('ClinicalNoteService.createClinicalNote - Data:', JSON.stringify(data, null, 2));
            try {
                yield this.ensureTableExists(dbClient);
                console.log('ClinicalNoteService.createClinicalNote - Table ensured');
            }
            catch (err) {
                console.error('ClinicalNoteService.createClinicalNote - Error ensuring table:', err);
                throw err;
            }
            const query = `
      INSERT INTO clinical_notes (
        patient_id, provider_id, note_type, content, summary, template_id, status
      ) VALUES ($1, $2, $3, $4, $5, $6, 'draft')
      RETURNING *
    `;
            const values = [
                data.patient_id,
                data.provider_id,
                data.note_type,
                data.content,
                data.summary || null,
                data.template_id || null
            ];
            console.log('ClinicalNoteService.createClinicalNote - Executing query with values:', values);
            try {
                const result = yield dbClient.query(query, values);
                console.log('ClinicalNoteService.createClinicalNote - Success, created note:', (_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.id);
                return result.rows[0];
            }
            catch (err) {
                console.error('ClinicalNoteService.createClinicalNote - Query error:', err);
                throw err;
            }
        });
    }
    /**
     * Get clinical note by ID
     */
    getClinicalNoteById(noteId_1) {
        return __awaiter(this, arguments, void 0, function* (noteId, includeVersions = false, client) {
            const dbClient = client || this.pool;
            yield this.ensureTableExists(dbClient);
            const noteResult = yield dbClient.query('SELECT * FROM clinical_notes WHERE id = $1', [noteId]);
            if (noteResult.rows.length === 0)
                return null;
            const note = noteResult.rows[0];
            if (includeVersions) {
                try {
                    const versionsResult = yield dbClient.query('SELECT * FROM clinical_note_versions WHERE note_id = $1 ORDER BY version_number DESC', [noteId]);
                    return Object.assign(Object.assign({}, note), { versions: versionsResult.rows });
                }
                catch (_a) {
                    return Object.assign(Object.assign({}, note), { versions: [] });
                }
            }
            return note;
        });
    }
    /**
     * Get clinical notes with filtering and pagination
     */
    getClinicalNotes(filters, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            yield this.ensureTableExists(dbClient);
            const conditions = ['1=1'];
            const values = [];
            let paramIndex = 1;
            if (filters.patient_id) {
                conditions.push(`patient_id = $${paramIndex}`);
                values.push(filters.patient_id);
                paramIndex++;
            }
            if (filters.provider_id) {
                conditions.push(`provider_id = $${paramIndex}`);
                values.push(filters.provider_id);
                paramIndex++;
            }
            if (filters.note_type) {
                conditions.push(`note_type = $${paramIndex}`);
                values.push(filters.note_type);
                paramIndex++;
            }
            if (filters.status) {
                conditions.push(`status = $${paramIndex}`);
                values.push(filters.status);
                paramIndex++;
            }
            if (filters.date_from) {
                conditions.push(`created_at >= $${paramIndex}`);
                values.push(filters.date_from);
                paramIndex++;
            }
            if (filters.date_to) {
                conditions.push(`created_at <= $${paramIndex}`);
                values.push(filters.date_to);
                paramIndex++;
            }
            if (filters.search) {
                conditions.push(`(content ILIKE $${paramIndex} OR summary ILIKE $${paramIndex})`);
                values.push(`%${filters.search}%`);
                paramIndex++;
            }
            const whereClause = conditions.join(' AND ');
            // Get total count
            const countResult = yield dbClient.query(`SELECT COUNT(*) FROM clinical_notes WHERE ${whereClause}`, values);
            const total = parseInt(countResult.rows[0].count);
            // Get paginated results
            const page = filters.page || 1;
            const limit = filters.limit || 10;
            const offset = (page - 1) * limit;
            const notesResult = yield dbClient.query(`SELECT * FROM clinical_notes WHERE ${whereClause} ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...values, limit, offset]);
            return { notes: notesResult.rows, total };
        });
    }
    /**
     * Update clinical note
     */
    updateClinicalNote(noteId, data, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            const updates = [];
            const values = [];
            let paramIndex = 1;
            if (data.content !== undefined) {
                updates.push(`content = $${paramIndex}`);
                values.push(data.content);
                paramIndex++;
            }
            if (data.summary !== undefined) {
                updates.push(`summary = $${paramIndex}`);
                values.push(data.summary);
                paramIndex++;
            }
            if (data.note_type !== undefined) {
                updates.push(`note_type = $${paramIndex}`);
                values.push(data.note_type);
                paramIndex++;
            }
            if (updates.length === 0) {
                return this.getClinicalNoteById(noteId, false, client);
            }
            updates.push(`updated_at = CURRENT_TIMESTAMP`);
            values.push(noteId);
            const result = yield dbClient.query(`UPDATE clinical_notes SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`, values);
            return result.rows.length > 0 ? result.rows[0] : null;
        });
    }
    /**
     * Sign a clinical note
     */
    signClinicalNote(noteId, signedBy, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            const result = yield dbClient.query(`UPDATE clinical_notes SET status = 'signed', signed_at = CURRENT_TIMESTAMP, signed_by = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND status = 'draft' RETURNING *`, [signedBy, noteId]);
            return result.rows.length > 0 ? result.rows[0] : null;
        });
    }
    /**
     * Delete a clinical note
     */
    deleteClinicalNote(noteId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            const result = yield dbClient.query('DELETE FROM clinical_notes WHERE id = $1', [noteId]);
            return result.rowCount !== null && result.rowCount > 0;
        });
    }
    /**
     * Get version history for a clinical note
     */
    getClinicalNoteVersions(noteId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            try {
                const result = yield dbClient.query('SELECT * FROM clinical_note_versions WHERE note_id = $1 ORDER BY version_number DESC', [noteId]);
                return result.rows;
            }
            catch (_a) {
                return [];
            }
        });
    }
    /**
     * Get a specific version of a clinical note
     */
    getClinicalNoteVersion(noteId, versionNumber, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            try {
                const result = yield dbClient.query('SELECT * FROM clinical_note_versions WHERE note_id = $1 AND version_number = $2', [noteId, versionNumber]);
                return result.rows.length > 0 ? result.rows[0] : null;
            }
            catch (_a) {
                return null;
            }
        });
    }
    /**
     * Get clinical notes by patient ID
     */
    getClinicalNotesByPatient(patientId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            yield this.ensureTableExists(dbClient);
            const result = yield dbClient.query('SELECT * FROM clinical_notes WHERE patient_id = $1 ORDER BY created_at DESC', [patientId]);
            return result.rows;
        });
    }
    /**
     * Get clinical notes by provider ID
     */
    getClinicalNotesByProvider(providerId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || this.pool;
            yield this.ensureTableExists(dbClient);
            const result = yield dbClient.query('SELECT * FROM clinical_notes WHERE provider_id = $1 ORDER BY created_at DESC', [providerId]);
            return result.rows;
        });
    }
}
exports.ClinicalNoteService = ClinicalNoteService;
