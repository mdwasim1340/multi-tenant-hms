"use strict";
/**
 * Team Alpha - S3 Service
 * Handle S3 file operations with presigned URLs and cost optimization
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateS3Key = generateS3Key;
exports.generateUploadUrl = generateUploadUrl;
exports.generateDownloadUrl = generateDownloadUrl;
exports.deleteFile = deleteFile;
exports.compressFile = compressFile;
exports.shouldCompressFile = shouldCompressFile;
exports.getFileSize = getFileSize;
exports.listRecordFiles = listRecordFiles;
exports.estimateStorageCost = estimateStorageCost;
exports.logFileAccess = logFileAccess;
exports.generateDownloadUrlWithTracking = generateDownloadUrlWithTracking;
exports.generateUploadUrlWithTracking = generateUploadUrlWithTracking;
exports.getAccessPatterns = getAccessPatterns;
exports.getStorageRecommendations = getStorageRecommendations;
exports.getTenantAccessStats = getTenantAccessStats;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const zlib_1 = require("zlib");
const util_1 = require("util");
const stream_1 = require("stream");
const pipelineAsync = (0, util_1.promisify)(stream_1.pipeline);
// Initialize S3 client
const s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
    },
});
const S3_BUCKET = process.env.S3_BUCKET_NAME || 'hospital-medical-records';
const PRESIGNED_URL_EXPIRATION = 3600; // 1 hour
/**
 * Generate S3 key for medical record attachment
 * Format: {tenant-id}/medical-records/{year}/{month}/{record-id}/{filename}
 */
function generateS3Key(tenantId, recordId, filename) {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    // Sanitize filename
    const sanitizedFilename = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
    return `${tenantId}/medical-records/${year}/${month}/${recordId}/${sanitizedFilename}`;
}
/**
 * Generate presigned URL for uploading a file to S3
 */
function generateUploadUrl(tenantId, recordId, filename, contentType) {
    return __awaiter(this, void 0, void 0, function* () {
        const s3Key = generateS3Key(tenantId, recordId, filename);
        const command = new client_s3_1.PutObjectCommand({
            Bucket: S3_BUCKET,
            Key: s3Key,
            ContentType: contentType,
            // Enable server-side encryption
            ServerSideEncryption: 'AES256',
            // Set storage class to Intelligent-Tiering for cost optimization
            StorageClass: 'INTELLIGENT_TIERING',
            // Add metadata
            Metadata: {
                'tenant-id': tenantId,
                'record-id': String(recordId),
                'uploaded-at': new Date().toISOString(),
            },
        });
        const uploadUrl = yield (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
            expiresIn: PRESIGNED_URL_EXPIRATION,
        });
        return { uploadUrl, s3Key };
    });
}
/**
 * Generate presigned URL for downloading a file from S3
 */
function generateDownloadUrl(s3Key) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: S3_BUCKET,
            Key: s3Key,
        });
        const downloadUrl = yield (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
            expiresIn: PRESIGNED_URL_EXPIRATION,
        });
        return downloadUrl;
    });
}
/**
 * Delete a file from S3
 */
function deleteFile(s3Key) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.DeleteObjectCommand({
            Bucket: S3_BUCKET,
            Key: s3Key,
        });
        yield s3Client.send(command);
    });
}
/**
 * Compress file buffer using gzip
 * Used for text files (PDFs, documents) to reduce storage costs
 */
function compressFile(buffer) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const chunks = [];
            const gzip = (0, zlib_1.createGzip)();
            gzip.on('data', (chunk) => chunks.push(chunk));
            gzip.on('end', () => resolve(Buffer.concat(chunks)));
            gzip.on('error', reject);
            gzip.write(buffer);
            gzip.end();
        });
    });
}
/**
 * Check if file type should be compressed
 * Compress text-based files, skip images and already compressed formats
 */
function shouldCompressFile(contentType) {
    const compressibleTypes = [
        'application/pdf',
        'text/',
        'application/json',
        'application/xml',
    ];
    const skipTypes = [
        'image/',
        'video/',
        'audio/',
        'application/zip',
        'application/gzip',
    ];
    // Skip if already compressed
    if (skipTypes.some(type => contentType.startsWith(type))) {
        return false;
    }
    // Compress if text-based
    return compressibleTypes.some(type => contentType.startsWith(type));
}
/**
 * Get file size from S3
 */
function getFileSize(s3Key) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: S3_BUCKET,
            Key: s3Key,
        });
        const response = yield s3Client.send(command);
        return response.ContentLength || 0;
    });
}
/**
 * List files for a medical record
 */
function listRecordFiles(tenantId, recordId) {
    return __awaiter(this, void 0, void 0, function* () {
        // This would use ListObjectsV2Command in production
        // For now, we'll rely on database records
        return [];
    });
}
/**
 * Calculate storage cost estimate
 * Based on AWS S3 Intelligent-Tiering pricing
 */
function estimateStorageCost(fileSizeBytes, daysStored = 30) {
    const fileSizeGB = fileSizeBytes / (1024 * 1024 * 1024);
    // Intelligent-Tiering pricing (approximate)
    const frequentAccessCost = 0.023; // per GB per month
    const infrequentAccessCost = 0.0125; // per GB per month
    // Assume first 30 days in frequent access, then infrequent
    const monthlyFraction = daysStored / 30;
    const cost = fileSizeGB * frequentAccessCost * monthlyFraction;
    return cost;
}
exports.default = {
    generateS3Key,
    generateUploadUrl,
    generateDownloadUrl,
    deleteFile,
    compressFile,
    shouldCompressFile,
    getFileSize,
    listRecordFiles,
    estimateStorageCost,
};
/**
 * Track file access for Intelligent-Tiering optimization
 */
const database_1 = __importDefault(require("../database"));
/**
 * Log file access for optimization analysis
 */
function logFileAccess(params) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield database_1.default.query(`
      INSERT INTO file_access_logs (
        tenant_id, file_id, file_path, access_type, user_id,
        file_size_bytes, storage_class, ip_address, user_agent,
        response_time_ms, success, error_message
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    `, [
                params.tenantId,
                params.fileId,
                params.filePath,
                params.accessType,
                params.userId || null,
                params.fileSizeBytes || null,
                params.storageClass || 'STANDARD',
                params.ipAddress || null,
                params.userAgent || null,
                params.responseTimeMs || null,
                params.success !== false,
                params.errorMessage || null
            ]);
        }
        catch (error) {
            console.error('Failed to log file access:', error);
            // Don't throw - logging failure shouldn't break file operations
        }
    });
}
/**
 * Enhanced download URL generation with access tracking
 */
function generateDownloadUrlWithTracking(tenantId, s3Key, userId, fileSize, ipAddress, userAgent) {
    return __awaiter(this, void 0, void 0, function* () {
        const startTime = Date.now();
        try {
            // Generate presigned URL
            const command = new client_s3_1.GetObjectCommand({
                Bucket: S3_BUCKET,
                Key: s3Key,
            });
            const url = yield (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
                expiresIn: PRESIGNED_URL_EXPIRATION,
            });
            const responseTime = Date.now() - startTime;
            // Log file access for optimization
            yield logFileAccess({
                tenantId,
                fileId: s3Key.split('/').pop() || s3Key,
                filePath: s3Key,
                accessType: 'download',
                userId,
                fileSizeBytes: fileSize,
                storageClass: 'STANDARD', // Default, could be enhanced to detect actual class
                ipAddress,
                userAgent,
                responseTimeMs: responseTime,
                success: true
            });
            return url;
        }
        catch (error) {
            const responseTime = Date.now() - startTime;
            // Log failed access
            yield logFileAccess({
                tenantId,
                fileId: s3Key.split('/').pop() || s3Key,
                filePath: s3Key,
                accessType: 'download',
                userId,
                fileSizeBytes: fileSize,
                ipAddress,
                userAgent,
                responseTimeMs: responseTime,
                success: false,
                errorMessage: error instanceof Error ? error.message : 'Unknown error'
            });
            throw error;
        }
    });
}
/**
 * Enhanced upload URL generation with access tracking
 */
function generateUploadUrlWithTracking(tenantId, recordId, filename, contentType, userId, ipAddress, userAgent) {
    return __awaiter(this, void 0, void 0, function* () {
        const startTime = Date.now();
        try {
            const result = yield generateUploadUrl(tenantId, recordId, filename, contentType);
            const responseTime = Date.now() - startTime;
            // Log file upload initiation
            yield logFileAccess({
                tenantId,
                fileId: filename,
                filePath: result.s3Key,
                accessType: 'upload',
                userId,
                storageClass: 'INTELLIGENT_TIERING',
                ipAddress,
                userAgent,
                responseTimeMs: responseTime,
                success: true
            });
            return result;
        }
        catch (error) {
            const responseTime = Date.now() - startTime;
            // Log failed upload
            yield logFileAccess({
                tenantId,
                fileId: filename,
                filePath: `${tenantId}/medical-records/${recordId}/${filename}`,
                accessType: 'upload',
                userId,
                ipAddress,
                userAgent,
                responseTimeMs: responseTime,
                success: false,
                errorMessage: error instanceof Error ? error.message : 'Unknown error'
            });
            throw error;
        }
    });
}
/**
 * Get access patterns for a tenant
 */
function getAccessPatterns(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield database_1.default.query(`
    SELECT * FROM file_access_patterns
    WHERE tenant_id = $1
    ORDER BY last_accessed DESC
  `, [tenantId]);
        return result.rows;
    });
}
/**
 * Get storage optimization recommendations
 */
function getStorageRecommendations(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield database_1.default.query(`
    SELECT * FROM recommend_storage_transitions($1)
  `, [tenantId]);
        return result.rows;
    });
}
/**
 * Get tenant access statistics
 */
function getTenantAccessStats(tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield database_1.default.query(`
    SELECT * FROM get_tenant_access_stats($1)
  `, [tenantId]);
        return result.rows[0] || {
            total_files: 0,
            total_accesses: 0,
            unique_users: 0,
            avg_accesses_per_file: 0,
            files_not_accessed_30_days: 0,
            files_not_accessed_90_days: 0,
            files_not_accessed_180_days: 0,
            recommended_standard: 0,
            recommended_standard_ia: 0,
            recommended_glacier: 0,
            recommended_deep_archive: 0
        };
    });
}
