"use strict";
/**
 * Notification WebSocket Service
 * Team: Epsilon
 * Purpose: Real-time notification delivery via WebSocket
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.notificationWebSocketService = void 0;
const ws_1 = require("ws");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwk_to_pem_1 = __importDefault(require("jwk-to-pem"));
const node_fetch_1 = __importDefault(require("node-fetch"));
class NotificationWebSocketService {
    constructor() {
        this.wss = null;
        this.clients = new Map();
        this.connectionInfo = new Map();
        this.heartbeatInterval = null;
        this.pems = {};
        this.initializeJWKS();
    }
    /**
     * Initialize JWKS for token verification
     */
    initializeJWKS() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const url = `https://cognito-idp.${process.env.AWS_REGION}.amazonaws.com/${process.env.COGNITO_USER_POOL_ID}/.well-known/jwks.json`;
                const response = yield (0, node_fetch_1.default)(url);
                const jwks = yield response.json();
                if (jwks && jwks.keys) {
                    this.pems = jwks.keys.reduce((acc, key) => {
                        if (key.kty === 'RSA') {
                            acc[key.kid] = (0, jwk_to_pem_1.default)({ kty: key.kty, n: key.n, e: key.e });
                        }
                        return acc;
                    }, {});
                }
            }
            catch (error) {
                console.error('Error initializing JWKS:', error);
            }
        });
    }
    /**
     * Verify JWT token
     */
    verifyToken(token) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const decodedToken = jsonwebtoken_1.default.decode(token, { complete: true });
                if (!decodedToken || !decodedToken.header.kid) {
                    return null;
                }
                const pem = this.pems[decodedToken.header.kid];
                if (!pem) {
                    return null;
                }
                const decoded = jsonwebtoken_1.default.verify(token, pem);
                return {
                    userId: decoded.sub ? parseInt(decoded.sub) : undefined,
                    tenantId: decoded['custom:tenant_id'] || decoded.tenant_id,
                    email: decoded.email,
                };
            }
            catch (error) {
                console.error('Token verification error:', error);
                return null;
            }
        });
    }
    /**
     * Initialize WebSocket server
     */
    initialize(server) {
        this.wss = new ws_1.Server({
            server,
            path: '/ws/notifications',
            verifyClient: (info, callback) => {
                // Allow connection, authentication happens in connection handler
                callback(true);
            },
        });
        this.wss.on('connection', (ws, req) => __awaiter(this, void 0, void 0, function* () {
            try {
                // Extract token from query string or headers
                const token = this.extractToken(req);
                if (!token) {
                    ws.close(1008, 'Authentication required');
                    return;
                }
                // Verify JWT token
                const decoded = yield this.verifyToken(token);
                if (!decoded || !decoded.userId || !decoded.tenantId) {
                    ws.close(1008, 'Invalid token');
                    return;
                }
                // Setup authenticated connection
                ws.userId = decoded.userId || 0;
                ws.tenantId = decoded.tenantId || '';
                ws.isAlive = true;
                ws.connectionId = this.generateConnectionId();
                // Store connection info
                if (ws.connectionId && ws.userId && ws.tenantId) {
                    this.connectionInfo.set(ws.connectionId, {
                        userId: ws.userId,
                        tenantId: ws.tenantId,
                        connectedAt: new Date(),
                        lastPing: new Date(),
                    });
                    // Add client to tracking
                    if (!this.clients.has(ws.userId)) {
                        this.clients.set(ws.userId, new Set());
                    }
                    this.clients.get(ws.userId).add(ws);
                }
                console.log(`[WebSocket] User ${ws.userId} (tenant: ${ws.tenantId}) connected. Total connections: ${this.getConnectionCount()}`);
                // Setup event handlers
                this.setupEventHandlers(ws);
                // Send connection confirmation
                this.sendToClient(ws, {
                    type: 'connected',
                    userId: ws.userId,
                    tenantId: ws.tenantId,
                    connectionId: ws.connectionId,
                    timestamp: new Date().toISOString(),
                });
            }
            catch (error) {
                console.error('[WebSocket] Connection error:', error);
                ws.close(1008, 'Authentication failed');
            }
        }));
        // Start heartbeat monitoring
        this.startHeartbeat();
        console.log('[WebSocket] Server initialized on path /ws/notifications');
    }
    /**
     * Setup event handlers for WebSocket connection
     */
    setupEventHandlers(ws) {
        // Handle pong responses (heartbeat)
        ws.on('pong', () => {
            ws.isAlive = true;
            if (ws.connectionId) {
                const info = this.connectionInfo.get(ws.connectionId);
                if (info) {
                    info.lastPing = new Date();
                }
            }
        });
        // Handle incoming messages
        ws.on('message', (data) => {
            try {
                const message = JSON.parse(data.toString());
                this.handleClientMessage(ws, message);
            }
            catch (error) {
                console.error('[WebSocket] Error parsing message:', error);
            }
        });
        // Handle connection close
        ws.on('close', () => {
            this.removeClient(ws);
            console.log(`[WebSocket] User ${ws.userId} disconnected. Total connections: ${this.getConnectionCount()}`);
        });
        // Handle errors
        ws.on('error', error => {
            console.error(`[WebSocket] Error for user ${ws.userId}:`, error);
            this.removeClient(ws);
        });
    }
    /**
     * Handle messages from client
     */
    handleClientMessage(ws, message) {
        switch (message.type) {
            case 'ping':
                this.sendToClient(ws, { type: 'pong', timestamp: new Date().toISOString() });
                break;
            case 'subscribe':
                // Client can subscribe to specific notification types
                console.log(`[WebSocket] User ${ws.userId} subscribed to ${message.channels}`);
                break;
            case 'unsubscribe':
                console.log(`[WebSocket] User ${ws.userId} unsubscribed from ${message.channels}`);
                break;
            default:
                console.log(`[WebSocket] Unknown message type: ${message.type}`);
        }
    }
    /**
     * Extract authentication token from request
     */
    extractToken(req) {
        // Try query parameter first
        const url = new URL(req.url, `http://${req.headers.host}`);
        const tokenFromQuery = url.searchParams.get('token');
        if (tokenFromQuery)
            return tokenFromQuery;
        // Try Authorization header
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            return authHeader.substring(7);
        }
        return null;
    }
    /**
     * Generate unique connection ID
     */
    generateConnectionId() {
        return `conn_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    }
    /**
     * Remove client from tracking
     */
    removeClient(ws) {
        if (ws.userId && this.clients.has(ws.userId)) {
            this.clients.get(ws.userId).delete(ws);
            if (this.clients.get(ws.userId).size === 0) {
                this.clients.delete(ws.userId);
            }
        }
        if (ws.connectionId) {
            this.connectionInfo.delete(ws.connectionId);
        }
    }
    /**
     * Start heartbeat monitoring
     */
    startHeartbeat() {
        this.heartbeatInterval = setInterval(() => {
            if (!this.wss)
                return;
            this.wss.clients.forEach((ws) => {
                if (ws.isAlive === false) {
                    console.log(`[WebSocket] Terminating dead connection for user ${ws.userId}`);
                    this.removeClient(ws);
                    return ws.terminate();
                }
                ws.isAlive = false;
                ws.ping();
            });
        }, 30000); // 30 seconds
    }
    /**
     * Stop heartbeat monitoring
     */
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }
    /**
     * Send notification to specific user
     */
    sendToUser(userId, tenantId, notification) {
        const userClients = this.clients.get(userId);
        if (!userClients || userClients.size === 0) {
            console.log(`[WebSocket] No active connections for user ${userId}`);
            return false;
        }
        let sentCount = 0;
        const message = JSON.stringify({
            type: 'notification',
            notification,
            timestamp: new Date().toISOString(),
        });
        userClients.forEach(ws => {
            if (ws.tenantId === tenantId && ws.readyState === ws_1.WebSocket.OPEN) {
                ws.send(message);
                sentCount++;
            }
        });
        console.log(`[WebSocket] Sent notification to ${sentCount} connections for user ${userId}`);
        return sentCount > 0;
    }
    /**
     * Send notification to all users in a tenant
     */
    broadcastToTenant(tenantId, notification) {
        let sentCount = 0;
        const message = JSON.stringify({
            type: 'notification',
            notification,
            timestamp: new Date().toISOString(),
        });
        this.clients.forEach((userClients, userId) => {
            userClients.forEach(ws => {
                if (ws.tenantId === tenantId && ws.readyState === ws_1.WebSocket.OPEN) {
                    ws.send(message);
                    sentCount++;
                }
            });
        });
        console.log(`[WebSocket] Broadcast notification to ${sentCount} connections in tenant ${tenantId}`);
        return sentCount;
    }
    /**
     * Send stats update to user
     */
    sendStatsUpdate(userId, tenantId, stats) {
        const userClients = this.clients.get(userId);
        if (!userClients)
            return false;
        const message = JSON.stringify({
            type: 'stats_update',
            stats,
            timestamp: new Date().toISOString(),
        });
        userClients.forEach(ws => {
            if (ws.tenantId === tenantId && ws.readyState === ws_1.WebSocket.OPEN) {
                ws.send(message);
            }
        });
        return true;
    }
    /**
     * Send message to specific client
     */
    sendToClient(ws, data) {
        if (ws.readyState === ws_1.WebSocket.OPEN) {
            ws.send(JSON.stringify(data));
        }
    }
    /**
     * Get total connection count
     */
    getConnectionCount() {
        var _a;
        return ((_a = this.wss) === null || _a === void 0 ? void 0 : _a.clients.size) || 0;
    }
    /**
     * Get connection count for specific user
     */
    getUserConnectionCount(userId) {
        var _a;
        return ((_a = this.clients.get(userId)) === null || _a === void 0 ? void 0 : _a.size) || 0;
    }
    /**
     * Get connection count for specific tenant
     */
    getTenantConnectionCount(tenantId) {
        let count = 0;
        this.clients.forEach(userClients => {
            userClients.forEach(ws => {
                if (ws.tenantId === tenantId)
                    count++;
            });
        });
        return count;
    }
    /**
     * Get all active connections info
     */
    getConnectionsInfo() {
        const connections = [];
        this.connectionInfo.forEach((info, connectionId) => {
            connections.push(Object.assign(Object.assign({}, info), { connectionId }));
        });
        return connections;
    }
    /**
     * Close all connections and cleanup
     */
    shutdown() {
        console.log('[WebSocket] Shutting down...');
        this.stopHeartbeat();
        if (this.wss) {
            this.wss.clients.forEach(ws => {
                ws.close(1001, 'Server shutting down');
            });
            this.wss.close();
        }
        this.clients.clear();
        this.connectionInfo.clear();
        console.log('[WebSocket] Shutdown complete');
    }
}
// Export singleton instance
exports.notificationWebSocketService = new NotificationWebSocketService();
