"use strict";
/**
 * Bed Transfer Service
 * Handles patient bed transfer operations and transfer history
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedTransferService = void 0;
class BedTransferService {
    constructor(pool) {
        this.pool = pool;
    }
    /**
     * Create a new bed transfer
     */
    createBedTransfer(data, tenantId, userId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = client ? client : this.pool;
            // Validate source and destination beds exist
            const fromBedResult = yield query.query(`SELECT department_id FROM beds WHERE id = $1 AND is_active = true`, [data.from_bed_id]);
            const toBedResult = yield query.query(`SELECT department_id FROM beds WHERE id = $1 AND is_active = true`, [data.to_bed_id]);
            if (fromBedResult.rows.length === 0) {
                throw new Error(`Source bed with ID ${data.from_bed_id} not found`);
            }
            if (toBedResult.rows.length === 0) {
                throw new Error(`Destination bed with ID ${data.to_bed_id} not found`);
            }
            const fromDeptId = fromBedResult.rows[0].department_id;
            const toDeptId = toBedResult.rows[0].department_id;
            const result = yield query.query(`INSERT INTO bed_transfers (
        patient_id, from_bed_id, to_bed_id, from_department_id, to_department_id,
        transfer_date, reason, status, notes, created_by, updated_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *`, [
                data.patient_id,
                data.from_bed_id,
                data.to_bed_id,
                fromDeptId,
                toDeptId,
                data.transfer_date,
                data.reason || null,
                'pending',
                data.notes || null,
                userId,
                userId,
            ]);
            return this.formatTransfer(result.rows[0]);
        });
    }
    /**
     * Get transfer by ID
     */
    getBedTransferById(transferId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.pool.query('SELECT * FROM bed_transfers WHERE id = $1', [transferId]);
            return result.rows.length > 0 ? this.formatTransfer(result.rows[0]) : null;
        });
    }
    /**
     * Get transfers with filtering and pagination
     */
    getBedTransfers(filters, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const page = filters.page || 1;
            const limit = filters.limit || 10;
            const offset = (page - 1) * limit;
            let whereConditions = ['1=1'];
            let queryParams = [];
            let paramIndex = 1;
            if (filters.patient_id) {
                whereConditions.push(`patient_id = $${paramIndex}`);
                queryParams.push(filters.patient_id);
                paramIndex++;
            }
            if (filters.status) {
                whereConditions.push(`status = $${paramIndex}`);
                queryParams.push(filters.status);
                paramIndex++;
            }
            const whereClause = whereConditions.join(' AND ');
            // Get total count
            const countResult = yield this.pool.query(`SELECT COUNT(*) as count FROM bed_transfers WHERE ${whereClause}`, queryParams);
            const total = parseInt(countResult.rows[0].count);
            // Get paginated results
            const transfersResult = yield this.pool.query(`SELECT * FROM bed_transfers WHERE ${whereClause}
       ORDER BY transfer_date DESC
       LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...queryParams, limit, offset]);
            return {
                transfers: transfersResult.rows.map(row => this.formatTransfer(row)),
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            };
        });
    }
    /**
     * Update transfer
     */
    updateBedTransfer(transferId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const updates = [];
            const values = [];
            let paramIndex = 1;
            if (data.status !== undefined) {
                updates.push(`status = $${paramIndex}`);
                values.push(data.status);
                paramIndex++;
            }
            if (data.completion_date !== undefined) {
                updates.push(`completion_date = $${paramIndex}`);
                values.push(data.completion_date);
                paramIndex++;
            }
            if (data.notes !== undefined) {
                updates.push(`notes = $${paramIndex}`);
                values.push(data.notes);
                paramIndex++;
            }
            updates.push(`updated_by = $${paramIndex}`);
            values.push(userId);
            paramIndex++;
            updates.push(`updated_at = CURRENT_TIMESTAMP`);
            values.push(transferId);
            const result = yield this.pool.query(`UPDATE bed_transfers SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`, values);
            if (result.rows.length === 0) {
                throw new Error(`Transfer with ID ${transferId} not found`);
            }
            return this.formatTransfer(result.rows[0]);
        });
    }
    /**
     * Complete a bed transfer
     */
    completeBedTransfer(transferId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get transfer details
            const transferResult = yield this.pool.query('SELECT from_bed_id, to_bed_id FROM bed_transfers WHERE id = $1', [transferId]);
            if (transferResult.rows.length === 0) {
                throw new Error(`Transfer with ID ${transferId} not found`);
            }
            const { from_bed_id, to_bed_id } = transferResult.rows[0];
            // Update transfer status
            const result = yield this.pool.query(`UPDATE bed_transfers SET 
        status = 'completed',
        completion_date = $1,
        updated_by = $2,
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 RETURNING *`, [data.completion_date, userId, transferId]);
            // Update bed statuses
            yield this.pool.query(`UPDATE beds SET status = 'available', updated_by = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`, [userId, from_bed_id]);
            yield this.pool.query(`UPDATE beds SET status = 'occupied', updated_by = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`, [userId, to_bed_id]);
            return this.formatTransfer(result.rows[0]);
        });
    }
    /**
     * Cancel a bed transfer
     */
    cancelBedTransfer(transferId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.pool.query(`UPDATE bed_transfers SET 
        status = 'cancelled',
        notes = COALESCE(notes, '') || E'\n' || $1,
        updated_by = $2,
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 RETURNING *`, [data.reason, userId, transferId]);
            if (result.rows.length === 0) {
                throw new Error(`Transfer with ID ${transferId} not found`);
            }
            return this.formatTransfer(result.rows[0]);
        });
    }
    /**
     * Get transfer history for a patient
     */
    getTransferHistory(patientId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.pool.query(`SELECT * FROM bed_transfers WHERE patient_id = $1 ORDER BY transfer_date DESC`, [patientId]);
            return result.rows.map(row => this.formatTransfer(row));
        });
    }
    /**
     * Format transfer row from database
     */
    formatTransfer(row) {
        return {
            id: row.id,
            patient_id: row.patient_id,
            from_bed_id: row.from_bed_id,
            to_bed_id: row.to_bed_id,
            from_department_id: row.from_department_id,
            to_department_id: row.to_department_id,
            transfer_date: row.transfer_date,
            transfer_reason: row.transfer_reason || row.reason,
            completion_date: row.completion_date,
            status: row.status,
            notes: row.notes,
            created_at: row.created_at,
            updated_at: row.updated_at,
        };
    }
}
exports.BedTransferService = BedTransferService;
