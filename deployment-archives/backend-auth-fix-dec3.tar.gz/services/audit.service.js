"use strict";
/**
 * Team Alpha - Audit Service
 * Business logic for audit trail system
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAuditLog = createAuditLog;
exports.getAuditLogs = getAuditLogs;
exports.getAuditLogById = getAuditLogById;
exports.getResourceAuditLogs = getResourceAuditLogs;
exports.getAuditLogStats = getAuditLogStats;
exports.exportAuditLogs = exportAuditLogs;
exports.deleteOldAuditLogs = deleteOldAuditLogs;
const database_1 = __importDefault(require("../database"));
/**
 * Create an audit log entry
 */
function createAuditLog(data) {
    return __awaiter(this, void 0, void 0, function* () {
        const { tenant_id, user_id, action, resource_type, resource_id, changes, ip_address, user_agent, } = data;
        // Skip audit log if user_id is missing (required field)
        if (!user_id) {
            console.warn('Skipping audit log - user_id is required but was not provided');
            return null;
        }
        const query = `
    INSERT INTO public.audit_logs (
      tenant_id, user_id, action, resource_type, resource_id,
      changes, ip_address, user_agent
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING *
  `;
        const values = [
            tenant_id,
            user_id,
            action,
            resource_type,
            resource_id || null,
            changes ? JSON.stringify(changes) : null,
            ip_address || null,
            user_agent || null,
        ];
        const result = yield database_1.default.query(query, values);
        return result.rows[0];
    });
}
/**
 * Get audit logs with filters and pagination
 */
function getAuditLogs() {
    return __awaiter(this, arguments, void 0, function* (filters = {}) {
        const { page = 1, limit = 50, tenant_id, user_id, action, resource_type, resource_id, date_from, date_to, search, } = filters;
        const offset = (page - 1) * limit;
        // Build WHERE clause
        const conditions = ['1=1'];
        const params = [];
        let paramIndex = 1;
        if (tenant_id) {
            conditions.push(`tenant_id = $${paramIndex}`);
            params.push(tenant_id);
            paramIndex++;
        }
        if (user_id) {
            conditions.push(`user_id = $${paramIndex}`);
            params.push(user_id);
            paramIndex++;
        }
        if (action) {
            conditions.push(`action = $${paramIndex}`);
            params.push(action);
            paramIndex++;
        }
        if (resource_type) {
            conditions.push(`resource_type = $${paramIndex}`);
            params.push(resource_type);
            paramIndex++;
        }
        if (resource_id) {
            conditions.push(`resource_id = $${paramIndex}`);
            params.push(resource_id);
            paramIndex++;
        }
        if (date_from) {
            conditions.push(`created_at >= $${paramIndex}`);
            params.push(date_from);
            paramIndex++;
        }
        if (date_to) {
            conditions.push(`created_at <= $${paramIndex}`);
            params.push(date_to);
            paramIndex++;
        }
        if (search) {
            conditions.push(`(
      action ILIKE $${paramIndex} OR
      resource_type ILIKE $${paramIndex} OR
      ip_address ILIKE $${paramIndex}
    )`);
            params.push(`%${search}%`);
            paramIndex++;
        }
        const whereClause = conditions.join(' AND ');
        // Get total count
        const countQuery = `
    SELECT COUNT(*) as total
    FROM public.audit_logs
    WHERE ${whereClause}
  `;
        const countResult = yield database_1.default.query(countQuery, params);
        const total = parseInt(countResult.rows[0].total);
        // Get paginated logs
        const logsQuery = `
    SELECT *
    FROM public.audit_logs
    WHERE ${whereClause}
    ORDER BY created_at DESC
    LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
  `;
        params.push(limit, offset);
        const logsResult = yield database_1.default.query(logsQuery, params);
        return {
            logs: logsResult.rows,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    });
}
/**
 * Get a specific audit log by ID
 */
function getAuditLogById(id, tenantId) {
    return __awaiter(this, void 0, void 0, function* () {
        const query = `
    SELECT *
    FROM public.audit_logs
    WHERE id = $1 AND tenant_id = $2
  `;
        const result = yield database_1.default.query(query, [id, tenantId]);
        return result.rows[0] || null;
    });
}
/**
 * Get audit logs for a specific resource
 */
function getResourceAuditLogs(tenantId, resourceType, resourceId) {
    return __awaiter(this, void 0, void 0, function* () {
        const query = `
    SELECT *
    FROM public.audit_logs
    WHERE tenant_id = $1
      AND resource_type = $2
      AND resource_id = $3
    ORDER BY created_at DESC
  `;
        const result = yield database_1.default.query(query, [tenantId, resourceType, resourceId]);
        return result.rows;
    });
}
/**
 * Get audit log statistics
 */
function getAuditLogStats(tenantId, dateFrom, dateTo) {
    return __awaiter(this, void 0, void 0, function* () {
        const conditions = ['tenant_id = $1'];
        const params = [tenantId];
        let paramIndex = 2;
        if (dateFrom) {
            conditions.push(`created_at >= $${paramIndex}`);
            params.push(dateFrom);
            paramIndex++;
        }
        if (dateTo) {
            conditions.push(`created_at <= $${paramIndex}`);
            params.push(dateTo);
            paramIndex++;
        }
        const whereClause = conditions.join(' AND ');
        // Get total logs
        const totalQuery = `
    SELECT COUNT(*) as total
    FROM public.audit_logs
    WHERE ${whereClause}
  `;
        const totalResult = yield database_1.default.query(totalQuery, params);
        const total_logs = parseInt(totalResult.rows[0].total);
        // Get logs by action
        const actionQuery = `
    SELECT action, COUNT(*) as count
    FROM public.audit_logs
    WHERE ${whereClause}
    GROUP BY action
  `;
        const actionResult = yield database_1.default.query(actionQuery, params);
        const logs_by_action = actionResult.rows.reduce((acc, row) => {
            acc[row.action] = parseInt(row.count);
            return acc;
        }, {});
        // Get logs by resource type
        const resourceQuery = `
    SELECT resource_type, COUNT(*) as count
    FROM public.audit_logs
    WHERE ${whereClause}
    GROUP BY resource_type
  `;
        const resourceResult = yield database_1.default.query(resourceQuery, params);
        const logs_by_resource = resourceResult.rows.reduce((acc, row) => {
            acc[row.resource_type] = parseInt(row.count);
            return acc;
        }, {});
        // Get logs by user (top 10)
        const userQuery = `
    SELECT 
      al.user_id,
      u.name as user_name,
      COUNT(*) as log_count
    FROM public.audit_logs al
    LEFT JOIN public.users u ON al.user_id = u.id
    WHERE ${whereClause}
    GROUP BY al.user_id, u.name
    ORDER BY log_count DESC
    LIMIT 10
  `;
        const userResult = yield database_1.default.query(userQuery, params);
        const logs_by_user = userResult.rows.map((row) => ({
            user_id: row.user_id,
            user_name: row.user_name || 'Unknown User',
            log_count: parseInt(row.log_count),
        }));
        // Get recent activity (last 20)
        const recentQuery = `
    SELECT *
    FROM public.audit_logs
    WHERE ${whereClause}
    ORDER BY created_at DESC
    LIMIT 20
  `;
        const recentResult = yield database_1.default.query(recentQuery, params);
        const recent_activity = recentResult.rows;
        return {
            total_logs,
            logs_by_action,
            logs_by_resource,
            logs_by_user,
            recent_activity,
        };
    });
}
/**
 * Export audit logs to CSV
 */
function exportAuditLogs() {
    return __awaiter(this, arguments, void 0, function* (filters = {}) {
        const { logs } = yield getAuditLogs(Object.assign(Object.assign({}, filters), { limit: 10000 }));
        // CSV headers
        const headers = [
            'ID',
            'Tenant ID',
            'User ID',
            'Action',
            'Resource Type',
            'Resource ID',
            'IP Address',
            'Created At',
        ];
        // CSV rows
        const rows = logs.map((log) => [
            log.id,
            log.tenant_id,
            log.user_id,
            log.action,
            log.resource_type,
            log.resource_id || '',
            log.ip_address || '',
            log.created_at.toISOString(),
        ]);
        // Combine headers and rows
        const csvContent = [headers, ...rows]
            .map((row) => row.map((cell) => `"${cell}"`).join(','))
            .join('\n');
        return csvContent;
    });
}
/**
 * Delete old audit logs (for retention policy)
 * Note: HIPAA requires 7 years retention, so this should only be used after that period
 */
function deleteOldAuditLogs(olderThanDate) {
    return __awaiter(this, void 0, void 0, function* () {
        const query = `
    DELETE FROM public.audit_logs
    WHERE created_at < $1
    RETURNING id
  `;
        const result = yield database_1.default.query(query, [olderThanDate]);
        return result.rowCount || 0;
    });
}
