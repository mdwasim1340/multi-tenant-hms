"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiagnosisService = void 0;
class DiagnosisService {
    constructor(pool) {
        this.pool = pool;
    }
    createDiagnosis(data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Verify medical record exists
                const recordCheck = yield client.query('SELECT id FROM medical_records WHERE id = $1', [data.medical_record_id]);
                if (recordCheck.rows.length === 0) {
                    throw new Error('Medical record not found');
                }
                const insertQuery = `
        INSERT INTO diagnoses (
          medical_record_id, diagnosis_code, diagnosis_name,
          diagnosis_type, severity, status, onset_date, notes, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
                const result = yield client.query(insertQuery, [
                    data.medical_record_id,
                    data.diagnosis_code || null,
                    data.diagnosis_name,
                    data.diagnosis_type || 'primary',
                    data.severity || null,
                    data.status || 'active',
                    data.onset_date || null,
                    data.notes || null,
                    userId
                ]);
                return result.rows[0];
            }
            finally {
                client.release();
            }
        });
    }
    updateDiagnosisStatus(id, status, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const updateQuery = `
        UPDATE diagnoses 
        SET status = $1,
            resolution_date = CASE WHEN $1 = 'resolved' THEN CURRENT_DATE ELSE resolution_date END
        WHERE id = $2
        RETURNING *
      `;
                const result = yield client.query(updateQuery, [status, id]);
                if (result.rows.length === 0) {
                    throw new Error('Diagnosis not found');
                }
                return result.rows[0];
            }
            finally {
                client.release();
            }
        });
    }
    getDiagnosesByMedicalRecord(medicalRecordId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query('SELECT * FROM diagnoses WHERE medical_record_id = $1 ORDER BY created_at DESC', [medicalRecordId]);
                return result.rows;
            }
            finally {
                client.release();
            }
        });
    }
}
exports.DiagnosisService = DiagnosisService;
