"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventService = exports.EventService = void 0;
const redis_1 = require("../config/redis");
const server_1 = require("../websocket/server");
class EventService {
    // Publish event to Redis stream
    publishEvent(event) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const streamKey = `events:${event.tenantId}`;
                yield redis_1.redisClient.xAdd(streamKey, '*', {
                    type: event.type,
                    tenantId: event.tenantId,
                    userId: ((_a = event.userId) === null || _a === void 0 ? void 0 : _a.toString()) || '',
                    data: JSON.stringify(event.data),
                    timestamp: event.timestamp.toISOString()
                });
                // Also broadcast via WebSocket for immediate delivery
                this.broadcastEvent(event);
                // Store in global events stream for analytics
                yield redis_1.redisClient.xAdd('events:global', '*', {
                    type: event.type,
                    tenantId: event.tenantId,
                    timestamp: event.timestamp.toISOString()
                });
            }
            catch (error) {
                console.error('Error publishing event:', error);
            }
        });
    }
    // Broadcast event via WebSocket
    broadcastEvent(event) {
        try {
            const realtimeServer = (0, server_1.getRealtimeServer)();
            realtimeServer.broadcastToTenant(event.tenantId, {
                type: 'event',
                event: event
            });
        }
        catch (error) {
            console.error('Error broadcasting event:', error);
        }
    }
    // Get recent events for tenant
    getRecentEvents(tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, count = 50) {
            try {
                const streamKey = `events:${tenantId}`;
                const events = yield redis_1.redisClient.xRevRange(streamKey, '+', '-', { COUNT: count });
                return events.map(event => ({
                    type: event.message.type,
                    tenantId: event.message.tenantId,
                    userId: event.message.userId ? parseInt(event.message.userId) : undefined,
                    data: JSON.parse(event.message.data),
                    timestamp: new Date(event.message.timestamp)
                }));
            }
            catch (error) {
                console.error('Error getting recent events:', error);
                return [];
            }
        });
    }
    // Cache data in Redis
    cacheSet(key, value, expirySeconds) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const serialized = JSON.stringify(value);
                if (expirySeconds) {
                    yield redis_1.redisClient.setEx(key, expirySeconds, serialized);
                }
                else {
                    yield redis_1.redisClient.set(key, serialized);
                }
            }
            catch (error) {
                console.error('Error setting cache:', error);
            }
        });
    }
    // Get cached data from Redis
    cacheGet(key) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const data = yield redis_1.redisClient.get(key);
                if (!data)
                    return null;
                return JSON.parse(data);
            }
            catch (error) {
                console.error('Error getting cache:', error);
                return null;
            }
        });
    }
    // Delete cached data
    cacheDelete(key) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield redis_1.redisClient.del(key);
            }
            catch (error) {
                console.error('Error deleting cache:', error);
            }
        });
    }
    // Increment counter in Redis
    incrementCounter(key_1) {
        return __awaiter(this, arguments, void 0, function* (key, amount = 1) {
            try {
                return yield redis_1.redisClient.incrBy(key, amount);
            }
            catch (error) {
                console.error('Error incrementing counter:', error);
                return 0;
            }
        });
    }
    // Get counter value
    getCounter(key) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const value = yield redis_1.redisClient.get(key);
                return value ? parseInt(value) : 0;
            }
            catch (error) {
                console.error('Error getting counter:', error);
                return 0;
            }
        });
    }
}
exports.EventService = EventService;
exports.eventService = new EventService();
