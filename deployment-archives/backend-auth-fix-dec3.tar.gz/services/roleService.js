"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteRole = exports.updateRole = exports.createRole = exports.getRole = exports.getRoles = void 0;
const database_1 = __importDefault(require("../database"));
const ALLOWED_SORT_FIELDS = ['name', 'description', 'created_at'];
const ALLOWED_ORDER_DIRECTIONS = ['asc', 'desc'];
const getRoles = (queryParams) => __awaiter(void 0, void 0, void 0, function* () {
    const { page = 1, limit = 10, sortBy = 'created_at', order = 'desc' } = queryParams, filters = __rest(queryParams, ["page", "limit", "sortBy", "order"]);
    const offset = (page - 1) * limit;
    if (!ALLOWED_SORT_FIELDS.includes(sortBy)) {
        throw new Error(`Invalid sort field: ${sortBy}`);
    }
    if (!ALLOWED_ORDER_DIRECTIONS.includes(order)) {
        throw new Error(`Invalid order direction: ${order}`);
    }
    let query = 'SELECT r.*, COUNT(ur.user_id) as users FROM roles r LEFT JOIN user_roles ur ON r.id = ur.role_id';
    const queryParamsArray = [];
    if (Object.keys(filters).length > 0) {
        query += ' WHERE ';
        const filterClauses = Object.entries(filters).map(([key, value], index) => {
            queryParamsArray.push(value);
            return `r.${key} = $${index + 1}`;
        });
        query += filterClauses.join(' AND ');
    }
    query += ' GROUP BY r.id';
    query += ` ORDER BY r.${sortBy} ${order} LIMIT $${queryParamsArray.length + 1} OFFSET $${queryParamsArray.length + 2}`;
    queryParamsArray.push(limit, offset);
    const { rows } = yield database_1.default.query(query, queryParamsArray);
    return rows;
});
exports.getRoles = getRoles;
const getRole = (id) => __awaiter(void 0, void 0, void 0, function* () {
    const { rows } = yield database_1.default.query('SELECT * FROM roles WHERE id = $1', [id]);
    return rows[0];
});
exports.getRole = getRole;
const createRole = (roleData) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, description } = roleData;
    const { rows } = yield database_1.default.query('INSERT INTO roles (name, description) VALUES ($1, $2) RETURNING *', [name, description]);
    return rows[0];
});
exports.createRole = createRole;
const updateRole = (id, roleData) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, description } = roleData;
    const { rows } = yield database_1.default.query('UPDATE roles SET name = $1, description = $2 WHERE id = $3 RETURNING *', [name, description, id]);
    return rows[0];
});
exports.updateRole = updateRole;
const deleteRole = (id) => __awaiter(void 0, void 0, void 0, function* () {
    yield database_1.default.query('DELETE FROM user_roles WHERE role_id = $1', [id]);
    yield database_1.default.query('DELETE FROM roles WHERE id = $1', [id]);
});
exports.deleteRole = deleteRole;
