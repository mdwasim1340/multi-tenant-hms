"use strict";
/**
 * Expense Aggregator Service
 *
 * Aggregates expense data for Profit & Loss reports.
 * Fetches data from billing_adjustments (refunds, write-offs) and
 * calculates operational expenses from the billing system.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expenseAggregatorService = exports.ExpenseAggregatorService = void 0;
const database_1 = __importDefault(require("../database"));
class ExpenseAggregatorService {
    /**
     * Get total expenses for a period, broken down by category
     * Queries billing_adjustments for refunds/write-offs and estimates operational costs
     */
    getExpensesByPeriod(options) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const { tenantId, dateRange } = options;
            if (!dateRange) {
                throw new Error('Date range is required for expense aggregation');
            }
            const client = yield database_1.default.connect();
            try {
                // Initialize breakdown with zeros
                const breakdown = {
                    salaries: 0,
                    supplies: 0,
                    utilities: 0,
                    maintenance: 0,
                    other: 0,
                    total: 0
                };
                // Query 1: Get refunds and write-offs from billing_adjustments
                try {
                    const adjustmentsQuery = `
          SELECT 
            adjustment_type,
            SUM(ABS(amount)) as total_amount
          FROM billing_adjustments
          WHERE tenant_id = $1
            AND created_at >= $2
            AND created_at <= $3
            AND adjustment_type IN ('refund', 'write_off', 'discount')
            AND status = 'approved'
          GROUP BY adjustment_type
        `;
                    const adjustmentsResult = yield client.query(adjustmentsQuery, [
                        tenantId,
                        dateRange.startDate,
                        dateRange.endDate + ' 23:59:59'
                    ]);
                    // Map adjustments to expense categories
                    adjustmentsResult.rows.forEach(row => {
                        const amount = parseFloat(row.total_amount) || 0;
                        switch (row.adjustment_type) {
                            case 'refund':
                            case 'write_off':
                                breakdown.other += amount;
                                break;
                        }
                    });
                }
                catch (dbError) {
                    if (dbError.code !== '42P01') {
                        console.warn('[ExpenseAggregator] Error querying billing_adjustments:', dbError.message);
                    }
                }
                // Query 2: Get actual paid revenue to estimate operational expenses
                // In a real system, you'd have a dedicated expenses table
                try {
                    const revenueQuery = `
          SELECT COALESCE(SUM(amount), 0) as total_revenue
          FROM invoices
          WHERE tenant_id = $1
            AND status = 'paid'
            AND created_at >= $2
            AND created_at <= $3
        `;
                    const revenueResult = yield client.query(revenueQuery, [
                        tenantId,
                        dateRange.startDate,
                        dateRange.endDate + ' 23:59:59'
                    ]);
                    const totalRevenue = parseFloat((_a = revenueResult.rows[0]) === null || _a === void 0 ? void 0 : _a.total_revenue) || 0;
                    // Estimate expenses as percentages of revenue (typical hospital ratios)
                    // These are placeholder calculations - real data should come from an expenses table
                    if (totalRevenue > 0) {
                        breakdown.salaries = Math.round(totalRevenue * 0.35 * 100) / 100; // 35% for salaries
                        breakdown.supplies = Math.round(totalRevenue * 0.15 * 100) / 100; // 15% for supplies
                        breakdown.utilities = Math.round(totalRevenue * 0.05 * 100) / 100; // 5% for utilities
                        breakdown.maintenance = Math.round(totalRevenue * 0.05 * 100) / 100; // 5% for maintenance
                    }
                }
                catch (dbError) {
                    if (dbError.code !== '42P01') {
                        console.warn('[ExpenseAggregator] Error estimating expenses:', dbError.message);
                    }
                }
                // Calculate total
                breakdown.total =
                    breakdown.salaries +
                        breakdown.supplies +
                        breakdown.utilities +
                        breakdown.maintenance +
                        breakdown.other;
                return breakdown;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get expenses by specific category
     */
    getExpensesByCategory(tenantId, category, dateRange) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get full breakdown and return specific category
            const breakdown = yield this.getExpensesByPeriod({
                tenantId,
                dateRange: { startDate: dateRange.startDate, endDate: dateRange.endDate }
            });
            return breakdown[category] || 0;
        });
    }
    /**
     * Get total expense count (number of expense records)
     */
    getExpenseCount(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, dateRange } = options;
            if (!dateRange) {
                throw new Error('Date range is required');
            }
            const client = yield database_1.default.connect();
            try {
                // Count billing adjustments as expense records
                const query = `
        SELECT COUNT(*) as count
        FROM billing_adjustments
        WHERE tenant_id = $1
          AND created_at >= $2
          AND created_at <= $3
          AND adjustment_type IN ('refund', 'write_off')
      `;
                const result = yield client.query(query, [
                    tenantId,
                    dateRange.startDate,
                    dateRange.endDate + ' 23:59:59'
                ]);
                return parseInt(result.rows[0].count) || 0;
            }
            catch (dbError) {
                if (dbError.code === '42P01') {
                    return 0;
                }
                throw dbError;
            }
            finally {
                client.release();
            }
        });
    }
}
exports.ExpenseAggregatorService = ExpenseAggregatorService;
exports.expenseAggregatorService = new ExpenseAggregatorService();
