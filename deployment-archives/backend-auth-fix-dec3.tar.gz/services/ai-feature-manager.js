"use strict";
/**
 * AI Feature Manager Service
 * Manages enabling/disabling of AI-powered bed management features per tenant
 * Includes caching, audit logging, and tenant isolation
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.aiFeatureManager = exports.AIFeatureManagerService = void 0;
const database_1 = __importDefault(require("../database"));
const bed_management_1 = require("../types/bed-management");
// Simple in-memory cache for feature status
const featureCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes
class AIFeatureManagerService {
    /**
     * Check if a specific feature is enabled for a tenant
     */
    isFeatureEnabled(tenantId, featureName) {
        return __awaiter(this, void 0, void 0, function* () {
            const cacheKey = `${tenantId}:${featureName}`;
            const cached = featureCache.get(cacheKey);
            // Return cached value if still valid
            if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
                return cached.enabled;
            }
            try {
                const result = yield database_1.default.query(`SELECT enabled FROM ai_feature_management 
         WHERE tenant_id = $1 AND feature_name = $2`, [tenantId, featureName]);
                const enabled = result.rows.length > 0 ? result.rows[0].enabled : true; // Default to enabled
                // Update cache
                featureCache.set(cacheKey, { enabled, timestamp: Date.now() });
                return enabled;
            }
            catch (error) {
                console.error('Error checking feature status:', error);
                return true; // Fail open - allow feature if check fails
            }
        });
    }
    /**
     * Get all features and their status for a tenant
     */
    getAllFeatures(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield database_1.default.query(`SELECT * FROM ai_feature_management 
         WHERE tenant_id = $1 
         ORDER BY feature_name`, [tenantId]);
                // If no features exist, create default entries
                if (result.rows.length === 0) {
                    yield this.initializeDefaultFeatures(tenantId);
                    return this.getAllFeatures(tenantId);
                }
                return result.rows;
            }
            catch (error) {
                console.error('Error getting all features:', error);
                throw error;
            }
        });
    }
    /**
     * Initialize default features for a tenant (all enabled)
     */
    initializeDefaultFeatures(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const features = Object.values(bed_management_1.BedManagementFeature);
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                for (const feature of features) {
                    yield client.query(`INSERT INTO ai_feature_management (tenant_id, feature_name, enabled, enabled_at)
           VALUES ($1, $2, true, CURRENT_TIMESTAMP)
           ON CONFLICT (tenant_id, feature_name) DO NOTHING`, [tenantId, feature]);
                }
                yield client.query('COMMIT');
            }
            catch (error) {
                yield client.query('ROLLBACK');
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Enable a feature for a tenant
     */
    enableFeature(tenantId, featureName, userId, configuration) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                // Get previous state for audit log
                const previousState = yield client.query(`SELECT enabled, configuration FROM ai_feature_management 
         WHERE tenant_id = $1 AND feature_name = $2`, [tenantId, featureName]);
                // Update or insert feature status
                yield client.query(`INSERT INTO ai_feature_management 
         (tenant_id, feature_name, enabled, enabled_at, configuration, last_modified_by, updated_at)
         VALUES ($1, $2, true, CURRENT_TIMESTAMP, $3, $4, CURRENT_TIMESTAMP)
         ON CONFLICT (tenant_id, feature_name) 
         DO UPDATE SET 
           enabled = true,
           enabled_at = CURRENT_TIMESTAMP,
           disabled_at = NULL,
           disabled_reason = NULL,
           configuration = COALESCE($3, ai_feature_management.configuration),
           last_modified_by = $4,
           updated_at = CURRENT_TIMESTAMP`, [tenantId, featureName, configuration ? JSON.stringify(configuration) : null, userId]);
                // Create audit log entry
                yield client.query(`INSERT INTO ai_feature_audit_log 
         (tenant_id, feature_name, action, previous_state, new_state, performed_by)
         VALUES ($1, $2, 'enabled', $3, $4, $5)`, [
                    tenantId,
                    featureName,
                    previousState.rows.length > 0 ? JSON.stringify(previousState.rows[0]) : null,
                    JSON.stringify({ enabled: true, configuration }),
                    userId,
                ]);
                yield client.query('COMMIT');
                // Clear cache
                const cacheKey = `${tenantId}:${featureName}`;
                featureCache.delete(cacheKey);
            }
            catch (error) {
                yield client.query('ROLLBACK');
                console.error('Error enabling feature:', error);
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Disable a feature for a tenant
     */
    disableFeature(tenantId, featureName, userId, reason) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                // Get previous state for audit log
                const previousState = yield client.query(`SELECT enabled, configuration FROM ai_feature_management 
         WHERE tenant_id = $1 AND feature_name = $2`, [tenantId, featureName]);
                // Update feature status
                yield client.query(`INSERT INTO ai_feature_management 
         (tenant_id, feature_name, enabled, disabled_at, disabled_reason, last_modified_by, updated_at)
         VALUES ($1, $2, false, CURRENT_TIMESTAMP, $3, $4, CURRENT_TIMESTAMP)
         ON CONFLICT (tenant_id, feature_name) 
         DO UPDATE SET 
           enabled = false,
           disabled_at = CURRENT_TIMESTAMP,
           disabled_reason = $3,
           last_modified_by = $4,
           updated_at = CURRENT_TIMESTAMP`, [tenantId, featureName, reason, userId]);
                // Create audit log entry
                yield client.query(`INSERT INTO ai_feature_audit_log 
         (tenant_id, feature_name, action, previous_state, new_state, reason, performed_by)
         VALUES ($1, $2, 'disabled', $3, $4, $5, $6)`, [
                    tenantId,
                    featureName,
                    previousState.rows.length > 0 ? JSON.stringify(previousState.rows[0]) : null,
                    JSON.stringify({ enabled: false }),
                    reason,
                    userId,
                ]);
                yield client.query('COMMIT');
                // Clear cache
                const cacheKey = `${tenantId}:${featureName}`;
                featureCache.delete(cacheKey);
            }
            catch (error) {
                yield client.query('ROLLBACK');
                console.error('Error disabling feature:', error);
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Update feature configuration
     */
    updateConfiguration(tenantId, featureName, userId, configuration) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                // Get previous state for audit log
                const previousState = yield client.query(`SELECT enabled, configuration FROM ai_feature_management 
         WHERE tenant_id = $1 AND feature_name = $2`, [tenantId, featureName]);
                // Update configuration
                yield client.query(`UPDATE ai_feature_management 
         SET configuration = $3, last_modified_by = $4, updated_at = CURRENT_TIMESTAMP
         WHERE tenant_id = $1 AND feature_name = $2`, [tenantId, featureName, JSON.stringify(configuration), userId]);
                // Create audit log entry
                yield client.query(`INSERT INTO ai_feature_audit_log 
         (tenant_id, feature_name, action, previous_state, new_state, performed_by)
         VALUES ($1, $2, 'configured', $3, $4, $5)`, [
                    tenantId,
                    featureName,
                    previousState.rows.length > 0 ? JSON.stringify(previousState.rows[0]) : null,
                    JSON.stringify({ configuration }),
                    userId,
                ]);
                yield client.query('COMMIT');
                // Clear cache
                const cacheKey = `${tenantId}:${featureName}`;
                featureCache.delete(cacheKey);
            }
            catch (error) {
                yield client.query('ROLLBACK');
                console.error('Error updating configuration:', error);
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get audit log for a feature
     */
    getAuditLog(tenantId_1, featureName_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, featureName, limit = 50) {
            try {
                let query = `
        SELECT * FROM ai_feature_audit_log 
        WHERE tenant_id = $1
      `;
                const params = [tenantId];
                if (featureName) {
                    query += ` AND feature_name = $2`;
                    params.push(featureName);
                }
                query += ` ORDER BY performed_at DESC LIMIT $${params.length + 1}`;
                params.push(limit);
                const result = yield database_1.default.query(query, params);
                return result.rows;
            }
            catch (error) {
                console.error('Error getting audit log:', error);
                throw error;
            }
        });
    }
    /**
     * Clear cache for a tenant (useful after bulk updates)
     */
    clearCache(tenantId) {
        const features = Object.values(bed_management_1.BedManagementFeature);
        features.forEach((feature) => {
            const cacheKey = `${tenantId}:${feature}`;
            featureCache.delete(cacheKey);
        });
    }
    /**
     * Clear all cache (useful for testing or maintenance)
     */
    clearAllCache() {
        featureCache.clear();
    }
}
exports.AIFeatureManagerService = AIFeatureManagerService;
// Export singleton instance
exports.aiFeatureManager = new AIFeatureManagerService();
