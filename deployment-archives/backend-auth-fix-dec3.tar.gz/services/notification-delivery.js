"use strict";
/**
 * Notification Delivery Orchestrator
 * Team: Epsilon
 * Purpose: Coordinate delivery across all channels (in-app, email, SMS, push)
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationDeliveryService = void 0;
const notification_broadcaster_1 = require("./notification-broadcaster");
const notification_email_1 = require("./notification-email");
const notification_sms_1 = require("./notification-sms");
const database_1 = __importDefault(require("../database"));
class NotificationDeliveryService {
    /**
     * Get user notification preferences
     */
    static getUserPreferences(tenantId, userId, notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT email_enabled, sms_enabled, push_enabled, in_app_enabled
         FROM notification_settings 
         WHERE user_id = $1 AND notification_type = $2`, [userId, notificationType]);
                // Default preferences if not found
                return result.rows[0] || {
                    email_enabled: true,
                    sms_enabled: false,
                    push_enabled: true,
                    in_app_enabled: true,
                };
            }
            catch (error) {
                console.error('Error getting user preferences:', error);
                // Return defaults on error
                return {
                    email_enabled: true,
                    sms_enabled: false,
                    push_enabled: true,
                    in_app_enabled: true,
                };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Deliver notification via in-app channels (WebSocket/SSE)
     */
    static deliverInApp(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield notification_broadcaster_1.NotificationBroadcaster.broadcastToUser(tenantId, notification.user_id, notification);
                const success = result.websocket || result.sse;
                return {
                    channel: 'in_app',
                    success,
                    error: success ? undefined : 'No active connections',
                };
            }
            catch (error) {
                return {
                    channel: 'in_app',
                    success: false,
                    error: error.message,
                };
            }
        });
    }
    /**
     * Deliver notification via email
     */
    static deliverEmail(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield notification_email_1.NotificationEmailService.sendEmailWithRetry(tenantId, notification, 3 // Max 3 retries
                );
                return {
                    channel: 'email',
                    success: result.success,
                    messageId: result.messageId,
                    error: result.error,
                };
            }
            catch (error) {
                return {
                    channel: 'email',
                    success: false,
                    error: error.message,
                };
            }
        });
    }
    /**
     * Deliver notification via SMS
     */
    static deliverSMS(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield notification_sms_1.NotificationSMSService.sendSMSWithRetry(tenantId, notification, 3 // Max 3 retries
                );
                return {
                    channel: 'sms',
                    success: result.success,
                    messageId: result.messageId,
                    error: result.error,
                };
            }
            catch (error) {
                return {
                    channel: 'sms',
                    success: false,
                    error: error.message,
                };
            }
        });
    }
    /**
     * Deliver notification via push (placeholder for future implementation)
     */
    static deliverPush(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: Implement Web Push API integration
            return {
                channel: 'push',
                success: false,
                error: 'Push notifications not yet implemented',
            };
        });
    }
    /**
     * Deliver notification to all enabled channels
     */
    static deliverNotification(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`📤 Starting delivery for notification ${notification.id} to user ${notification.user_id}`);
            // Get user preferences
            const preferences = yield this.getUserPreferences(tenantId, notification.user_id, notification.type);
            const results = [];
            // Deliver via in-app (WebSocket/SSE) if enabled
            if (preferences.in_app_enabled) {
                const result = yield this.deliverInApp(tenantId, notification);
                results.push(result);
            }
            // Deliver via email if enabled
            if (preferences.email_enabled) {
                const result = yield this.deliverEmail(tenantId, notification);
                results.push(result);
            }
            // Deliver via SMS if enabled
            if (preferences.sms_enabled) {
                const result = yield this.deliverSMS(tenantId, notification);
                results.push(result);
            }
            // Deliver via push if enabled
            if (preferences.push_enabled) {
                const result = yield this.deliverPush(tenantId, notification);
                results.push(result);
            }
            // Calculate summary
            const successful = results.filter(r => r.success).length;
            const failed = results.filter(r => !r.success).length;
            const report = {
                notificationId: notification.id,
                results,
                summary: {
                    total: results.length,
                    successful,
                    failed,
                },
            };
            console.log(`📊 Delivery complete for notification ${notification.id}: ${successful}/${results.length} successful`);
            return report;
        });
    }
    /**
     * Deliver notification to multiple users
     */
    static deliverToMultipleUsers(tenantId, userIds, notificationData) {
        return __awaiter(this, void 0, void 0, function* () {
            const reports = [];
            for (const userId of userIds) {
                // Create notification for each user
                const notification = yield database_1.default.query(`INSERT INTO "${tenantId}".notifications (
          user_id, type, priority, title, message, data, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *`, [
                    userId,
                    notificationData.type,
                    notificationData.priority || 'medium',
                    notificationData.title,
                    notificationData.message,
                    notificationData.data ? JSON.stringify(notificationData.data) : null,
                    notificationData.created_by || null,
                ]);
                // Deliver notification
                const report = yield this.deliverNotification(tenantId, notification.rows[0]);
                reports.push(report);
            }
            return reports;
        });
    }
    /**
     * Deliver notification to all users in tenant
     */
    static deliverToTenant(tenantId, notificationData) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get all active users in tenant
            const result = yield database_1.default.query(`SELECT id FROM users WHERE tenant_id = $1 AND status = 'active'`, [tenantId]);
            const userIds = result.rows.map(row => row.id);
            return this.deliverToMultipleUsers(tenantId, userIds, notificationData);
        });
    }
    /**
     * Get delivery statistics for notification
     */
    static getDeliveryStats(tenantId, notificationId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT 
          channel,
          COUNT(*) as total,
          COUNT(*) FILTER (WHERE status = 'delivered') as successful,
          COUNT(*) FILTER (WHERE status = 'failed') as failed
         FROM notification_history
         WHERE notification_id = $1
         GROUP BY channel`, [notificationId]);
                const by_channel = {};
                let total = 0;
                result.rows.forEach(row => {
                    by_channel[row.channel] = {
                        total: parseInt(row.total),
                        successful: parseInt(row.successful),
                        failed: parseInt(row.failed),
                    };
                    total += parseInt(row.total);
                });
                return { total, by_channel };
            }
            finally {
                client.release();
            }
        });
    }
}
exports.NotificationDeliveryService = NotificationDeliveryService;
