"use strict";
/**
 * Notification SMS Service
 * Team: Epsilon
 * Purpose: SMS delivery via AWS SNS
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationSMSService = void 0;
const client_sns_1 = require("@aws-sdk/client-sns");
const database_1 = __importDefault(require("../database"));
const snsClient = new client_sns_1.SNSClient({
    region: process.env.SNS_REGION || process.env.AWS_REGION || 'us-west-2',
    credentials: {
        accessKeyId: process.env.SNS_ACCESS_KEY_ID || process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.SNS_SECRET_ACCESS_KEY || process.env.AWS_SECRET_ACCESS_KEY || '',
    },
});
class NotificationSMSService {
    /**
     * Render template with variables
     */
    static renderTemplate(template, variables) {
        let rendered = template;
        Object.entries(variables).forEach(([key, value]) => {
            const regex = new RegExp(`{{${key}}}`, 'g');
            rendered = rendered.replace(regex, String(value));
        });
        return rendered;
    }
    /**
     * Get user phone number
     */
    static getUserPhone(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const result = yield database_1.default.query('SELECT phone FROM users WHERE id = $1', [userId]);
                return ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.phone) || null;
            }
            catch (error) {
                console.error('Error getting user phone:', error);
                return null;
            }
        });
    }
    /**
     * Get notification template
     */
    static getTemplate(notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield database_1.default.query('SELECT * FROM notification_templates WHERE template_key = $1', [notificationType]);
                return result.rows[0] || null;
            }
            catch (error) {
                console.error('Error getting template:', error);
                return null;
            }
        });
    }
    /**
     * Check if user has SMS notifications enabled
     */
    static isSMSEnabled(tenantId, userId, notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT sms_enabled FROM notification_settings 
         WHERE user_id = $1 AND notification_type = $2`, [userId, notificationType]);
                // Default to false if no settings found (SMS is opt-in)
                return ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.sms_enabled) === true;
            }
            catch (error) {
                console.error('Error checking SMS settings:', error);
                return false; // Default to disabled
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Check if within quiet hours
     */
    static isWithinQuietHours(tenantId, userId, notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT quiet_hours_start, quiet_hours_end FROM notification_settings 
         WHERE user_id = $1 AND notification_type = $2`, [userId, notificationType]);
                if (!result.rows[0] || !result.rows[0].quiet_hours_start || !result.rows[0].quiet_hours_end) {
                    return false;
                }
                const now = new Date();
                const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                const { quiet_hours_start, quiet_hours_end } = result.rows[0];
                return currentTime >= quiet_hours_start && currentTime <= quiet_hours_end;
            }
            catch (error) {
                console.error('Error checking quiet hours:', error);
                return false;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Log delivery attempt
     */
    static logDelivery(tenantId, notificationId, status, errorMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield client.query(`INSERT INTO notification_history (
          notification_id, channel, status, error_message, delivered_at
        ) VALUES ($1, $2, $3, $4, $5)`, [
                    notificationId,
                    'sms',
                    status,
                    errorMessage || null,
                    status === 'delivered' ? new Date() : null,
                ]);
            }
            catch (error) {
                console.error('Error logging delivery:', error);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Format phone number for E.164 format
     */
    static formatPhoneNumber(phone) {
        // Remove all non-digit characters
        let cleaned = phone.replace(/\D/g, '');
        // Add + prefix if not present
        if (!cleaned.startsWith('+')) {
            // Assume US number if no country code
            if (cleaned.length === 10) {
                cleaned = '+1' + cleaned;
            }
            else {
                cleaned = '+' + cleaned;
            }
        }
        return cleaned;
    }
    /**
     * Truncate message to SMS length limit
     */
    static truncateMessage(message, maxLength = 160) {
        if (message.length <= maxLength) {
            return message;
        }
        return message.substring(0, maxLength - 3) + '...';
    }
    /**
     * Send SMS notification
     */
    static sendSMS(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Check if SMS is enabled
                if (!process.env.ENABLE_SNS || process.env.ENABLE_SNS !== 'true') {
                    console.log('📱 SMS service is disabled');
                    return { success: false, error: 'SMS service disabled' };
                }
                // Check if SMS is enabled for this notification type
                const smsEnabled = yield this.isSMSEnabled(tenantId, notification.user_id, notification.type);
                if (!smsEnabled) {
                    console.log(`📱 SMS disabled for user ${notification.user_id}, type ${notification.type}`);
                    return { success: false, error: 'SMS notifications disabled' };
                }
                // Check quiet hours (skip for critical notifications)
                if (notification.priority.toLowerCase() !== 'critical') {
                    const inQuietHours = yield this.isWithinQuietHours(tenantId, notification.user_id, notification.type);
                    if (inQuietHours) {
                        console.log(`🔕 Within quiet hours for user ${notification.user_id}`);
                        yield this.logDelivery(tenantId, notification.id, 'pending', 'Within quiet hours');
                        return { success: false, error: 'Within quiet hours' };
                    }
                }
                // Get user phone
                const userPhone = yield this.getUserPhone(notification.user_id);
                if (!userPhone) {
                    console.error(`❌ No phone found for user ${notification.user_id}`);
                    yield this.logDelivery(tenantId, notification.id, 'failed', 'No phone number');
                    return { success: false, error: 'No phone number' };
                }
                // Format phone number
                const formattedPhone = this.formatPhoneNumber(userPhone);
                // Get template
                const template = yield this.getTemplate(notification.type);
                // Prepare SMS content
                let message = notification.message;
                if (template && template.sms_template) {
                    const variables = notification.data || {};
                    message = this.renderTemplate(template.sms_template, variables);
                }
                // Truncate message to SMS length
                message = this.truncateMessage(message);
                // Send SMS via AWS SNS
                const command = new client_sns_1.PublishCommand({
                    PhoneNumber: formattedPhone,
                    Message: message,
                    MessageAttributes: {
                        'AWS.SNS.SMS.SMSType': {
                            DataType: 'String',
                            StringValue: notification.priority.toLowerCase() === 'critical' ? 'Transactional' : 'Promotional',
                        },
                    },
                });
                const response = yield snsClient.send(command);
                console.log(`✅ SMS sent to ${formattedPhone} (MessageId: ${response.MessageId})`);
                yield this.logDelivery(tenantId, notification.id, 'delivered');
                return { success: true, messageId: response.MessageId };
            }
            catch (error) {
                console.error('❌ Error sending SMS:', error);
                yield this.logDelivery(tenantId, notification.id, 'failed', error.message);
                return { success: false, error: error.message };
            }
        });
    }
    /**
     * Send SMS with retry logic
     */
    static sendSMSWithRetry(tenantId_1, notification_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, notification, maxRetries = 3) {
            let lastError = '';
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                console.log(`📱 SMS delivery attempt ${attempt}/${maxRetries} for notification ${notification.id}`);
                const result = yield this.sendSMS(tenantId, notification);
                if (result.success) {
                    return result;
                }
                lastError = result.error || 'Unknown error';
                // Don't retry if SMS is disabled or within quiet hours
                if (lastError === 'SMS notifications disabled' ||
                    lastError === 'Within quiet hours' ||
                    lastError === 'SMS service disabled') {
                    return result;
                }
                // Wait before retry (exponential backoff)
                if (attempt < maxRetries) {
                    const delay = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
                    yield new Promise(resolve => setTimeout(resolve, delay));
                }
            }
            return { success: false, error: `Failed after ${maxRetries} attempts: ${lastError}` };
        });
    }
}
exports.NotificationSMSService = NotificationSMSService;
