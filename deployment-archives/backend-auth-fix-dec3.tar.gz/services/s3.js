"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateShareUrl = exports.getFileMetadata = exports.listFiles = exports.deleteFile = exports.getDownloadUrl = exports.getUploadUrl = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    }
});
const getUploadUrl = (tenantId, filename, contentType) => __awaiter(void 0, void 0, void 0, function* () {
    const key = `${tenantId}/${Date.now()}-${filename}`;
    const command = new client_s3_1.PutObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
        ContentType: contentType,
    });
    const uploadUrl = yield (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn: 3600 });
    return { uploadUrl, key };
});
exports.getUploadUrl = getUploadUrl;
const getDownloadUrl = (tenantId, key, filename) => __awaiter(void 0, void 0, void 0, function* () {
    // Ensure the key belongs to the tenant for security
    if (!key.startsWith(`${tenantId}/`)) {
        throw new Error('Access denied: File does not belong to tenant');
    }
    const command = new client_s3_1.GetObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
        ResponseContentDisposition: filename ? `attachment; filename="${filename}"` : 'attachment',
    });
    return (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn: 3600 });
});
exports.getDownloadUrl = getDownloadUrl;
const deleteFile = (tenantId, key) => __awaiter(void 0, void 0, void 0, function* () {
    // Ensure the key belongs to the tenant for security
    if (!key.startsWith(`${tenantId}/`)) {
        throw new Error('Access denied: File does not belong to tenant');
    }
    const command = new client_s3_1.DeleteObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
    });
    yield s3Client.send(command);
});
exports.deleteFile = deleteFile;
const listFiles = (tenantId) => __awaiter(void 0, void 0, void 0, function* () {
    const command = new client_s3_1.ListObjectsV2Command({
        Bucket: process.env.S3_BUCKET_NAME,
        Prefix: `${tenantId}/`,
    });
    const response = yield s3Client.send(command);
    if (!response.Contents) {
        return [];
    }
    return response.Contents.map(object => ({
        key: object.Key,
        filename: object.Key.split('/').pop(),
        size: object.Size || 0,
        lastModified: object.LastModified || new Date(),
    }));
});
exports.listFiles = listFiles;
const getFileMetadata = (tenantId, key) => __awaiter(void 0, void 0, void 0, function* () {
    // Ensure the key belongs to the tenant for security
    if (!key.startsWith(`${tenantId}/`)) {
        throw new Error('Access denied: File does not belong to tenant');
    }
    const command = new client_s3_1.HeadObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
    });
    const response = yield s3Client.send(command);
    return {
        key,
        filename: key.split('/').pop(),
        size: response.ContentLength || 0,
        lastModified: response.LastModified || new Date(),
        contentType: response.ContentType,
    };
});
exports.getFileMetadata = getFileMetadata;
const generateShareUrl = (tenantId_1, key_1, ...args_1) => __awaiter(void 0, [tenantId_1, key_1, ...args_1], void 0, function* (tenantId, key, expiresIn = 86400) {
    // Ensure the key belongs to the tenant for security
    if (!key.startsWith(`${tenantId}/`)) {
        throw new Error('Access denied: File does not belong to tenant');
    }
    const command = new client_s3_1.GetObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
    });
    return (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn });
});
exports.generateShareUrl = generateShareUrl;
