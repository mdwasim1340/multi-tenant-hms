"use strict";
/**
 * Notification Email Service
 * Team: Epsilon
 * Purpose: Email delivery via AWS SES with template rendering
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationEmailService = void 0;
const client_ses_1 = require("@aws-sdk/client-ses");
const database_1 = __importDefault(require("../database"));
const sesClient = new client_ses_1.SESClient({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
    },
});
class NotificationEmailService {
    /**
     * Render template with variables
     */
    static renderTemplate(template, variables) {
        let rendered = template;
        Object.entries(variables).forEach(([key, value]) => {
            const regex = new RegExp(`{{${key}}}`, 'g');
            rendered = rendered.replace(regex, String(value));
        });
        return rendered;
    }
    /**
     * Get user email address
     */
    static getUserEmail(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                const result = yield database_1.default.query('SELECT email FROM users WHERE id = $1', [userId]);
                return ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.email) || null;
            }
            catch (error) {
                console.error('Error getting user email:', error);
                return null;
            }
        });
    }
    /**
     * Get notification template
     */
    static getTemplate(notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield database_1.default.query('SELECT * FROM notification_templates WHERE template_key = $1', [notificationType]);
                return result.rows[0] || null;
            }
            catch (error) {
                console.error('Error getting template:', error);
                return null;
            }
        });
    }
    /**
     * Check if user has email notifications enabled
     */
    static isEmailEnabled(tenantId, userId, notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT email_enabled FROM notification_settings 
         WHERE user_id = $1 AND notification_type = $2`, [userId, notificationType]);
                // Default to true if no settings found
                return ((_a = result.rows[0]) === null || _a === void 0 ? void 0 : _a.email_enabled) !== false;
            }
            catch (error) {
                console.error('Error checking email settings:', error);
                return true; // Default to enabled
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Check if within quiet hours
     */
    static isWithinQuietHours(tenantId, userId, notificationType) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const result = yield client.query(`SELECT quiet_hours_start, quiet_hours_end FROM notification_settings 
         WHERE user_id = $1 AND notification_type = $2`, [userId, notificationType]);
                if (!result.rows[0] || !result.rows[0].quiet_hours_start || !result.rows[0].quiet_hours_end) {
                    return false; // No quiet hours configured
                }
                const now = new Date();
                const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                const { quiet_hours_start, quiet_hours_end } = result.rows[0];
                // Simple time comparison (doesn't handle overnight ranges)
                return currentTime >= quiet_hours_start && currentTime <= quiet_hours_end;
            }
            catch (error) {
                console.error('Error checking quiet hours:', error);
                return false;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Log delivery attempt
     */
    static logDelivery(tenantId, notificationId, status, errorMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield client.query(`INSERT INTO notification_history (
          notification_id, channel, status, error_message, delivered_at
        ) VALUES ($1, $2, $3, $4, $5)`, [
                    notificationId,
                    'email',
                    status,
                    errorMessage || null,
                    status === 'delivered' ? new Date() : null,
                ]);
            }
            catch (error) {
                console.error('Error logging delivery:', error);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Send email notification
     */
    static sendEmail(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Check if email is enabled for this notification type
                const emailEnabled = yield this.isEmailEnabled(tenantId, notification.user_id, notification.type);
                if (!emailEnabled) {
                    console.log(`📧 Email disabled for user ${notification.user_id}, type ${notification.type}`);
                    return { success: false, error: 'Email notifications disabled' };
                }
                // Check quiet hours (skip for critical notifications)
                if (notification.priority.toLowerCase() !== 'critical') {
                    const inQuietHours = yield this.isWithinQuietHours(tenantId, notification.user_id, notification.type);
                    if (inQuietHours) {
                        console.log(`🔕 Within quiet hours for user ${notification.user_id}`);
                        yield this.logDelivery(tenantId, notification.id, 'pending', 'Within quiet hours');
                        return { success: false, error: 'Within quiet hours' };
                    }
                }
                // Get user email
                const userEmail = yield this.getUserEmail(notification.user_id);
                if (!userEmail) {
                    console.error(`❌ No email found for user ${notification.user_id}`);
                    yield this.logDelivery(tenantId, notification.id, 'failed', 'No email address');
                    return { success: false, error: 'No email address' };
                }
                // Get template
                const template = yield this.getTemplate(notification.type);
                // Prepare email content
                let subject = notification.title;
                let body = notification.message;
                if (template && template.subject_template && template.body_template) {
                    const variables = notification.data || {};
                    subject = this.renderTemplate(template.subject_template, variables);
                    body = this.renderTemplate(template.body_template, variables);
                }
                // Send email via AWS SES
                const command = new client_ses_1.SendEmailCommand({
                    Source: process.env.EMAIL_SENDER || 'noreply@hospital.com',
                    Destination: {
                        ToAddresses: [userEmail],
                    },
                    Message: {
                        Subject: {
                            Data: subject,
                            Charset: 'UTF-8',
                        },
                        Body: {
                            Text: {
                                Data: body,
                                Charset: 'UTF-8',
                            },
                            Html: {
                                Data: `
                <html>
                  <body>
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                      <h2 style="color: #333;">${subject}</h2>
                      <p style="color: #666; line-height: 1.6;">${body.replace(/\n/g, '<br>')}</p>
                      <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                      <p style="color: #999; font-size: 12px;">
                        This is an automated notification from your hospital management system.
                      </p>
                    </div>
                  </body>
                </html>
              `,
                                Charset: 'UTF-8',
                            },
                        },
                    },
                });
                const response = yield sesClient.send(command);
                console.log(`✅ Email sent to ${userEmail} (MessageId: ${response.MessageId})`);
                yield this.logDelivery(tenantId, notification.id, 'delivered');
                return { success: true, messageId: response.MessageId };
            }
            catch (error) {
                console.error('❌ Error sending email:', error);
                yield this.logDelivery(tenantId, notification.id, 'failed', error.message);
                return { success: false, error: error.message };
            }
        });
    }
    /**
     * Send email with retry logic
     */
    static sendEmailWithRetry(tenantId_1, notification_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, notification, maxRetries = 3) {
            let lastError = '';
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                console.log(`📧 Email delivery attempt ${attempt}/${maxRetries} for notification ${notification.id}`);
                const result = yield this.sendEmail(tenantId, notification);
                if (result.success) {
                    return result;
                }
                lastError = result.error || 'Unknown error';
                // Don't retry if email is disabled or within quiet hours
                if (lastError === 'Email notifications disabled' || lastError === 'Within quiet hours') {
                    return result;
                }
                // Wait before retry (exponential backoff)
                if (attempt < maxRetries) {
                    const delay = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
                    yield new Promise(resolve => setTimeout(resolve, delay));
                }
            }
            return { success: false, error: `Failed after ${maxRetries} attempts: ${lastError}` };
        });
    }
}
exports.NotificationEmailService = NotificationEmailService;
