"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierService = exports.SupplierNotFoundError = void 0;
const inventory_validation_1 = require("../validation/inventory.validation");
const inventory_item_service_1 = require("./inventory-item.service");
class SupplierNotFoundError extends Error {
    constructor(supplierId) {
        super(`Supplier with ID ${supplierId} not found`);
        this.name = 'SupplierNotFoundError';
    }
}
exports.SupplierNotFoundError = SupplierNotFoundError;
/**
 * SupplierService - Manages supplier CRUD and relationships
 * Team Beta - Inventory Management System
 */
class SupplierService {
    constructor(pool) {
        this.pool = pool;
    }
    getSuppliers(tenantId, params) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                let where = [];
                let values = [];
                let i = 1;
                if (params === null || params === void 0 ? void 0 : params.status) {
                    where.push(`status = $${i}`);
                    values.push(params.status);
                    i++;
                }
                if (params === null || params === void 0 ? void 0 : params.search) {
                    where.push(`(name ILIKE $${i} OR code ILIKE $${i} OR email ILIKE $${i})`);
                    values.push(`%${params.search}%`);
                    i++;
                }
                const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
                const query = `SELECT * FROM suppliers ${whereClause} ORDER BY name ASC`;
                const res = yield client.query(query, values);
                return res.rows;
            }
            finally {
                client.release();
            }
        });
    }
    getSupplierById(supplierId, tenantId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || (yield this.pool.connect());
            try {
                if (!client)
                    yield dbClient.query(`SET search_path TO "${tenantId}"`);
                const res = yield dbClient.query(`SELECT * FROM suppliers WHERE id = $1`, [supplierId]);
                if (res.rows.length === 0)
                    throw new SupplierNotFoundError(supplierId);
                return res.rows[0];
            }
            finally {
                if (!client)
                    dbClient.release();
            }
        });
    }
    createSupplier(data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const validated = inventory_validation_1.createSupplierSchema.parse(data);
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Code uniqueness
                if (validated.code) {
                    const dup = yield client.query('SELECT id FROM suppliers WHERE code = $1', [validated.code]);
                    if (dup.rows.length)
                        throw new inventory_item_service_1.InventoryValidationError(`Supplier code '${validated.code}' already exists`);
                }
                // Prepare data
                const supData = Object.assign(Object.assign({}, validated), { status: validated.status || 'active', created_by: userId, updated_by: userId, created_at: new Date(), updated_at: new Date() });
                const cols = Object.keys(supData);
                const vals = Object.values(supData);
                const ph = vals.map((_, i) => `$${i + 1}`).join(', ');
                const insert = `INSERT INTO suppliers(${cols.join(',')}) VALUES (${ph}) RETURNING *`;
                const res = yield client.query(insert, vals);
                return yield this.getSupplierById(res.rows[0].id, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    updateSupplier(supplierId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const validated = inventory_validation_1.updateSupplierSchema.parse(data);
            const upd = Object.fromEntries(Object.entries(validated).filter(([_, v]) => v !== undefined));
            if (!Object.keys(upd).length)
                throw new inventory_item_service_1.InventoryValidationError('No valid fields for update');
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield this.getSupplierById(supplierId, tenantId, client);
                if (upd.code) {
                    const dup = yield client.query('SELECT id FROM suppliers WHERE code = $1 AND id <> $2', [upd.code, supplierId]);
                    if (dup.rows.length)
                        throw new inventory_item_service_1.InventoryValidationError(`Supplier code '${upd.code}' already exists`);
                }
                const finalUpd = Object.assign(Object.assign({}, upd), { updated_by: userId, updated_at: new Date() });
                const entries = Object.entries(finalUpd);
                const set = entries.map(([k], i) => `${k} = $${i + 2}`).join(', ');
                const vals = entries.map(([_, v]) => v);
                yield client.query(`UPDATE suppliers SET ${set} WHERE id = $1`, [supplierId, ...vals]);
                return yield this.getSupplierById(supplierId, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    deleteSupplier(supplierId, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                yield this.getSupplierById(supplierId, tenantId, client);
                // Soft delete (status = 'inactive')
                yield client.query(`UPDATE suppliers SET status = 'inactive', updated_by = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $1`, [supplierId, userId]);
            }
            finally {
                client.release();
            }
        });
    }
    getSupplierItems(supplierId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const q = `SELECT * FROM inventory_items WHERE supplier_id = $1 AND status='active' ORDER BY name ASC`;
                const res = yield client.query(q, [supplierId]);
                return res.rows;
            }
            finally {
                client.release();
            }
        });
    }
    getSupplierStats(supplierId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const q = `SELECT COUNT(*) AS item_count, AVG(lead_time_days) AS avg_lead_time FROM suppliers WHERE id = $1`;
                const res = yield client.query(q, [supplierId]);
                return { item_count: parseInt(res.rows[0].item_count), avg_lead_time: parseFloat(res.rows[0].avg_lead_time) || 0 };
            }
            finally {
                client.release();
            }
        });
    }
}
exports.SupplierService = SupplierService;
