"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PatientService = void 0;
const AppError_1 = require("../errors/AppError");
class PatientService {
    constructor(pool) {
        this.pool = pool;
    }
    createPatient(data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check for duplicate patient number
                const existingPatient = yield client.query('SELECT id FROM patients WHERE patient_number = $1', [data.patient_number]);
                if (existingPatient.rows.length > 0) {
                    throw new AppError_1.DuplicateError('Patient', 'patient_number');
                }
                // Separate custom fields from patient data
                const { custom_fields } = data, patientData = __rest(data, ["custom_fields"]);
                // Normalize date_of_birth to DATE (YYYY-MM-DD) for Postgres
                if (patientData.date_of_birth) {
                    try {
                        const d = new Date(patientData.date_of_birth);
                        const normalized = isNaN(d.getTime())
                            ? String(patientData.date_of_birth).split('T')[0]
                            : d.toISOString().split('T')[0];
                        patientData.date_of_birth = normalized;
                    }
                    catch (_a) {
                        patientData.date_of_birth = String(patientData.date_of_birth).split('T')[0];
                    }
                }
                // Add audit fields
                const dataWithAudit = Object.assign(Object.assign({}, patientData), { created_by: userId, updated_by: userId });
                // Build insert query
                const columns = Object.keys(dataWithAudit);
                const values = Object.values(dataWithAudit);
                const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
                const insertQuery = `
        INSERT INTO patients (${columns.join(', ')})
        VALUES (${placeholders})
        RETURNING *
      `;
                const result = yield client.query(insertQuery, values);
                const patient = result.rows[0];
                // Handle custom fields if provided
                if (custom_fields && Object.keys(custom_fields).length > 0) {
                    yield this.saveCustomFields(client, patient.id, custom_fields);
                }
                // Fetch complete patient with custom fields
                const completePatient = yield this.getPatientById(patient.id, tenantId, client);
                if (!completePatient) {
                    throw new Error('PATIENT_CREATION_FAILED');
                }
                return completePatient;
            }
            finally {
                client.release();
            }
        });
    }
    getPatientById(patientId, tenantId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || (yield this.pool.connect());
            try {
                if (!client) {
                    yield dbClient.query(`SET search_path TO "${tenantId}"`);
                }
                const query = `
        SELECT 
          p.*,
          EXTRACT(YEAR FROM AGE(p.date_of_birth)) as age
        FROM patients p
        WHERE p.id = $1
      `;
                const result = yield dbClient.query(query, [patientId]);
                if (result.rows.length === 0) {
                    return null;
                }
                const patient = result.rows[0];
                // Get custom fields
                patient.custom_fields = yield this.getCustomFields(dbClient, patientId);
                return patient;
            }
            finally {
                if (!client) {
                    dbClient.release();
                }
            }
        });
    }
    updatePatient(patientId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check patient exists
                const existing = yield this.getPatientById(patientId, tenantId, client);
                if (!existing) {
                    throw new AppError_1.NotFoundError('Patient');
                }
                // Separate custom fields
                const { custom_fields } = data, patientData = __rest(data, ["custom_fields"]);
                if (Object.keys(patientData).length > 0) {
                    // Add audit fields
                    const dataWithAudit = Object.assign(Object.assign({}, patientData), { updated_by: userId, updated_at: new Date() });
                    // Build update query
                    const entries = Object.entries(dataWithAudit);
                    const setClause = entries
                        .map(([key], i) => `${key} = $${i + 2}`)
                        .join(', ');
                    const values = entries.map(([, value]) => value);
                    const updateQuery = `
          UPDATE patients 
          SET ${setClause}
          WHERE id = $1
          RETURNING *
        `;
                    yield client.query(updateQuery, [patientId, ...values]);
                }
                // Update custom fields if provided
                if (custom_fields) {
                    yield this.deleteCustomFields(client, patientId);
                    if (Object.keys(custom_fields).length > 0) {
                        yield this.saveCustomFields(client, patientId, custom_fields);
                    }
                }
                const updatedPatient = yield this.getPatientById(patientId, tenantId, client);
                if (!updatedPatient) {
                    throw new Error('PATIENT_UPDATE_FAILED');
                }
                return updatedPatient;
            }
            finally {
                client.release();
            }
        });
    }
    deletePatient(patientId, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                const patient = yield this.getPatientById(patientId, tenantId, client);
                if (!patient) {
                    throw new AppError_1.NotFoundError('Patient');
                }
                // Soft delete
                const query = `
        UPDATE patients 
        SET status = 'inactive', updated_by = $2, updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
        RETURNING *
      `;
                yield client.query(query, [patientId, userId]);
                const deletedPatient = yield this.getPatientById(patientId, tenantId, client);
                if (!deletedPatient) {
                    throw new Error('PATIENT_DELETE_FAILED');
                }
                return deletedPatient;
            }
            finally {
                client.release();
            }
        });
    }
    saveCustomFields(client, patientId, customFields) {
        return __awaiter(this, void 0, void 0, function* () {
            const fieldNames = Object.keys(customFields);
            if (fieldNames.length === 0)
                return;
            // Get field definitions
            const fieldsQuery = `
      SELECT id, name, field_type
      FROM public.custom_fields 
      WHERE name = ANY($1) AND applies_to = 'patients'
    `;
            const fieldsResult = yield client.query(fieldsQuery, [fieldNames]);
            const fieldDefinitions = fieldsResult.rows;
            // Insert custom field values
            const values = [];
            for (const fieldDef of fieldDefinitions) {
                const value = customFields[fieldDef.name];
                if (value !== undefined && value !== null && value !== '') {
                    values.push({
                        entity_type: 'patient',
                        entity_id: patientId,
                        field_id: fieldDef.id,
                        value: typeof value === 'object' ? JSON.stringify(value) : String(value),
                    });
                }
            }
            if (values.length > 0) {
                const insertQuery = `
        INSERT INTO custom_field_values (entity_type, entity_id, field_id, value)
        VALUES ${values
                    .map((_, i) => `($${i * 4 + 1}, $${i * 4 + 2}, $${i * 4 + 3}, $${i * 4 + 4})`)
                    .join(', ')}
      `;
                const params = values.flatMap((v) => [
                    v.entity_type,
                    v.entity_id,
                    v.field_id,
                    v.value,
                ]);
                yield client.query(insertQuery, params);
            }
        });
    }
    getCustomFields(client, patientId) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = `
      SELECT 
        cf.name as field_name,
        cf.field_type as field_type,
        cfv.value as field_value
      FROM custom_field_values cfv
      JOIN public.custom_fields cf ON cf.id = cfv.field_id
      WHERE cfv.entity_type = 'patient' AND cfv.entity_id = $1
      ORDER BY cf.display_order
    `;
            const result = yield client.query(query, [patientId]);
            const customFields = {};
            result.rows.forEach((row) => {
                customFields[row.field_name] = row.field_value;
            });
            return customFields;
        });
    }
    deleteCustomFields(client, patientId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield client.query('DELETE FROM custom_field_values WHERE entity_type = $1 AND entity_id = $2', ['patient', patientId]);
        });
    }
}
exports.PatientService = PatientService;
