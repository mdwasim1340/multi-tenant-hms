"use strict";
/**
 * Notification Broadcaster Service
 * Team: Epsilon
 * Purpose: Coordinate real-time notification delivery across WebSocket and SSE
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationBroadcaster = void 0;
const notification_server_1 = require("../websocket/notification-server");
const notification_sse_1 = require("./notification-sse");
const notification_1 = require("./notification");
class NotificationBroadcaster {
    /**
     * Broadcast notification to user via all available channels
     */
    static broadcastToUser(tenantId, userId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            const results = {
                websocket: false,
                sse: false,
            };
            // Try WebSocket first
            const wsServer = (0, notification_server_1.getNotificationWebSocket)();
            if (wsServer) {
                results.websocket = wsServer.broadcastToUser(tenantId, userId, notification);
            }
            // Try SSE as fallback or additional channel
            const sseService = (0, notification_sse_1.getNotificationSSEService)();
            if (sseService) {
                results.sse = sseService.sendToUser(tenantId, userId, notification);
            }
            // Log delivery status
            if (results.websocket || results.sse) {
                console.log(`✅ Notification ${notification.id} delivered to user ${userId} (WS: ${results.websocket}, SSE: ${results.sse})`);
            }
            else {
                console.log(`📭 Notification ${notification.id} queued for user ${userId} (no active connections)`);
            }
            return results;
        });
    }
    /**
     * Broadcast notification to all users in tenant
     */
    static broadcastToTenant(tenantId, notification) {
        return __awaiter(this, void 0, void 0, function* () {
            const results = {
                websocket: 0,
                sse: 0,
            };
            // Broadcast via WebSocket
            const wsServer = (0, notification_server_1.getNotificationWebSocket)();
            if (wsServer) {
                results.websocket = wsServer.broadcastToTenant(tenantId, notification);
            }
            // Broadcast via SSE
            const sseService = (0, notification_sse_1.getNotificationSSEService)();
            if (sseService) {
                results.sse = sseService.sendToTenant(tenantId, notification);
            }
            console.log(`📢 Notification ${notification.id} broadcast to tenant ${tenantId} (WS: ${results.websocket}, SSE: ${results.sse})`);
            return results;
        });
    }
    /**
     * Send statistics update to user
     */
    static sendStatsUpdate(tenantId, userId, stats) {
        return __awaiter(this, void 0, void 0, function* () {
            const results = {
                websocket: false,
                sse: false,
            };
            // Send via WebSocket
            const wsServer = (0, notification_server_1.getNotificationWebSocket)();
            if (wsServer) {
                results.websocket = wsServer.sendStatsUpdate(tenantId, userId, stats);
            }
            // Send via SSE
            const sseService = (0, notification_sse_1.getNotificationSSEService)();
            if (sseService) {
                results.sse = sseService.sendStatsUpdate(tenantId, userId, stats);
            }
            return results;
        });
    }
    /**
     * Create notification and broadcast immediately (in-app only)
     * For multi-channel delivery, use NotificationDeliveryService
     */
    static createAndBroadcast(tenantId, notificationData) {
        return __awaiter(this, void 0, void 0, function* () {
            // Create notification in database
            const notification = yield notification_1.NotificationService.createNotification(tenantId, notificationData);
            // Broadcast to user via in-app channels (WebSocket/SSE)
            yield this.broadcastToUser(tenantId, notification.user_id, notification);
            // Update user statistics
            const stats = yield notification_1.NotificationService.getNotificationStats(tenantId, notification.user_id);
            yield this.sendStatsUpdate(tenantId, notification.user_id, stats);
            return notification;
        });
    }
    /**
     * Get connection statistics
     */
    static getConnectionStats() {
        const wsServer = (0, notification_server_1.getNotificationWebSocket)();
        const sseService = (0, notification_sse_1.getNotificationSSEService)();
        return {
            websocket: {
                total: wsServer ? wsServer.getConnectionCount() : 0,
            },
            sse: {
                total: sseService ? sseService.getConnectionCount() : 0,
            },
        };
    }
    /**
     * Get tenant connection statistics
     */
    static getTenantConnectionStats(tenantId) {
        const wsServer = (0, notification_server_1.getNotificationWebSocket)();
        const sseService = (0, notification_sse_1.getNotificationSSEService)();
        return {
            websocket: wsServer ? wsServer.getTenantConnectionCount(tenantId) : 0,
            sse: sseService ? sseService.getTenantConnectionCount(tenantId) : 0,
        };
    }
    /**
     * Get user connection statistics
     */
    static getUserConnectionStats(tenantId, userId) {
        const wsServer = (0, notification_server_1.getNotificationWebSocket)();
        const sseService = (0, notification_sse_1.getNotificationSSEService)();
        return {
            websocket: wsServer ? wsServer.getUserConnectionCount(tenantId, userId) : 0,
            sse: sseService ? sseService.getUserConnectionCount(tenantId, userId) : 0,
        };
    }
}
exports.NotificationBroadcaster = NotificationBroadcaster;
