"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoryService = exports.CategoryNotFoundError = void 0;
const inventory_validation_1 = require("../validation/inventory.validation");
const inventory_item_service_1 = require("./inventory-item.service");
/**
 * CategoryNotFoundError - Thrown when category doesn't exist
 */
class CategoryNotFoundError extends Error {
    constructor(categoryId) {
        super(`Category with ID ${categoryId} not found`);
        this.name = 'CategoryNotFoundError';
    }
}
exports.CategoryNotFoundError = CategoryNotFoundError;
/**
 * CategoryService - Manages inventory category operations
 * Supports hierarchical category structures
 * Team: Beta, System: Inventory Management
 */
class CategoryService {
    constructor(pool) {
        this.pool = pool;
    }
    /**
     * Get all categories with optional filtering
     */
    getCategories(tenantId, params) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                let whereConditions = [];
                let queryParams = [];
                let paramIndex = 1;
                if (params === null || params === void 0 ? void 0 : params.status) {
                    whereConditions.push(`c.status = $${paramIndex}`);
                    queryParams.push(params.status);
                    paramIndex++;
                }
                if ((params === null || params === void 0 ? void 0 : params.parent_category_id) !== undefined) {
                    if (params.parent_category_id === null) {
                        whereConditions.push(`c.parent_category_id IS NULL`);
                    }
                    else {
                        whereConditions.push(`c.parent_category_id = $${paramIndex}`);
                        queryParams.push(params.parent_category_id);
                        paramIndex++;
                    }
                }
                if (params === null || params === void 0 ? void 0 : params.search) {
                    whereConditions.push(`(c.name ILIKE $${paramIndex} OR c.code ILIKE $${paramIndex})`);
                    queryParams.push(`%${params.search}%`);
                    paramIndex++;
                }
                const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
                const query = `
        SELECT 
          c.*,
          pc.name as parent_category_name,
          pc.code as parent_category_code,
          (SELECT COUNT(*) FROM inventory_categories WHERE parent_category_id = c.id) as child_count,
          (SELECT COUNT(*) FROM inventory_items WHERE category_id = c.id AND status = 'active') as item_count
        FROM inventory_categories c
        LEFT JOIN inventory_categories pc ON pc.id = c.parent_category_id
        ${whereClause}
        ORDER BY c.name ASC
      `;
                const result = yield client.query(query, queryParams);
                return result.rows.map((row) => {
                    // Parse counts
                    row.child_count = parseInt(row.child_count) || 0;
                    row.item_count = parseInt(row.item_count) || 0;
                    // Add parent category info if exists
                    if (row.parent_category_name) {
                        row.parent_category = {
                            id: row.parent_category_id,
                            name: row.parent_category_name,
                            code: row.parent_category_code,
                        };
                    }
                    return row;
                });
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get category by ID with parent information
     * @throws CategoryNotFoundError if category doesn't exist
     */
    getCategoryById(categoryId, tenantId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const dbClient = client || (yield this.pool.connect());
            try {
                if (!client) {
                    yield dbClient.query(`SET search_path TO "${tenantId}"`);
                }
                const query = `
        SELECT 
          c.*,
          pc.name as parent_category_name,
          pc.code as parent_category_code,
          (SELECT COUNT(*) FROM inventory_categories WHERE parent_category_id = c.id) as child_count,
          (SELECT COUNT(*) FROM inventory_items WHERE category_id = c.id AND status = 'active') as item_count
        FROM inventory_categories c
        LEFT JOIN inventory_categories pc ON pc.id = c.parent_category_id
        WHERE c.id = $1
      `;
                const result = yield dbClient.query(query, [categoryId]);
                if (result.rows.length === 0) {
                    throw new CategoryNotFoundError(categoryId);
                }
                const category = result.rows[0];
                // Parse counts
                category.child_count = parseInt(category.child_count) || 0;
                category.item_count = parseInt(category.item_count) || 0;
                // Add parent category info if exists
                if (category.parent_category_name) {
                    category.parent_category = {
                        id: category.parent_category_id,
                        name: category.parent_category_name,
                        code: category.parent_category_code,
                    };
                }
                return category;
            }
            finally {
                if (!client) {
                    dbClient.release();
                }
            }
        });
    }
    /**
     * Create a new category
     * @throws InventoryValidationError if validation fails or code already exists
     */
    createCategory(data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Validate input data
            const validatedData = inventory_validation_1.createCategorySchema.parse(data);
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check for duplicate code
                const duplicateCheck = yield client.query('SELECT id FROM inventory_categories WHERE code = $1', [validatedData.code]);
                if (duplicateCheck.rows.length > 0) {
                    throw new inventory_item_service_1.InventoryValidationError(`Category code '${validatedData.code}' already exists`);
                }
                // If parent category provided, verify it exists and prevent circular reference
                if (validatedData.parent_category_id) {
                    const parentCheck = yield client.query('SELECT id FROM inventory_categories WHERE id = $1', [validatedData.parent_category_id]);
                    if (parentCheck.rows.length === 0) {
                        throw new inventory_item_service_1.InventoryValidationError(`Parent category with ID ${validatedData.parent_category_id} not found`);
                    }
                }
                // Prepare data with audit fields
                const categoryData = Object.assign(Object.assign({}, validatedData), { status: validatedData.status || 'active', created_by: userId, updated_by: userId, created_at: new Date(), updated_at: new Date() });
                const columns = Object.keys(categoryData);
                const values = Object.values(categoryData);
                const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
                const insertQuery = `
        INSERT INTO inventory_categories (${columns.join(', ')})
        VALUES (${placeholders})
        RETURNING *
      `;
                const result = yield client.query(insertQuery, values);
                const createdCategory = result.rows[0];
                // Fetch complete category with parent info
                return yield this.getCategoryById(createdCategory.id, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Update category information
     * @throws CategoryNotFoundError if category doesn't exist
     * @throws InventoryValidationError if update violates constraints
     */
    updateCategory(categoryId, data, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Validate partial update data
            const validatedData = inventory_validation_1.updateCategorySchema.parse(data);
            const updateData = Object.fromEntries(Object.entries(validatedData).filter(([_, v]) => v !== undefined));
            if (Object.keys(updateData).length === 0) {
                throw new inventory_item_service_1.InventoryValidationError('No valid fields provided for update');
            }
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check category exists
                yield this.getCategoryById(categoryId, tenantId, client);
                // If updating parent, validate it exists and prevent circular reference
                if (updateData.parent_category_id !== undefined) {
                    if (updateData.parent_category_id === categoryId) {
                        throw new inventory_item_service_1.InventoryValidationError('Category cannot be its own parent');
                    }
                    if (updateData.parent_category_id !== null) {
                        // Check parent exists
                        const parentCheck = yield client.query('SELECT id FROM inventory_categories WHERE id = $1', [updateData.parent_category_id]);
                        if (parentCheck.rows.length === 0) {
                            throw new inventory_item_service_1.InventoryValidationError(`Parent category with ID ${updateData.parent_category_id} not found`);
                        }
                        // Prevent circular reference (check if parent is a descendant)
                        const isDescendant = yield this.isDescendantOf(Number(updateData.parent_category_id), categoryId, tenantId, client);
                        if (isDescendant) {
                            throw new inventory_item_service_1.InventoryValidationError('Cannot set parent: would create circular reference');
                        }
                    }
                }
                // Prepare update data with audit fields
                const finalUpdateData = Object.assign(Object.assign({}, updateData), { updated_by: userId, updated_at: new Date() });
                const entries = Object.entries(finalUpdateData).filter(([_, v]) => v !== undefined);
                const setClause = entries.map(([key], i) => `${key} = $${i + 2}`).join(', ');
                const values = entries.map(([_, value]) => value);
                const updateQuery = `
        UPDATE inventory_categories
        SET ${setClause}
        WHERE id = $1
        RETURNING *
      `;
                yield client.query(updateQuery, [categoryId, ...values]);
                return yield this.getCategoryById(categoryId, tenantId, client);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Soft delete a category (set status = 'inactive')
     * Cannot delete if it has active items or child categories
     * @throws CategoryNotFoundError if category doesn't exist
     * @throws InventoryValidationError if category has dependencies
     */
    deleteCategory(categoryId, tenantId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Check category exists
                const category = yield this.getCategoryById(categoryId, tenantId, client);
                // Check for child categories
                const childCountResult = yield client.query('SELECT COUNT(*) as count FROM inventory_categories WHERE parent_category_id = $1', [categoryId]);
                if (parseInt(childCountResult.rows[0].count) > 0) {
                    throw new inventory_item_service_1.InventoryValidationError('Cannot delete category with child categories');
                }
                // Check for active items
                const itemCountResult = yield client.query('SELECT COUNT(*) as count FROM inventory_items WHERE category_id = $1', [categoryId]);
                if (parseInt(itemCountResult.rows[0].count) > 0) {
                    throw new inventory_item_service_1.InventoryValidationError('Cannot delete category with active inventory items');
                }
                // Soft delete
                const updateQuery = `
        UPDATE inventory_categories
        SET status = 'inactive',
            updated_by = $2,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
      `;
                yield client.query(updateQuery, [categoryId, userId]);
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get hierarchical category tree
     * Returns nested category structure
     */
    getCategoryTree(tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, status = 'active') {
            const client = yield this.pool.connect();
            try {
                yield client.query(`SET search_path TO "${tenantId}"`);
                // Get all categories
                let whereClause = '';
                if (status !== 'all') {
                    whereClause = `WHERE status = '${status}'`;
                }
                const query = `
        SELECT 
          c.*,
          (SELECT COUNT(*) FROM inventory_items WHERE category_id = c.id AND status = 'active') as item_count
        FROM inventory_categories c
        ${whereClause}
        ORDER BY c.name ASC
      `;
                const result = yield client.query(query);
                const categories = result.rows;
                // Build tree structure
                const categoryMap = new Map();
                const rootCategories = [];
                // First pass: create map
                categories.forEach((cat) => {
                    cat.item_count = parseInt(cat.item_count) || 0;
                    cat.children = [];
                    categoryMap.set(cat.id, cat);
                });
                // Second pass: build tree
                categories.forEach((cat) => {
                    if (cat.parent_category_id) {
                        const parent = categoryMap.get(cat.parent_category_id);
                        if (parent) {
                            parent.children.push(cat);
                        }
                        else {
                            // Parent not found (possibly inactive), treat as root
                            rootCategories.push(cat);
                        }
                    }
                    else {
                        rootCategories.push(cat);
                    }
                });
                return rootCategories;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get direct children of a category
     */
    getCategoryChildren(categoryId, tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.getCategories(tenantId, {
                parent_category_id: categoryId,
                status: 'active',
            });
        });
    }
    /**
     * Check if category A is a descendant of category B
     * Used to prevent circular references
     */
    isDescendantOf(potentialDescendantId, ancestorId, tenantId, client) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = `
      WITH RECURSIVE category_hierarchy AS (
        -- Base case: start with the potential descendant
        SELECT id, parent_category_id
        FROM inventory_categories
        WHERE id = $1
        
        UNION ALL
        
        -- Recursive case: traverse up the tree
        SELECT c.id, c.parent_category_id
        FROM inventory_categories c
        INNER JOIN category_hierarchy ch ON c.id = ch.parent_category_id
      )
      SELECT EXISTS(
        SELECT 1 FROM category_hierarchy WHERE id = $2
      ) as is_descendant
    `;
            const result = yield client.query(query, [potentialDescendantId, ancestorId]);
            return result.rows[0].is_descendant;
        });
    }
}
exports.CategoryService = CategoryService;
