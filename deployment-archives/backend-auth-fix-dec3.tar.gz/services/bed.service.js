"use strict";
/**
 * Bed Service
 * Business logic for bed management operations
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedService = void 0;
const database_1 = __importDefault(require("../database"));
const bed_1 = require("../types/bed");
class BedService {
    /**
     * Get beds with filtering and pagination
     */
    getBeds(tenantId, params) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            const { page = 1, limit = 1000, department_id, status, bed_type, floor_number, room_number, search, sort_by = 'bed_number', sort_order = 'asc', is_active, } = params;
            const offset = (page - 1) * limit;
            const queryParams = [];
            let paramIndex = 1;
            // Build WHERE clause
            let whereClause = 'WHERE 1=1';
            if (department_id) {
                whereClause += ` AND b.department_id = $${paramIndex}`;
                queryParams.push(department_id);
                paramIndex++;
            }
            if (status) {
                whereClause += ` AND b.status = $${paramIndex}`;
                queryParams.push(status);
                paramIndex++;
            }
            if (bed_type) {
                whereClause += ` AND b.bed_type = $${paramIndex}`;
                queryParams.push(bed_type);
                paramIndex++;
            }
            if (floor_number !== undefined) {
                whereClause += ` AND b.floor_number = $${paramIndex}`;
                queryParams.push(floor_number);
                paramIndex++;
            }
            if (room_number) {
                whereClause += ` AND b.room_number = $${paramIndex}`;
                queryParams.push(room_number);
                paramIndex++;
            }
            if (is_active !== undefined) {
                whereClause += ` AND b.is_active = $${paramIndex}`;
                queryParams.push(is_active);
                paramIndex++;
            }
            if (search) {
                whereClause += ` AND (b.bed_number ILIKE $${paramIndex} OR b.room_number ILIKE $${paramIndex})`;
                queryParams.push(`%${search}%`);
                paramIndex++;
            }
            // Get total count
            const countQuery = `
      SELECT COUNT(*) as total
      FROM beds b
      ${whereClause}
    `;
            const countResult = yield database_1.default.query(countQuery, queryParams);
            const total = parseInt(countResult.rows[0].total);
            // Get beds with department info
            const bedsQuery = `
      SELECT 
        b.*,
        d.name as department_name,
        d.department_code,
        (
          SELECT COUNT(*) 
          FROM bed_assignments ba 
          WHERE ba.bed_id = b.id AND ba.status = 'active'
        ) as has_active_assignment
      FROM beds b
      LEFT JOIN departments d ON b.department_id = d.id
      ${whereClause}
      ORDER BY b.${sort_by} ${sort_order}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
            queryParams.push(limit, offset);
            const bedsResult = yield database_1.default.query(bedsQuery, queryParams);
            return {
                beds: bedsResult.rows,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            };
        });
    }
    /**
     * Get bed by ID
     */
    getBedById(tenantId, bedId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            const query = `
      SELECT 
        b.*,
        d.name as department_name,
        d.department_code,
        ba.id as current_assignment_id,
        ba.patient_id,
        ba.admission_date,
        p.first_name,
        p.last_name,
        p.patient_number
      FROM beds b
      LEFT JOIN departments d ON b.department_id = d.id
      LEFT JOIN bed_assignments ba ON b.id = ba.bed_id AND ba.status = 'active'
      LEFT JOIN patients p ON ba.patient_id = p.id
      WHERE b.id = $1
    `;
            const result = yield database_1.default.query(query, [bedId]);
            if (result.rows.length === 0) {
                throw new bed_1.BedNotFoundError(bedId);
            }
            return result.rows[0];
        });
    }
    /**
     * Create new bed
     */
    createBed(tenantId, data, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            const { bed_number, department_id, category_id, bed_type, floor_number, room_number, wing, status, features, notes, } = data;
            // Map category_id to department_id if only category_id is provided
            let finalDepartmentId = department_id;
            if (!finalDepartmentId && category_id) {
                // Map category to department (categories and departments have similar IDs in this system)
                finalDepartmentId = category_id;
            }
            // Convert features to PostgreSQL array format
            let featuresArray = null;
            if (features) {
                if (Array.isArray(features)) {
                    featuresArray = features;
                }
                else if (typeof features === 'object') {
                    // Extract feature names from object (e.g., {equipment: [...], features: [...]})
                    const allFeatures = [];
                    if (features.equipment && Array.isArray(features.equipment)) {
                        allFeatures.push(...features.equipment);
                    }
                    if (features.features && Array.isArray(features.features)) {
                        allFeatures.push(...features.features);
                    }
                    // Also handle boolean flags like {monitor: true, oxygen: true}
                    Object.entries(features).forEach(([key, value]) => {
                        if (value === true && key !== 'equipment' && key !== 'features') {
                            allFeatures.push(key);
                        }
                    });
                    featuresArray = allFeatures.length > 0 ? allFeatures : null;
                }
            }
            const query = `
      INSERT INTO beds (
        bed_number, department_id, category_id, bed_type, floor_number, room_number,
        wing, features, notes, status, is_active, created_by, unit
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true, $11, $12)
      RETURNING *
    `;
            const result = yield database_1.default.query(query, [
                bed_number,
                finalDepartmentId || null,
                category_id || null,
                bed_type || 'standard',
                floor_number || null,
                room_number || null,
                wing || null,
                featuresArray, // PostgreSQL will handle array conversion
                notes || null,
                status || 'available',
                userId || null,
                'General', // Default unit value since it's NOT NULL
            ]);
            // Update department bed count if department_id is set
            if (finalDepartmentId) {
                try {
                    yield database_1.default.query('UPDATE departments SET active_bed_count = active_bed_count + 1 WHERE id = $1', [finalDepartmentId]);
                }
                catch (err) {
                    // Ignore if departments table doesn't exist or department not found
                    console.log('Note: Could not update department bed count:', err.message);
                }
            }
            return result.rows[0];
        });
    }
    /**
     * Update bed
     */
    updateBed(tenantId, bedId, data, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            // Check if bed exists
            yield this.getBedById(tenantId, bedId);
            const updates = [];
            const values = [];
            let paramIndex = 1;
            if (data.bed_number !== undefined) {
                updates.push(`bed_number = $${paramIndex}`);
                values.push(data.bed_number);
                paramIndex++;
            }
            if (data.department_id !== undefined) {
                updates.push(`department_id = $${paramIndex}`);
                values.push(data.department_id);
                paramIndex++;
            }
            if (data.bed_type !== undefined) {
                updates.push(`bed_type = $${paramIndex}`);
                values.push(data.bed_type);
                paramIndex++;
            }
            if (data.floor_number !== undefined) {
                updates.push(`floor_number = $${paramIndex}`);
                values.push(data.floor_number);
                paramIndex++;
            }
            if (data.room_number !== undefined) {
                updates.push(`room_number = $${paramIndex}`);
                values.push(data.room_number);
                paramIndex++;
            }
            if (data.wing !== undefined) {
                updates.push(`wing = $${paramIndex}`);
                values.push(data.wing);
                paramIndex++;
            }
            if (data.status !== undefined) {
                updates.push(`status = $${paramIndex}`);
                values.push(data.status);
                paramIndex++;
            }
            if (data.features !== undefined) {
                // Convert features to PostgreSQL array format (same as createBed)
                let featuresArray = null;
                if (data.features) {
                    if (Array.isArray(data.features)) {
                        featuresArray = data.features;
                    }
                    else if (typeof data.features === 'object') {
                        // Extract feature names from object (e.g., {equipment: [...], features: [...]})
                        const allFeatures = [];
                        if (data.features.equipment && Array.isArray(data.features.equipment)) {
                            allFeatures.push(...data.features.equipment);
                        }
                        if (data.features.features && Array.isArray(data.features.features)) {
                            allFeatures.push(...data.features.features);
                        }
                        // Also handle boolean flags like {monitor: true, oxygen: true}
                        Object.entries(data.features).forEach(([key, value]) => {
                            if (value === true && key !== 'equipment' && key !== 'features') {
                                allFeatures.push(key);
                            }
                        });
                        featuresArray = allFeatures.length > 0 ? allFeatures : null;
                    }
                }
                updates.push(`features = $${paramIndex}`);
                values.push(featuresArray); // PostgreSQL will handle array conversion
                paramIndex++;
            }
            if (data.last_cleaned_at !== undefined) {
                updates.push(`last_cleaned_at = $${paramIndex}`);
                values.push(data.last_cleaned_at);
                paramIndex++;
            }
            if (data.last_maintenance_at !== undefined) {
                updates.push(`last_maintenance_at = $${paramIndex}`);
                values.push(data.last_maintenance_at);
                paramIndex++;
            }
            if (data.notes !== undefined) {
                updates.push(`notes = $${paramIndex}`);
                values.push(data.notes);
                paramIndex++;
            }
            if (data.is_active !== undefined) {
                updates.push(`is_active = $${paramIndex}`);
                values.push(data.is_active);
                paramIndex++;
            }
            if (userId) {
                updates.push(`updated_by = $${paramIndex}`);
                values.push(userId);
                paramIndex++;
            }
            updates.push(`updated_at = CURRENT_TIMESTAMP`);
            const query = `
      UPDATE beds
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING *
    `;
            values.push(bedId);
            const result = yield database_1.default.query(query, values);
            return result.rows[0];
        });
    }
    /**
     * Delete bed (soft delete)
     */
    deleteBed(tenantId, bedId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            // Check if bed exists
            yield this.getBedById(tenantId, bedId);
            // Check if bed has active assignment
            const assignmentCheck = yield database_1.default.query('SELECT id FROM bed_assignments WHERE bed_id = $1 AND status = $2', [bedId, 'active']);
            if (assignmentCheck.rows.length > 0) {
                throw new Error('Cannot delete bed with active assignment');
            }
            // Soft delete
            yield database_1.default.query('UPDATE beds SET is_active = false, updated_by = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', [userId || null, bedId]);
        });
    }
    /**
     * Update bed status
     */
    updateBedStatus(tenantId, bedId, status, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.updateBed(tenantId, bedId, { status }, userId);
        });
    }
    /**
     * Check bed availability
     */
    checkBedAvailability(tenantId, bedId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            const bed = yield this.getBedById(tenantId, bedId);
            if (!bed.is_active) {
                return false;
            }
            if (bed.status !== 'available' && bed.status !== 'reserved') {
                return false;
            }
            // Check for active assignment
            const assignmentCheck = yield database_1.default.query('SELECT id FROM bed_assignments WHERE bed_id = $1 AND status = $2', [bedId, 'active']);
            return assignmentCheck.rows.length === 0;
        });
    }
    /**
     * Get bed occupancy metrics
     */
    getBedOccupancy(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set tenant schema context
            yield database_1.default.query(`SET search_path TO "${tenantId}", public`);
            const query = `
      SELECT 
        COUNT(*) as total_beds,
        COUNT(*) FILTER (WHERE status = 'available') as available_beds,
        COUNT(*) FILTER (WHERE status = 'occupied') as occupied_beds,
        COUNT(*) FILTER (WHERE status = 'maintenance') as maintenance_beds,
        COUNT(*) FILTER (WHERE status = 'cleaning') as cleaning_beds,
        COUNT(*) FILTER (WHERE status = 'reserved') as reserved_beds
      FROM beds
      WHERE is_active = true
    `;
            const result = yield database_1.default.query(query);
            const row = result.rows[0];
            const total = parseInt(row.total_beds);
            const occupied = parseInt(row.occupied_beds);
            return {
                total_beds: total,
                available_beds: parseInt(row.available_beds),
                occupied_beds: occupied,
                maintenance_beds: parseInt(row.maintenance_beds),
                cleaning_beds: parseInt(row.cleaning_beds),
                reserved_beds: parseInt(row.reserved_beds),
                occupancy_rate: total > 0 ? (occupied / total) * 100 : 0,
                availability_rate: total > 0 ? (parseInt(row.available_beds) / total) * 100 : 0,
            };
        });
    }
}
exports.BedService = BedService;
exports.default = new BedService();
