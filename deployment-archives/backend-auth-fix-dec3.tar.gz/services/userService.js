"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUser = exports.updateUser = exports.createUser = exports.getUserByEmail = exports.getUser = exports.getUsers = void 0;
const database_1 = __importDefault(require("../database"));
const bcrypt = __importStar(require("bcrypt"));
const SALT_ROUNDS = 10;
const ALLOWED_SORT_FIELDS = ['name', 'email', 'tenant', 'role', 'status', 'joinDate', 'created_at'];
const ALLOWED_ORDER_DIRECTIONS = ['asc', 'desc'];
const getUsers = (queryParams) => __awaiter(void 0, void 0, void 0, function* () {
    const { page = 1, limit = 10, sortBy = 'created_at', order = 'desc' } = queryParams, filters = __rest(queryParams, ["page", "limit", "sortBy", "order"]);
    const offset = (page - 1) * limit;
    if (!ALLOWED_SORT_FIELDS.includes(sortBy)) {
        throw new Error(`Invalid sort field: ${sortBy}`);
    }
    if (!ALLOWED_ORDER_DIRECTIONS.includes(order)) {
        throw new Error(`Invalid order direction: ${order}`);
    }
    // Map frontend field names to database column names
    const sortFieldMap = {
        'joinDate': 'created_at',
        'created_at': 'created_at',
        'name': 'name',
        'email': 'email',
        'tenant': 'tenant',
        'role': 'role',
        'status': 'status'
    };
    const dbSortField = sortFieldMap[sortBy] || sortBy;
    let query = 'SELECT u.*, r.name as role, t.name as tenant, u.created_at as joinDate FROM users u LEFT JOIN user_roles ur ON u.id = ur.user_id LEFT JOIN roles r ON ur.role_id = r.id LEFT JOIN tenants t ON u.tenant_id = t.id';
    const queryParamsArray = [];
    if (Object.keys(filters).length > 0) {
        query += ' WHERE ';
        const filterClauses = Object.entries(filters).map(([key, value], index) => {
            queryParamsArray.push(value);
            return `u.${key} = $${index + 1}`;
        });
        query += filterClauses.join(' AND ');
    }
    const totalResult = yield database_1.default.query(`SELECT COUNT(*) FROM (${query}) as total`, queryParamsArray);
    const total = parseInt(totalResult.rows[0].count, 10);
    const activeResult = yield database_1.default.query(`SELECT COUNT(*) FROM users WHERE status = 'active'`, []);
    const active = parseInt(activeResult.rows[0].count, 10);
    const adminsResult = yield database_1.default.query(`SELECT COUNT(*) FROM users u JOIN user_roles ur ON u.id = ur.user_id JOIN roles r ON ur.role_id = r.id WHERE r.name = 'Admin'`, []);
    const admins = parseInt(adminsResult.rows[0].count, 10);
    query += ` ORDER BY u.${dbSortField} ${order} LIMIT $${queryParamsArray.length + 1} OFFSET $${queryParamsArray.length + 2}`;
    queryParamsArray.push(limit, offset);
    const { rows } = yield database_1.default.query(query, queryParamsArray);
    return { users: rows, total, active, admins };
});
exports.getUsers = getUsers;
const getUser = (id) => __awaiter(void 0, void 0, void 0, function* () {
    const { rows } = yield database_1.default.query('SELECT * FROM users WHERE id = $1', [id]);
    return rows[0];
});
exports.getUser = getUser;
const getUserByEmail = (email) => __awaiter(void 0, void 0, void 0, function* () {
    const { rows } = yield database_1.default.query('SELECT * FROM users WHERE email = $1', [email]);
    return rows[0];
});
exports.getUserByEmail = getUserByEmail;
const createUser = (userData) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, email, password, status, phone_number, last_login_date, profile_picture_url, role_id, tenant_id } = userData;
    const hashedPassword = yield bcrypt.hash(password, SALT_ROUNDS);
    const { rows } = yield database_1.default.query('INSERT INTO users (name, email, password, status, phone_number, last_login_date, profile_picture_url, tenant_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *', [name, email, hashedPassword, status, phone_number, last_login_date, profile_picture_url, tenant_id]);
    const user = rows[0];
    if (role_id) {
        yield database_1.default.query('INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2)', [user.id, role_id]);
    }
    return user;
});
exports.createUser = createUser;
const updateUser = (id, userData) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, email, password, status, phone_number, last_login_date, profile_picture_url, role_id, tenant_id } = userData;
    let hashedPassword = password;
    if (password) {
        hashedPassword = yield bcrypt.hash(password, SALT_ROUNDS);
    }
    const { rows } = yield database_1.default.query('UPDATE users SET name = $1, email = $2, password = $3, status = $4, phone_number = $5, last_login_date = $6, profile_picture_url = $7, tenant_id = $8 WHERE id = $9 RETURNING *', [name, email, hashedPassword, status, phone_number, last_login_date, profile_picture_url, tenant_id, id]);
    const user = rows[0];
    if (role_id) {
        yield database_1.default.query('DELETE FROM user_roles WHERE user_id = $1', [id]);
        yield database_1.default.query('INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2)', [user.id, role_id]);
    }
    return user;
});
exports.updateUser = updateUser;
const deleteUser = (id) => __awaiter(void 0, void 0, void 0, function* () {
    yield database_1.default.query('DELETE FROM user_roles WHERE user_id = $1', [id]);
    yield database_1.default.query('DELETE FROM users WHERE id = $1', [id]);
});
exports.deleteUser = deleteUser;
