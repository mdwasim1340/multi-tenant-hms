"use strict";
/**
 * Liability Calculator Service
 *
 * Calculates liability values from the liabilities table for Balance Sheet reports.
 * Categorizes liabilities into current and long-term categories.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.liabilityCalculatorService = exports.LiabilityCalculatorService = void 0;
const database_1 = __importDefault(require("../database"));
class LiabilityCalculatorService {
    /**
     * Get total liabilities as of a specific date, broken down by category
     */
    getLiabilitiesAsOfDate(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, asOfDate } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required for liability calculation');
            }
            const client = yield database_1.default.connect();
            try {
                // Ensure tenant schema has proper prefix
                const schemaName = tenantId.startsWith('tenant_') ? tenantId : `tenant_${tenantId}`;
                yield client.query(`SET search_path TO "${schemaName}", public`);
                // Build WHERE clause (no tenant_id filter needed since we're in tenant schema)
                const conditions = [
                    'as_of_date <= $1'
                ];
                const params = [asOfDate];
                const whereClause = conditions.join(' AND ');
                // Query to get latest liability values by type
                const query = `
        WITH latest_liabilities AS (
          SELECT DISTINCT ON (liability_type, liability_name)
            liability_type,
            liability_category,
            liability_name,
            amount
          FROM liabilities
          WHERE ${whereClause}
          ORDER BY liability_type, liability_name, as_of_date DESC
        )
        SELECT 
          liability_type,
          liability_category,
          SUM(amount) as total_amount
        FROM latest_liabilities
        GROUP BY liability_type, liability_category
      `;
                const result = yield client.query(query, params);
                // Initialize breakdown with zeros
                const currentLiabilities = {
                    accountsPayable: 0,
                    accruedExpenses: 0,
                    total: 0
                };
                const longTermLiabilities = {
                    loans: 0,
                    mortgages: 0,
                    total: 0
                };
                // Map liability types to breakdown categories
                result.rows.forEach(row => {
                    const amount = parseFloat(row.total_amount) || 0;
                    const liabilityType = row.liability_type;
                    const category = row.liability_category;
                    if (category === 'current') {
                        switch (liabilityType) {
                            case 'payable':
                                currentLiabilities.accountsPayable += amount;
                                break;
                            case 'accrued':
                            case 'tax':
                                currentLiabilities.accruedExpenses += amount;
                                break;
                        }
                    }
                    else if (category === 'long-term') {
                        switch (liabilityType) {
                            case 'loan':
                            case 'lease':
                                longTermLiabilities.loans += amount;
                                break;
                            case 'mortgage':
                                longTermLiabilities.mortgages += amount;
                                break;
                        }
                    }
                });
                // Note: For a hospital billing system, liabilities are typically managed separately
                // The liabilities table may be empty if no manual entries have been made
                // This is expected behavior - liabilities like loans, mortgages are entered manually
                // Calculate totals
                currentLiabilities.total = currentLiabilities.accountsPayable + currentLiabilities.accruedExpenses;
                longTermLiabilities.total = longTermLiabilities.loans + longTermLiabilities.mortgages;
                const breakdown = {
                    current: currentLiabilities,
                    longTerm: longTermLiabilities,
                    total: currentLiabilities.total + longTermLiabilities.total
                };
                return breakdown;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get liabilities by specific category (current or long-term)
     */
    getLiabilitiesByCategory(tenantId, category, asOfDate) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                const query = `
        WITH latest_liabilities AS (
          SELECT DISTINCT ON (liability_type, liability_name)
            amount
          FROM liabilities
          WHERE tenant_id = $1
            AND liability_category = $2
            AND as_of_date <= $3
          ORDER BY liability_type, liability_name, as_of_date DESC
        )
        SELECT COALESCE(SUM(amount), 0) as total
        FROM latest_liabilities
      `;
                const result = yield client.query(query, [tenantId, category, asOfDate]);
                return parseFloat(result.rows[0].total) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get liabilities by specific type
     */
    getLiabilitiesByType(tenantId, liabilityType, asOfDate) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                const query = `
        WITH latest_liabilities AS (
          SELECT DISTINCT ON (liability_name)
            amount
          FROM liabilities
          WHERE tenant_id = $1
            AND liability_type = $2
            AND as_of_date <= $3
          ORDER BY liability_name, as_of_date DESC
        )
        SELECT COALESCE(SUM(amount), 0) as total
        FROM latest_liabilities
      `;
                const result = yield client.query(query, [tenantId, liabilityType, asOfDate]);
                return parseFloat(result.rows[0].total) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get liabilities due within a specific period
     */
    getLiabilitiesDueWithin(tenantId, asOfDate, daysAhead) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                const query = `
        WITH latest_liabilities AS (
          SELECT DISTINCT ON (liability_type, liability_name)
            liability_name,
            liability_type,
            amount,
            due_date
          FROM liabilities
          WHERE tenant_id = $1
            AND as_of_date <= $2
            AND due_date IS NOT NULL
            AND due_date <= ($2::date + $3::integer)
          ORDER BY liability_type, liability_name, as_of_date DESC
        )
        SELECT 
          liability_name,
          liability_type,
          amount,
          due_date
        FROM latest_liabilities
        ORDER BY due_date ASC
      `;
                const result = yield client.query(query, [tenantId, asOfDate, daysAhead]);
                const items = result.rows.map(row => ({
                    name: row.liability_name,
                    type: row.liability_type,
                    amount: parseFloat(row.amount) || 0,
                    dueDate: row.due_date
                }));
                const total = items.reduce((sum, item) => sum + item.amount, 0);
                return { total, items };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get liability count
     */
    getLiabilityCount(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, asOfDate } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required');
            }
            const client = yield database_1.default.connect();
            try {
                const query = `
        SELECT COUNT(DISTINCT liability_name) as count
        FROM liabilities
        WHERE tenant_id = $1
          AND as_of_date <= $2
      `;
                const result = yield client.query(query, [tenantId, asOfDate]);
                return parseInt(result.rows[0].count) || 0;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Get detailed liability list
     */
    getDetailedLiabilities(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, asOfDate } = options;
            if (!asOfDate) {
                throw new Error('As-of date is required');
            }
            const client = yield database_1.default.connect();
            try {
                const query = `
        SELECT DISTINCT ON (liability_type, liability_name)
          liability_name,
          liability_type,
          liability_category,
          amount,
          due_date,
          interest_rate
        FROM liabilities
        WHERE tenant_id = $1
          AND as_of_date <= $2
        ORDER BY liability_type, liability_name, as_of_date DESC
      `;
                const result = yield client.query(query, [tenantId, asOfDate]);
                const liabilities = result.rows.map(row => ({
                    name: row.liability_name,
                    type: row.liability_type,
                    category: row.liability_category,
                    amount: parseFloat(row.amount) || 0,
                    dueDate: row.due_date,
                    interestRate: row.interest_rate ? parseFloat(row.interest_rate) : undefined
                }));
                // Calculate summary
                const summary = yield this.getLiabilitiesAsOfDate(options);
                return { liabilities, summary };
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Calculate interest expense for a period
     */
    calculateInterestExpense(tenantId, dateRange) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                // Get all liabilities with interest rates
                const query = `
        SELECT DISTINCT ON (liability_name)
          amount,
          interest_rate
        FROM liabilities
        WHERE tenant_id = $1
          AND as_of_date <= $2
          AND interest_rate IS NOT NULL
          AND interest_rate > 0
        ORDER BY liability_name, as_of_date DESC
      `;
                const result = yield client.query(query, [tenantId, dateRange.endDate]);
                // Calculate days in period
                const startDate = new Date(dateRange.startDate);
                const endDate = new Date(dateRange.endDate);
                const daysInPeriod = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
                // Calculate interest expense
                let totalInterest = 0;
                result.rows.forEach(row => {
                    const principal = parseFloat(row.amount) || 0;
                    const annualRate = parseFloat(row.interest_rate) || 0;
                    const dailyRate = annualRate / 100 / 365;
                    const interest = principal * dailyRate * daysInPeriod;
                    totalInterest += interest;
                });
                return Math.round(totalInterest * 100) / 100; // Round to 2 decimal places
            }
            finally {
                client.release();
            }
        });
    }
}
exports.LiabilityCalculatorService = LiabilityCalculatorService;
exports.liabilityCalculatorService = new LiabilityCalculatorService();
