"use strict";
/**
 * Bed Transfer Service
 * Business logic for patient bed transfers
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedTransferService = void 0;
const database_1 = __importDefault(require("../database"));
const bed_1 = require("../types/bed");
class BedTransferService {
    /**
     * Get bed transfers with filtering and pagination
     */
    getBedTransfers(tenantId, params) {
        return __awaiter(this, void 0, void 0, function* () {
            const { page = 1, limit = 10, patient_id, from_bed_id, to_bed_id, from_department_id, to_department_id, status, transfer_type, transfer_date_from, transfer_date_to, sort_by = 'transfer_date', sort_order = 'desc', } = params;
            const offset = (page - 1) * limit;
            const queryParams = [];
            let paramIndex = 1;
            // Build WHERE clause
            let whereClause = 'WHERE 1=1';
            if (patient_id) {
                whereClause += ` AND bt.patient_id = $${paramIndex}`;
                queryParams.push(patient_id);
                paramIndex++;
            }
            if (from_bed_id) {
                whereClause += ` AND bt.from_bed_id = $${paramIndex}`;
                queryParams.push(from_bed_id);
                paramIndex++;
            }
            if (to_bed_id) {
                whereClause += ` AND bt.to_bed_id = $${paramIndex}`;
                queryParams.push(to_bed_id);
                paramIndex++;
            }
            if (from_department_id) {
                whereClause += ` AND bt.from_department_id = $${paramIndex}`;
                queryParams.push(from_department_id);
                paramIndex++;
            }
            if (to_department_id) {
                whereClause += ` AND bt.to_department_id = $${paramIndex}`;
                queryParams.push(to_department_id);
                paramIndex++;
            }
            if (status) {
                whereClause += ` AND bt.status = $${paramIndex}`;
                queryParams.push(status);
                paramIndex++;
            }
            if (transfer_type) {
                whereClause += ` AND bt.transfer_type = $${paramIndex}`;
                queryParams.push(transfer_type);
                paramIndex++;
            }
            if (transfer_date_from) {
                whereClause += ` AND bt.transfer_date >= $${paramIndex}`;
                queryParams.push(transfer_date_from);
                paramIndex++;
            }
            if (transfer_date_to) {
                whereClause += ` AND bt.transfer_date <= $${paramIndex}`;
                queryParams.push(transfer_date_to);
                paramIndex++;
            }
            // Get total count
            const countQuery = `SELECT COUNT(*) as total FROM bed_transfers bt ${whereClause}`;
            const countResult = yield database_1.default.query(countQuery, queryParams);
            const total = parseInt(countResult.rows[0].total);
            // Get transfers with joined data
            const transfersQuery = `
      SELECT 
        bt.*,
        p.first_name,
        p.last_name,
        p.patient_number,
        fb.bed_number as from_bed_number,
        fb.room_number as from_room_number,
        tb.bed_number as to_bed_number,
        tb.room_number as to_room_number,
        fd.name as from_department_name,
        td.name as to_department_name
      FROM bed_transfers bt
      LEFT JOIN patients p ON bt.patient_id = p.id
      LEFT JOIN beds fb ON bt.from_bed_id = fb.id
      LEFT JOIN beds tb ON bt.to_bed_id = tb.id
      LEFT JOIN departments fd ON bt.from_department_id = fd.id
      LEFT JOIN departments td ON bt.to_department_id = td.id
      ${whereClause}
      ORDER BY bt.${sort_by} ${sort_order}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
            queryParams.push(limit, offset);
            const result = yield database_1.default.query(transfersQuery, queryParams);
            return {
                transfers: result.rows,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            };
        });
    }
    /**
     * Get bed transfer by ID
     */
    getBedTransferById(tenantId, transferId) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = `
      SELECT 
        bt.*,
        p.first_name,
        p.last_name,
        p.patient_number,
        fb.bed_number as from_bed_number,
        tb.bed_number as to_bed_number,
        fd.name as from_department_name,
        td.name as to_department_name
      FROM bed_transfers bt
      LEFT JOIN patients p ON bt.patient_id = p.id
      LEFT JOIN beds fb ON bt.from_bed_id = fb.id
      LEFT JOIN beds tb ON bt.to_bed_id = tb.id
      LEFT JOIN departments fd ON bt.from_department_id = fd.id
      LEFT JOIN departments td ON bt.to_department_id = td.id
      WHERE bt.id = $1
    `;
            const result = yield database_1.default.query(query, [transferId]);
            if (result.rows.length === 0) {
                throw new Error(`Bed transfer with ID ${transferId} not found`);
            }
            return result.rows[0];
        });
    }
    /**
     * Create bed transfer
     */
    createBedTransfer(tenantId, data, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                // Validate source and destination beds are different
                if (data.from_bed_id === data.to_bed_id) {
                    throw new bed_1.InvalidTransferError('Source and destination beds must be different');
                }
                // Get bed details
                const fromBedQuery = yield client.query('SELECT department_id, status FROM beds WHERE id = $1', [data.from_bed_id]);
                const toBedQuery = yield client.query('SELECT department_id, status FROM beds WHERE id = $1', [data.to_bed_id]);
                if (fromBedQuery.rows.length === 0) {
                    throw new bed_1.InvalidTransferError('Source bed not found');
                }
                if (toBedQuery.rows.length === 0) {
                    throw new bed_1.InvalidTransferError('Destination bed not found');
                }
                const fromDepartmentId = fromBedQuery.rows[0].department_id;
                const toDepartmentId = toBedQuery.rows[0].department_id;
                const toBedStatus = toBedQuery.rows[0].status;
                // Check destination bed availability
                if (toBedStatus !== 'available') {
                    throw new bed_1.InvalidTransferError('Destination bed is not available');
                }
                // Verify patient is assigned to source bed
                const assignmentCheck = yield client.query('SELECT id FROM bed_assignments WHERE patient_id = $1 AND bed_id = $2 AND status = $3', [data.patient_id, data.from_bed_id, 'active']);
                if (assignmentCheck.rows.length === 0) {
                    throw new bed_1.InvalidTransferError('Patient is not assigned to the source bed');
                }
                // Create transfer record
                const insertQuery = `
        INSERT INTO bed_transfers (
          patient_id, from_bed_id, to_bed_id, from_department_id, to_department_id,
          transfer_reason, transfer_type, notes, status, requested_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending', $9)
        RETURNING *
      `;
                const result = yield client.query(insertQuery, [
                    data.patient_id,
                    data.from_bed_id,
                    data.to_bed_id,
                    fromDepartmentId,
                    toDepartmentId,
                    data.transfer_reason,
                    data.transfer_type || 'routine',
                    data.notes || null,
                    userId || null,
                ]);
                yield client.query('COMMIT');
                return result.rows[0];
            }
            catch (error) {
                yield client.query('ROLLBACK');
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Update bed transfer
     */
    updateBedTransfer(tenantId, transferId, data, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Check if transfer exists
            const transfer = yield this.getBedTransferById(tenantId, transferId);
            if (transfer.status !== 'pending') {
                throw new bed_1.InvalidTransferError('Can only update pending transfers');
            }
            const updates = [];
            const values = [];
            let paramIndex = 1;
            if (data.transfer_reason !== undefined) {
                updates.push(`transfer_reason = $${paramIndex}`);
                values.push(data.transfer_reason);
                paramIndex++;
            }
            if (data.transfer_type !== undefined) {
                updates.push(`transfer_type = $${paramIndex}`);
                values.push(data.transfer_type);
                paramIndex++;
            }
            if (data.notes !== undefined) {
                updates.push(`notes = $${paramIndex}`);
                values.push(data.notes);
                paramIndex++;
            }
            updates.push(`updated_at = CURRENT_TIMESTAMP`);
            const query = `
      UPDATE bed_transfers
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING *
    `;
            values.push(transferId);
            const result = yield database_1.default.query(query, values);
            return result.rows[0];
        });
    }
    /**
     * Complete bed transfer
     */
    completeBedTransfer(tenantId, transferId, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const client = yield database_1.default.connect();
            try {
                yield client.query('BEGIN');
                // Get transfer details
                const transfer = yield this.getBedTransferById(tenantId, transferId);
                if (transfer.status === 'completed') {
                    throw new bed_1.InvalidTransferError('Transfer already completed');
                }
                if (transfer.status === 'cancelled') {
                    throw new bed_1.InvalidTransferError('Cannot complete cancelled transfer');
                }
                // Update transfer status
                const updateQuery = `
        UPDATE bed_transfers
        SET status = 'completed', completed_by = $1, completion_date = CURRENT_TIMESTAMP
        WHERE id = $2
        RETURNING *
      `;
                const result = yield client.query(updateQuery, [userId || null, transferId]);
                yield client.query('COMMIT');
                return result.rows[0];
            }
            catch (error) {
                yield client.query('ROLLBACK');
                throw error;
            }
            finally {
                client.release();
            }
        });
    }
    /**
     * Cancel bed transfer
     */
    cancelBedTransfer(tenantId, transferId, cancellationReason, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const transfer = yield this.getBedTransferById(tenantId, transferId);
            if (transfer.status === 'completed') {
                throw new bed_1.InvalidTransferError('Cannot cancel completed transfer');
            }
            if (transfer.status === 'cancelled') {
                throw new bed_1.InvalidTransferError('Transfer already cancelled');
            }
            const query = `
      UPDATE bed_transfers
      SET status = 'cancelled', cancellation_reason = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
            const result = yield database_1.default.query(query, [cancellationReason, transferId]);
            return result.rows[0];
        });
    }
    /**
     * Get transfer history for patient
     */
    getPatientTransferHistory(tenantId, patientId) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = `
      SELECT 
        bt.*,
        fb.bed_number as from_bed_number,
        tb.bed_number as to_bed_number,
        fd.name as from_department_name,
        td.name as to_department_name
      FROM bed_transfers bt
      LEFT JOIN beds fb ON bt.from_bed_id = fb.id
      LEFT JOIN beds tb ON bt.to_bed_id = tb.id
      LEFT JOIN departments fd ON bt.from_department_id = fd.id
      LEFT JOIN departments td ON bt.to_department_id = td.id
      WHERE bt.patient_id = $1
      ORDER BY bt.transfer_date DESC
    `;
            const result = yield database_1.default.query(query, [patientId]);
            return result.rows;
        });
    }
}
exports.BedTransferService = BedTransferService;
exports.default = new BedTransferService();
