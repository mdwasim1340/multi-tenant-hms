"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.backupService = exports.BackupService = void 0;
const database_1 = __importDefault(require("../database"));
const client_s3_1 = require("@aws-sdk/client-s3");
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const zlib = __importStar(require("zlib"));
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class BackupService {
    constructor() {
        this.s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION });
    }
    // Create backup for tenant
    createBackup(config) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, backupType, storageTier } = config;
            // Create backup job record
            const jobResult = yield database_1.default.query(`
      INSERT INTO backup_jobs (tenant_id, backup_type, storage_tier, status, started_at)
      VALUES ($1, $2, $3, 'pending', CURRENT_TIMESTAMP)
      RETURNING *
    `, [tenantId, backupType, storageTier]);
            const job = jobResult.rows[0];
            // Start backup process asynchronously
            this.performBackup(job.id, config).catch(err => {
                console.error('Backup failed:', err);
                this.updateJobStatus(job.id, 'failed', err.message);
            });
            return job;
        });
    }
    // Perform actual backup
    performBackup(jobId, config) {
        return __awaiter(this, void 0, void 0, function* () {
            const { tenantId, backupType, storageTier } = config;
            try {
                // Update status to running
                yield this.updateJobStatus(jobId, 'running');
                // Create temporary directory for backup (cross-platform)
                const tmpDir = process.platform === 'win32' ? process.env.TEMP || 'C:\\temp' : '/tmp';
                const backupDir = path.join(tmpDir, `backup-${jobId}`);
                if (!fs.existsSync(backupDir)) {
                    fs.mkdirSync(backupDir, { recursive: true });
                }
                // Create backup file
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const backupFileName = `${tenantId}-${timestamp}.sql`;
                const backupFile = path.join(backupDir, backupFileName);
                // Dump tenant schema
                yield this.dumpTenantSchema(tenantId, backupFile);
                // Compress backup using Node.js built-in zlib
                const compressedFile = `${backupFile}.gz`;
                yield this.compressFile(backupFile, compressedFile);
                // Get file size
                const stats = fs.statSync(compressedFile);
                const fileSize = stats.size;
                // Upload to S3 (simplified - only S3 for now)
                const backupLocation = yield this.uploadToS3(compressedFile, tenantId, jobId, storageTier);
                // Update job with completion
                yield database_1.default.query(`
        UPDATE backup_jobs 
        SET status = 'completed',
            backup_size_bytes = $1,
            backup_location = $2,
            completed_at = CURRENT_TIMESTAMP
        WHERE id = $3
      `, [fileSize, backupLocation, jobId]);
                // Cleanup temporary files
                if (fs.existsSync(compressedFile)) {
                    fs.unlinkSync(compressedFile);
                }
                if (fs.existsSync(backupDir)) {
                    fs.rmSync(backupDir, { recursive: true, force: true });
                }
                console.log(`✅ Backup completed for tenant ${tenantId}, job ${jobId}`);
            }
            catch (error) {
                console.error(`❌ Backup failed for tenant ${tenantId}, job ${jobId}:`, error);
                yield this.updateJobStatus(jobId, 'failed', error.message);
                throw error;
            }
        });
    }
    // Compress file using Node.js zlib
    compressFile(inputFile, outputFile) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                const readStream = fs.createReadStream(inputFile);
                const writeStream = fs.createWriteStream(outputFile);
                const gzipStream = zlib.createGzip();
                readStream
                    .pipe(gzipStream)
                    .pipe(writeStream)
                    .on('finish', () => {
                    // Remove original file after compression
                    fs.unlinkSync(inputFile);
                    resolve();
                })
                    .on('error', reject);
            });
        });
    }
    // Dump tenant schema to file
    dumpTenantSchema(tenantId, outputFile) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Check if tenant schema exists
                const schemaCheck = yield database_1.default.query('SELECT schema_name FROM information_schema.schemata WHERE schema_name = $1', [tenantId]);
                if (schemaCheck.rows.length === 0) {
                    throw new Error(`Tenant schema '${tenantId}' does not exist`);
                }
                // Use pg_dump to export the tenant schema
                const command = `docker exec backend-postgres-1 pg_dump -U postgres -d multitenant_db -n "${tenantId}" --no-owner --no-privileges`;
                const { stdout, stderr } = yield execAsync(command);
                if (stderr && !stderr.includes('WARNING')) {
                    throw new Error(`pg_dump error: ${stderr}`);
                }
                // Write the dump to file
                fs.writeFileSync(outputFile, stdout);
                console.log(`📦 Schema dumped for tenant ${tenantId} to ${outputFile}`);
            }
            catch (error) {
                throw new Error(`Failed to dump tenant schema: ${error.message}`);
            }
        });
    }
    // Upload to S3
    uploadToS3(filePath, tenantId, jobId, storageTier) {
        return __awaiter(this, void 0, void 0, function* () {
            const fileName = path.basename(filePath);
            const s3Key = `backups/${tenantId}/${jobId}/${fileName}`;
            const fileContent = fs.readFileSync(filePath);
            const storageClass = storageTier === 's3_ia' ? 'STANDARD_IA' : 'STANDARD';
            yield this.s3Client.send(new client_s3_1.PutObjectCommand({
                Bucket: process.env.S3_BUCKET_NAME,
                Key: s3Key,
                Body: fileContent,
                StorageClass: storageClass,
                Metadata: {
                    'tenant-id': tenantId,
                    'backup-job-id': jobId.toString(),
                    'backup-type': 'database-schema'
                }
            }));
            console.log(`☁️ Backup uploaded to S3: s3://${process.env.S3_BUCKET_NAME}/${s3Key}`);
            return `s3://${process.env.S3_BUCKET_NAME}/${s3Key}`;
        });
    }
    // Get backup history for tenant
    getBackupHistory(tenantId_1) {
        return __awaiter(this, arguments, void 0, function* (tenantId, limit = 50) {
            const result = yield database_1.default.query(`
      SELECT * FROM backup_jobs 
      WHERE tenant_id = $1 
      ORDER BY created_at DESC 
      LIMIT $2
    `, [tenantId, limit]);
            return result.rows;
        });
    }
    // Get backup statistics for tenant
    getBackupStats(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield database_1.default.query(`
      SELECT 
        COUNT(*) as total_backups,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_backups,
        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_backups,
        COALESCE(SUM(backup_size_bytes), 0) as total_size_bytes,
        MAX(CASE WHEN status = 'completed' THEN completed_at END) as last_backup_date
      FROM backup_jobs 
      WHERE tenant_id = $1
    `, [tenantId]);
            const row = result.rows[0];
            return {
                totalBackups: parseInt(row.total_backups),
                completedBackups: parseInt(row.completed_backups),
                failedBackups: parseInt(row.failed_backups),
                totalSizeBytes: parseInt(row.total_size_bytes),
                lastBackupDate: row.last_backup_date
            };
        });
    }
    // Setup backup schedules for tenant based on subscription tier
    setupBackupSchedules(tenantId, tierId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get retention policy for tier
            const policyResult = yield database_1.default.query('SELECT * FROM backup_retention_policies WHERE tier_id = $1', [tierId]);
            if (!policyResult.rows.length) {
                console.log(`No backup policy found for tier ${tierId}`);
                return;
            }
            const policy = policyResult.rows[0];
            // Create schedules based on policy
            if (policy.daily_retention_days > 0) {
                yield this.createSchedule(tenantId, 'daily', 's3_standard');
            }
            if (policy.weekly_retention_weeks > 0) {
                yield this.createSchedule(tenantId, 'weekly', 's3_ia');
            }
            if (policy.monthly_retention_months > 0) {
                yield this.createSchedule(tenantId, 'monthly', 's3_ia'); // Using S3 IA instead of B2 for now
            }
            console.log(`✅ Backup schedules set up for tenant ${tenantId} with tier ${tierId}`);
        });
    }
    // Create backup schedule
    createSchedule(tenantId, scheduleType, storageTier) {
        return __awaiter(this, void 0, void 0, function* () {
            const nextRun = this.calculateNextRun(scheduleType);
            yield database_1.default.query(`
      INSERT INTO backup_schedules (tenant_id, schedule_type, storage_tier, next_run_at)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (tenant_id, schedule_type) DO UPDATE
      SET storage_tier = $3, next_run_at = $4, is_active = true, updated_at = CURRENT_TIMESTAMP
    `, [tenantId, scheduleType, storageTier, nextRun]);
        });
    }
    // Calculate next run time
    calculateNextRun(scheduleType) {
        const now = new Date();
        switch (scheduleType) {
            case 'daily':
                now.setDate(now.getDate() + 1);
                now.setHours(2, 0, 0, 0); // 2 AM
                break;
            case 'weekly':
                now.setDate(now.getDate() + 7);
                now.setHours(3, 0, 0, 0); // 3 AM Sunday
                break;
            case 'monthly':
                now.setMonth(now.getMonth() + 1);
                now.setDate(1);
                now.setHours(4, 0, 0, 0); // 4 AM 1st of month
                break;
        }
        return now;
    }
    // Get backup schedules for tenant
    getBackupSchedules(tenantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield database_1.default.query('SELECT * FROM backup_schedules WHERE tenant_id = $1 ORDER BY schedule_type', [tenantId]);
            return result.rows;
        });
    }
    // Process scheduled backups (called by cron job)
    processScheduledBackups() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield database_1.default.query(`
      SELECT * FROM backup_schedules 
      WHERE is_active = true 
      AND next_run_at <= CURRENT_TIMESTAMP
    `);
            console.log(`📅 Processing ${result.rows.length} scheduled backups`);
            for (const schedule of result.rows) {
                try {
                    console.log(`🔄 Creating scheduled backup for tenant ${schedule.tenant_id} (${schedule.schedule_type})`);
                    yield this.createBackup({
                        tenantId: schedule.tenant_id,
                        backupType: 'full',
                        storageTier: schedule.storage_tier
                    });
                    // Update next run time
                    const nextRun = this.calculateNextRun(schedule.schedule_type);
                    yield database_1.default.query('UPDATE backup_schedules SET last_run_at = CURRENT_TIMESTAMP, next_run_at = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', [nextRun, schedule.id]);
                    console.log(`✅ Scheduled backup created for tenant ${schedule.tenant_id}`);
                }
                catch (error) {
                    console.error(`❌ Failed to create scheduled backup for tenant ${schedule.tenant_id}:`, error);
                }
            }
        });
    }
    // Update job status
    updateJobStatus(jobId, status, errorMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            yield database_1.default.query(`
      UPDATE backup_jobs 
      SET status = $1, error_message = $2
      WHERE id = $3
    `, [status, errorMessage || null, jobId]);
        });
    }
    // Get all tenants backup summary (admin only)
    getAllTenantsBackupSummary() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield database_1.default.query(`
      SELECT 
        t.id as tenant_id,
        t.name as tenant_name,
        COUNT(bj.id) as total_backups,
        COUNT(CASE WHEN bj.status = 'completed' THEN 1 END) as completed_backups,
        COUNT(CASE WHEN bj.status = 'failed' THEN 1 END) as failed_backups,
        COALESCE(SUM(bj.backup_size_bytes), 0) as total_size_bytes,
        MAX(CASE WHEN bj.status = 'completed' THEN bj.completed_at END) as last_backup_date
      FROM tenants t
      LEFT JOIN backup_jobs bj ON t.id = bj.tenant_id
      GROUP BY t.id, t.name
      ORDER BY t.name
    `);
            return result.rows;
        });
    }
}
exports.BackupService = BackupService;
exports.backupService = new BackupService();
