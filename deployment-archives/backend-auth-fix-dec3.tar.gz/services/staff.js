"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStaffPayroll = exports.createPayrollRecord = exports.getStaffPerformanceReviews = exports.createPerformanceReview = exports.getStaffAttendance = exports.recordStaffAttendance = exports.getStaffCredentials = exports.createStaffCredential = exports.updateStaffSchedule = exports.getStaffSchedules = exports.createStaffSchedule = exports.deleteStaffProfile = exports.updateStaffProfile = exports.getStaffProfileById = exports.getAllUsers = exports.getStaffProfiles = exports.createStaffProfile = exports.createStaffWithUser = void 0;
const database_1 = __importDefault(require("../database"));
const userService = __importStar(require("./userService"));
// Staff Profile Operations
/**
 * Create staff member with user account
 * This creates both a Cognito user and a staff profile
 */
const createStaffWithUser = (data, tenantId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Generate temporary password
        const temporaryPassword = generateTemporaryPassword();
        // Get role_id from role name
        const roleResult = yield database_1.default.query('SELECT id FROM roles WHERE name = $1', [data.role]);
        if (roleResult.rows.length === 0) {
            throw new Error(`Role '${data.role}' not found`);
        }
        const role_id = roleResult.rows[0].id;
        // Create user in database
        const user = yield userService.createUser({
            name: data.name,
            email: data.email,
            password: temporaryPassword,
            status: 'active',
            tenant_id: tenantId,
            role_id: role_id
        });
        // Create staff profile
        const staffProfile = yield (0, exports.createStaffProfile)({
            user_id: user.id,
            employee_id: data.employee_id,
            department: data.department,
            specialization: data.specialization,
            license_number: data.license_number,
            hire_date: data.hire_date,
            employment_type: data.employment_type,
            status: data.status || 'active',
            emergency_contact: data.emergency_contact
        });
        return {
            staff: staffProfile,
            credentials: {
                email: data.email,
                temporaryPassword: temporaryPassword,
                userId: user.id
            }
        };
    }
    catch (error) {
        console.error('Error in createStaffWithUser:', error);
        // Handle specific database errors
        if (error.code === '23505') { // PostgreSQL unique constraint violation
            if (error.constraint === 'users_email_key') {
                throw new Error(`Email address '${data.email}' is already registered in the system`);
            }
            if (error.constraint === 'staff_profiles_employee_id_key') {
                throw new Error(`Employee ID '${data.employee_id}' already exists`);
            }
            throw new Error('A record with this information already exists');
        }
        // Handle role not found
        if (error.message.includes('not found')) {
            throw error; // Re-throw as-is for clear message
        }
        // Generic error
        throw new Error(error.message || 'Failed to create staff member');
    }
});
exports.createStaffWithUser = createStaffWithUser;
/**
 * Generate a secure temporary password
 */
function generateTemporaryPassword() {
    const length = 12;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    let password = '';
    // Ensure password has at least one of each required character type
    password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)]; // Uppercase
    password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]; // Lowercase
    password += '0123456789'[Math.floor(Math.random() * 10)]; // Number
    password += '!@#$%^&*'[Math.floor(Math.random() * 8)]; // Special char
    // Fill the rest randomly
    for (let i = password.length; i < length; i++) {
        password += charset[Math.floor(Math.random() * charset.length)];
    }
    // Shuffle the password
    return password.split('').sort(() => Math.random() - 0.5).join('');
}
const createStaffProfile = (profile) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const result = yield database_1.default.query(`INSERT INTO staff_profiles 
      (user_id, employee_id, department, specialization, license_number, hire_date, 
       employment_type, status, emergency_contact)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`, [
            profile.user_id,
            profile.employee_id,
            profile.department,
            profile.specialization,
            profile.license_number,
            profile.hire_date,
            profile.employment_type,
            profile.status || 'active',
            profile.emergency_contact ? JSON.stringify(profile.emergency_contact) : null
        ]);
        return result.rows[0];
    }
    catch (error) {
        // Handle duplicate employee_id
        if (error.code === '23505' && error.constraint === 'staff_profiles_employee_id_key') {
            throw new Error(`Employee ID '${profile.employee_id}' already exists`);
        }
        throw error;
    }
});
exports.createStaffProfile = createStaffProfile;
const getStaffProfiles = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}, client = database_1.default) {
    let query = `
    SELECT 
      sp.*, 
      u.name as user_name, 
      u.email as user_email,
      (
        SELECT r.name 
        FROM public.user_roles ur 
        JOIN public.roles r ON ur.role_id = r.id 
        WHERE ur.user_id = sp.user_id 
        LIMIT 1
      ) as role
    FROM staff_profiles sp
    JOIN public.users u ON sp.user_id = u.id
    WHERE 1=1
  `;
    const params = [];
    if (filters.department) {
        params.push(filters.department);
        query += ` AND sp.department = $${params.length}`;
    }
    if (filters.status) {
        params.push(filters.status);
        query += ` AND sp.status = $${params.length}`;
    }
    if (filters.search) {
        params.push(`%${filters.search}%`);
        query += ` AND (u.name ILIKE $${params.length} OR sp.employee_id ILIKE $${params.length})`;
    }
    query += ' ORDER BY sp.created_at DESC';
    if (filters.limit) {
        params.push(filters.limit);
        query += ` LIMIT $${params.length}`;
    }
    if (filters.offset) {
        params.push(filters.offset);
        query += ` OFFSET $${params.length}`;
    }
    const result = yield client.query(query, params);
    return result.rows;
});
exports.getStaffProfiles = getStaffProfiles;
// Get all users including those without staff profiles (unverified)
const getAllUsers = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}, client = database_1.default) {
    let query = `
    SELECT 
      u.id as user_id,
      u.name as user_name,
      u.email as user_email,
      u.phone_number as user_phone,
      u.status as user_status,
      u.created_at as user_created_at,
      sp.id as staff_id,
      sp.employee_id,
      sp.department,
      sp.specialization,
      sp.hire_date,
      sp.employment_type,
      sp.status as staff_status,
      (
        SELECT r.name 
        FROM public.user_roles ur 
        JOIN public.roles r ON ur.role_id = r.id 
        WHERE ur.user_id = u.id 
        LIMIT 1
      ) as role,
      CASE 
        WHEN sp.id IS NULL THEN 'pending_verification'
        ELSE 'verified'
      END as verification_status
    FROM public.users u
    LEFT JOIN staff_profiles sp ON u.id = sp.user_id
    WHERE u.tenant_id = $1
  `;
    const params = [filters.tenant_id];
    if (filters.department) {
        params.push(filters.department);
        query += ` AND sp.department = $${params.length}`;
    }
    if (filters.status) {
        params.push(filters.status);
        query += ` AND (sp.status = $${params.length} OR u.status = $${params.length})`;
    }
    if (filters.search) {
        params.push(`%${filters.search}%`);
        query += ` AND (u.name ILIKE $${params.length} OR u.email ILIKE $${params.length} OR sp.employee_id ILIKE $${params.length})`;
    }
    // Filter by verification status
    if (filters.verification_status === 'verified') {
        query += ` AND sp.id IS NOT NULL`;
    }
    else if (filters.verification_status === 'pending') {
        query += ` AND sp.id IS NULL`;
    }
    // If no filter, show all
    query += ' ORDER BY u.created_at DESC';
    if (filters.limit) {
        params.push(filters.limit);
        query += ` LIMIT $${params.length}`;
    }
    if (filters.offset) {
        params.push(filters.offset);
        query += ` OFFSET $${params.length}`;
    }
    const result = yield client.query(query, params);
    return result.rows;
});
exports.getAllUsers = getAllUsers;
const getStaffProfileById = (id_1, ...args_1) => __awaiter(void 0, [id_1, ...args_1], void 0, function* (id, client = database_1.default) {
    const result = yield client.query(`SELECT 
      sp.*, 
      u.name as user_name, 
      u.email as user_email, 
      u.phone_number as user_phone,
      (
        SELECT r.name 
        FROM public.user_roles ur 
        JOIN public.roles r ON ur.role_id = r.id 
        WHERE ur.user_id = sp.user_id 
        LIMIT 1
      ) as role
    FROM staff_profiles sp
    JOIN public.users u ON sp.user_id = u.id
    WHERE sp.id = $1`, [id]);
    return result.rows[0];
});
exports.getStaffProfileById = getStaffProfileById;
const updateStaffProfile = (id_1, updates_1, ...args_1) => __awaiter(void 0, [id_1, updates_1, ...args_1], void 0, function* (id, updates, client = database_1.default) {
    const fields = [];
    const values = [];
    let paramCount = 1;
    // Only update fields that exist in staff_profiles table
    const allowedFields = ['employee_id', 'department', 'specialization', 'license_number',
        'hire_date', 'employment_type', 'status', 'emergency_contact', 'notes'];
    Object.entries(updates).forEach(([key, value]) => {
        if (key !== 'id' && value !== undefined && allowedFields.includes(key)) {
            fields.push(`${key} = $${paramCount}`);
            values.push(key === 'emergency_contact' ? JSON.stringify(value) : value);
            paramCount++;
        }
    });
    if (fields.length === 0)
        return null;
    fields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);
    const result = yield client.query(`UPDATE staff_profiles SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`, values);
    return result.rows[0];
});
exports.updateStaffProfile = updateStaffProfile;
const deleteStaffProfile = (id_1, ...args_1) => __awaiter(void 0, [id_1, ...args_1], void 0, function* (id, client = database_1.default) {
    yield client.query('DELETE FROM staff_profiles WHERE id = $1', [id]);
});
exports.deleteStaffProfile = deleteStaffProfile;
// Staff Schedule Operations
const createStaffSchedule = (schedule) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`INSERT INTO staff_schedules 
    (staff_id, shift_date, shift_start, shift_end, shift_type, status, notes)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING *`, [
        schedule.staff_id,
        schedule.shift_date,
        schedule.shift_start,
        schedule.shift_end,
        schedule.shift_type,
        schedule.status || 'scheduled',
        schedule.notes
    ]);
    return result.rows[0];
});
exports.createStaffSchedule = createStaffSchedule;
const getStaffSchedules = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = `
    SELECT ss.*, sp.employee_id, u.name as staff_name
    FROM staff_schedules ss
    JOIN staff_profiles sp ON ss.staff_id = sp.id
    JOIN users u ON sp.user_id = u.id
    WHERE 1=1
  `;
    const params = [];
    if (filters.staff_id) {
        params.push(filters.staff_id);
        query += ` AND ss.staff_id = $${params.length}`;
    }
    if (filters.date) {
        params.push(filters.date);
        query += ` AND ss.shift_date = $${params.length}`;
    }
    if (filters.status) {
        params.push(filters.status);
        query += ` AND ss.status = $${params.length}`;
    }
    query += ' ORDER BY ss.shift_date DESC, ss.shift_start ASC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getStaffSchedules = getStaffSchedules;
const updateStaffSchedule = (id, updates) => __awaiter(void 0, void 0, void 0, function* () {
    const fields = [];
    const values = [];
    let paramCount = 1;
    Object.entries(updates).forEach(([key, value]) => {
        if (key !== 'id' && value !== undefined) {
            fields.push(`${key} = $${paramCount}`);
            values.push(value);
            paramCount++;
        }
    });
    if (fields.length === 0)
        return null;
    fields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);
    const result = yield database_1.default.query(`UPDATE staff_schedules SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`, values);
    return result.rows[0];
});
exports.updateStaffSchedule = updateStaffSchedule;
// Staff Credentials Operations
const createStaffCredential = (credential) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`INSERT INTO staff_credentials 
    (staff_id, credential_type, credential_name, issuing_authority, issue_date, 
     expiry_date, credential_number, status)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING *`, [
        credential.staff_id,
        credential.credential_type,
        credential.credential_name,
        credential.issuing_authority,
        credential.issue_date,
        credential.expiry_date,
        credential.credential_number,
        credential.status || 'active'
    ]);
    return result.rows[0];
});
exports.createStaffCredential = createStaffCredential;
const getStaffCredentials = (staffId) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`SELECT * FROM staff_credentials WHERE staff_id = $1 ORDER BY expiry_date ASC`, [staffId]);
    return result.rows;
});
exports.getStaffCredentials = getStaffCredentials;
// Staff Attendance Operations
const recordStaffAttendance = (attendance) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`INSERT INTO staff_attendance 
    (staff_id, attendance_date, clock_in, clock_out, status, leave_type, notes)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING *`, [
        attendance.staff_id,
        attendance.attendance_date,
        attendance.clock_in,
        attendance.clock_out,
        attendance.status,
        attendance.leave_type,
        attendance.notes
    ]);
    return result.rows[0];
});
exports.recordStaffAttendance = recordStaffAttendance;
const getStaffAttendance = (...args_1) => __awaiter(void 0, [...args_1], void 0, function* (filters = {}) {
    let query = `SELECT * FROM staff_attendance WHERE 1=1`;
    const params = [];
    if (filters.staff_id) {
        params.push(filters.staff_id);
        query += ` AND staff_id = $${params.length}`;
    }
    if (filters.date) {
        params.push(filters.date);
        query += ` AND attendance_date = $${params.length}`;
    }
    query += ' ORDER BY attendance_date DESC';
    const result = yield database_1.default.query(query, params);
    return result.rows;
});
exports.getStaffAttendance = getStaffAttendance;
// Staff Performance Operations
const createPerformanceReview = (review) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`INSERT INTO staff_performance 
    (staff_id, review_date, reviewer_id, performance_score, strengths, 
     areas_for_improvement, goals, comments)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING *`, [
        review.staff_id,
        review.review_date,
        review.reviewer_id,
        review.performance_score,
        review.strengths,
        review.areas_for_improvement,
        review.goals,
        review.comments
    ]);
    return result.rows[0];
});
exports.createPerformanceReview = createPerformanceReview;
const getStaffPerformanceReviews = (staffId) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`SELECT sp.*, u.name as reviewer_name
    FROM staff_performance sp
    LEFT JOIN users u ON sp.reviewer_id = u.id
    WHERE sp.staff_id = $1
    ORDER BY sp.review_date DESC`, [staffId]);
    return result.rows;
});
exports.getStaffPerformanceReviews = getStaffPerformanceReviews;
// Staff Payroll Operations
const createPayrollRecord = (payroll) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`INSERT INTO staff_payroll 
    (staff_id, pay_period_start, pay_period_end, base_salary, overtime_hours, 
     overtime_pay, bonuses, deductions, net_pay, payment_date, payment_status)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    RETURNING *`, [
        payroll.staff_id,
        payroll.pay_period_start,
        payroll.pay_period_end,
        payroll.base_salary,
        payroll.overtime_hours,
        payroll.overtime_pay,
        payroll.bonuses,
        payroll.deductions,
        payroll.net_pay,
        payroll.payment_date,
        payroll.payment_status || 'pending'
    ]);
    return result.rows[0];
});
exports.createPayrollRecord = createPayrollRecord;
const getStaffPayroll = (staffId) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield database_1.default.query(`SELECT * FROM staff_payroll 
    WHERE staff_id = $1 
    ORDER BY pay_period_start DESC`, [staffId]);
    return result.rows;
});
exports.getStaffPayroll = getStaffPayroll;
